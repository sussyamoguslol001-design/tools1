#!/usr/bin/env python3
"""Authenticated Android proxy relays and persistent per-device rotation."""

from __future__ import annotations

import base64
import concurrent.futures
import hashlib
import ipaddress
import json
import os
import random
import re
import select
import socket
import socketserver
import ssl
import subprocess
import threading
import time
from collections import deque
from urllib.parse import urlparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


MAX_HEADER_BYTES = 65536
MAX_RELAY_TARGET_ACTIVITY = 1024
TRIMMED_RELAY_TARGET_ACTIVITY = 768


def _config_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off", ""}:
        return False
    raise ValueError(f"invalid boolean value: {value!r}")


@dataclass(frozen=True, repr=False)
class ProxyEndpoint:
    host: str
    port: int
    username: str
    password: str

    @property
    def identity(self) -> str:
        canonical = f"{self.username}:{self.password}@{self.host.lower()}:{self.port}"
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def __repr__(self) -> str:
        return f"ProxyEndpoint({self.redacted}, credentials=***)"

    @property
    def redacted(self) -> str:
        return f"{self.host}:{self.port}"

    @property
    def basic_authorization(self) -> str:
        token = base64.b64encode(
            f"{self.username}:{self.password}".encode("utf-8")
        ).decode("ascii")
        return f"Basic {token}"


class ProxySetupError(OSError):
    def __init__(
        self, stage: str, message: str, details: dict[str, Any] | None = None
    ) -> None:
        super().__init__(message)
        self.stage = stage
        self.details = dict(details or {})


def parse_proxy_line(raw_line: str, line_number: int = 0) -> ProxyEndpoint | None:
    line = raw_line.strip()
    if not line or line.startswith("#"):
        return None

    location = f" on line {line_number}" if line_number else ""
    if "@" in line:
        credentials, address = line.rsplit("@", 1)
        if ":" not in credentials or ":" not in address:
            raise ValueError(f"invalid USERNAME:PASSWORD@IP:PORT proxy{location}")
        username, password = credentials.split(":", 1)
        host, raw_port = address.rsplit(":", 1)
    else:
        parts = line.split(":", 3)
        if len(parts) != 4:
            raise ValueError(f"invalid IP:PORT:USERNAME:PASSWORD proxy{location}")
        host, raw_port, username, password = parts

    host = host.strip()
    username = username.strip()
    password = password.strip()
    if not host or not username or not password:
        raise ValueError(f"proxy fields cannot be empty{location}")
    if any(char.isspace() for char in host):
        raise ValueError(f"proxy host cannot contain whitespace{location}")
    try:
        ipaddress.ip_address(host)
    except ValueError as exc:
        raise ValueError(f"proxy host must be a valid IP address{location}") from exc
    try:
        port = int(raw_port)
    except ValueError as exc:
        raise ValueError(f"proxy port must be numeric{location}") from exc
    if not 1 <= port <= 65535:
        raise ValueError(f"proxy port is outside 1-65535{location}")
    return ProxyEndpoint(host, port, username, password)


def load_proxy_list(path: Path) -> list[ProxyEndpoint]:
    if not path.exists():
        raise ValueError(f"proxy list does not exist: {path}")
    endpoints: list[ProxyEndpoint] = []
    seen: set[str] = set()
    for line_number, raw in enumerate(
        path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1
    ):
        endpoint = parse_proxy_line(raw, line_number)
        if endpoint is None or endpoint.identity in seen:
            continue
        seen.add(endpoint.identity)
        endpoints.append(endpoint)
    if len(endpoints) < 2:
        raise ValueError(
            "proxy rotation requires at least two unique valid proxies so a device "
            "never reuses the same proxy on consecutive runs"
        )
    return endpoints


def _receive_header(sock: socket.socket) -> tuple[bytes, bytes]:
    data = bytearray()
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(8192)
        if not chunk:
            break
        data.extend(chunk)
        if len(data) > MAX_HEADER_BYTES:
            raise OSError("proxy header exceeded safety limit")
    marker = data.find(b"\r\n\r\n")
    if marker < 0:
        return bytes(data), b""
    marker += 4
    return bytes(data[:marker]), bytes(data[marker:])


def _inject_proxy_authorization(header: bytes, authorization: str) -> bytes:
    text = header.decode("iso-8859-1", errors="replace").rstrip("\r\n")
    lines = text.split("\r\n")
    filtered = [
        line
        for line in lines
        if not line.lower().startswith("proxy-authorization:")
        and not line.lower().startswith("proxy-connection:")
    ]
    filtered.append(f"Proxy-Authorization: {authorization}")
    filtered.append("Proxy-Connection: Keep-Alive")
    return ("\r\n".join(filtered) + "\r\n\r\n").encode("iso-8859-1")


def _pipe_sockets(
    left: socket.socket,
    right: socket.socket,
    on_transfer: Callable[[int, int], None] | None = None,
) -> tuple[int, int]:
    sockets = [left, right]
    left_to_right = 0
    right_to_left = 0
    while True:
        readable, _, exceptional = select.select(sockets, [], sockets, 30.0)
        if exceptional or not readable:
            return left_to_right, right_to_left
        for source in readable:
            target = right if source is left else left
            data = source.recv(65536)
            if not data:
                return left_to_right, right_to_left
            target.sendall(data)
            if source is left:
                left_to_right += len(data)
                if on_transfer is not None:
                    on_transfer(len(data), 0)
            else:
                right_to_left += len(data)
                if on_transfer is not None:
                    on_transfer(0, len(data))


class _RelayServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, relay: "AuthenticatedProxyRelay") -> None:
        self.relay = relay
        super().__init__(("127.0.0.1", 0), _RelayHandler)


class _RelayHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        relay: AuthenticatedProxyRelay = self.server.relay  # type: ignore[attr-defined]
        endpoint = relay.endpoint
        if endpoint is None:
            return
        client: socket.socket = self.request
        relay.register_connection(client)
        client.settimeout(relay.socket_timeout)
        target_name = "unknown"
        try:
            header, remainder = _receive_header(client)
            if not header:
                return
            first_line = header.split(b"\r\n", 1)[0].decode(
                "iso-8859-1", errors="replace"
            )
            parts = first_line.split()
            target_name = parts[1] if len(parts) >= 2 else "unknown"
            upstream = socket.create_connection(
                (endpoint.host, endpoint.port), relay.socket_timeout
            )
            relay.register_connection(upstream)
            upstream.settimeout(relay.socket_timeout)
            try:
                forwarded = _inject_proxy_authorization(
                    header, endpoint.basic_authorization
                )
                upstream.sendall(forwarded)
                if remainder:
                    upstream.sendall(remainder)
                if first_line.upper().startswith("CONNECT "):
                    response_header, response_remainder = _receive_header(upstream)
                    if not response_header:
                        relay.mark_failed_connection(target_name)
                        return
                    status_line = response_header.split(b"\r\n", 1)[0]
                    if re.match(br"HTTP/\d(?:\.\d)?\s+2\d\d\b", status_line):
                        # Publish the verified state before the response becomes
                        # visible to the client.  Otherwise a fast client can
                        # receive the 2xx and observe the old metrics for a brief
                        # window even though the upstream CONNECT already
                        # succeeded.
                        relay.mark_verified_connection(target_name)
                        client.sendall(response_header)
                        if response_remainder:
                            client.sendall(response_remainder)
                        _pipe_sockets(
                            client,
                            upstream,
                            lambda sent, received: relay.add_transferred_bytes(
                                sent, received, target_name
                            ),
                        )
                    else:
                        relay.mark_failed_connection(target_name)
                        client.sendall(response_header)
                        if response_remainder:
                            client.sendall(response_remainder)
                    return
                relay.mark_verified_connection(target_name)
                _pipe_sockets(
                    client,
                    upstream,
                    lambda sent, received: relay.add_transferred_bytes(
                        sent, received, target_name
                    ),
                )
            finally:
                relay.unregister_connection(upstream)
                upstream.close()
        except (OSError, ValueError):
            relay.mark_failed_connection(target_name)
            return
        finally:
            relay.unregister_connection(client)


class AuthenticatedProxyRelay:
    def __init__(
        self,
        socket_timeout: float = 15.0,
        verified_target_observer: Callable[[str], None] | None = None,
    ) -> None:
        self.socket_timeout = max(1.0, float(socket_timeout))
        self._verified_target_observer = verified_target_observer
        self._endpoint: ProxyEndpoint | None = None
        self._endpoint_lock = threading.Lock()
        self._verified_connections = 0
        self._failed_connections = 0
        self._verified_targets: dict[str, int] = {}
        self._failed_targets: dict[str, int] = {}
        self._bytes_sent = 0
        self._bytes_received = 0
        self._last_success_epoch = 0.0
        self._last_target = ""
        self._target_events: list[tuple[float, str]] = []
        self._target_activity: dict[str, dict[str, float | int]] = {}
        self._assignment_generation = 0
        self._metrics_lock = threading.Lock()
        self._connections: set[socket.socket] = set()
        self._connections_lock = threading.Lock()
        self._server = _RelayServer(self)
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name=f"proxy-relay-{self._server.server_address[1]}",
            daemon=True,
        )
        self._thread.start()

    @property
    def port(self) -> int:
        return int(self._server.server_address[1])

    @property
    def endpoint(self) -> ProxyEndpoint | None:
        with self._endpoint_lock:
            return self._endpoint

    def set_endpoint(self, endpoint: ProxyEndpoint) -> None:
        changed = False
        with self._endpoint_lock:
            changed = self._endpoint is not None and self._endpoint != endpoint
            self._endpoint = endpoint
        if changed:
            self.close_active_connections()
        with self._metrics_lock:
            self._assignment_generation += 1

    def register_connection(self, connection: socket.socket) -> None:
        with self._connections_lock:
            self._connections.add(connection)

    def unregister_connection(self, connection: socket.socket) -> None:
        with self._connections_lock:
            self._connections.discard(connection)

    def close_active_connections(self) -> None:
        with self._connections_lock:
            connections = list(self._connections)
            self._connections.clear()
        for connection in connections:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                connection.close()
            except OSError:
                pass

    def mark_verified_connection(self, target: str = "") -> None:
        with self._metrics_lock:
            now = time.time()
            self._verified_connections += 1
            if target:
                self._verified_targets[target] = self._verified_targets.get(target, 0) + 1
            self._last_success_epoch = now
            self._last_target = target
            self._target_events.append((now, target))
            if len(self._target_events) > 4096:
                del self._target_events[:-2048]
        if target and self._verified_target_observer is not None:
            try:
                self._verified_target_observer(target)
            except Exception:
                # Proof telemetry must never break the relay data path.
                pass

    def mark_failed_connection(self, target: str = "") -> None:
        with self._metrics_lock:
            self._failed_connections += 1
            if target:
                self._failed_targets[target] = self._failed_targets.get(target, 0) + 1

    def add_transferred_bytes(
        self, sent: int, received: int, target: str = ""
    ) -> None:
        with self._metrics_lock:
            now = time.time()
            sent_count = max(0, int(sent))
            received_count = max(0, int(received))
            self._bytes_sent += sent_count
            self._bytes_received += received_count
            if target and (sent_count or received_count):
                activity = self._target_activity.setdefault(
                    target,
                    {"last_epoch": 0.0, "bytes_sent": 0, "bytes_received": 0},
                )
                activity["last_epoch"] = now
                activity["bytes_sent"] = int(activity["bytes_sent"]) + sent_count
                activity["bytes_received"] = (
                    int(activity["bytes_received"]) + received_count
                )
                self._last_success_epoch = now
                self._last_target = target
                if len(self._target_activity) > MAX_RELAY_TARGET_ACTIVITY:
                    oldest = sorted(
                        self._target_activity,
                        key=lambda name: float(
                            self._target_activity[name].get("last_epoch", 0) or 0
                        ),
                    )[
                        : len(self._target_activity)
                        - TRIMMED_RELAY_TARGET_ACTIVITY
                    ]
                    for old_target in oldest:
                        self._target_activity.pop(old_target, None)

    def verified_connections(self) -> int:
        with self._metrics_lock:
            return self._verified_connections

    def verified_target_connections(self, target: str) -> int:
        with self._metrics_lock:
            return int(self._verified_targets.get(target, 0))

    def failed_target_connections(self, target: str) -> int:
        with self._metrics_lock:
            return int(self._failed_targets.get(target, 0))

    def snapshot(self) -> dict[str, Any]:
        with self._metrics_lock:
            return {
                "generation": self._assignment_generation,
                "verified_connections": self._verified_connections,
                "failed_connections": self._failed_connections,
                "bytes_sent": self._bytes_sent,
                "bytes_received": self._bytes_received,
                "last_success_epoch": self._last_success_epoch,
                "last_target": self._last_target,
                "active_target_count": len(self._target_activity),
            }

    def is_alive(self) -> bool:
        return self._thread.is_alive()

    def has_target_since(self, suffixes: tuple[str, ...], since_epoch: float) -> bool:
        return bool(self.matching_targets_since(suffixes, since_epoch))

    def matching_targets_since(
        self, suffixes: tuple[str, ...], since_epoch: float
    ) -> list[str]:
        with self._metrics_lock:
            events = list(self._target_events)
            activity = {
                target: dict(values)
                for target, values in self._target_activity.items()
            }
        matches: list[str] = []
        seen: set[str] = set()
        for event_epoch, raw_target in events:
            target = str(raw_target).split(":", 1)[0].lower().rstrip(".")
            if event_epoch < since_epoch or not any(
                target == suffix or target.endswith("." + suffix)
                for suffix in suffixes
            ):
                continue
            if raw_target not in seen:
                seen.add(raw_target)
                matches.append(raw_target)
        for raw_target, values in activity.items():
            target = str(raw_target).split(":", 1)[0].lower().rstrip(".")
            if float(values.get("last_epoch", 0) or 0) < since_epoch or not any(
                target == suffix or target.endswith("." + suffix)
                for suffix in suffixes
            ):
                continue
            if raw_target not in seen:
                seen.add(raw_target)
                matches.append(raw_target)
        return matches

    def close(self) -> None:
        self.close_active_connections()
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=2.0)


class ProxyRotationState:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.next_slot = 0
        self.devices: dict[str, dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict) or payload.get("version") != 1:
            return
        try:
            self.next_slot = max(0, int(payload.get("next_slot", 0)))
        except (TypeError, ValueError):
            self.next_slot = 0
        raw_devices = payload.get("devices", {})
        if not isinstance(raw_devices, dict):
            return
        for serial, raw in raw_devices.items():
            if not isinstance(raw, dict):
                continue
            try:
                slot = max(0, int(raw.get("slot", 0)))
            except (TypeError, ValueError):
                continue
            self.devices[str(serial)] = {
                "slot": slot,
                "last_proxy_id": str(raw.get("last_proxy_id", "")),
                "last_proxy_host": str(raw.get("last_proxy_host", "")),
            }
            self.next_slot = max(self.next_slot, slot + 1)

    def _device(self, serial: str) -> dict[str, Any]:
        if serial not in self.devices:
            slot = self.next_slot
            self.next_slot += 1
            self.devices[serial] = {
                "slot": slot,
                "last_proxy_id": "",
                "last_proxy_host": "",
            }
        return self.devices[serial]

    def candidate_order(
        self, serial: str, endpoints: list[ProxyEndpoint]
    ) -> list[ProxyEndpoint]:
        """Return randomized candidates, excluding only the last proxy first."""
        device = self._device(serial)
        last_id = str(device.get("last_proxy_id", ""))
        last_host = str(device.get("last_proxy_host", "")).casefold()
        if not last_host and last_id:
            last_host = next(
                (
                    endpoint.host.casefold()
                    for endpoint in endpoints
                    if endpoint.identity == last_id
                ),
                "",
            )
        candidates = [
            endpoint for endpoint in endpoints if endpoint.host.casefold() != last_host
        ]
        if not candidates:
            candidates = list(endpoints)
        random.SystemRandom().shuffle(candidates)
        return candidates

    def plan_assignments(
        self,
        serials: Iterable[str],
        endpoints: list[ProxyEndpoint],
    ) -> dict[str, ProxyEndpoint]:
        """Random, automatically balanced assignment with no immediate repeat."""
        serial_list = list(dict.fromkeys(str(serial) for serial in serials))
        if not serial_list:
            return {}
        if len(endpoints) < 2:
            raise ValueError("at least two healthy proxies are required")
        rng = random.SystemRandom()

        # First try an exact balanced quota match. Every proxy receives either
        # floor(devices/proxies) or ceil(devices/proxies) assignments; when
        # proxies outnumber devices, a random subset receives one assignment.
        base_load, extra_count = divmod(len(serial_list), len(endpoints))
        samples = max(8, min(64, len(endpoints) * 2))
        for _sample in range(samples):
            proxy_order = list(range(len(endpoints)))
            rng.shuffle(proxy_order)
            extra_indexes = set(proxy_order[:extra_count])
            slot_proxy_indexes = [
                proxy_index
                for proxy_index in range(len(endpoints))
                for _ in range(
                    base_load + (1 if proxy_index in extra_indexes else 0)
                )
            ]
            adjacency: list[list[int]] = []
            for serial in serial_list:
                device = self._device(serial)
                last_id = str(device.get("last_proxy_id", ""))
                last_host = str(device.get("last_proxy_host", "")).casefold()
                if not last_host and last_id:
                    last_host = next(
                        (
                            endpoint.host.casefold()
                            for endpoint in endpoints
                            if endpoint.identity == last_id
                        ),
                        "",
                    )
                allowed = [
                    slot_index
                    for slot_index, proxy_index in enumerate(slot_proxy_indexes)
                    if endpoints[proxy_index].host.casefold() != last_host
                ]
                rng.shuffle(allowed)
                adjacency.append(allowed)

            slot_owner = [-1] * len(slot_proxy_indexes)

            def match(device_index: int, seen_slots: set[int]) -> bool:
                for slot_index in adjacency[device_index]:
                    if slot_index in seen_slots:
                        continue
                    seen_slots.add(slot_index)
                    previous_owner = slot_owner[slot_index]
                    if previous_owner < 0 or match(previous_owner, seen_slots):
                        slot_owner[slot_index] = device_index
                        return True
                return False

            if all(
                match(device_index, set())
                for device_index in range(len(serial_list))
            ):
                device_slots = {
                    owner: slot_index
                    for slot_index, owner in enumerate(slot_owner)
                    if owner >= 0
                }
                return {
                    serial: endpoints[
                        slot_proxy_indexes[device_slots[device_index]]
                    ]
                    for device_index, serial in enumerate(serial_list)
                }

        # A highly irregular legacy rotation state can make exact quotas
        # incompatible with the no-repeat rule. Fall back to least-used random
        # selection so every device still receives a different proxy.
        # Randomize device order and choose among the currently least-used
        # eligible proxies. This distributes any device/proxy ratio
        # automatically: 80/10 -> 8 each; 50/70 -> 50 randomly selected
        # proxies with one device each. A device's immediately previous proxy
        # is excluded, but becomes eligible after one different assignment.
        shuffled_serials = list(serial_list)
        rng.shuffle(shuffled_serials)
        loads = {endpoint.identity: 0 for endpoint in endpoints}
        assignments: dict[str, ProxyEndpoint] = {}
        for serial in shuffled_serials:
            device = self._device(serial)
            last_id = str(device.get("last_proxy_id", ""))
            last_host = str(device.get("last_proxy_host", "")).casefold()
            if not last_host and last_id:
                last_host = next(
                    (
                        endpoint.host.casefold()
                        for endpoint in endpoints
                        if endpoint.identity == last_id
                    ),
                    "",
                )
            eligible = [
                endpoint
                for endpoint in endpoints
                if endpoint.host.casefold() != last_host
            ]
            if not eligible:
                # Defensive only: startup already requires at least two proxies.
                eligible = list(endpoints)
            minimum_load = min(loads[endpoint.identity] for endpoint in eligible)
            least_used = [
                endpoint
                for endpoint in eligible
                if loads[endpoint.identity] == minimum_load
            ]
            selected = rng.choice(least_used)
            assignments[serial] = selected
            loads[selected.identity] += 1
        return assignments

    def commit(self, assignments: dict[str, ProxyEndpoint], endpoints: list[ProxyEndpoint]) -> None:
        for serial, endpoint in assignments.items():
            device = self._device(serial)
            device["last_proxy_id"] = endpoint.identity
            device["last_proxy_host"] = endpoint.host
        self.save()

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "source": "per_device_no_immediate_repeat",
            "next_slot": self.next_slot,
            "devices": self.devices,
        }
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        temp.replace(self.path)


class ProxyManager:
    def __init__(
        self,
        config: dict[str, Any],
        base_dir: Path,
        log: Callable[[str], None] = print,
        adb_runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
        stop_event: threading.Event | None = None,
    ) -> None:
        try:
            self.enabled = _config_bool(config.get("proxy_enabled", False))
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        self.log = log
        self.base_dir = base_dir
        self.config = config
        self.compact_logging = _config_bool(
            config.get("compact_console_logging", False), False
        )
        self._stop_event = stop_event or threading.Event()
        self.adb_executable = str(config.get("adb_executable", "adb"))
        try:
            self.device_port = int(config.get("proxy_device_port", 19090))
            self.timeout = max(
                2.0, float(config.get("proxy_connect_timeout_seconds", 12))
            )
            self.adb_control_timeout = max(
                2.0, float(config.get("proxy_adb_control_timeout_seconds", 8))
            )
            self.confirmation_deadline = max(
                0.1,
                min(
                    2.0,
                    self.timeout,
                    float(config.get("proxy_confirmation_deadline_seconds", 2)),
                ),
            )
            self.assignment_max_attempts = max(
                1, int(config.get("proxy_assignment_max_attempts", 3))
            )
            self.parallel_setup = max(1, int(config.get("proxy_parallel_setup", 100)))
            self.setup_stagger_seconds = max(
                0.0, min(1.0, float(config.get("proxy_setup_stagger_seconds", 0.05)))
            )
            self.shutdown_parallel = max(
                1, int(config.get("proxy_shutdown_parallel", 40))
            )
            self.shutdown_timeout = max(
                1.0,
                float(
                    config.get(
                        "proxy_shutdown_command_timeout_seconds",
                        min(3.0, self.timeout),
                    )
                ),
            )
            self.event_buffer_limit = max(
                100, int(config.get("proxy_cycle_event_buffer_limit", 10000))
            )
            self.persistent_log_max_bytes = max(
                1024 * 1024,
                int(float(config.get("proxy_persistent_log_max_mb", 50)) * 1024 * 1024),
            )
            self.persistent_log_backups = max(
                1, int(config.get("proxy_persistent_log_backups", 5))
            )
            self.inactive_relay_retention_seconds = max(
                0.0,
                float(config.get("proxy_inactive_relay_retention_seconds", 3600)),
            )
        except (TypeError, ValueError) as exc:
            raise SystemExit(
                "proxy device port, timeout, setup parallelism, and shutdown "
                "parallelism, telemetry limits, and relay retention must be numeric"
            ) from exc
        if not 1 <= self.device_port <= 65535:
            raise SystemExit("proxy_device_port must be between 1 and 65535")
        self.probe_target = str(
            config.get("proxy_probe_target", "www.tiktok.com:443")
        ).strip()
        if not re.fullmatch(r"[A-Za-z0-9.-]+:\d{1,5}", self.probe_target):
            raise SystemExit("proxy_probe_target must use HOST:PORT format")
        probe_port = int(self.probe_target.rsplit(":", 1)[1])
        if not 1 <= probe_port <= 65535:
            raise SystemExit("proxy_probe_target port must be between 1 and 65535")
        self._adb_runner = adb_runner or subprocess.run
        self._lock = threading.Lock()
        self._selection_lock = threading.RLock()
        self._lease_condition = threading.Condition(self._selection_lock)
        self._resource_lock = threading.Lock()
        self._device_release_locks: dict[str, threading.Lock] = {}
        self._relays: dict[str, AuthenticatedProxyRelay] = {}
        self._relay_last_used: dict[str, float] = {}
        self._original_proxy: dict[str, str] = {}
        self._configured_relays: dict[str, int] = {}
        self._workflow_baselines: dict[str, float] = {}
        self._workflow_failed_connection_baselines: dict[str, int] = {}
        self._assignment_contexts: dict[str, str] = {}
        self._probe_diagnostics: dict[str, dict[str, Any]] = {}
        self._last_assignments: dict[str, str] = {}
        # Per-device preparation failure scope. Device/ADB control failures must
        # never poison an otherwise healthy external proxy for the whole round.
        self._prepare_failure_scopes: dict[str, str] = {}
        self._health_lock = threading.Lock()
        self._error_lock = threading.Lock()
        self._usage_lock = threading.Lock()
        self._assignment_lock = threading.Lock()
        self._proof_lock = threading.Lock()
        self._tiktok_proof_arms: dict[str, tuple[Path, float]] = {}
        self._persistent_log_lock = threading.Lock()
        self._last_persistent_log_warning_epoch = 0.0
        self._error_events: deque[tuple[int, dict[str, Any]]] = deque()
        self._usage_events: deque[tuple[int, dict[str, Any]]] = deque()
        self._assignment_events: deque[tuple[int, dict[str, Any]]] = deque()
        self._error_event_sequence = 0
        self._usage_event_sequence = 0
        self._assignment_event_sequence = 0
        self._dropped_error_events = 0
        self._dropped_usage_events = 0
        self._dropped_assignment_events = 0
        self.health: dict[str, dict[str, Any]] = {}
        # Eligibility is round-scoped and comes only from the configured list.
        # Persisted health data is diagnostic; it never removes a proxy from a
        # future watchlist round.
        self._round_failed_proxy_ids: set[str] = set()
        self._round_assignment_counts: dict[str, int] = {}
        # A proxy host may belong to only one device from successful selection
        # until that device's proxy/ADB cleanup finishes.  Host-level ownership
        # also protects lists that accidentally contain the same IP more than
        # once with different ports or credentials.
        self._active_proxy_leases: dict[str, str] = {}
        self._device_proxy_leases: dict[str, ProxyEndpoint] = {}
        self.max_active_leases = max(1, int(config.get("max_parallel", 16)))
        self._current_round = 0
        self._closed = False
        self.proxy_path: Path | None = None

        self.health_state_path = self._resolve_path(
            "proxy_health_state_file", "state/proxy_health.json"
        )
        self.error_log_path = self._resolve_path(
            "proxy_error_log_file", "state/proxy_errors.jsonl"
        )
        self.usage_log_path = self._resolve_path(
            "proxy_usage_log_file", "state/proxy_usage.jsonl"
        )
        self.assignment_log_path = self._resolve_path(
            "proxy_assignment_log_file", "state/proxy_assignments.jsonl"
        )
        self.health_cache_seconds = max(
            0.0, float(config.get("proxy_health_cache_seconds", 300))
        )
        self.health_parallel = max(
            1, int(config.get("proxy_health_check_parallel", 20))
        )
        self.minimum_healthy = max(
            2, int(config.get("proxy_minimum_healthy", 2))
        )
        self.exit_ip_urls = tuple(
            str(value).strip()
            for value in config.get("proxy_exit_ip_check_urls", [])
            if str(value).strip()
        )
        self.startup_health_check = _config_bool(
            config.get("proxy_startup_health_check", False)
        )
        self.verify_device_path = _config_bool(
            config.get("proxy_verify_device_path", True), True
        )
        self.verify_tiktok_traffic = _config_bool(
            config.get("proxy_verify_tiktok_traffic", False)
        )
        self.tiktok_domain_suffixes = tuple(
            str(value).strip().lower().lstrip(".")
            for value in config.get("proxy_tiktok_domain_suffixes", ["tiktok.com"])
            if str(value).strip()
        )
        self._load_health_state()

        # Recover devices left on this program's loopback proxy by a previous
        # hard crash/forced termination.  The relay behind 127.0.0.1 only
        # exists while this program is alive, so keeping that setting after a
        # restart leaves the device without internet.  Only our exact managed
        # setting is cleared; unrelated/user-configured proxies are untouched.
        self._recover_stale_managed_proxy_state(context="startup")

        if not self.enabled:
            self.endpoints = []
            self.rotation = ProxyRotationState(
                self._resolve_path("proxy_rotation_state_file", "state/proxy_rotation.json")
            )
            return
        try:
            fail_closed = _config_bool(config.get("proxy_fail_closed", True), True)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        if not fail_closed:
            raise SystemExit(
                "proxy_fail_closed must remain true; direct fallback is not allowed"
            )
        proxy_path = self._resolve_path("proxy_list_file", "proxy_list.txt")
        self.proxy_path = proxy_path
        try:
            self.endpoints = load_proxy_list(proxy_path)
        except ValueError as exc:
            self._record_proxy_error(
                context="startup",
                stage="proxy_list",
                message=str(exc),
                details={"proxy_list_file": str(proxy_path)},
            )
            raise SystemExit(f"Proxy configuration error: {exc}") from exc
        self.rotation = ProxyRotationState(
            self._resolve_path("proxy_rotation_state_file", "state/proxy_rotation.json")
        )
        now = time.time()
        if self.startup_health_check:
            self.refresh_health(force=False)
            healthy_count = len(self.healthy_endpoints())
            if healthy_count < self.minimum_healthy:
                self._record_proxy_error(
                    context="startup",
                    stage="minimum_healthy",
                    message=(
                        f"Proxy health check left {healthy_count} healthy proxy(s); "
                        f"at least {self.minimum_healthy} are required"
                    ),
                    details={
                        "configured_proxy_count": len(self.endpoints),
                        "healthy_proxy_count": healthy_count,
                        "minimum_healthy": self.minimum_healthy,
                    },
                )
                raise SystemExit(
                    f"Proxy health check left {healthy_count} healthy proxy(s); "
                    f"at least {self.minimum_healthy} are required"
                )
        else:
            for endpoint in self.endpoints:
                self.health.setdefault(
                    endpoint.identity,
                    self._health_record(endpoint, "available", now),
                )
            self._save_health_state()

    def _connected_adb_devices(self) -> list[str]:
        """Return currently connected/authorized ADB device serials."""
        try:
            result = self._adb_runner(
                [self.adb_executable, "devices"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(5.0, self.adb_control_timeout),
            )
        except (OSError, subprocess.SubprocessError) as exc:
            self.log(
                f"[PROXY RECOVERY] Could not list ADB devices: "
                f"{type(exc).__name__}: {exc}"
            )
            return []
        if result.returncode != 0:
            self.log(
                "[PROXY RECOVERY] Could not list ADB devices; "
                f"adb returned {result.returncode}."
            )
            return []

        serials: list[str] = []
        for raw_line in str(result.stdout or "").splitlines():
            parts = raw_line.strip().split()
            if len(parts) >= 2 and parts[1] == "device":
                serials.append(parts[0])
        return list(dict.fromkeys(serials))

    def _recover_stale_managed_proxy_state(self, *, context: str) -> dict[str, int]:
        """Restore direct internet for devices stranded on our loopback proxy.

        A hard process kill or PC restart can prevent normal ``close()`` cleanup.
        On the next start (and again during shutdown) inspect every connected ADB
        device.  If and only if its Android global proxy is this program's exact
        ``127.0.0.1:<proxy_device_port>`` value, clear it and remove the matching
        ADB reverse mapping.  Other proxy settings are deliberately preserved.
        """
        serials = self._connected_adb_devices()
        if not serials:
            return {"checked": 0, "cleared": 0, "failed": 0}

        managed_setting = f"127.0.0.1:{self.device_port}"
        device_socket = f"tcp:{self.device_port}"
        cleared = 0
        failed = 0
        counter_lock = threading.Lock()

        def recover_one(serial: str) -> None:
            nonlocal cleared, failed
            try:
                current = self._adb(
                    serial,
                    "shell",
                    "settings",
                    "get",
                    "global",
                    "http_proxy",
                    timeout=self.shutdown_timeout,
                )
                if current.returncode != 0:
                    with counter_lock:
                        failed += 1
                    return
                if current.stdout.strip() != managed_setting:
                    return

                applied = self._adb(
                    serial,
                    "shell",
                    "settings",
                    "put",
                    "global",
                    "http_proxy",
                    ":0",
                    timeout=self.shutdown_timeout,
                )
                # The reverse mapping is owned by this proxy manager.  Failure
                # to remove a missing/stale mapping is non-fatal as long as the
                # Android proxy itself is verified clear.
                try:
                    self._adb(
                        serial,
                        "reverse",
                        "--remove",
                        device_socket,
                        timeout=self.shutdown_timeout,
                    )
                except (OSError, subprocess.SubprocessError):
                    pass
                checked = self._adb(
                    serial,
                    "shell",
                    "settings",
                    "get",
                    "global",
                    "http_proxy",
                    timeout=self.shutdown_timeout,
                )
                if (
                    applied.returncode == 0
                    and checked.returncode == 0
                    and self._proxy_setting_is_clear(checked.stdout)
                ):
                    with self._resource_lock:
                        self._configured_relays.pop(serial, None)
                    with counter_lock:
                        cleared += 1
                    return
                with counter_lock:
                    failed += 1
            except (OSError, subprocess.SubprocessError):
                with counter_lock:
                    failed += 1

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(self.shutdown_parallel, len(serials)),
            thread_name_prefix="proxy-recovery",
        ) as executor:
            futures = [executor.submit(recover_one, serial) for serial in serials]
            concurrent.futures.wait(futures)

        if cleared or failed:
            self.log(
                f"[PROXY RECOVERY] context={context} | checked={len(serials)} | "
                f"cleared_stale={cleared} | failed={failed}"
            )
        return {"checked": len(serials), "cleared": cleared, "failed": failed}

    def request_stop(self) -> None:
        """Prevent new proxy setup work from being queued during shutdown."""
        self._stop_event.set()
        with self._lease_condition:
            self._lease_condition.notify_all()

    def _stopping(self) -> bool:
        return self._stop_event.is_set()

    def _resolve_path(self, key: str, default: str) -> Path:
        path = Path(str(self.config.get(key, default)))
        return path if path.is_absolute() else self.base_dir / path

    @staticmethod
    def _command_diagnostics(
        result: subprocess.CompletedProcess[str] | None,
    ) -> dict[str, Any]:
        if result is None:
            return {}
        return {
            "return_code": int(result.returncode),
            "stdout": str(result.stdout or "")[-2000:],
            "stderr": str(result.stderr or "")[-2000:],
        }

    def _record_proxy_error(
        self,
        *,
        context: str,
        stage: str,
        message: str,
        serial: str = "",
        endpoint: ProxyEndpoint | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Persist a credential-free diagnostic immediately and for cycle logs."""
        event = {
            "timestamp_epoch": time.time(),
            "timestamp_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
            "context": str(context),
            "stage": str(stage),
            "device": str(serial),
            "proxy": endpoint.redacted if endpoint is not None else "",
            "message": str(message)[:1000],
            "details": dict(details or {}),
        }
        with self._error_lock:
            self._error_event_sequence += 1
            if len(self._error_events) >= self.event_buffer_limit:
                self._error_events.popleft()
                self._dropped_error_events += 1
            self._error_events.append((self._error_event_sequence, event))
            self._append_persistent_event(self.error_log_path, event)

    def _record_proxy_usage(
        self,
        *,
        context: str,
        stage: str,
        serial: str,
        endpoint: ProxyEndpoint,
        started_epoch: float,
        relay: AuthenticatedProxyRelay,
    ) -> None:
        targets = relay.matching_targets_since(
            self.tiktok_domain_suffixes, started_epoch
        )
        exit_ip = self._known_exit_ip(endpoint)
        event = {
            "timestamp_epoch": time.time(),
            "timestamp_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
            "context": str(context),
            "stage": str(stage),
            "device": str(serial),
            "device_ip": self._device_ip(serial),
            "proxy": endpoint.redacted,
            "proxy_ip": endpoint.host,
            "proxy_port": endpoint.port,
            "exit_ip": exit_ip,
            "verified": bool(targets),
            "observed_tiktok_targets": targets,
            "started_epoch": float(started_epoch),
            "relay_snapshot": relay.snapshot(),
        }
        with self._usage_lock:
            self._usage_event_sequence += 1
            if len(self._usage_events) >= self.event_buffer_limit:
                self._usage_events.popleft()
                self._dropped_usage_events += 1
            self._usage_events.append((self._usage_event_sequence, event))
            self._append_persistent_event(self.usage_log_path, event)
        self.log(
            f"[PROXY USED] device={serial} | device_ip={self._device_ip(serial)}"
            f" | proxy={endpoint.redacted} | proxy_ip={endpoint.host}"
            f" | exit_ip={exit_ip} | tiktok=VERIFIED | context={context}"
        )

    @staticmethod
    def _device_ip(serial: str) -> str:
        raw = str(serial).strip()
        host = raw.rsplit(":", 1)[0] if ":" in raw else raw
        try:
            return str(ipaddress.ip_address(host))
        except ValueError:
            return host or "unknown"

    def _known_exit_ip(self, endpoint: ProxyEndpoint) -> str:
        with self._health_lock:
            value = str(self.health.get(endpoint.identity, {}).get("exit_ip", "")).strip()
        return value or "not_checked"

    def _record_proxy_assignment(
        self,
        *,
        context: str,
        serial: str,
        endpoint: ProxyEndpoint,
    ) -> None:
        """Persist and print one credential-free successful device assignment."""
        exit_ip = self._known_exit_ip(endpoint)
        event = {
            "timestamp_epoch": time.time(),
            "timestamp_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
            "context": str(context),
            "round": int(self._current_round),
            "status": "assigned",
            "device": str(serial),
            "device_ip": self._device_ip(serial),
            "proxy": endpoint.redacted,
            "proxy_ip": endpoint.host,
            "proxy_port": endpoint.port,
            "exit_ip": exit_ip,
            "exclusive_lease": True,
        }
        with self._assignment_lock:
            self._assignment_event_sequence += 1
            if len(self._assignment_events) >= self.event_buffer_limit:
                self._assignment_events.popleft()
                self._dropped_assignment_events += 1
            self._assignment_events.append((self._assignment_event_sequence, event))
            self._append_persistent_event(self.assignment_log_path, event)
        self.log(
            f"[PROXY ASSIGN] device={serial} | device_ip={event['device_ip']}"
            f" | proxy={endpoint.redacted} | proxy_ip={endpoint.host}"
            f" | exit_ip={exit_ip} | lease=EXCLUSIVE | context={context}"
        )

    def _append_persistent_event(self, path: Path, event: dict[str, Any]) -> None:
        """Append one JSONL record, rotating bounded backups before the write."""
        encoded = json.dumps(event, ensure_ascii=False) + "\n"
        try:
            with self._persistent_log_lock:
                path.parent.mkdir(parents=True, exist_ok=True)
                try:
                    current_size = path.stat().st_size
                except FileNotFoundError:
                    current_size = 0
                if (
                    current_size
                    and current_size + len(encoded.encode("utf-8"))
                    > self.persistent_log_max_bytes
                ):
                    for index in range(self.persistent_log_backups, 0, -1):
                        source = (
                            path
                            if index == 1
                            else path.with_name(f"{path.name}.{index - 1}")
                        )
                        destination = path.with_name(f"{path.name}.{index}")
                        if not source.exists():
                            continue
                        if destination.exists():
                            destination.unlink()
                        source.replace(destination)
                with path.open("a", encoding="utf-8") as handle:
                    handle.write(encoded)
        except OSError as exc:
            now = time.time()
            if now - self._last_persistent_log_warning_epoch >= 60:
                self._last_persistent_log_warning_epoch = now
                self.log(
                    f"[PROXY LOG] Persistent telemetry write failed for {path}: "
                    f"{type(exc).__name__}: {exc}"
                )

    def _health_record(
        self,
        endpoint: ProxyEndpoint,
        status: str,
        checked_epoch: float,
        *,
        exit_ip: str = "",
        latency_ms: int = 0,
        error: str = "",
        consecutive_failures: int = 0,
    ) -> dict[str, Any]:
        return {
            "proxy_id": endpoint.identity,
            "address": endpoint.redacted,
            "status": status,
            "exit_ip": exit_ip,
            "latency_ms": max(0, int(latency_ms)),
            "last_checked_epoch": float(checked_epoch),
            "consecutive_failures": max(0, int(consecutive_failures)),
            "last_error": str(error)[:300],
        }

    def _load_health_state(self) -> None:
        if not self.health_state_path.exists():
            return
        try:
            payload = json.loads(self.health_state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict) or payload.get("version") != 1:
            return
        records = payload.get("proxies", {})
        if isinstance(records, dict):
            self.health = {
                str(key): dict(value)
                for key, value in records.items()
                if isinstance(value, dict)
            }

    def _save_health_state(self) -> None:
        self.health_state_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "source": "redacted_proxy_health",
            "proxies": self.health,
        }
        temp = self.health_state_path.with_suffix(self.health_state_path.suffix + ".tmp")
        temp.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        temp.replace(self.health_state_path)

    def _probe_exit_ip(self, endpoint: ProxyEndpoint, url: str) -> tuple[str, int]:
        relay = AuthenticatedProxyRelay(self.timeout)
        relay.set_endpoint(endpoint)
        started = time.monotonic()
        try:
            parsed = urlparse(url)
            host = parsed.hostname or ""
            port = parsed.port or 443
            path = parsed.path or "/"
            if parsed.query:
                path += "?" + parsed.query
            raw = socket.create_connection(("127.0.0.1", relay.port), self.timeout)
            raw.settimeout(self.timeout)
            try:
                raw.sendall(
                    (
                        f"CONNECT {host}:{port} HTTP/1.1\r\n"
                        f"Host: {host}:{port}\r\nConnection: close\r\n\r\n"
                    ).encode("ascii")
                )
                response_header, _ = _receive_header(raw)
                status = response_header.split(b"\r\n", 1)[0]
                if not re.match(br"HTTP/\d(?:\.\d)?\s+2\d\d\b", status):
                    raise OSError("exit-IP CONNECT was rejected")
                context = ssl.create_default_context()
                with context.wrap_socket(raw, server_hostname=host) as secure:
                    secure.sendall(
                        (
                            f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
                            "User-Agent: local-proxy-health-check\r\n"
                            "Connection: close\r\n\r\n"
                        ).encode("ascii")
                    )
                    response = bytearray()
                    while len(response) < 65536:
                        chunk = secure.recv(8192)
                        if not chunk:
                            break
                        response.extend(chunk)
            finally:
                try:
                    raw.close()
                except OSError:
                    pass
            response_status = bytes(response).split(b"\r\n", 1)[0]
            if not re.match(br"HTTP/\d(?:\.\d)?\s+2\d\d\b", response_status):
                raise OSError("exit-IP endpoint returned non-success status")
            body = bytes(response).partition(b"\r\n\r\n")[2].decode(
                "utf-8", errors="replace"
            )
            for token in re.split(r"[\s,;<>]+", body):
                candidate = token.strip("[]()'\"")
                try:
                    ipaddress.ip_address(candidate)
                    return candidate, int((time.monotonic() - started) * 1000)
                except ValueError:
                    continue
            raise ValueError("exit-IP endpoint returned no valid IP")
        finally:
            relay.close()

    def _check_endpoint_health(
        self, endpoint: ProxyEndpoint
    ) -> tuple[ProxyEndpoint, bool, str, int, str]:
        last_error = "no exit-IP check URL configured"
        url = self.exit_ip_urls[0] if self.exit_ip_urls else ""
        if url:
            try:
                exit_ip, latency = self._probe_exit_ip(endpoint, url)
                return endpoint, True, exit_ip, latency, ""
            except (OSError, ValueError, ssl.SSLError) as exc:
                last_error = type(exc).__name__ + ": " + str(exc)
                self._record_proxy_error(
                    context="health_check",
                    stage="exit_ip_check",
                    message=last_error,
                    endpoint=endpoint,
                    details={
                        "url": url,
                        "connect_timeout_seconds": self.timeout,
                    },
                )
        return endpoint, False, "", 0, last_error

    def refresh_health(self, force: bool = False) -> dict[str, int]:
        if not self.enabled:
            return {"healthy": 0, "failed": 0}
        now = time.time()
        to_check: list[ProxyEndpoint] = []
        current_ids = {endpoint.identity for endpoint in self.endpoints}
        self.health = {
            key: value for key, value in self.health.items() if key in current_ids
        }
        for endpoint in self.endpoints:
            record = self.health.get(endpoint.identity, {})
            fresh = now - float(record.get("last_checked_epoch", 0) or 0) < self.health_cache_seconds
            if force or not fresh or record.get("status") != "healthy":
                to_check.append(endpoint)
        if to_check:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(self.health_parallel, len(to_check))
            ) as executor:
                results = list(executor.map(self._check_endpoint_health, to_check))
            with self._health_lock:
                for endpoint, ok, exit_ip, latency, error in results:
                    old = self.health.get(endpoint.identity, {})
                    failures = 0 if ok else int(old.get("consecutive_failures", 0) or 0) + 1
                    status = "healthy" if ok else "failed"
                    self.health[endpoint.identity] = self._health_record(
                        endpoint,
                        status,
                        now,
                        exit_ip=exit_ip,
                        latency_ms=latency,
                        error=error,
                        consecutive_failures=failures,
                    )
                    if not ok:
                        self._record_proxy_error(
                            context="health_check",
                            stage="exit_ip_health",
                            message=error,
                            endpoint=endpoint,
                            details={
                                "check_urls": list(self.exit_ip_urls),
                                "connect_timeout_seconds": self.timeout,
                                "consecutive_health_failures": failures,
                            },
                        )
                self._save_health_state()
        return self.health_counts()

    def health_counts(self) -> dict[str, int]:
        counts = {"healthy": 0, "available": 0, "round_failed": 0, "failed": 0}
        for record in self.health.values():
            status = str(record.get("status", "available"))
            if status == "healthy":
                counts["healthy"] += 1
            elif status in {"failed", "quarantined", "failed_this_round"}:
                counts["round_failed"] += 1
                counts["failed"] += 1
            else:
                counts["available"] += 1
        return counts

    def _available_endpoints_locked(
        self,
        excluded: set[str] | None = None,
        *,
        include_leased: bool = False,
    ) -> list[ProxyEndpoint]:
        """Return eligible endpoints while ``_selection_lock`` is held."""
        with self._health_lock:
            excluded_ids = excluded or set()
            return [
                endpoint
                for endpoint in self.endpoints
                if endpoint.identity not in excluded_ids
                and endpoint.identity not in self._round_failed_proxy_ids
                and (
                    include_leased
                    or endpoint.host.casefold() not in self._active_proxy_leases
                )
            ]

    def available_endpoints(self, excluded: set[str] | None = None) -> list[ProxyEndpoint]:
        """Return round-eligible endpoints that are not actively leased."""
        with self._selection_lock:
            return self._available_endpoints_locked(excluded)

    def _reserve_proxy_lease_locked(
        self, serial: str, endpoint: ProxyEndpoint
    ) -> int:
        host_key = endpoint.host.casefold()
        if serial in self._device_proxy_leases:
            raise RuntimeError(f"device {serial} already owns an active proxy lease")
        if host_key in self._active_proxy_leases:
            raise RuntimeError(f"proxy {endpoint.redacted} is already actively leased")
        self._active_proxy_leases[host_key] = serial
        self._device_proxy_leases[serial] = endpoint
        return len(self._device_proxy_leases)

    def _release_proxy_lease(self, serial: str) -> None:
        endpoint: ProxyEndpoint | None = None
        active_count = 0
        with self._lease_condition:
            endpoint = self._device_proxy_leases.pop(str(serial), None)
            if endpoint is not None:
                host_key = endpoint.host.casefold()
                if self._active_proxy_leases.get(host_key) == str(serial):
                    self._active_proxy_leases.pop(host_key, None)
                active_count = len(self._device_proxy_leases)
                self._lease_condition.notify_all()
        if endpoint is not None:
            self.log(
                f"[PROXY LEASE] released | device={serial}"
                f" | proxy={endpoint.redacted}"
                f" | active={active_count}/{self.max_active_leases}"
            )

    def begin_round(self, round_number: int) -> bool:
        """Reload the proxy list and make every configured proxy round-eligible."""
        if not self.enabled:
            self._current_round = int(round_number)
            return True
        assert self.proxy_path is not None
        try:
            current_endpoints = load_proxy_list(self.proxy_path)
        except (OSError, ValueError) as exc:
            error = f"{type(exc).__name__}: {exc}"
            self._record_proxy_error(
                context=f"round={int(round_number)}",
                stage="proxy_list_reload",
                message=error,
                details={"proxy_list_file": str(self.proxy_path)},
            )
            self.log(
                f"[PROXY ERROR] round={int(round_number)} | proxy_list={self.proxy_path}"
                f" | action=SKIP_ROUND | retry=NEXT_ROUND | error={error}"
            )
            return False
        with self._selection_lock:
            with self._health_lock:
                self.endpoints = current_endpoints
                self._round_failed_proxy_ids.clear()
                self._round_assignment_counts = {
                    endpoint.identity: 0 for endpoint in self.endpoints
                }
                current_ids = {endpoint.identity for endpoint in self.endpoints}
                self.health = {
                    identity: record
                    for identity, record in self.health.items()
                    if identity in current_ids
                }
                self._last_assignments.clear()
                self._current_round = int(round_number)
                now = time.time()
                for endpoint in self.endpoints:
                    old = self.health.get(endpoint.identity, {})
                    self.health[endpoint.identity] = self._health_record(
                        endpoint,
                        "available",
                        now,
                        exit_ip=str(old.get("exit_ip", "")),
                        latency_ms=int(old.get("latency_ms", 0) or 0),
                        consecutive_failures=int(old.get("consecutive_failures", 0) or 0),
                    )
        self.log(
            f"[PROXY ROUND] round={self._current_round} | loaded={len(self.endpoints)}"
            f" | unique_ips={len({endpoint.host for endpoint in self.endpoints})}"
            f" | eligible={len(self.endpoints)}"
            f" | active_lease_limit={self.max_active_leases} | source={self.proxy_path}"
        )
        return True

    def healthy_endpoints(self) -> list[ProxyEndpoint]:
        """Compatibility alias for callers that need the current usable pool."""
        return self.available_endpoints()

    def _adb(self, serial: str, *args: str, timeout: float | None = None) -> subprocess.CompletedProcess[str]:
        return self._adb_runner(
            [self.adb_executable, "-s", serial, *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout or self.adb_control_timeout,
        )

    def arm_tiktok_proof(self, serial: str, proof_path: Path) -> None:
        """Arm a per-worker proof file after proxy preparation and before TikTok starts."""
        path = Path(proof_path)
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass
        with self._proof_lock:
            self._tiktok_proof_arms[str(serial)] = (path, time.time())

    def disarm_tiktok_proof(self, serial: str) -> None:
        with self._proof_lock:
            self._tiktok_proof_arms.pop(str(serial), None)

    def _release_lock_for(self, serial: str) -> threading.Lock:
        with self._resource_lock:
            return self._device_release_locks.setdefault(str(serial), threading.Lock())

    def _restore_device_proxy(
        self,
        serial: str,
        original: str,
        *,
        relay: AuthenticatedProxyRelay | None = None,
    ) -> list[str]:
        """Restore one device in a fixed order and return bounded cleanup errors."""
        errors: list[str] = []
        managed_setting = f"127.0.0.1:{self.device_port}"
        desired = (
            original
            if original
            and not self._proxy_setting_is_clear(original)
            and original != managed_setting
            else ":0"
        )

        def run(label: str, *args: str) -> subprocess.CompletedProcess[str] | None:
            try:
                result = self._adb(serial, *args, timeout=self.shutdown_timeout)
            except (OSError, subprocess.SubprocessError) as exc:
                errors.append(f"{label}: {type(exc).__name__}: {exc}")
                return None
            if result.returncode != 0:
                details = self._command_diagnostics(result)
                errors.append(f"{label}: command failed: {details}")
            return result

        applied = run(
            "restore_http_proxy",
            "shell", "settings", "put", "global", "http_proxy", desired,
        )
        checked = run(
            "verify_http_proxy",
            "shell", "settings", "get", "global", "http_proxy",
        )
        removed = run(
            "remove_reverse", "reverse", "--remove", f"tcp:{self.device_port}"
        )
        reverse_list = run("verify_reverse_removed", "reverse", "--list")

        value = checked.stdout.strip() if checked is not None else ""
        proxy_verified = bool(
            applied is not None
            and applied.returncode == 0
            and checked is not None
            and checked.returncode == 0
            and (
                self._proxy_setting_is_clear(value)
                if desired == ":0"
                else value == desired
            )
        )
        if not proxy_verified:
            errors.append(
                f"verify_http_proxy: expected={desired!r} actual={value!r}"
            )
        reverse_verified = bool(
            reverse_list is not None
            and reverse_list.returncode == 0
            and f"tcp:{self.device_port}" not in reverse_list.stdout
        )
        if not reverse_verified:
            errors.append("verify_reverse_removed: managed mapping is still present or unreadable")

        active_relay = relay
        if active_relay is None:
            with self._resource_lock:
                active_relay = self._relays.get(serial)
        if active_relay is not None:
            active_relay.close_active_connections()
        self.disarm_tiktok_proof(serial)

        if proxy_verified and reverse_verified:
            with self._resource_lock:
                self._configured_relays.pop(serial, None)
                self._original_proxy.pop(serial, None)
        if removed is None:
            # Keep the local variable intentionally consumed: later verification
            # is authoritative, while this preserves the attempted command order.
            pass
        return errors

    def release_device(self, serial: str) -> list[str]:
        """Release one completed workflow without affecting any other device."""
        serial = str(serial)
        started = time.monotonic()
        failed_endpoint: ProxyEndpoint | None = None
        self.log(f"[PROXY] PROXY_CLEANUP_STARTED | device={serial}")
        try:
            with self._release_lock_for(serial):
                with self._resource_lock:
                    original = self._original_proxy.get(serial, ":0")
                errors = self._restore_device_proxy(serial, original)
                if errors:
                    # If Android/ADB cleanup cannot be verified, stop the local
                    # relay before freeing the external proxy. The affected
                    # phone may retain a stale loopback setting, but it cannot
                    # continue sending traffic through the released endpoint.
                    with self._resource_lock:
                        relay = self._relays.pop(serial, None)
                        self._relay_last_used.pop(serial, None)
                    if relay is not None:
                        failed_endpoint = relay.endpoint
                        try:
                            relay.close()
                        except Exception as exc:
                            errors.append(
                                f"close_failed_relay: {type(exc).__name__}: {exc}"
                            )
        finally:
            # The endpoint becomes selectable only after settings restoration,
            # ADB reverse removal, verification, and relay connection closure.
            self._release_proxy_lease(serial)
        if errors:
            for message in errors:
                self._record_proxy_error(
                    context="workflow_cleanup",
                    stage="release_device",
                    message=message,
                    serial=serial,
                    endpoint=failed_endpoint,
                )
        self.log(
            f"[PROXY] PROXY_CLEANUP_FINISHED | device={serial} | "
            f"elapsed={time.monotonic() - started:.3f}s | errors={len(errors)}"
        )
        return errors

    def _observe_tiktok_target(self, serial: str, raw_target: str) -> None:
        if not self.enabled or not self.verify_tiktok_traffic:
            return
        host = str(raw_target).split(":", 1)[0].lower().rstrip(".")
        if not host or not any(
            host == suffix or host.endswith("." + suffix)
            for suffix in self.tiktok_domain_suffixes
        ):
            return
        now = time.time()
        serial_key = str(serial)
        with self._proof_lock:
            armed = self._tiktok_proof_arms.get(serial_key)
            if armed is None:
                return
            proof_path, armed_epoch = armed
            baseline = float(self._workflow_baselines.get(serial_key, 0.0) or 0.0)
            if now < max(armed_epoch, baseline):
                return
            # TikTok opens several relay connections in parallel. Claim this
            # worker's proof while still holding the lock so exactly one matching
            # connection may write it; all others immediately see it as consumed.
            self._tiktok_proof_arms.pop(serial_key, None)

        relay = self._relays.get(serial_key)
        endpoint = relay.endpoint if relay else None
        payload = {
            "verified": True,
            "serial": serial_key,
            "target": str(raw_target),
            "proxy": endpoint.redacted if endpoint is not None else "",
            "armed_epoch": armed_epoch,
            "baseline_epoch": baseline,
            "observed_epoch": now,
        }
        # A unique same-directory temp file keeps os.replace atomic without
        # allowing unrelated relay threads to contend on one shared .tmp name.
        temp = proof_path.with_name(
            f"{proof_path.name}.tmp-{os.getpid()}-{threading.get_ident()}-{time.time_ns()}"
        )
        try:
            proof_path.parent.mkdir(parents=True, exist_ok=True)
            temp.write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
            os.replace(temp, proof_path)
            if endpoint is not None:
                self.log(
                    f"[PROXY] {serial} | VERIFIED TikTok target {raw_target} via "
                    f"{endpoint.redacted} | Submit gate unlocked"
                )
        except OSError as exc:
            # If that one claimed write genuinely failed, allow a later TikTok
            # connection in this same workflow to try again. Never overwrite a
            # newer arm that may already have been installed for the device.
            with self._proof_lock:
                if serial_key not in self._tiktok_proof_arms:
                    self._tiktok_proof_arms[serial_key] = armed
            self._record_proxy_error(
                context=self._assignment_contexts.get(serial_key, "workflow"),
                stage="workflow_tiktok_proof",
                message=f"failed to persist TikTok proof: {type(exc).__name__}: {exc}",
                serial=serial_key,
                endpoint=endpoint,
            )
        finally:
            try:
                temp.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                pass

    def _relay_for(self, serial: str) -> AuthenticatedProxyRelay:
        with self._resource_lock:
            relay = self._relays.get(serial)
            if relay is None:
                relay = AuthenticatedProxyRelay(
                    self.timeout,
                    verified_target_observer=lambda target, device=serial: self._observe_tiktok_target(
                        device, target
                    ),
                )
                self._relays[serial] = relay
            self._relay_last_used[serial] = time.monotonic()
            return relay

    def prune_inactive_relays(self, active_serials: Iterable[str]) -> int:
        """Close relays for devices absent beyond the configured idle window."""
        if not self.enabled or self.inactive_relay_retention_seconds <= 0:
            return 0
        active = {str(serial) for serial in active_serials}
        cutoff = time.monotonic() - self.inactive_relay_retention_seconds
        with self._resource_lock:
            stale_serials = [
                serial
                for serial in self._relays
                if serial not in active
                and self._relay_last_used.get(serial, 0.0) <= cutoff
            ]
            stale_relays = {
                serial: self._relays.pop(serial) for serial in stale_serials
            }
            for serial in stale_serials:
                self._relay_last_used.pop(serial, None)
                self._configured_relays.pop(serial, None)
                self._workflow_baselines.pop(serial, None)
                self._assignment_contexts.pop(serial, None)
                with self._proof_lock:
                    self._tiktok_proof_arms.pop(serial, None)
                self._probe_diagnostics.pop(serial, None)
                self._last_assignments.pop(serial, None)
        if stale_relays:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(self.parallel_setup, len(stale_relays)),
                thread_name_prefix="proxy-relay-prune",
            ) as executor:
                futures = [
                    executor.submit(relay.close) for relay in stale_relays.values()
                ]
                concurrent.futures.wait(futures)
            self.log(
                f"[PROXY MAINTENANCE] Closed {len(stale_relays)} inactive relay(s)."
            )
        return len(stale_relays)

    def _capture_original_proxy(self, serial: str) -> None:
        with self._resource_lock:
            if serial in self._original_proxy:
                return
        result = self._adb(serial, "shell", "settings", "get", "global", "http_proxy")
        if result.returncode != 0:
            raise ProxySetupError(
                "capture_original_proxy",
                "could not read the device's existing Android proxy setting",
                self._command_diagnostics(result),
            )
        original = result.stdout.strip()
        # A previous forced termination can leave our loopback proxy behind.
        # It is never a legitimate external/original proxy because the host
        # relay exists only for the lifetime of this process.
        if original == f"127.0.0.1:{self.device_port}":
            original = ":0"
        with self._resource_lock:
            self._original_proxy.setdefault(serial, original)

    @staticmethod
    def _proxy_setting_is_clear(value: str) -> bool:
        return value.strip().lower() in {"", "null", ":0", "none"}

    def _install_reverse_mapping(
        self, serial: str, relay: AuthenticatedProxyRelay
    ) -> None:
        """Install and verify the per-device ADB reverse mapping once."""
        device_socket = f"tcp:{self.device_port}"
        host_socket = f"tcp:{relay.port}"
        expected_mapping = f"{device_socket} {host_socket}"
        removed = self._adb(
            serial, "reverse", "--remove", device_socket, timeout=self.adb_control_timeout
        )
        installed = self._adb(
            serial, "reverse", device_socket, host_socket, timeout=self.adb_control_timeout
        )
        checked = self._adb(serial, "reverse", "--list", timeout=self.adb_control_timeout)
        mapping_seen = checked.returncode == 0 and expected_mapping in checked.stdout
        details = {
            "expected_mapping": expected_mapping,
            "remove": self._command_diagnostics(removed),
            "install": self._command_diagnostics(installed),
            "readback": self._command_diagnostics(checked),
            "mapping_seen": mapping_seen,
        }
        if installed.returncode == 0 and mapping_seen:
            return

        raise ProxySetupError(
            "adb_reverse_verify",
            "ADB reverse mapping did not verify",
            details,
        )

    def _configure_device(
        self,
        serial: str,
        relay: AuthenticatedProxyRelay,
    ) -> None:
        self._capture_original_proxy(serial)
        setting = f"127.0.0.1:{self.device_port}"
        if (
            self._configured_relays.get(serial) == relay.port
        ):
            checked = self._adb(
                serial, "shell", "settings", "get", "global", "http_proxy"
            )
            reverse_list = self._adb(serial, "reverse", "--list")
            mapping = f"tcp:{self.device_port} tcp:{relay.port}"
            if (
                checked.returncode == 0
                and checked.stdout.strip() == setting
                and reverse_list.returncode == 0
                and mapping in reverse_list.stdout
            ):
                return
        self._install_reverse_mapping(serial, relay)
        applied = self._adb(
            serial,
            "shell",
            "settings",
            "put",
            "global",
            "http_proxy",
            setting,
        )
        if applied.returncode != 0:
            raise ProxySetupError(
                "android_proxy_apply",
                "Android global proxy setting failed",
                self._command_diagnostics(applied),
            )
        checked = self._adb(
            serial, "shell", "settings", "get", "global", "http_proxy"
        )
        if checked.returncode != 0 or checked.stdout.strip() != setting:
            details = self._command_diagnostics(checked)
            details.update({"expected_setting": setting, "actual_setting": checked.stdout.strip()})
            raise ProxySetupError(
                "android_proxy_verify",
                "Android global proxy setting did not verify",
                details,
            )
        self._configured_relays[serial] = relay.port

    def _probe_device(self, serial: str, relay: AuthenticatedProxyRelay) -> bool:
        if not self.verify_device_path:
            self._probe_diagnostics[serial] = {"verification_disabled": True}
            return True
        verified_before = relay.verified_target_connections(self.probe_target)
        failed_before = relay.failed_target_connections(self.probe_target)
        started = time.monotonic()
        linger_seconds = max(1, int(round(self.confirmation_deadline)))
        command = (
            f"(printf 'CONNECT {self.probe_target} HTTP/1.1\\r\\n"
            f"Host: {self.probe_target}\\r\\nConnection: close\\r\\n\\r\\n' "
            f") "
            f"| toybox nc -q {linger_seconds} -w {max(2, int(self.timeout))} "
            f"127.0.0.1 {self.device_port} >/dev/null 2>&1 &"
        )
        result = self._adb(
            serial,
            "shell",
            "sh",
            "-c",
            # ADB concatenates shell arguments before executing them remotely.
            # Keep the complete pipeline quoted so `sh -c` receives it as one
            # command instead of treating only `printf` as the command string.
            f'"{command}"',
            timeout=self.timeout,
        )
        confirmation_started = time.monotonic()
        deadline = confirmation_started + self.confirmation_deadline
        target_confirmed = False
        target_failed = False
        poll_event = threading.Event()
        while time.monotonic() < deadline:
            if self._stopping():
                break
            target_confirmed = (
                relay.verified_target_connections(self.probe_target) > verified_before
            )
            target_failed = (
                relay.failed_target_connections(self.probe_target) > failed_before
            )
            if target_confirmed or target_failed:
                break
            remaining = deadline - time.monotonic()
            poll_event.wait(max(0.0, min(0.02, remaining)))
        elapsed = time.monotonic() - started
        confirmation_elapsed = time.monotonic() - confirmation_started
        # A relay-observed upstream failure is genuine negative evidence.  A
        # silent toybox probe is inconclusive (Android builds can terminate or
        # suppress it), so do not reject an otherwise configured relay solely
        # because this synthetic command produced no confirmation.
        inconclusive = not target_confirmed and not target_failed
        passed = bool(target_confirmed or (inconclusive and result.returncode == 0))
        self._probe_diagnostics[serial] = {
            **self._command_diagnostics(result),
            "probe_target": self.probe_target,
            "device_proxy_port": self.device_port,
            "confirmation_deadline_seconds": self.confirmation_deadline,
            "probe_total_elapsed_seconds": round(elapsed, 6),
            "relay_confirmation_elapsed_seconds": round(confirmation_elapsed, 6),
            "expected_target_confirmed": target_confirmed,
            "expected_target_failed": target_failed,
            "synthetic_probe_inconclusive": inconclusive,
            "inconclusive_allowed": bool(inconclusive and result.returncode == 0),
            "verified_target_before": verified_before,
            "verified_target_after": relay.verified_target_connections(self.probe_target),
            "failed_target_before": failed_before,
            "failed_target_after": relay.failed_target_connections(self.probe_target),
            "relay_snapshot": relay.snapshot(),
        }
        if passed:
            evidence = "CONNECT confirmed" if target_confirmed else "relay configured; probe inconclusive"
            if not self.compact_logging:
                self.log(f"[PROXY] {serial} | {evidence} | elapsed={elapsed:.2f}s")
        return passed

    def _record_proxy_success(self, endpoint: ProxyEndpoint) -> None:
        with self._health_lock:
            now = time.time()
            old = self.health.get(endpoint.identity, {})
            self.health[endpoint.identity] = self._health_record(
                endpoint,
                "healthy",
                max(now, float(old.get("last_checked_epoch", 0) or 0)),
                exit_ip=str(old.get("exit_ip", "")),
                latency_ms=int(old.get("latency_ms", 0) or 0),
            )

    def _skip_proxy_for_round(self, endpoint: ProxyEndpoint, error: str) -> None:
        """Skip a genuinely failed endpoint until the next watchlist round."""
        with self._health_lock:
            now = time.time()
            old = self.health.get(endpoint.identity, {})
            failures = int(old.get("consecutive_failures", 0) or 0) + 1
            self._round_failed_proxy_ids.add(endpoint.identity)
            self.health[endpoint.identity] = self._health_record(
                endpoint,
                "failed_this_round",
                now,
                exit_ip=str(old.get("exit_ip", "")),
                latency_ms=int(old.get("latency_ms", 0) or 0),
                error=error,
                consecutive_failures=failures,
            )

    def _log_proxy_round_skip(
        self,
        *,
        serial: str,
        endpoint: ProxyEndpoint,
        context: str,
        error: str,
    ) -> None:
        self.log(
            f"[PROXY ERROR] device={serial} | proxy={endpoint.redacted}"
            f" | round={self._current_round} | action=SKIP_PROXY_THIS_ROUND"
            f" | retry=NEXT_ROUND | context={context} | error={error}"
        )

    def _prepare_with_fallback(
        self, serial: str, context: str
    ) -> tuple[str, ProxyEndpoint | None, str]:
        attempted: set[str] = set()
        errors: list[str] = []
        maximum = min(self.assignment_max_attempts, len(self.endpoints))
        with self._selection_lock:
            if serial in self._device_proxy_leases:
                return serial, None, "device already owns an active proxy lease"
        while len(attempted) < maximum:
            if self._stopping():
                return serial, None, "cancelled by shutdown"
            with self._lease_condition:
                eligible = self._available_endpoints_locked(
                    attempted, include_leased=True
                )
                if not eligible:
                    break
                available = [
                    endpoint
                    for endpoint in eligible
                    if endpoint.host.casefold() not in self._active_proxy_leases
                ]
                rotation_device = self.rotation._device(serial)
                last_host = str(
                    rotation_device.get("last_proxy_host", "")
                ).casefold()
                if not last_host:
                    last_id = str(rotation_device.get("last_proxy_id", ""))
                    last_host = next(
                        (
                            endpoint.host.casefold()
                            for endpoint in self.endpoints
                            if endpoint.identity == last_id
                        ),
                        "",
                    )
                non_repeat_eligible = [
                    endpoint
                    for endpoint in eligible
                    if endpoint.host.casefold() != last_host
                ]
                non_repeat_available = [
                    endpoint
                    for endpoint in available
                    if endpoint.host.casefold() != last_host
                ]
                if (
                    not available
                    or len(self._device_proxy_leases) >= self.max_active_leases
                    or (non_repeat_eligible and not non_repeat_available)
                ):
                    self._lease_condition.wait(timeout=0.25)
                    continue
                randomized = self.rotation.candidate_order(serial, available)
                minimum_uses = min(
                    self._round_assignment_counts.get(candidate.identity, 0)
                    for candidate in randomized
                )
                endpoint = next(
                    candidate
                    for candidate in randomized
                    if self._round_assignment_counts.get(candidate.identity, 0)
                    == minimum_uses
                )
                self._round_assignment_counts[endpoint.identity] = minimum_uses + 1
                active_count = self._reserve_proxy_lease_locked(serial, endpoint)
            self.log(
                f"[PROXY LEASE] acquired | device={serial}"
                f" | proxy={endpoint.redacted}"
                f" | active={active_count}/{self.max_active_leases}"
            )
            attempted.add(endpoint.identity)
            if not self.compact_logging:
                self.log(
                    f"[PROXY TRY] device={serial} | proxy={endpoint.redacted}"
                    f" | context={context}"
                )
            try:
                _serial, prepared, error = self._prepare_one(serial, endpoint, context)
            except Exception:
                try:
                    self.release_device(serial)
                except Exception:
                    self._release_proxy_lease(serial)
                raise
            if self._stopping():
                self.release_device(serial)
                return serial, None, "cancelled by shutdown"
            if prepared is not None:
                self._prepare_failure_scopes.pop(serial, None)
                with self._selection_lock:
                    self.rotation.commit({serial: endpoint}, list(self.endpoints))
                self._last_assignments[serial] = endpoint.redacted
                self._record_proxy_assignment(
                    context=context,
                    serial=serial,
                    endpoint=endpoint,
                )
                return serial, endpoint, ""
            # Only relay-observed upstream proxy failure may quarantine an
            # endpoint. ADB/device-control failures belong to this phone only;
            # trying more proxies would just poison healthy endpoints.
            failure_scope = self._prepare_failure_scopes.pop(serial, "proxy")
            if failure_scope == "proxy":
                # Mark the endpoint before releasing its lease, so a waiting
                # setup thread cannot claim it during the cleanup handoff.
                self._skip_proxy_for_round(endpoint, error)
            # A failed setup may already have installed the Android proxy and
            # ADB reverse. Restore and verify both before another device can
            # acquire this proxy host.
            self.release_device(serial)
            errors.append(f"{endpoint.redacted}: {error}")
            if failure_scope != "proxy":
                self.log(
                    f"[PROXY] {serial} | device/ADB preparation failed | "
                    f"proxy {endpoint.redacted} remains eligible"
                )
                return serial, None, f"device/ADB preparation failure: {error}"
            self._log_proxy_round_skip(
                serial=serial,
                endpoint=endpoint,
                context=context,
                error=error,
            )
        detail = "; ".join(errors[-maximum:]) or "no eligible proxy available this round"
        return serial, None, detail

    def _prepare_one(
        self, serial: str, endpoint: ProxyEndpoint, context: str
    ) -> tuple[str, ProxyEndpoint | None, str]:
        if self._stopping():
            return serial, None, "cancelled by shutdown"
        relay = self._relay_for(serial)
        self._prepare_failure_scopes.pop(serial, None)
        try:
            relay.set_endpoint(endpoint)
            self._configure_device(serial, relay)
            if self._stopping():
                return serial, None, "cancelled by shutdown"
            if not self._probe_device(serial, relay):
                if self._stopping():
                    return serial, None, "cancelled by shutdown"
                raise ProxySetupError(
                    "device_connect_probe",
                    "device-to-proxy CONNECT verification failed",
                    dict(self._probe_diagnostics.get(serial, {})),
                )
            # Start the proof window after the synthetic CONNECT succeeds.
            # Actual TikTok-domain activity is evaluated after the real workflow,
            # so preparation never launches/stops TikTok or blocks on app startup.
            self._workflow_baselines[serial] = time.time()
            self._workflow_failed_connection_baselines[serial] = int(
                relay.snapshot().get("failed_connections", 0) or 0
            )
            self._assignment_contexts[serial] = context
            self._record_proxy_success(endpoint)
            return serial, endpoint, ""
        except ProxySetupError as exc:
            error = str(exc)
            # A synthetic device probe is proof of a bad external proxy only
            # when the host relay itself observed an upstream CONNECT failure.
            # Android settings/reverse/ADB failures are device-path failures.
            self._prepare_failure_scopes[serial] = (
                "proxy"
                if exc.stage == "device_connect_probe"
                and bool(exc.details.get("expected_target_failed"))
                else "device"
            )
            self._record_proxy_error(
                context=context,
                stage=exc.stage,
                message=error,
                serial=serial,
                endpoint=endpoint,
                details=exc.details,
            )
            return serial, None, error
        except subprocess.TimeoutExpired as exc:
            error = f"ADB command timed out after {exc.timeout} seconds"
            self._prepare_failure_scopes[serial] = "device"
            self._record_proxy_error(
                context=context,
                stage="adb_timeout",
                message=error,
                serial=serial,
                endpoint=endpoint,
                details={"command": [str(item) for item in (exc.cmd or [])]},
            )
            return serial, None, error
        except (OSError, subprocess.SubprocessError) as exc:
            error = f"{type(exc).__name__}: {exc}"
            self._prepare_failure_scopes[serial] = "device"
            self._record_proxy_error(
                context=context,
                stage="unexpected_setup_error",
                message=error,
                serial=serial,
                endpoint=endpoint,
            )
            return serial, None, error

    def prepare_stream(
        self, serials: Iterable[str], context: str
    ) -> Iterable[tuple[str, bool, str, str]]:
        """Yield devices from a bounded rolling proxy-preparation window.

        At most ``parallel_setup`` devices are preparing at once.  A completed
        device is yielded immediately, then one new device is submitted to
        refill the free slot.  This avoids the old queue-all-first delay while
        preserving the same bounded ADB/proxy setup concurrency.
        """
        serial_list = list(dict.fromkeys(str(serial) for serial in serials))
        if not self.enabled:
            for serial in serial_list:
                yield serial, True, "disabled", ""
            return
        if not serial_list:
            return

        worker_count = min(self.parallel_setup, len(serial_list))
        serial_iter = iter(serial_list)
        executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=worker_count,
            thread_name_prefix="proxy-prepare",
        )
        try:
            futures: dict[concurrent.futures.Future, str] = {}

            def submit_one(serial: str, *, stagger: bool) -> None:
                if self._stopping():
                    return
                if stagger and self.setup_stagger_seconds > 0:
                    self._stop_event.wait(self.setup_stagger_seconds)
                if self._stopping():
                    return
                futures[executor.submit(self._prepare_with_fallback, serial, context)] = serial

            # Fill only the active window.  The first result can therefore be
            # consumed after at most the small window stagger, not N*stagger.
            for index in range(worker_count):
                try:
                    serial = next(serial_iter)
                except StopIteration:
                    break
                submit_one(serial, stagger=index > 0)

            while futures:
                if self._stopping():
                    for future in futures:
                        future.cancel()
                    break
                completed, _ = concurrent.futures.wait(
                    futures,
                    timeout=0.1,
                    return_when=concurrent.futures.FIRST_COMPLETED,
                )
                if not completed:
                    continue
                for future in completed:
                    expected_serial = futures.pop(future)
                    try:
                        serial, endpoint, error = future.result()
                    except Exception as exc:
                        serial = expected_serial
                        endpoint = None
                        error = f"{type(exc).__name__}: {exc}"
                        self._record_proxy_error(
                            context=context,
                            stage="unexpected_setup_exception",
                            message=error,
                            serial=serial,
                        )

                    # Yield immediately.  When the caller asks for the next
                    # item, refill exactly one free preparation slot.
                    if endpoint is None and error == "cancelled by shutdown":
                        continue
                    if endpoint is None:
                        self.log(f"[PROXY] {serial} failed closed: {error}")
                        yield serial, False, "", error
                    else:
                        yield serial, True, endpoint.redacted, ""

                    try:
                        next_serial = next(serial_iter)
                    except StopIteration:
                        continue
                    submit_one(next_serial, stagger=True)
        finally:
            # Running ADB calls are not safely interruptible. Wait only for the
            # small active window so any modified device is included in close()
            # restoration; queued work has already been cancelled.
            executor.shutdown(wait=True, cancel_futures=True)

        try:
            with self._health_lock:
                self._save_health_state()
        except OSError as exc:
            self._record_proxy_error(
                context=context,
                stage="health_state_persist",
                message=f"{type(exc).__name__}: {exc}",
                details={"prepared_devices": len(self._last_assignments)},
            )

    def verify_workflow_traffic(self, serials: Iterable[str]) -> bool:
        if not self.enabled:
            return True
        all_verified = True
        actual_traffic_failures = 0
        unverified_traffic = 0
        for serial in dict.fromkeys(str(value) for value in serials):
            relay = self._relays.get(serial)
            baseline = self._workflow_baselines.get(serial, 0.0)
            failed_before = self._workflow_failed_connection_baselines.get(serial, 0)
            failed_after = int(
                relay.snapshot().get("failed_connections", 0) if relay else 0
            )
            endpoint = relay.endpoint if relay else None
            if endpoint is not None and failed_after > failed_before:
                error = "relay recorded a failed connection during actual workflow traffic"
                self._skip_proxy_for_round(
                    endpoint,
                    error,
                )
                self._record_proxy_error(
                    context=self._assignment_contexts.get(serial, "workflow"),
                    stage="workflow_proxy_connection",
                    message=error,
                    serial=serial,
                    endpoint=endpoint,
                    details={
                        "failed_connections_before": failed_before,
                        "failed_connections_after": failed_after,
                    },
                )
                self._log_proxy_round_skip(
                    serial=serial,
                    endpoint=endpoint,
                    context=self._assignment_contexts.get(serial, "workflow"),
                    error=error,
                )
                actual_traffic_failures += 1
            if not self.verify_tiktok_traffic:
                continue
            verified = bool(
                relay
                and relay.is_alive()
                and relay.has_target_since(self.tiktok_domain_suffixes, baseline)
            )
            if not verified:
                all_verified = False
                unverified_traffic += 1
                if endpoint is not None:
                    self._record_proxy_error(
                        context="workflow",
                        stage="workflow_tiktok_traffic",
                        message="no TikTok relay traffic observed during workflow",
                        serial=serial,
                        endpoint=endpoint,
                        details={
                            "baseline_epoch": baseline,
                            "accepted_domain_suffixes": list(self.tiktok_domain_suffixes),
                            "observed_tiktok_targets": relay.matching_targets_since(
                                self.tiktok_domain_suffixes, baseline
                            ),
                            "relay_snapshot": relay.snapshot(),
                        },
                    )
                if not self.compact_logging:
                    self.log(
                        f"[PROXY] {serial}: workflow traffic was not verified; "
                        "diagnostics were logged without globally disabling the proxy."
                    )
            else:
                endpoint = relay.endpoint
                if endpoint is not None:
                    self._record_proxy_usage(
                        context=self._assignment_contexts.get(serial, "workflow"),
                        stage="workflow_tiktok_traffic",
                        serial=serial,
                        endpoint=endpoint,
                        started_epoch=baseline,
                        relay=relay,
                    )
        if self.compact_logging and (actual_traffic_failures or unverified_traffic):
            self.log(
                f"[PROXY] traffic summary | failed={actual_traffic_failures} | "
                f"unverified={unverified_traffic} | details={self.error_log_path}"
            )
        return all_verified

    def write_health_log(
        self,
        directory: Path,
        *,
        finalize_cycle: bool = False,
    ) -> tuple[Path, Path] | None:
        if not self.enabled:
            return None
        directory.mkdir(parents=True, exist_ok=True)
        counts = self.health_counts()
        records = sorted(
            (dict(record) for record in self.health.values()),
            key=lambda item: str(item.get("address", "")),
        )
        with self._error_lock:
            errors = [dict(event) for _sequence, event in self._error_events]
            final_error_sequence = (
                self._error_events[-1][0] if self._error_events else 0
            )
            dropped_errors = self._dropped_error_events
        with self._usage_lock:
            usage = [dict(event) for _sequence, event in self._usage_events]
            final_usage_sequence = (
                self._usage_events[-1][0] if self._usage_events else 0
            )
            dropped_usage = self._dropped_usage_events
        with self._assignment_lock:
            assignments = [
                dict(event) for _sequence, event in self._assignment_events
            ]
            final_assignment_sequence = (
                self._assignment_events[-1][0] if self._assignment_events else 0
            )
            dropped_assignments = self._dropped_assignment_events
        payload = {
            "timestamp_epoch": time.time(),
            "configured": len(self.endpoints),
            "counts": counts,
            "assignment_policy": "random_least_used_no_immediate_ip_repeat",
            "assignments": dict(sorted(self._last_assignments.items())),
            "proxy_error_count": len(errors),
            "verified_usage_count": len(usage),
            "assignment_record_count": len(assignments),
            "cycle_buffer_dropped_error_count": dropped_errors,
            "cycle_buffer_dropped_usage_count": dropped_usage,
            "cycle_buffer_dropped_assignment_count": dropped_assignments,
            "proxies": records,
        }
        json_path = directory / "PROXY_HEALTH.json"
        text_path = directory / "PROXY_HEALTH.txt"
        json_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        lines = [
            f"configured: {len(self.endpoints)}",
            f"healthy: {counts['healthy']}",
            f"available unchecked: {counts['available']}",
            f"failed this round: {counts['round_failed']}",
            "assignment policy: random among least-used proxies; no immediate IP repeat per device",
            f"proxy errors logged: {len(errors)}",
            f"verified usage records: {len(usage)}",
            f"assignment records: {len(assignments)}",
            f"cycle-buffer proxy errors dropped after limit: {dropped_errors}",
            f"cycle-buffer usage records dropped after limit: {dropped_usage}",
            f"cycle-buffer assignment records dropped after limit: {dropped_assignments}",
            "",
            "assignments:",
        ]
        lines.extend(
            f"- {serial}: {address}"
            for serial, address in sorted(self._last_assignments.items())
        )
        lines.append("")
        lines.append("proxy health:")
        lines.extend(
            "- {address} | {status} | exit_ip={exit_ip} | latency_ms={latency_ms} "
            "| failures={consecutive_failures} | error={last_error}".format(**record)
            for record in records
        )
        text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        error_json_path = directory / "PROXY_ERRORS.json"
        error_text_path = directory / "PROXY_ERRORS.txt"
        error_json_path.write_text(
            json.dumps(errors, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        error_lines = [f"proxy errors: {len(errors)}"]
        for event in errors:
            error_lines.extend(
                [
                    "",
                    f"time: {event['timestamp_local']}",
                    f"context: {event['context']}",
                    f"stage: {event['stage']}",
                    f"device: {event['device'] or '-'}",
                    f"proxy: {event['proxy'] or '-'}",
                    f"message: {event['message']}",
                    "details: " + json.dumps(event["details"], ensure_ascii=False),
                ]
            )
        error_text_path.write_text("\n".join(error_lines) + "\n", encoding="utf-8")
        usage_json_path = directory / "PROXY_USAGE.json"
        usage_text_path = directory / "PROXY_USAGE.txt"
        usage_json_path.write_text(
            json.dumps(usage, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        usage_lines = [f"verified proxy usage records: {len(usage)}"]
        for event in usage:
            usage_lines.extend(
                [
                    "",
                    f"time: {event['timestamp_local']}",
                    f"context: {event['context']}",
                    f"stage: {event['stage']}",
                    f"device: {event['device']}",
                    f"device IP: {event['device_ip']}",
                    f"proxy: {event['proxy']}",
                    f"proxy IP: {event['proxy_ip']}",
                    f"proxy port: {event['proxy_port']}",
                    f"exit IP: {event['exit_ip']}",
                    f"verified: {event['verified']}",
                    "TikTok targets: "
                    + ", ".join(event["observed_tiktok_targets"]),
                    "relay: "
                    + json.dumps(event["relay_snapshot"], ensure_ascii=False),
                ]
            )
        usage_text_path.write_text("\n".join(usage_lines) + "\n", encoding="utf-8")
        assignment_json_path = directory / "PROXY_ASSIGNMENTS.json"
        assignment_text_path = directory / "PROXY_ASSIGNMENTS.txt"
        assignment_json_path.write_text(
            json.dumps(assignments, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        assignment_lines = [f"successful proxy assignments: {len(assignments)}"]
        for event in assignments:
            assignment_lines.append(
                f"{event['timestamp_local']} | device={event['device']}"
                f" | device_ip={event['device_ip']} | proxy={event['proxy']}"
                f" | proxy_ip={event['proxy_ip']} | proxy_port={event['proxy_port']}"
                f" | exit_ip={event['exit_ip']} | lease=EXCLUSIVE"
                f" | context={event['context']}"
            )
        assignment_text_path.write_text(
            "\n".join(assignment_lines) + "\n", encoding="utf-8"
        )
        if finalize_cycle:
            with self._error_lock:
                while (
                    self._error_events
                    and self._error_events[0][0] <= final_error_sequence
                ):
                    self._error_events.popleft()
                self._dropped_error_events = max(
                    0, self._dropped_error_events - dropped_errors
                )
            with self._usage_lock:
                while (
                    self._usage_events
                    and self._usage_events[0][0] <= final_usage_sequence
                ):
                    self._usage_events.popleft()
                self._dropped_usage_events = max(
                    0, self._dropped_usage_events - dropped_usage
                )
            with self._assignment_lock:
                while (
                    self._assignment_events
                    and self._assignment_events[0][0] <= final_assignment_sequence
                ):
                    self._assignment_events.popleft()
                self._dropped_assignment_events = max(
                    0, self._dropped_assignment_events - dropped_assignments
                )
        return text_path, json_path

    def close(self) -> None:
        # Only protect the state transition/snapshot. ADB cleanup can be slow,
        # so holding the manager lock while restoring every device serially made
        # shutdown grow linearly with device count.
        close_started = time.monotonic()
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self.request_stop()
            original_items = list(self._original_proxy.items())
            with self._resource_lock:
                relays = dict(self._relays)
                self._relays.clear()
                self._relay_last_used.clear()
        restore_target_count = len(original_items)
        restore_failures: list[str] = []
        restore_failure_lock = threading.Lock()

        def record_restore_failure(
            serial: str,
            message: str,
            details: dict[str, Any] | None = None,
        ) -> None:
            relay = relays.get(serial)
            self._record_proxy_error(
                context="shutdown",
                stage="restore_device_proxy",
                message=message,
                serial=serial,
                endpoint=relay.endpoint if relay else None,
                details=details,
            )
            with restore_failure_lock:
                restore_failures.append(serial)

        def restore_one(serial: str, original: str) -> None:
            try:
                with self._release_lock_for(serial):
                    errors = self._restore_device_proxy(
                        serial, original, relay=relays.get(serial)
                    )
            finally:
                self._release_proxy_lease(serial)
            if errors:
                record_restore_failure(serial, "; ".join(errors))

        if original_items:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(self.shutdown_parallel, len(original_items)),
                thread_name_prefix="proxy-restore",
            ) as executor:
                futures = [
                    executor.submit(restore_one, serial, original)
                    for serial, original in original_items
                ]
                concurrent.futures.wait(futures)

        if restore_failures:
            self.log(
                f"[PROXY] Proxy restoration incomplete | restored="
                f"{restore_target_count - len(restore_failures)} | "
                f"unavailable={len(restore_failures)} | "
                f"duration={time.monotonic() - close_started:.1f}s | "
                f"details={self.error_log_path}"
            )
        elif restore_target_count:
            self.log(
                f"[PROXY] Proxy restoration complete for {restore_target_count} "
                f"device(s) in {time.monotonic() - close_started:.1f}s."
            )

        # Final safety sweep: if a device was left on our managed loopback
        # proxy outside this process's normal assignment bookkeeping (for
        # example after an earlier hard crash), restore direct internet too.
        self._recover_stale_managed_proxy_state(context="shutdown")

        if relays:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(self.shutdown_parallel, len(relays)),
                thread_name_prefix="proxy-relay-close",
            ) as executor:
                futures = [executor.submit(relay.close) for relay in relays.values()]
                concurrent.futures.wait(futures)

        # Also wake and clear any reservation that stopped before Android proxy
        # state was captured. Normal workflow leases have already been released
        # by release_device() or restore_one().
        with self._lease_condition:
            self._active_proxy_leases.clear()
            self._device_proxy_leases.clear()
            self._lease_condition.notify_all()
