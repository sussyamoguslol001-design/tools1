#!/usr/bin/env python3
"""Configuration loading for the fail-fast multi-device runner."""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def load_json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as exc:
        raise SystemExit(f"Required configuration not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(
            f"Invalid JSON in {path}: line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc
    if not isinstance(value, dict):
        raise SystemExit(f"Configuration root must be an object: {path}")
    return value


def config_bool(value: Any, key: str) -> bool:
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().casefold()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise SystemExit(f"{key} must be true or false")


def _number(
    values: dict[str, Any], key: str, default: float, *, integer: bool = False
) -> int | float:
    raw = values.get(key, default)
    try:
        value = int(raw) if integer else float(raw)
    except (TypeError, ValueError) as exc:
        kind = "a whole number" if integer else "numeric"
        raise SystemExit(f"{key} must be {kind}") from exc
    if value < 0:
        raise SystemExit(f"{key} cannot be negative")
    return value


@dataclass(frozen=True)
class RuntimeSettings:
    values: dict[str, Any]
    base_dir: Path

    def path(self, key: str, default: str) -> Path:
        value = Path(str(self.values.get(key, default)))
        return value if value.is_absolute() else self.base_dir / value


def load_runtime_settings(path: Path) -> RuntimeSettings:
    """Load settings used by the circular-watchlist runtime."""
    values = load_json_object(path)

    for key, default in (
        ("watchlist_poll_interval_seconds", 0.5),
        ("adb_host_timeout_seconds", 15),
        ("device_refresh_timeout_seconds", 15),
        ("adb_device_cache_seconds", 10),
        ("adb_first_retry_seconds", 5),
        ("adb_second_retry_seconds", 15),
        ("adb_recovery_cooldown_seconds", 60),
        ("adb_server_start_settle_seconds", 5),
        ("adb_health_stable_interval_seconds", 2),
        ("adb_no_devices_retry_seconds", 30),
        ("live_precheck_timeout_seconds", 100),
        ("worker_job_timeout_seconds", 180),
        ("proxy_connect_timeout_seconds", 4),
        ("proxy_confirmation_deadline_seconds", 2),
        ("proxy_submit_proof_timeout_seconds", 1.5),
        ("proxy_early_proof_timeout_seconds", 2.5),
        ("proxy_adb_control_timeout_seconds", 8),
        ("proxy_setup_stagger_seconds", 0.05),
        ("proxy_shutdown_command_timeout_seconds", 2),
        ("shutdown_worker_grace_seconds", 0.3),
        ("shutdown_device_cleanup_timeout_seconds", 1),
        ("proxy_health_cache_seconds", 300),
        ("proxy_persistent_log_max_mb", 50),
        ("uiautomator_device_lock_timeout_seconds", 6),
        ("uiautomator_reset_settle_seconds", 0.8),
        ("proxy_inactive_relay_retention_seconds", 3600),
        ("maintenance_interval_seconds", 3600),
        ("log_retention_days", 3),
    ):
        values[key] = _number(values, key, default)

    for key, default in (
        ("max_parallel", 16),
        ("adb_failure_threshold", 3),
        ("adb_server_port", 5037),
        ("proxy_device_port", 19090),
        ("proxy_parallel_setup", 4),
        ("proxy_shutdown_parallel", 32),
        ("proxy_health_check_parallel", 16),
        ("proxy_minimum_healthy", 2),
        ("proxy_assignment_max_attempts", 3),
        ("checker_max_devices", 3),
        ("proxy_cycle_event_buffer_limit", 10000),
        ("proxy_persistent_log_backups", 5),
        ("log_retention_max_total_mb", 2048),
        ("progress_log_every_devices", 10),
    ):
        values[key] = _number(values, key, default, integer=True)

    for key in (
        "max_parallel",
        "adb_failure_threshold",
        "proxy_parallel_setup",
        "proxy_shutdown_parallel",
        "proxy_health_check_parallel",
        "proxy_minimum_healthy",
        "proxy_assignment_max_attempts",
        "checker_max_devices",
        "proxy_persistent_log_backups",
        "progress_log_every_devices",
    ):
        if int(values[key]) < 1:
            raise SystemExit(f"{key} must be at least 1")
    if not 1 <= int(values["proxy_device_port"]) <= 65535:
        raise SystemExit("proxy_device_port must be between 1 and 65535")
    if not 1 <= int(values["adb_server_port"]) <= 65535:
        raise SystemExit("adb_server_port must be between 1 and 65535")
    if not 0.5 <= float(values["uiautomator_device_lock_timeout_seconds"]) <= 15:
        raise SystemExit("uiautomator_device_lock_timeout_seconds must be between 0.5 and 15")
    if not 0.2 <= float(values["uiautomator_reset_settle_seconds"]) <= 3:
        raise SystemExit("uiautomator_reset_settle_seconds must be between 0.2 and 3")
    if float(values["watchlist_poll_interval_seconds"]) <= 0:
        raise SystemExit("watchlist_poll_interval_seconds must be greater than zero")
    for key in (
        "adb_host_timeout_seconds",
        "device_refresh_timeout_seconds",
        "adb_device_cache_seconds",
        "adb_first_retry_seconds",
        "adb_second_retry_seconds",
        "adb_recovery_cooldown_seconds",
        "adb_server_start_settle_seconds",
        "adb_health_stable_interval_seconds",
        "adb_no_devices_retry_seconds",
    ):
        if float(values[key]) <= 0:
            raise SystemExit(f"{key} must be greater than zero")
    if not 5 <= float(values["live_precheck_timeout_seconds"]) <= 100:
        raise SystemExit("live_precheck_timeout_seconds must be between 5 and 100")
    if not 45 <= float(values["worker_job_timeout_seconds"]) <= 180:
        raise SystemExit("worker_job_timeout_seconds must be between 45 and 180")
    if float(values["proxy_connect_timeout_seconds"]) <= 0:
        raise SystemExit("proxy_connect_timeout_seconds must be greater than zero")
    if not 0.1 <= float(values["proxy_confirmation_deadline_seconds"]) <= 2:
        raise SystemExit("proxy_confirmation_deadline_seconds must be between 0.1 and 2")
    if not 0.1 <= float(values["proxy_submit_proof_timeout_seconds"]) <= 3:
        raise SystemExit("proxy_submit_proof_timeout_seconds must be between 0.1 and 3")
    if not 0.1 <= float(values["proxy_early_proof_timeout_seconds"]) <= 5:
        raise SystemExit("proxy_early_proof_timeout_seconds must be between 0.1 and 5")
    if not 2 <= float(values["proxy_adb_control_timeout_seconds"]) <= 15:
        raise SystemExit("proxy_adb_control_timeout_seconds must be between 2 and 15")
    if not 0 <= float(values["proxy_setup_stagger_seconds"]) <= 1:
        raise SystemExit("proxy_setup_stagger_seconds must be between 0 and 1")
    if 0 < float(values["maintenance_interval_seconds"]) < 60:
        raise SystemExit("maintenance_interval_seconds must be zero or at least 60")
    if int(values["proxy_cycle_event_buffer_limit"]) < 100:
        raise SystemExit("proxy_cycle_event_buffer_limit must be at least 100")
    if float(values["proxy_persistent_log_max_mb"]) < 1:
        raise SystemExit("proxy_persistent_log_max_mb must be at least 1")

    for key, default in (
        ("proxy_enabled", True),
        ("proxy_fail_closed", True),
        ("proxy_startup_health_check", False),
        ("proxy_verify_device_path", True),
        ("proxy_verify_tiktok_traffic", True),
        ("diagnostics_enabled", False),
        ("detailed_logging", False),
        ("compact_console_logging", True),
        ("compact_success_logging", True),
    ):
        values[key] = config_bool(values.get(key, default), key)
    if values["proxy_enabled"] and not values["proxy_fail_closed"]:
        raise SystemExit("proxy_fail_closed must remain true")

    for key, default in (
        ("list_urls_file", "list_urls.txt"),
        ("excluded_lists_file", "excluded_lists.txt"),
        ("report_types_file", "report_types.json"),
        ("workflow_defaults_file", "_shared/workflow_defaults.json"),
        ("proxy_list_file", "proxy_list.txt"),
        ("proxy_rotation_state_file", "state/proxy_rotation.json"),
        ("proxy_health_state_file", "state/proxy_health.json"),
        ("proxy_error_log_file", "state/proxy_errors.jsonl"),
        ("proxy_usage_log_file", "state/proxy_usage.jsonl"),
        ("proxy_assignment_log_file", "state/proxy_assignments.jsonl"),
        ("adb_health_state_file", "state/adb_health.json"),
        ("instance_lock_file", "state/loop_runner.lock"),
        ("cycle_logs_root", "cycle_logs"),
        ("failed_logs_root", "failed_logs"),
        ("success_logs_root", "success_logs"),
    ):
        normalized = str(values.get(key, default)).strip()
        if not normalized:
            raise SystemExit(f"{key} cannot be empty")
        values[key] = normalized

    values["runtime_mode"] = "24/7"
    raw_adb = str(values.get("adb_executable", "adb")).strip() or "adb"
    adb_path = Path(raw_adb).expanduser()
    if adb_path.is_absolute():
        resolved_adb = adb_path.resolve()
    elif adb_path.parent != Path("."):
        resolved_adb = (path.resolve().parent / adb_path).resolve()
    else:
        found_adb = shutil.which(raw_adb)
        if found_adb is None:
            raise SystemExit(f"adb_executable was not found: {raw_adb}")
        resolved_adb = Path(found_adb).resolve()
    if not resolved_adb.is_file():
        raise SystemExit(f"adb_executable is not a file: {resolved_adb}")
    values["adb_executable"] = str(resolved_adb)
    values["report_action"] = str(values.get("report_action", "3")).strip()
    if not values["report_action"]:
        raise SystemExit("report_action cannot be empty")

    urls = values.get("proxy_exit_ip_check_urls", [])
    if not isinstance(urls, list) or not urls or not all(
        isinstance(item, str) and item.startswith("https://") for item in urls
    ):
        raise SystemExit("proxy_exit_ip_check_urls must contain at least one HTTPS URL")
    suffixes = values.get("proxy_tiktok_domain_suffixes", [])
    if not isinstance(suffixes, list) or not all(
        isinstance(item, str) and item.strip() for item in suffixes
    ):
        raise SystemExit("proxy_tiktok_domain_suffixes must be a string list")

    return RuntimeSettings(values=values, base_dir=path.resolve().parent)


def load_report_catalog(path: Path, base_dir: Path) -> dict[str, dict[str, Any]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SystemExit(f"Report catalog not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid report catalog JSON: {exc}") from exc
    if not isinstance(payload, list) or not payload:
        raise SystemExit("report_types.json must be a non-empty array")
    actions: dict[str, dict[str, Any]] = {}
    for item in payload:
        if not isinstance(item, dict):
            raise SystemExit("Every report catalog entry must be an object")
        action_id = str(item.get("id", "")).strip()
        label = str(item.get("label", "")).strip()
        directory = str(item.get("project_directory", "")).strip()
        if not action_id or not label or not directory or action_id in actions:
            raise SystemExit("Report IDs, labels, and directories must be unique and non-empty")
        project_dir = (base_dir / directory).resolve()
        if not (project_dir / "config.json").is_file():
            raise SystemExit(f"Report config is missing: {project_dir / 'config.json'}")
        if not (project_dir / "tiktok_live_selector_workflow.py").is_file():
            raise SystemExit(f"Report workflow is missing: {project_dir}")
        actions[action_id] = {"label": label, "project_dir": project_dir}
    return actions


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_workflow_config(path: Path, shared_defaults_path: Path) -> dict[str, Any]:
    values = deep_merge(load_json_object(shared_defaults_path), load_json_object(path))
    try:
        stabilization = float(values.get("live_stabilization_seconds", 0))
    except (TypeError, ValueError) as exc:
        raise SystemExit("live_stabilization_seconds must be numeric") from exc
    if stabilization < 0:
        raise SystemExit("live_stabilization_seconds must be >= 0")
    values["live_stabilization_seconds"] = stabilization
    return values
