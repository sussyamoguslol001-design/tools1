from __future__ import annotations

import inspect
import json
import sys
import tempfile
import threading
import time
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import Mock, call, patch

import loop_runner


class StreamingProxyStub:
    enabled = True

    def __init__(self, failed: set[str] | None = None) -> None:
        self.failed = failed or set()
        self.prepare_calls: list[list[str]] = []
        self.events: list[str] = []
        self.rounds: list[int] = []
        self.released: list[str] = []

    def begin_round(self, round_number):
        self.rounds.append(round_number)

    def prepare_stream(self, serials, _context):
        values = list(serials)
        self.prepare_calls.append(values)
        self.events.append("proxy_prepare:" + ",".join(values))
        for serial in values:
            if serial in self.failed:
                yield serial, False, "", "proxy unavailable"
            else:
                yield serial, True, "proxy", ""

    def verify_workflow_traffic(self, serials):
        self.events.append("verify:" + ",".join(serials))
        return True

    def release_device(self, serial):
        self.released.append(serial)
        self.events.append("release:" + serial)
        return []

    def write_health_log(self, *_args, **_kwargs):
        self.events.append("health_log")
        return None

    def prune_inactive_relays(self, serials):
        self.events.append("prune:" + ",".join(serials))
        return 0


class MaintenanceStub:
    def __init__(self) -> None:
        self.calls = 0

    def run_if_due(self) -> None:
        self.calls += 1


def username(value: str | None) -> str:
    return loop_runner.username_from_url(value or "")


class WatchlistTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()

    def make_watchlist(self, root: Path, content: str = ""):
        path = root / "list_urls.txt"
        path.write_text(content, encoding="utf-8")
        return loop_runner.LiveWatchlist(path)

    def test_file_order_normalization_deduplication_and_invalid_ignores_are_read_only(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            original = (
                "\n@first.fx\nhttps://www.tiktok.com/@second.fx/live\n"
                "@first.fx\nnot a username!\nhttps://example.com/@bad/live\n"
            )
            watchlist = self.make_watchlist(root, original)

            snapshot = watchlist.read_snapshot()

            self.assertEqual(
                [username(value) for value in snapshot.targets],
                ["first.fx", "second.fx"],
            )
            self.assertEqual(snapshot.duplicate_count, 1)
            self.assertEqual(snapshot.invalid_count, 2)
            self.assertEqual(watchlist.path.read_text(encoding="utf-8"), original)

    def test_runtime_additions_removals_and_round_restart_are_observed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = self.make_watchlist(root, "@first.fx\n@old.fx\n")
            first_round = watchlist.read_snapshot()
            self.assertEqual([username(v) for v in first_round.targets], ["first.fx", "old.fx"])

            watchlist.path.write_text("@first.fx\n@new.fx\n", encoding="utf-8")
            second_round = watchlist.read_snapshot()
            third_round = watchlist.read_snapshot()

            self.assertEqual([username(v) for v in second_round.targets], ["first.fx", "new.fx"])
            self.assertEqual(username(third_round.targets[0]), "first.fx")

    def test_two_rounds_process_in_file_order_and_wrap_to_first(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = self.make_watchlist(root, "@one.fx\n@two.fx\n@three.fx\n")
            exclusions = make_exclusions(root)
            seen: list[str] = []
            proxy = StreamingProxyStub()

            def process(**kwargs):
                seen.append(username(kwargs["live_url"]))
                return "OFFLINE"

            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "process_watchlist_target", side_effect=process
            ):
                sequence = 0
                for round_number in (1, 2):
                    snapshot = watchlist.read_snapshot()
                    _visited, sequence = loop_runner.run_watchlist_round(
                        config=make_config(root),
                        round_number=round_number,
                        sequence_start=sequence,
                        snapshot=snapshot,
                        watchlist=watchlist,
                        exclusions=exclusions,
                        proxy_manager=proxy,
                        maintenance=MaintenanceStub(),
                        action_choice="3",
                    )

            self.assertEqual(
                seen,
                ["one.fx", "two.fx", "three.fx", "one.fx", "two.fx", "three.fx"],
            )
            self.assertEqual(proxy.rounds, [1, 2])

    def test_invalid_proxy_list_skips_entire_round_without_target_results(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = self.make_watchlist(root, "@one.fx\n@two.fx\n")
            proxy = StreamingProxyStub()
            proxy.begin_round = Mock(return_value=False)
            with patch.object(loop_runner, "process_watchlist_target") as process, patch.object(
                loop_runner, "safe_print"
            ) as output:
                visited, sequence = loop_runner.run_watchlist_round(
                    config=make_config(root),
                    round_number=4,
                    sequence_start=12,
                    snapshot=watchlist.read_snapshot(),
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=proxy,
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )
            self.assertEqual((visited, sequence), (0, 12))
            process.assert_not_called()
            self.assertTrue(
                any("PROXY_LIST_RELOAD_FAILED" in str(item) for item in output.call_args_list)
            )

    def test_removal_during_round_prevents_later_scheduling(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = self.make_watchlist(root, "@one.fx\n@two.fx\n")
            seen: list[str] = []

            def process(**kwargs):
                seen.append(username(kwargs["live_url"]))
                watchlist.path.write_text("@one.fx\n", encoding="utf-8")
                return "OFFLINE"

            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "process_watchlist_target", side_effect=process
            ):
                loop_runner.run_watchlist_round(
                    config=make_config(root),
                    round_number=1,
                    sequence_start=0,
                    snapshot=watchlist.read_snapshot(),
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )

            self.assertEqual(seen, ["one.fx"])

    def test_exactly_one_live_triggers_mobile_legend_discovery_once(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = self.make_watchlist(root, "@one.fx\n@two.fx\n@three.fx\n")
            exclusions = make_exclusions(root)
            proxy = StreamingProxyStub()

            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "process_watchlist_target",
                side_effect=["OFFLINE", "LIVE", "OFFLINE"],
            ), patch.object(
                loop_runner, "process_single_live_discovery", return_value="LIVE"
            ) as discovery:
                visited, sequence = loop_runner.run_watchlist_round(
                    config=make_config(root),
                    round_number=1,
                    sequence_start=0,
                    snapshot=watchlist.read_snapshot(),
                    watchlist=watchlist,
                    exclusions=exclusions,
                    proxy_manager=proxy,
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )

            self.assertEqual(visited, 3)
            self.assertEqual(sequence, 4)
            discovery.assert_called_once()
            self.assertEqual(discovery.call_args.kwargs["search_query"], "mobile legend")

    def test_zero_or_multiple_live_does_not_trigger_discovery(self) -> None:
        for outcomes in (["OFFLINE", "OFFLINE"], ["LIVE", "LIVE"], ["LIVE", "LIVE", "LIVE"]):
            with self.subTest(outcomes=outcomes), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                content = "".join(f"@user{i}.fx\n" for i in range(len(outcomes)))
                watchlist = self.make_watchlist(root, content)
                with patch.object(loop_runner, "safe_print"), patch.object(
                    loop_runner, "process_watchlist_target", side_effect=outcomes
                ), patch.object(loop_runner, "process_single_live_discovery") as discovery:
                    loop_runner.run_watchlist_round(
                        config=make_config(root),
                        round_number=1,
                        sequence_start=0,
                        snapshot=watchlist.read_snapshot(),
                        watchlist=watchlist,
                        exclusions=make_exclusions(root),
                        proxy_manager=StreamingProxyStub(),
                        maintenance=MaintenanceStub(),
                        action_choice="3",
                    )
                discovery.assert_not_called()

    def test_watchlist_has_no_automatic_write_or_removal_method(self) -> None:
        source = inspect.getsource(loop_runner.LiveWatchlist)
        self.assertNotIn("atomic_write_text", source)
        self.assertNotIn("def remove", source)
        self.assertNotIn("unlink", source)


def make_config(root: Path, max_parallel: int = 2) -> dict:
    values = dict(loop_runner.CONFIG)
    values.update(
        {
            "max_parallel": max_parallel,
            "failed_logs_root": str(root / "failed"),
            "success_logs_root": str(root / "success"),
            "cycle_logs_root": str(root / "cycles"),
            "adb_health_state_file": str(root / "state" / "adb_health.json"),
        }
    )
    return values


def make_exclusions(root: Path, content: str = "") -> loop_runner.ExclusionList:
    path = root / "excluded_lists.txt"
    path.write_text(content, encoding="utf-8")
    return loop_runner.ExclusionList(path)


class OutcomeLoggingTests(unittest.TestCase):
    def test_successes_append_to_one_compact_cycle_file(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            config["compact_success_logging"] = True
            paths = []
            for serial in ("device-1:5555", "device-2:5555"):
                paths.append(loop_runner.write_minimal_result(
                    config=config,
                    cycle_id="cycle1",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serial=serial,
                    action_choice="3",
                    outcome=loop_runner.WorkerJobOutcome(
                        serial=serial,
                        code=0,
                        status="success",
                        submission_completed=True,
                        duration_seconds=1.25,
                    ),
                ))
            self.assertEqual(paths[0], paths[1])
            self.assertEqual(paths[0].name, "SUCCESS_DEVICES.jsonl")
            records = [json.loads(line) for line in paths[0].read_text(
                encoding="utf-8"
            ).splitlines()]
            self.assertEqual([item["device"] for item in records], [
                "device-1:5555", "device-2:5555"
            ])
            self.assertFalse((root / "success").exists())

    def test_live_ended_outcome_is_not_written_to_failed_logs(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            outcome = loop_runner.WorkerJobOutcome(
                serial="device:5555",
                code=0,
                status="live_ended",
                error_code="LIVE_ENDED_DURING_WORKFLOW",
                stage="SUBMIT",
                reason="LIVE_ENDED_DURING_WORKFLOW: TikTok explicitly ended the LIVE",
            )
            path = loop_runner.write_minimal_result(
                config=config,
                cycle_id="cycle1",
                live_url="https://www.tiktok.com/@target.fx/live",
                serial="device:5555",
                action_choice="3",
                outcome=outcome,
            )
            self.assertEqual(path.name, "LIVE_ENDED.json")
            self.assertIn("LIVE_ENDED_DURING_WORKFLOW", str(path))
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(payload["status"], "live_ended")
            self.assertEqual(payload["error"], "")
            self.assertFalse((root / "failed").exists())


class UiAutomatorCleanupTests(unittest.TestCase):
    def test_forced_child_cleanup_resets_only_project_owned_uiautomator(self) -> None:
        config = {
            "adb_executable": "adb",
            "uiautomator_device_lock_timeout_seconds": 1,
            "uiautomator_reset_settle_seconds": 0.2,
        }
        repair = {
            "before": ["123 com.wetest.uia2.Main"],
            "killed_pids": ["123"],
            "after": [],
        }
        with patch.object(loop_runner, "device_control_lease", return_value=nullcontext()), \
             patch.object(loop_runner, "stop_our_uiautomator_processes", return_value=repair) as stop:
            loop_runner.cleanup_uiautomator_after_forced_child_exit(
                config=config, serial="device:5555"
            )
        stop.assert_called_once()
        self.assertEqual(stop.call_args.args[:2], ("adb", "device:5555"))

    def test_shutdown_cleanup_runs_only_once_per_device(self) -> None:
        loop_runner.STOP_EVENT.set()
        with loop_runner.FORCED_CLEANUP_LOCK:
            loop_runner.FORCED_CLEANUP_DONE.clear()
        try:
            with patch.object(loop_runner, "force_stop_tiktok_after_forced_child_exit") as force, \
                 patch.object(loop_runner, "cleanup_uiautomator_after_forced_child_exit") as uia:
                for _ in range(2):
                    loop_runner.cleanup_forced_child_once(
                        config={}, serial="device:5555", action_choice="3"
                    )
            force.assert_called_once()
            uia.assert_called_once()
        finally:
            loop_runner.STOP_EVENT.clear()


class ShutdownTests(unittest.TestCase):
    def test_shutdown_coordinator_is_idempotent(self) -> None:
        class Manager:
            def __init__(self):
                self.stop_calls = 0
                self.close_calls = 0

            def request_stop(self):
                self.stop_calls += 1

            def close(self):
                self.close_calls += 1

        loop_runner.STOP_EVENT.clear()
        manager = Manager()
        coordinator = loop_runner.ShutdownCoordinator({})
        coordinator.attach_proxy_manager(manager)
        with patch.object(loop_runner, "terminate_active_processes") as terminate, \
             patch.object(loop_runner, "safe_print"):
            coordinator.request("ENTER")
            coordinator.request("Ctrl+C")
            coordinator.finalize()
            coordinator.finalize()
        self.assertTrue(loop_runner.STOP_EVENT.is_set())
        self.assertEqual(manager.stop_calls, 1)
        self.assertEqual(manager.close_calls, 1)
        terminate.assert_called_once()
        loop_runner.STOP_EVENT.clear()


class CheckerOrderingTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.clear()
        with loop_runner.DEVICE_MODEL_HINTS_LOCK:
            loop_runner.DEVICE_MODEL_HINTS.clear()

    def test_preferred_models_are_normalized_deduplicated_and_randomized(self) -> None:
        config = make_config(Path(tempfile.gettempdir()))
        config.update({
            "checker_preferred_models": ["SM_F721U1", "sm-f721u1", "Pixel 8"],
            "checker_use_speed_history": False,
        })
        serials = ["slow:5555", "fast-a:5555", "fast-b:5555", "pixel:5555", "fast-a:5555"]
        with loop_runner.DEVICE_MODEL_HINTS_LOCK:
            loop_runner.DEVICE_MODEL_HINTS.update({
                "fast-a:5555": "SM-F721U1",
                "fast-b:5555": "SM_F721U1",
                "pixel:5555": "Pixel 8",
            })
        with patch.object(loop_runner.random, "shuffle", side_effect=lambda values: values.reverse()):
            ordered = loop_runner.ordered_checker_candidates(config, serials)
        self.assertEqual(ordered, ["fast-b:5555", "fast-a:5555", "pixel:5555", "slow:5555"])
        self.assertEqual(serials, ["slow:5555", "fast-a:5555", "fast-b:5555", "pixel:5555", "fast-a:5555"])

    def test_speed_history_orders_only_the_shuffled_fallback_pool(self) -> None:
        config = make_config(Path(tempfile.gettempdir()))
        config.update({"checker_preferred_models": [], "checker_use_speed_history": True})
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.update({"a:5555": 1.0, "c:5555": 2.0})
        with patch.object(loop_runner.random, "shuffle", side_effect=lambda values: values.reverse()):
            ordered = loop_runner.ordered_checker_candidates(config, ["a:5555", "b:5555", "c:5555"])
        self.assertEqual(ordered, ["a:5555", "c:5555", "b:5555"])


    def test_random_preferred_pool_is_not_resorted_by_history_and_is_fresh_each_call(self) -> None:
        config = make_config(Path(tempfile.gettempdir()))
        config.update({"checker_preferred_models": " SM_F721U1 ", "checker_use_speed_history": True})
        serials = ["a:5555", "b:5555", "c:5555", "d:5555", "fallback:5555"]
        with loop_runner.DEVICE_MODEL_HINTS_LOCK:
            loop_runner.DEVICE_MODEL_HINTS.update({s: "sm_f721u1" for s in serials[:4]})
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.update({s: i + 1 for i, s in enumerate(serials)})
        with patch.object(loop_runner.random, "shuffle", side_effect=lambda values: values.reverse()) as shuffle:
            first = loop_runner.ordered_checker_candidates(config, serials)
            second = loop_runner.ordered_checker_candidates(config, serials)
        self.assertEqual(first[:3], ["d:5555", "c:5555", "b:5555"])
        self.assertEqual(first, second)
        self.assertEqual(shuffle.call_count, 4)  # Preferred and fallback pools on each invocation.

    def test_fallback_equal_and_unknown_speeds_retain_shuffled_order(self) -> None:
        config = make_config(Path(tempfile.gettempdir()))
        config.update({"checker_preferred_models": [], "checker_use_speed_history": True})
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.update({"a:5555": 1, "b:5555": 1})
        with patch.object(loop_runner.random, "shuffle", side_effect=lambda values: values.reverse()):
            serials = ["a:5555", "b:5555", "c:5555", "d:5555"]
            self.assertEqual(loop_runner.ordered_checker_candidates(config, serials), ["b:5555", "a:5555", "d:5555", "c:5555"])
            config["checker_use_speed_history"] = False
            self.assertEqual(loop_runner.ordered_checker_candidates(config, serials), list(reversed(serials)))


class SummaryTests(unittest.TestCase):
    def test_precheck_and_discovery_summaries_include_attempts(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            attempts = (
                loop_runner.CheckerAttemptOutcome(
                    "checker:5555", "sm-f721u1", "UNKNOWN", "CHECKER_PROXY_FAILED",
                    "proxy unavailable", proxy_seconds=0.1239,
                ),
            )
            precheck_path = loop_runner.write_precheck_summary(
                config=config,
                cycle_id="summary",
                live_url="https://www.tiktok.com/@target.fx/live",
                precheck=loop_runner.LivePrecheckOutcome("UNKNOWN", attempts=attempts),
            )
            discovery_path = loop_runner.write_discovery_summary(
                config=config,
                cycle_id="summary",
                search_query="mobile legend",
                discovery=loop_runner.LiveDiscoveryOutcome("NONE", attempts=attempts),
            )
            precheck = json.loads(precheck_path.read_text(encoding="utf-8"))
            discovery = json.loads(discovery_path.read_text(encoding="utf-8"))
        self.assertEqual(precheck["decision_rule"], "any_live")
        self.assertEqual(discovery["decision_rule"], "first_found")
        self.assertEqual(precheck["attempts"][0]["proxy_seconds"], 0.124)
        self.assertEqual(discovery["attempts"][0]["error_code"], "CHECKER_PROXY_FAILED")

    def test_discovery_writes_summary_before_handing_found_target_to_workflow(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            discovery = loop_runner.LiveDiscoveryOutcome(
                "FOUND", username="mlbb.live", live_url="https://www.tiktok.com/@mlbb.live/live",
                serial="checker:5555",
            )
            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "refresh_connected_tcp_devices", return_value=["checker:5555"]
            ), patch.object(
                loop_runner, "run_global_live_discovery", return_value=discovery
            ), patch.object(
                loop_runner, "process_watchlist_target", return_value="LIVE"
            ) as target:
                result = loop_runner.process_single_live_discovery(
                    config=config, cycle_id="handoff", search_query="mobile legend",
                    watchlist=watchlist, exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(), maintenance=MaintenanceStub(), action_choice="3",
                )
            self.assertEqual(result, "LIVE")
            self.assertTrue((root / "cycles" / "handoff" / "LIVE_DISCOVERY.json").is_file())
            self.assertTrue(target.call_args.kwargs["preconfirmed_live"].status == "LIVE")
            self.assertFalse(target.call_args.kwargs["require_watchlist_membership"])


class GlobalPrecheckTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()
        shuffle = patch.object(loop_runner.random, "shuffle", side_effect=lambda values: None)
        shuffle.start()
        self.addCleanup(shuffle.stop)
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.clear()
        with loop_runner.DEVICE_MODEL_HINTS_LOCK:
            loop_runner.DEVICE_MODEL_HINTS.clear()

    def test_hard_timeout_can_recover_latest_stage_from_console(self) -> None:
        console = [
            "INFO STEP | SEARCH_OPEN | Open TikTok Search",
            "INFO STEP | SEARCH_USERS_TAB | Select TikTok Users results",
        ]
        self.assertEqual(
            loop_runner.latest_precheck_stage(console), "SEARCH_USERS_TAB"
        )

    def test_timeout_log_includes_stage_and_elapsed(self) -> None:
        outcome = loop_runner.LivePrecheckOutcome(
            "UNKNOWN",
            "checker:5555",
            "LIVE_PRECHECK_TIMEOUT",
            "shared deadline exhausted | stage=SEARCH_OPEN",
            duration_seconds=79.1,
        )
        with patch.object(loop_runner, "safe_print") as printer:
            loop_runner.log_live_precheck(
                "https://www.tiktok.com/@target.fx/live", outcome
            )
        line = printer.call_args.args[0]
        self.assertIn("stage=SEARCH_OPEN", line)
        self.assertIn("elapsed=79.1s", line)

    def test_forced_child_exit_force_stops_detected_tiktok_package(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = make_config(Path(directory))
            with patch.object(
                loop_runner,
                "workflow_template",
                return_value={
                    "tiktok_package": "auto",
                    "tiktok_packages": ["com.ss.android.ugc.trill"],
                    "cleanup_timeout_seconds": 2,
                },
            ), patch.object(loop_runner.subprocess, "run") as runner:
                loop_runner.force_stop_tiktok_after_forced_child_exit(
                    config=config,
                    serial="checker:5555",
                    action_choice="3",
                    metadata={"tiktok_package": "com.detected.tiktok"},
                )

            commands = [call.args[0] for call in runner.call_args_list]
            self.assertEqual(
                commands[0],
                [
                    str(config.get("adb_executable", "adb")),
                    "-s",
                    "checker:5555",
                    "shell",
                    "am",
                    "force-stop",
                    "com.detected.tiktok",
                ],
            )

    def test_timed_out_child_finishes_before_next_process_starts(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = loop_runner.run_process_quiet(
                [sys.executable, "-c", "import time; time.sleep(5)"],
                cwd=root,
                timeout_seconds=0.1,
                detailed_logging=False,
            )
            self.assertTrue(first[3])
            self.assertFalse(loop_runner.ACTIVE_PROCESSES)
            second = loop_runner.run_process_quiet(
                [sys.executable, "-c", "print('next-ready')"],
                cwd=root,
                timeout_seconds=3,
                detailed_logging=False,
            )
            self.assertEqual(second[0], 0)
            self.assertIn("next-ready", second[1])
            self.assertFalse(loop_runner.ACTIVE_PROCESSES)

    def test_first_selected_device_live_stops_precheck_early(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub()
            expected = loop_runner.LivePrecheckOutcome(
                "LIVE", "checker:5555", workflow_seconds=0.2
            )
            with patch.object(
                loop_runner, "run_live_precheck_job", return_value=expected
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root),
                    cycle_id="one_checker",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=proxy,
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertEqual(result.status, "LIVE")
            self.assertEqual(proxy.prepare_calls, [["checker:5555"]])
            self.assertEqual(child.call_count, 1)
            self.assertEqual(child.call_args.kwargs["serial"], "checker:5555")

    def test_two_offline_then_one_live_accepts_any_verified_live(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = [
                loop_runner.LivePrecheckOutcome("OFFLINE", "checker:5555", workflow_seconds=0.1),
                loop_runner.LivePrecheckOutcome("OFFLINE", "other:5555", workflow_seconds=0.2),
                loop_runner.LivePrecheckOutcome("LIVE", "third:5555", workflow_seconds=0.3),
            ]
            with patch.object(loop_runner, "run_live_precheck_job", side_effect=outcomes) as child:
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root),
                    cycle_id="any_live",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )
            self.assertEqual(result.status, "LIVE")
            self.assertEqual(result.serial, "third:5555")
            self.assertAlmostEqual(result.workflow_seconds, 0.6)
            self.assertEqual([item.status for item in result.attempts], ["OFFLINE", "OFFLINE", "LIVE"])
            self.assertEqual(child.call_count, 3)

    def test_unknown_then_offline_then_live_accepts_live(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = [
                loop_runner.LivePrecheckOutcome("UNKNOWN", "checker:5555", "LIVE_PRECHECK_TIMEOUT", workflow_seconds=0.1),
                loop_runner.LivePrecheckOutcome("OFFLINE", "other:5555", workflow_seconds=0.2),
                loop_runner.LivePrecheckOutcome("LIVE", "third:5555", workflow_seconds=0.3),
            ]
            with patch.object(loop_runner, "run_live_precheck_job", side_effect=outcomes):
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root), cycle_id="unknown_then_live",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=StreamingProxyStub(), exclusions=make_exclusions(root), action_choice="3",
                )
            self.assertEqual(result.status, "LIVE")
            self.assertEqual(result.error_code, "")
            self.assertEqual(len(result.attempts), 3)

    def test_all_offline_returns_last_offline_after_three_checks(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = [
                loop_runner.LivePrecheckOutcome("OFFLINE", serial, workflow_seconds=0.1)
                for serial in ("checker:5555", "other:5555", "third:5555")
            ]
            with patch.object(loop_runner, "run_live_precheck_job", side_effect=outcomes):
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root), cycle_id="all_offline",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555", "fourth:5555"],
                    proxy_manager=StreamingProxyStub(), exclusions=make_exclusions(root), action_choice="3",
                )
            self.assertEqual(result.status, "OFFLINE")
            self.assertEqual(result.serial, "third:5555")
            self.assertEqual(len(result.attempts), 3)

    def test_proxy_failure_does_not_allow_a_fourth_checker(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            proxy = StreamingProxyStub({"checker:5555"})
            with patch.object(
                loop_runner,
                "run_live_precheck_job",
                side_effect=[
                    loop_runner.LivePrecheckOutcome("OFFLINE", "other:5555"),
                    loop_runner.LivePrecheckOutcome("OFFLINE", "third:5555"),
                ],
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=config, cycle_id="no_fourth", live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555", "fourth:5555"],
                    proxy_manager=proxy, exclusions=make_exclusions(root), action_choice="3",
                )
            self.assertEqual(result.status, "UNKNOWN")
            self.assertEqual(result.error_code, "CHECKER_PROXY_FAILED")
            self.assertEqual(proxy.prepare_calls, [["checker:5555"], ["other:5555"], ["third:5555"]])
            self.assertEqual(child.call_count, 2)

    def test_duplicate_serials_and_configured_limit_are_not_retried(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            config["checker_max_devices"] = 2
            with patch.object(
                loop_runner,
                "run_live_precheck_job",
                side_effect=[
                    loop_runner.LivePrecheckOutcome("OFFLINE", "checker:5555"),
                    loop_runner.LivePrecheckOutcome("OFFLINE", "other:5555"),
                ],
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=config, cycle_id="dedupe", live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "checker:5555", "other:5555", "third:5555"],
                    proxy_manager=StreamingProxyStub(), exclusions=make_exclusions(root), action_choice="3",
                )
            self.assertEqual(result.status, "OFFLINE")
            self.assertEqual([call.kwargs["serial"] for call in child.call_args_list], ["checker:5555", "other:5555"])

    def test_preferred_checker_model_is_used_without_extra_adb_probe(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            config["checker_preferred_models"] = ["SM-F721U1"]
            with loop_runner.DEVICE_MODEL_HINTS_LOCK:
                loop_runner.DEVICE_MODEL_HINTS.update({
                    "slow:5555": "SM-G950U",
                    "fast:5555": "SM-F721U1",
                })
            proxy = StreamingProxyStub()
            expected = loop_runner.LivePrecheckOutcome(
                "LIVE", "fast:5555", workflow_seconds=0.2
            )
            with patch.object(
                loop_runner, "run_live_precheck_job", return_value=expected
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=config,
                    cycle_id="preferred_checker",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["slow:5555", "fast:5555"],
                    proxy_manager=proxy,
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )
            self.assertEqual(result.status, "LIVE")
            self.assertEqual(proxy.prepare_calls, [["fast:5555"]])
            self.assertEqual(child.call_args.kwargs["serial"], "fast:5555")

    def test_checker_proxy_failure_is_unknown_without_child_start(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub({"checker:5555", "other:5555", "third:5555"})
            with patch.object(loop_runner, "run_live_precheck_job") as child:
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root),
                    cycle_id="proxy_unknown",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555", "fourth:5555"],
                    proxy_manager=proxy,
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertEqual(result.status, "UNKNOWN")
            self.assertEqual(result.error_code, "CHECKER_PROXY_FAILED")
            self.assertEqual(
                proxy.prepare_calls,
                [["checker:5555"], ["other:5555"], ["third:5555"]],
            )
            child.assert_not_called()

    def test_unhealthy_checker_device_falls_back_to_next_checker(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub()
            outcomes = [
                loop_runner.LivePrecheckOutcome(
                    "UNKNOWN",
                    "checker:5555",
                    "UIAUTOMATOR_CONNECTION_FAILED",
                    "AccessibilityServiceAlreadyRegisteredError",
                    workflow_seconds=0.1,
                ),
                loop_runner.LivePrecheckOutcome(
                    "LIVE", "other:5555", workflow_seconds=0.2
                ),
            ]
            with patch.object(
                loop_runner, "run_live_precheck_job", side_effect=outcomes
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root),
                    cycle_id="checker_fallback",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=proxy,
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertEqual(result.status, "LIVE")
            self.assertEqual(result.serial, "other:5555")
            self.assertEqual(proxy.prepare_calls, [["checker:5555"], ["other:5555"]])
            self.assertEqual(child.call_count, 2)
            self.assertEqual(
                [call.kwargs["serial"] for call in child.call_args_list],
                ["checker:5555", "other:5555"],
            )

    def test_checker_uses_one_working_proxy_ready_device(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub({"checker:5555"})
            expected = loop_runner.LivePrecheckOutcome(
                "LIVE", "other:5555", workflow_seconds=0.2
            )
            with patch.object(
                loop_runner, "run_live_precheck_job", return_value=expected
            ) as child:
                result = loop_runner.run_global_live_precheck(
                    config=make_config(root),
                    cycle_id="second_checker",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=proxy,
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertEqual(result.status, "LIVE")
            self.assertEqual(proxy.prepare_calls, [["checker:5555"], ["other:5555"]])
            child.assert_called_once()
            self.assertEqual(child.call_args.kwargs["serial"], "other:5555")


class GlobalDiscoveryTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()
        shuffle = patch.object(loop_runner.random, "shuffle", side_effect=lambda values: None)
        shuffle.start()
        self.addCleanup(shuffle.stop)
        with loop_runner.CHECKER_SPEED_LOCK:
            loop_runner.CHECKER_SPEED_SECONDS.clear()
        with loop_runner.DEVICE_MODEL_HINTS_LOCK:
            loop_runner.DEVICE_MODEL_HINTS.clear()

    def test_no_result_on_one_checker_tries_next_and_finds_live(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub()
            outcomes = [
                loop_runner.LiveDiscoveryOutcome(
                    "NONE",
                    serial="checker:5555",
                    error_code="DISCOVERY_NO_LIVE_RESULT",
                    reason="this checker exposed no usable card",
                    workflow_seconds=0.2,
                ),
                loop_runner.LiveDiscoveryOutcome(
                    "FOUND",
                    username="rixixi_",
                    live_url="https://www.tiktok.com/@rixixi_/live",
                    serial="other:5555",
                    workflow_seconds=0.3,
                ),
            ]
            with patch.object(
                loop_runner, "run_live_discovery_job", side_effect=outcomes
            ) as child, patch.object(loop_runner, "safe_print"):
                result = loop_runner.run_global_live_discovery(
                    config=make_config(root),
                    cycle_id="discovery_checker_fallback",
                    search_query="mobile legend",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=proxy,
                    action_choice="3",
                )

            self.assertEqual(result.status, "FOUND")
            self.assertEqual(result.username, "rixixi_")
            self.assertEqual(proxy.prepare_calls, [["checker:5555"], ["other:5555"]])
            self.assertEqual(
                [call.kwargs["serial"] for call in child.call_args_list],
                ["checker:5555", "other:5555"],
            )

    def test_stale_candidates_on_one_checker_try_next_checker(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub()
            outcomes = [
                loop_runner.LiveDiscoveryOutcome(
                    "NONE",
                    serial="checker:5555",
                    error_code="DISCOVERY_STALE_LIVE_RESULT",
                    reason="all bounded visible candidates resolved stale",
                    workflow_seconds=0.2,
                ),
                loop_runner.LiveDiscoveryOutcome(
                    "FOUND",
                    username="mlbb.second",
                    live_url="https://www.tiktok.com/@mlbb.second/live",
                    serial="other:5555",
                    workflow_seconds=0.3,
                ),
            ]
            with patch.object(
                loop_runner, "run_live_discovery_job", side_effect=outcomes
            ) as child, patch.object(loop_runner, "safe_print"):
                result = loop_runner.run_global_live_discovery(
                    config=make_config(root),
                    cycle_id="discovery_stale_checker_fallback",
                    search_query="mobile legend",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=proxy,
                    action_choice="3",
                )

            self.assertEqual(result.status, "FOUND")
            self.assertEqual(result.username, "mlbb.second")
            self.assertEqual(child.call_count, 2)

    def test_all_bounded_checkers_without_cards_return_none(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proxy = StreamingProxyStub()
            outcomes = [
                loop_runner.LiveDiscoveryOutcome(
                    "NONE",
                    serial=serial,
                    error_code="DISCOVERY_NO_LIVE_RESULT",
                    reason="no usable result on this checker",
                    workflow_seconds=0.2,
                )
                for serial in ("checker:5555", "other:5555", "third:5555")
            ]
            with patch.object(
                loop_runner, "run_live_discovery_job", side_effect=outcomes
            ) as child, patch.object(loop_runner, "safe_print"):
                result = loop_runner.run_global_live_discovery(
                    config=make_config(root),
                    cycle_id="discovery_all_none",
                    search_query="mobile legend",
                    serials=["checker:5555", "other:5555", "third:5555", "fourth:5555"],
                    proxy_manager=proxy,
                    action_choice="3",
                )

            self.assertEqual(result.status, "NONE")
            self.assertEqual(result.error_code, "DISCOVERY_NO_LIVE_RESULT")
            self.assertEqual(child.call_count, 3)
            self.assertEqual(
                proxy.prepare_calls,
                [["checker:5555"], ["other:5555"], ["third:5555"]],
            )

    def test_unknown_then_found_retries_next_distinct_device(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = [
                loop_runner.LiveDiscoveryOutcome("UNKNOWN", serial="checker:5555", error_code="LIVE_DISCOVERY_TIMEOUT", workflow_seconds=0.1),
                loop_runner.LiveDiscoveryOutcome(
                    "FOUND", username="mlbb.live", live_url="https://www.tiktok.com/@mlbb.live/live",
                    serial="other:5555", workflow_seconds=0.2,
                ),
            ]
            with patch.object(loop_runner, "run_live_discovery_job", side_effect=outcomes) as child:
                result = loop_runner.run_global_live_discovery(
                    config=make_config(root), cycle_id="unknown_found", search_query="mobile legend",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=StreamingProxyStub(), action_choice="3",
                )
            self.assertEqual(result.status, "FOUND")
            self.assertEqual(result.username, "mlbb.live")
            self.assertAlmostEqual(result.workflow_seconds, 0.3)
            self.assertEqual([call.kwargs["serial"] for call in child.call_args_list], ["checker:5555", "other:5555"])

    def test_last_unknown_wins_over_no_result_when_no_live_is_found(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = [
                loop_runner.LiveDiscoveryOutcome("NONE", serial="checker:5555", error_code="DISCOVERY_NO_LIVE_RESULT"),
                loop_runner.LiveDiscoveryOutcome("UNKNOWN", serial="other:5555", error_code="LIVE_DISCOVERY_TIMEOUT"),
                loop_runner.LiveDiscoveryOutcome("NONE", serial="third:5555", error_code="DISCOVERY_STALE_LIVE_RESULT"),
            ]
            with patch.object(loop_runner, "run_live_discovery_job", side_effect=outcomes):
                result = loop_runner.run_global_live_discovery(
                    config=make_config(root), cycle_id="unknown_priority", search_query="mobile legend",
                    serials=["checker:5555", "other:5555", "third:5555"],
                    proxy_manager=StreamingProxyStub(), action_choice="3",
                )
            self.assertEqual(result.status, "UNKNOWN")
            self.assertEqual(result.error_code, "LIVE_DISCOVERY_TIMEOUT")
            self.assertEqual(len(result.attempts), 3)


class BoundedCheckerContractTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()
        self.addCleanup(loop_runner.STOP_EVENT.clear)
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = make_config(self.root)
        self.config.update({"checker_max_devices": 3, "checker_preferred_models": [], "checker_use_speed_history": False})
        self.serials = ["a:5555", "b:5555", "c:5555", "d:5555"]
        self.exclusions = Mock()
        self.exclusions.contains.return_value = False
        shuffle = patch.object(loop_runner.random, "shuffle", side_effect=lambda values: None)
        shuffle.start()
        self.addCleanup(shuffle.stop)

    def outcome(self, kind, status, serial, **kwargs):
        cls = loop_runner.LivePrecheckOutcome if kind == "precheck" else loop_runner.LiveDiscoveryOutcome
        if status == "FOUND":
            kwargs.update(username="mlbb.live", live_url="https://www.tiktok.com/@mlbb.live/live")
        return cls(status=status, serial=serial, **kwargs)

    def run_check(self, kind, proxy, serials=None):
        kwargs = dict(config=self.config, cycle_id="contract", serials=self.serials if serials is None else serials,
                      proxy_manager=proxy, action_choice="3")
        if kind == "precheck":
            kwargs.update(live_url="https://www.tiktok.com/@target.fx/live", exclusions=self.exclusions)
        else:
            kwargs["search_query"] = "mobile legend"
        return getattr(loop_runner, "run_global_live_" + kind)(**kwargs)

    def test_exhaustion_preserves_unknown_diagnostics_and_proxy_uncertainty(self) -> None:
        cases = (
            ("precheck", ["OFFLINE", "UNKNOWN", "OFFLINE"], "UNKNOWN", 1),
            ("precheck", ["UNKNOWN", "UNKNOWN", "UNKNOWN"], "UNKNOWN", 2),
            ("precheck", ["PROXY", "UNKNOWN", "OFFLINE"], "UNKNOWN", 1),
            ("discovery", ["NONE", "UNKNOWN", "NONE"], "UNKNOWN", 1),
            ("discovery", ["UNKNOWN", "UNKNOWN", "UNKNOWN"], "UNKNOWN", 2),
            ("discovery", ["NONE", "PROXY", "PROXY"], "NONE", 0),
            ("discovery", ["PROXY", "PROXY", "PROXY"], "UNKNOWN", 2),
        )
        for kind, statuses, expected_status, representative in cases:
            with self.subTest(kind=kind, statuses=statuses):
                proxy = StreamingProxyStub({s for s, status in zip(self.serials, statuses) if status == "PROXY"})
                outcomes = [self.outcome(kind, status, serial, error_code="TEST_UNKNOWN" if status == "UNKNOWN" else "",
                                         reason=f"diagnostic-{i}")
                            for i, (serial, status) in enumerate(zip(self.serials, statuses)) if status != "PROXY"]
                with patch.object(loop_runner, "run_live_" + kind + "_job", side_effect=outcomes) as child:
                    result = self.run_check(kind, proxy)
                self.assertEqual(result.status, expected_status)
                self.assertEqual(result.serial, self.serials[representative])
                self.assertEqual(len(result.attempts), 3)
                self.assertEqual(child.call_count, len(outcomes))
                if "UNKNOWN" in statuses:
                    self.assertEqual(result.error_code, "TEST_UNKNOWN")
                    self.assertEqual(result.reason, f"diagnostic-{representative}")
                if statuses == ["PROXY"] * 3:
                    self.assertEqual(result.error_code, "DISCOVERY_PROXY_FAILED")

    def test_stop_before_work_and_no_devices_have_no_attempts(self) -> None:
        for kind in ("precheck", "discovery"):
            for stopped in (False, True):
                with self.subTest(kind=kind, stopped=stopped):
                    loop_runner.STOP_EVENT.set() if stopped else loop_runner.STOP_EVENT.clear()
                    proxy = Mock()
                    result = self.run_check(kind, proxy, serials=[])
                    self.assertEqual(result.error_code, "CANCELLED" if stopped else "NO_CHECKER_DEVICE")
                    self.assertEqual(result.attempts, ())
                    self.assertGreaterEqual(result.duration_seconds, 0)
                    proxy.prepare_stream.assert_not_called()

    def test_malformed_preparation_consumes_one_slot_and_a_later_success_can_win(self) -> None:
        for kind, success in (("precheck", "LIVE"), ("discovery", "FOUND")):
            for response in ([], [("bad", True, "", "")], [("a:5555", True)], [None], [("a:5555", False, "", "failed")]):
                with self.subTest(kind=kind, response=response):
                    proxy = Mock(prepare_stream=Mock(side_effect=[response, [("b:5555", True, "", "")]]))
                    with patch.object(loop_runner, "run_live_" + kind + "_job", return_value=self.outcome(kind, success, "b:5555")) as child:
                        result = self.run_check(kind, proxy)
                    self.assertEqual((result.status, result.serial, result.error_code), (success, "b:5555", ""))
                    self.assertEqual(len(result.attempts), 2)
                    self.assertFalse(result.attempts[0].workflow_started)
                    self.assertEqual(result.attempts[0].workflow_seconds, 0)
                    self.assertEqual(result.attempts[0].error_code, "CHECKER_PROXY_FAILED" if kind == "precheck" else "DISCOVERY_PROXY_FAILED")
                    child.assert_called_once()

    def test_cancellation_during_any_proxy_response_is_never_proxy_failure(self) -> None:
        for kind in ("precheck", "discovery"):
            for response in ([], [("wrong:5555", True, "", "")], [("a:5555", False, "", "unavailable")], [("a:5555", True, "", "")]):
                with self.subTest(kind=kind, response=response):
                    loop_runner.STOP_EVENT.clear()
                    def prepare(*_args):
                        loop_runner.STOP_EVENT.set()
                        return response
                    proxy = Mock(prepare_stream=Mock(side_effect=prepare))
                    with patch.object(loop_runner, "run_live_" + kind + "_job") as child:
                        result = self.run_check(kind, proxy)
                    self.assertTrue(result.cancelled)
                    self.assertEqual((result.serial, result.error_code), ("a:5555", "CANCELLED"))
                    self.assertEqual(len(result.attempts), 1)
                    self.assertEqual(result.attempts[0].error_code, "CANCELLED")
                    self.assertFalse(result.attempts[0].workflow_started)
                    child.assert_not_called()
                    proxy.prepare_stream.assert_called_once()

    def test_stop_between_candidates_does_not_fabricate_an_attempt_or_identity(self) -> None:
        for kind in ("precheck", "discovery"):
            with self.subTest(kind=kind), patch.object(loop_runner.STOP_EVENT, "is_set", side_effect=[False, False, False, False, True]), patch.object(
                loop_runner, "run_live_" + kind + "_job", return_value=self.outcome(kind, "UNKNOWN", "a:5555")
            ) as child:
                result = self.run_check(kind, StreamingProxyStub())
            self.assertEqual((result.serial, result.error_code, result.reason), ("b:5555", "CANCELLED", "shutdown requested"))
            self.assertTrue(result.cancelled)
            self.assertEqual(len(result.attempts), 1)
            child.assert_called_once()
            if kind == "discovery":
                self.assertEqual((result.username, result.live_url), ("", ""))

    def test_fatal_and_cancelled_children_stop_before_accepting_success(self) -> None:
        for kind, success in (("precheck", "LIVE"), ("discovery", "FOUND")):
            for guard in ("INTERNAL_PROGRAM_ERROR", "CANCELLED", "STOP_EVENT"):
                with self.subTest(kind=kind, guard=guard):
                    loop_runner.STOP_EVENT.clear()
                    def child_result(**_kwargs):
                        if guard == "STOP_EVENT":
                            loop_runner.STOP_EVENT.set()
                        return self.outcome(kind, "UNKNOWN" if guard == "INTERNAL_PROGRAM_ERROR" else success,
                                            "a:5555", error_code=guard if guard == "INTERNAL_PROGRAM_ERROR" else "",
                                            cancelled=guard == "CANCELLED", workflow_seconds=2)
                    with patch.object(loop_runner, "run_live_" + kind + "_job", side_effect=child_result) as child:
                        result = self.run_check(kind, StreamingProxyStub())
                    self.assertEqual(result.error_code, "INTERNAL_PROGRAM_ERROR" if guard == "INTERNAL_PROGRAM_ERROR" else "CANCELLED")
                    self.assertEqual(result.status, "UNKNOWN")
                    self.assertEqual(len(result.attempts), 1)
                    self.assertEqual(result.workflow_seconds, 2)
                    child.assert_called_once()

    def test_exclusion_before_during_preparation_and_after_child_prevents_more_work(self) -> None:
        for stage in ("before", "prepare_empty", "prepare_ready", "child"):
            with self.subTest(stage=stage):
                self.exclusions.contains.return_value = stage == "before"
                def prepare(*_args):
                    self.exclusions.contains.return_value = stage.startswith("prepare")
                    return [] if stage == "prepare_empty" else [("a:5555", True, "", "")]
                def child_result(**_kwargs):
                    self.exclusions.contains.return_value = True
                    return self.outcome("precheck", "LIVE", "a:5555")
                proxy = Mock(prepare_stream=Mock(side_effect=prepare))
                with patch.object(loop_runner, "run_live_precheck_job", side_effect=child_result) as child:
                    result = self.run_check("precheck", proxy)
                self.assertEqual((result.status, result.error_code), ("UNKNOWN", "TARGET_EXCLUDED"))
                self.assertEqual(child.call_count, int(stage == "child"))
                self.assertEqual(len(result.attempts), int(stage != "before"))

    def test_proxy_and_child_timings_are_separate_and_speed_cache_uses_each_child(self) -> None:
        for kind, negative, success in (("precheck", "OFFLINE", "LIVE"), ("discovery", "NONE", "FOUND")):
            with self.subTest(kind=kind):
                now = [100.0]
                def prepare(serials, _context):
                    now[0] += 2
                    return [(serials[0], True, "", "")]
                def child_result(**kwargs):
                    serial = kwargs["serial"]
                    seconds = 5.0 if serial == "a:5555" else 7.0
                    now[0] += seconds
                    return self.outcome(kind, negative if serial == "a:5555" else success, serial, workflow_seconds=seconds)
                with patch.object(loop_runner.time, "monotonic", side_effect=lambda: now[0]), patch.object(
                    loop_runner, "remember_checker_speed"
                ) as speed, patch.object(loop_runner, "run_live_" + kind + "_job", side_effect=child_result):
                    result = self.run_check(kind, Mock(prepare_stream=Mock(side_effect=prepare)))
                self.assertEqual((result.proxy_seconds, result.workflow_seconds, result.duration_seconds), (4.0, 12.0, 16.0))
                self.assertEqual([a.proxy_seconds for a in result.attempts], [2, 2])
                self.assertEqual([a.workflow_seconds for a in result.attempts], [5, 7])
                self.assertEqual(speed.call_args_list, [call("a:5555", 5.0), call("b:5555", 7.0)])

    def test_each_checker_proxy_is_released_after_its_workflow(self) -> None:
        for kind, negative, success in (
            ("precheck", "OFFLINE", "LIVE"),
            ("discovery", "NONE", "FOUND"),
        ):
            with self.subTest(kind=kind):
                proxy = StreamingProxyStub()
                results = [
                    self.outcome(kind, negative, "a:5555"),
                    self.outcome(kind, success, "b:5555"),
                ]
                with patch.object(
                    loop_runner, "run_live_" + kind + "_job", side_effect=results
                ):
                    result = self.run_check(kind, proxy)
                self.assertEqual(result.status, success)
                self.assertEqual(proxy.released, ["a:5555", "b:5555"])

    def test_discovery_limits_devices_once_even_after_proxy_or_excluded_target(self) -> None:
        for limit in (1, 2, 3, 9):
            with self.subTest(limit=limit):
                self.config["checker_max_devices"] = limit
                proxy = StreamingProxyStub({"a:5555"})
                with patch.object(loop_runner, "run_live_discovery_job", side_effect=lambda **kw: self.outcome(
                    "discovery", "NONE", kw["serial"], error_code="DISCOVERY_TARGET_EXCLUDED"
                )) as child:
                    result = self.run_check("discovery", proxy, serials=["a:5555", "a:5555"] + self.serials[1:])
                self.assertEqual(proxy.prepare_calls, [[s] for s in self.serials[:min(3, limit)]])
                self.assertEqual(child.call_count, min(3, limit) - 1)
                self.assertEqual(len(result.attempts), min(3, limit))


    def test_real_global_precheck_controls_the_full_pipeline_and_honors_late_removal(self) -> None:
        for statuses, late_change, expected in (
            (["OFFLINE", "OFFLINE", "LIVE"], "", "LIVE"),
            (["OFFLINE", "OFFLINE", "OFFLINE"], "", "OFFLINE"),
            (["UNKNOWN", "OFFLINE", "UNKNOWN"], "", "UNKNOWN"),
            (["OFFLINE", "OFFLINE", "LIVE"], "remove", "REMOVED"),
            (["OFFLINE", "OFFLINE", "LIVE"], "exclude", "EXCLUDED"),
        ):
            with self.subTest(statuses=statuses, late_change=late_change):
                self.exclusions.contains.return_value = False
                watchlist = loop_runner.LiveWatchlist(self.root / "list_urls.txt")
                watchlist.path.write_text("@target.fx\n", encoding="utf-8")
                maintenance = MaintenanceStub()
                proxy = StreamingProxyStub()
                def child_result(**kwargs):
                    status = statuses[self.serials.index(kwargs["serial"])]
                    if status == "LIVE" and late_change == "remove":
                        watchlist.path.write_text("", encoding="utf-8")
                    if status == "LIVE" and late_change == "exclude":
                        self.exclusions.contains.return_value = True
                    return self.outcome("precheck", status, kwargs["serial"])
                with patch.object(loop_runner, "refresh_connected_tcp_devices", return_value=self.serials), patch.object(
                    loop_runner, "run_live_precheck_job", side_effect=child_result
                ) as child, patch.object(loop_runner, "run_streaming_device_pipeline", return_value=(
                    loop_runner.WorkerBatchOutcome(), {"proxy_ready": 0, "proxy_total": 0, "reporting": 0}
                )) as pipeline, patch.object(loop_runner, "safe_print"):
                    result = loop_runner.process_watchlist_target(
                        config=self.config, cycle_id="contract", live_url="https://www.tiktok.com/@target.fx/live",
                        watchlist=watchlist, exclusions=self.exclusions, proxy_manager=proxy, maintenance=maintenance, action_choice="3",
                    )
                self.assertEqual(result, expected)
                self.assertEqual(child.call_count, 3)
                self.assertEqual(pipeline.call_count, int(expected == "LIVE"))
                if expected == "LIVE":
                    self.assertEqual(pipeline.call_args.kwargs["serials"], self.serials)
                self.assertEqual(maintenance.calls, 1)
                self.assertEqual(proxy.events.count("health_log"), 1)

    def test_discovery_summary_precedes_handoff_and_cleanup_occurs_once(self) -> None:
        for status, excluded in (("FOUND", False), ("FOUND", True), ("NONE", False), ("UNKNOWN", False)):
            with self.subTest(status=status, excluded=excluded):
                self.exclusions.contains.return_value = excluded
                maintenance = MaintenanceStub()
                proxy = StreamingProxyStub()
                discovery = self.outcome("discovery", status, "a:5555")
                watchlist = loop_runner.LiveWatchlist(self.root / "list_urls.txt")
                def pipeline_result(**_kwargs):
                    data = json.loads((self.root / "cycles" / "contract" / "LIVE_DISCOVERY.json").read_text(encoding="utf-8"))
                    self.assertEqual(data["status"], status)
                    return loop_runner.WorkerBatchOutcome(), {"proxy_ready": 0, "proxy_total": 0, "reporting": 0}
                with patch.object(loop_runner, "refresh_connected_tcp_devices", return_value=self.serials), patch.object(
                    loop_runner, "run_global_live_discovery", return_value=discovery
                ), patch.object(loop_runner, "run_global_live_precheck") as precheck, patch.object(
                    loop_runner, "run_streaming_device_pipeline", side_effect=pipeline_result
                ) as pipeline, patch.object(loop_runner, "safe_print"):
                    result = loop_runner.process_single_live_discovery(
                        config=self.config, cycle_id="contract", search_query="mobile legend", watchlist=watchlist,
                        exclusions=self.exclusions, proxy_manager=proxy, maintenance=maintenance, action_choice="3",
                    )
                self.assertEqual(result, "EXCLUDED" if excluded else "LIVE" if status == "FOUND" else status)
                self.assertEqual(pipeline.call_count, int(status == "FOUND" and not excluded))
                precheck.assert_not_called()
                self.assertEqual(maintenance.calls, 1)
                self.assertEqual(proxy.events.count("health_log"), 1)
                data = json.loads((self.root / "cycles" / "contract" / "LIVE_DISCOVERY.json").read_text(encoding="utf-8"))
                self.assertEqual(data["status"], status)
                self.assertTrue(watchlist.path.exists())
                if status == "FOUND" and not excluded:
                    preconfirmed = json.loads((self.root / "cycles" / "contract" / "LIVE_PRECHECK.json").read_text(encoding="utf-8"))
                    self.assertEqual(preconfirmed["attempts"], [])


class AdbHostSupervisorTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()

    def config(self, root: Path) -> dict:
        config = make_config(root)
        config.update(
            {
                "adb_device_cache_seconds": 10,
                "adb_failure_threshold": 3,
                "adb_first_retry_seconds": 5,
                "adb_second_retry_seconds": 15,
                "adb_recovery_cooldown_seconds": 60,
                "adb_server_start_settle_seconds": 5,
                "adb_health_stable_interval_seconds": 2,
                "adb_no_devices_retry_seconds": 30,
                "adb_server_port": 5037,
                "device_refresh_timeout_seconds": 15,
            }
        )
        return config

    def test_successful_device_snapshot_is_cached_and_force_bypasses_cache(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            with patch.object(
                supervisor,
                "_enumerate_devices",
                side_effect=[["one:5555"], ["two:5555"]],
            ) as enumerate_devices:
                self.assertEqual(supervisor.get_devices(), ["one:5555"])
                self.assertEqual(supervisor.get_devices(), ["one:5555"])
                self.assertEqual(supervisor.get_devices(force=True), ["two:5555"])
            self.assertEqual(enumerate_devices.call_count, 2)

    def test_first_two_failures_wait_five_then_fifteen_seconds(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            with patch.object(
                supervisor,
                "_enumerate_devices",
                side_effect=[RuntimeError("busy"), RuntimeError("busy"), ["one:5555"]],
            ), patch.object(supervisor, "_wait", return_value=True) as wait, patch.object(
                loop_runner, "safe_print"
            ):
                self.assertEqual(supervisor.get_devices(), ["one:5555"])
            self.assertEqual(wait.call_args_list, [call(5.0), call(15.0)])
            self.assertEqual(supervisor.snapshot.consecutive_failures, 0)

    def test_third_failure_recovers_once_and_returns_recovered_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))

            def recover() -> bool:
                supervisor._cached_devices = ["recovered:5555"]
                supervisor._cache_time = time.monotonic()
                return True

            with patch.object(
                supervisor,
                "_enumerate_devices",
                side_effect=RuntimeError("server stalled"),
            ), patch.object(supervisor, "_wait", return_value=True), patch.object(
                supervisor, "recover_server", side_effect=recover
            ) as recovery, patch.object(loop_runner, "safe_print"):
                self.assertEqual(supervisor.get_devices(), ["recovered:5555"])
            recovery.assert_called_once_with()

    def test_no_devices_waits_thirty_seconds_without_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            with patch.object(
                supervisor, "_enumerate_devices", side_effect=[[], ["one:5555"]]
            ), patch.object(supervisor, "_wait", return_value=True) as wait, patch.object(
                supervisor, "recover_server"
            ) as recovery, patch.object(loop_runner, "safe_print"):
                self.assertEqual(supervisor.get_devices(), ["one:5555"])
            wait.assert_called_once_with(30.0)
            recovery.assert_not_called()

    def test_round_does_not_allocate_cycle_or_advance_target_when_adb_is_stopped(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@one.fx\n@two.fx\n", encoding="utf-8")
            supervisor = Mock()
            supervisor.get_devices.side_effect = loop_runner.AdbHostUnavailable("stopped")
            with patch.object(loop_runner, "process_watchlist_target") as process, patch.object(
                loop_runner, "safe_print"
            ):
                visited, sequence = loop_runner.run_watchlist_round(
                    config=make_config(root),
                    round_number=1,
                    sequence_start=9,
                    snapshot=watchlist.read_snapshot(),
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                    adb_supervisor=supervisor,
                )
            self.assertEqual((visited, sequence), (0, 9))
            process.assert_not_called()
            self.assertFalse((root / "cycles").exists())

    def test_supervised_adb_shutdown_is_cancelled_not_username_unknown(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@target.fx\n", encoding="utf-8")
            supervisor = Mock()
            supervisor.get_devices.side_effect = loop_runner.AdbHostUnavailable("stopped")
            with patch.object(loop_runner, "run_global_live_precheck") as precheck, patch.object(
                loop_runner, "safe_print"
            ) as output:
                result = loop_runner.process_watchlist_target(
                    config=make_config(root),
                    cycle_id="cancelled-adb",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                    adb_supervisor=supervisor,
                )
            self.assertEqual(result, "CANCELLED")
            precheck.assert_not_called()
            self.assertFalse(any("live status unknown" in str(item) for item in output.call_args_list))

    def test_raw_adb_enumeration_failure_is_cancelled_not_username_unknown(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@target.fx\n", encoding="utf-8")
            with patch.object(
                loop_runner,
                "refresh_connected_tcp_devices",
                side_effect=RuntimeError("adb server unavailable"),
            ), patch.object(loop_runner, "run_global_live_precheck") as precheck, patch.object(
                loop_runner, "safe_print"
            ) as output:
                result = loop_runner.process_watchlist_target(
                    config=make_config(root),
                    cycle_id="cancelled-raw-adb",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )
            self.assertEqual(result, "CANCELLED")
            precheck.assert_not_called()
            self.assertFalse(any("live status unknown" in str(item) for item in output.call_args_list))

    def test_controlled_recovery_runs_kill_start_settle_and_two_health_checks(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            events: list[str] = []

            def enumerate_devices() -> list[str]:
                events.append("enumerate")
                if events.count("enumerate") == 1:
                    raise RuntimeError("stalled")
                return ["one:5555"]

            def control(argument: str):
                events.append(argument)
                return Mock(returncode=0)

            def wait(seconds: float) -> bool:
                events.append(f"wait:{seconds:g}")
                return True

            with patch.object(supervisor, "_wait_for_report_jobs", return_value=True), patch.object(
                supervisor, "_probe_server", return_value=False
            ), patch.object(supervisor, "_enumerate_devices", side_effect=enumerate_devices), patch.object(
                supervisor, "_server_listener_pid", side_effect=[123, None, 456]
            ), patch.object(supervisor, "_run_adb_control", side_effect=control), patch.object(
                supervisor, "_wait", side_effect=wait
            ), patch.object(loop_runner, "safe_print"):
                self.assertTrue(supervisor.recover_server())

            self.assertEqual(
                events,
                [
                    "enumerate",
                    "kill-server",
                    "wait:1",
                    "start-server",
                    "wait:5",
                    "enumerate",
                    "wait:2",
                    "enumerate",
                ],
            )
            self.assertEqual(supervisor.snapshot.state, "HEALTHY")

    def test_source_contains_no_image_wide_adb_termination(self) -> None:
        source = inspect.getsource(loop_runner.AdbHostSupervisor)
        self.assertNotIn('"/IM"', source)
        self.assertNotIn("ADB_DEVICE_REFRESH_FAILED", inspect.getsource(loop_runner))

    def test_recovery_defers_server_restart_while_report_jobs_are_active(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            with patch.object(supervisor, "_wait_for_report_jobs", return_value=False), patch.object(
                supervisor, "_run_adb_control"
            ) as control, patch.object(loop_runner, "safe_print"):
                self.assertFalse(supervisor.recover_server())
            control.assert_not_called()
            self.assertEqual(supervisor.snapshot.state, "COOLDOWN")

    def test_stability_confirmation_enumerates_twice_two_seconds_apart(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            with patch.object(
                supervisor, "_enumerate_devices", side_effect=[["one:5555"], ["one:5555"]]
            ) as enumerate_devices, patch.object(supervisor, "_wait", return_value=True) as wait:
                self.assertEqual(supervisor._confirm_stable(), ["one:5555"])
            self.assertEqual(enumerate_devices.call_count, 2)
            wait.assert_called_once_with(2.0)

    def test_targeted_fallback_kills_only_the_listener_pid(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            supervisor = loop_runner.AdbHostSupervisor(self.config(Path(directory)))
            completed = Mock(returncode=0, stdout="", stderr="")
            with patch.object(loop_runner.subprocess, "run", return_value=completed) as run:
                supervisor._terminate_server_listener(4321)
            self.assertEqual(
                run.call_args.args[0], ["taskkill", "/PID", "4321", "/T", "/F"]
            )
            self.assertNotIn("/IM", run.call_args.args[0])

    def test_health_state_records_required_runtime_fields(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            supervisor = loop_runner.AdbHostSupervisor(self.config(root))
            payload = json.loads((root / "state" / "adb_health.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["state"], "HEALTHY")
            self.assertEqual(payload["server_port"], 5037)
            self.assertIn("consecutive_failures", payload)
            self.assertIn("next_retry_at", payload)


class MonitoringDecisionTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()

    def run_status(self, status: str):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
        watchlist.path.write_text("@target.fx\n", encoding="utf-8")
        proxy = StreamingProxyStub()
        maintenance = MaintenanceStub()
        precheck = loop_runner.LivePrecheckOutcome(
            status, "checker:5555", duration_seconds=0.1
        )
        pipeline_patch = patch.object(loop_runner, "run_streaming_device_pipeline")
        pipeline = pipeline_patch.start()
        self.addCleanup(pipeline_patch.stop)
        refresh_patch = patch.object(
            loop_runner, "refresh_connected_tcp_devices", return_value=["checker:5555"]
        )
        refresh = refresh_patch.start()
        self.addCleanup(refresh_patch.stop)
        check_patch = patch.object(
            loop_runner, "run_global_live_precheck", return_value=precheck
        )
        check = check_patch.start()
        self.addCleanup(check_patch.stop)
        print_patch = patch.object(loop_runner, "safe_print")
        print_patch.start()
        self.addCleanup(print_patch.stop)
        result = loop_runner.process_watchlist_target(
            config=make_config(root),
            cycle_id="decision",
            live_url="https://www.tiktok.com/@target.fx/live",
            watchlist=watchlist,
            exclusions=make_exclusions(root),
            proxy_manager=proxy,
            maintenance=maintenance,
            action_choice="3",
        )
        return temporary, watchlist, result, pipeline, refresh, check

    def test_offline_and_unknown_stay_in_file_and_never_start_farm(self) -> None:
        for status in ("OFFLINE", "UNKNOWN"):
            with self.subTest(status=status):
                temporary, watchlist, result, pipeline, refresh, check = self.run_status(status)
                try:
                    self.assertEqual(result, status)
                    self.assertEqual(watchlist.path.read_text(encoding="utf-8"), "@target.fx\n")
                    pipeline.assert_not_called()
                    refresh.assert_called_once()
                    check.assert_called_once()
                finally:
                    temporary.cleanup()

    def test_internal_program_error_stops_monitor_instead_of_rotating_targets(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@target.fx\n", encoding="utf-8")
            precheck = loop_runner.LivePrecheckOutcome(
                "UNKNOWN",
                "checker:5555",
                error_code="INTERNAL_PROGRAM_ERROR",
                reason="AttributeError: missing internal helper",
                duration_seconds=0.1,
            )
            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "refresh_connected_tcp_devices", return_value=["checker:5555"]
            ), patch.object(
                loop_runner, "run_global_live_precheck", return_value=precheck
            ), patch.object(
                loop_runner, "run_streaming_device_pipeline"
            ) as pipeline:
                result = loop_runner.process_watchlist_target(
                    config=make_config(root),
                    cycle_id="internal-error",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )
            self.assertEqual(result, "INTERNAL_PROGRAM_ERROR")
            self.assertTrue(loop_runner.STOP_EVENT.is_set())
            pipeline.assert_not_called()

    def test_live_stays_in_file_and_only_then_starts_full_farm(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@target.fx\n", encoding="utf-8")
            events: list[str] = []
            proxy = StreamingProxyStub()
            precheck = loop_runner.LivePrecheckOutcome(
                "LIVE", "checker:5555", duration_seconds=0.1
            )
            batch = loop_runner.WorkerBatchOutcome()

            def refresh(_config):
                events.append("refresh")
                return ["checker:5555", "other:5555"]

            def check(**_kwargs):
                events.append("precheck_complete")
                return precheck

            def pipeline(**kwargs):
                events.append("full_pipeline")
                self.assertEqual(kwargs["serials"], ["checker:5555", "other:5555"])
                return batch, {"proxy_ready": 0.0, "proxy_total": 0.0, "reporting": 0.0}

            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "refresh_connected_tcp_devices", side_effect=refresh
            ) as refreshed, patch.object(
                loop_runner, "run_global_live_precheck", side_effect=check
            ), patch.object(
                loop_runner, "run_streaming_device_pipeline", side_effect=pipeline
            ) as full_pipeline:
                result = loop_runner.process_watchlist_target(
                    config=make_config(root),
                    cycle_id="live",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    watchlist=watchlist,
                    exclusions=make_exclusions(root),
                    proxy_manager=proxy,
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )

            self.assertEqual(result, "LIVE")
            self.assertEqual(events, ["refresh", "precheck_complete", "refresh", "full_pipeline"])
            self.assertEqual(refreshed.call_count, 2)
            full_pipeline.assert_called_once()
            self.assertEqual(watchlist.path.read_text(encoding="utf-8"), "@target.fx\n")

    def test_excluded_target_skips_before_device_or_precheck(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            watchlist = loop_runner.LiveWatchlist(root / "list_urls.txt")
            watchlist.path.write_text("@blocked.fx\n", encoding="utf-8")
            with patch.object(loop_runner, "safe_print"), patch.object(
                loop_runner, "refresh_connected_tcp_devices"
            ) as refresh, patch.object(loop_runner, "run_global_live_precheck") as check:
                result = loop_runner.process_watchlist_target(
                    config=make_config(root),
                    cycle_id="excluded",
                    live_url="https://www.tiktok.com/@blocked.fx/live",
                    watchlist=watchlist,
                    exclusions=make_exclusions(root, "@blocked.fx\n"),
                    proxy_manager=StreamingProxyStub(),
                    maintenance=MaintenanceStub(),
                    action_choice="3",
                )

            self.assertEqual(result, "EXCLUDED")
            refresh.assert_not_called()
            check.assert_not_called()
            self.assertEqual(watchlist.path.read_text(encoding="utf-8"), "@blocked.fx\n")


class PipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        loop_runner.STOP_EVENT.clear()

    def test_concurrency_is_bounded_and_one_failure_does_not_stop_others(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(6)]
            active = 0
            maximum = 0
            calls: list[str] = []
            lock = threading.Lock()

            def worker(*, serial, **_kwargs):
                nonlocal active, maximum
                with lock:
                    active += 1
                    maximum = max(maximum, active)
                    calls.append(serial)
                time.sleep(0.02)
                with lock:
                    active -= 1
                if serial == serials[1]:
                    return loop_runner.WorkerJobOutcome(
                        serial, 1, "failed", "SELECTOR_TIMEOUT"
                    )
                return loop_runner.WorkerJobOutcome(
                    serial, 0, "success", submission_completed=True
                )

            with patch.object(loop_runner, "run_worker_job", side_effect=worker):
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root, 2),
                    cycle_id="bounded",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=serials,
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertLessEqual(maximum, 2)
            self.assertEqual(set(calls), set(serials))
            self.assertEqual(batch.successes, 5)
            self.assertEqual(batch.failures, 1)

    def test_device_adb_proxy_setup_failure_is_not_counted_as_bad_proxy(self) -> None:
        class DeviceSetupFailureProxy(StreamingProxyStub):
            def prepare_stream(self, serials, _context):
                for serial in serials:
                    yield serial, False, "", "device/ADB preparation failure: ADB settings timeout"

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(loop_runner, "run_worker_job") as worker:
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root),
                    cycle_id="device_setup_fail",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["bad-device:5555"],
                    proxy_manager=DeviceSetupFailureProxy(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            worker.assert_not_called()
            self.assertEqual(batch.device_setup_failed, 1)
            self.assertEqual(batch.proxy_failed, 0)
            self.assertEqual(batch.failures, 1)

    def test_proxy_failure_is_terminal_without_worker_start(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(loop_runner, "run_worker_job") as worker:
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root),
                    cycle_id="proxy_fail",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=["bad:5555"],
                    proxy_manager=StreamingProxyStub({"bad:5555"}),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            worker.assert_not_called()
            self.assertEqual(batch.proxy_failed, 1)
            self.assertEqual(batch.failures, 1)

    def test_worker_live_ended_result_does_not_stop_new_workers(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(7)]
            calls: list[str] = []

            def ended(*, serial, **_kwargs):
                calls.append(serial)
                return loop_runner.WorkerJobOutcome(
                    serial=serial,
                    code=0,
                    status="live_ended",
                    error_code="LIVE_ENDED_DURING_WORKFLOW",
                    reason="LIVE_ENDED_DURING_WORKFLOW: worker-local external outcome",
                )

            with patch.object(loop_runner, "run_worker_job", side_effect=ended):
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root, 2),
                    cycle_id="ended_local_only",
                    live_url="https://www.tiktok.com/@ended.fx/live",
                    serials=serials,
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertFalse(batch.live_ended)
            self.assertCountEqual(calls, serials)
            self.assertEqual(batch.suppressed_serials, [])
            self.assertEqual(batch.live_ended_during_workflow, len(serials))
            self.assertEqual(batch.failures, 0)


    def test_one_normal_profile_does_not_suppress_entire_batch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(4)]
            calls: list[str] = []

            def worker(*, serial, **_kwargs):
                calls.append(serial)
                if serial == serials[0]:
                    return loop_runner.WorkerJobOutcome(
                        serial=serial,
                        code=0,
                        status="skipped",
                        error_code="LIVE_ENDED",
                        reason="LIVE_ENDED: confirmed normal profile opened after Users result #1",
                    )
                return loop_runner.WorkerJobOutcome(
                    serial=serial, code=0, status="success", submission_completed=True
                )

            with patch.object(loop_runner, "run_worker_job", side_effect=worker):
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root, 1),
                    cycle_id="one_profile",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=serials,
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertFalse(batch.live_ended)
            self.assertEqual(calls, serials)
            self.assertEqual(batch.suppressed_serials, [])

    def test_two_normal_profiles_are_local_failures_not_global_suppression(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(5)]
            calls: list[str] = []

            def worker(*, serial, **_kwargs):
                calls.append(serial)
                return loop_runner.WorkerJobOutcome(
                    serial=serial,
                    code=0,
                    status="skipped",
                    error_code="REPORT_DESTINATION_NOT_LIVE",
                    reason="exact target profile opened instead of active LIVE",
                )

            with patch.object(loop_runner, "run_worker_job", side_effect=worker):
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root, 1),
                    cycle_id="profiles_local_only",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=serials,
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )

            self.assertFalse(batch.live_ended)
            self.assertEqual(calls, serials)
            self.assertEqual(batch.suppressed_serials, [])

    def test_interruption_is_not_counted_as_live_ended_suppression(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(3)]
            loop_runner.STOP_EVENT.set()
            try:
                with patch.object(loop_runner, "run_worker_job") as worker:
                    batch, _ = loop_runner.run_streaming_device_pipeline(
                        config=make_config(root, 1),
                        cycle_id="interrupted",
                        live_url="https://www.tiktok.com/@target.fx/live",
                        serials=serials,
                        proxy_manager=StreamingProxyStub(),
                        exclusions=make_exclusions(root),
                        action_choice="3",
                    )
                worker.assert_not_called()
                self.assertTrue(batch.interrupted)
                self.assertEqual(batch.suppressed_serials, [])
                self.assertEqual(batch.not_started_interrupted_serials, serials)
            finally:
                loop_runner.STOP_EVENT.clear()

    def test_device_local_destination_error_does_not_halt_other_workers(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serials = [f"device-{index}:5555" for index in range(3)]

            def worker(*, serial, **_kwargs):
                if serial == serials[0]:
                    return loop_runner.WorkerJobOutcome(
                        serial=serial, code=1, status="failed",
                        error_code="DESTINATION_UNKNOWN", reason="local navigation error"
                    )
                return loop_runner.WorkerJobOutcome(
                    serial=serial, code=0, status="success", submission_completed=True
                )

            with patch.object(loop_runner, "run_worker_job", side_effect=worker):
                batch, _ = loop_runner.run_streaming_device_pipeline(
                    config=make_config(root, 1),
                    cycle_id="local_fail",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    serials=serials,
                    proxy_manager=StreamingProxyStub(),
                    exclusions=make_exclusions(root),
                    action_choice="3",
                )
            self.assertFalse(batch.live_ended)
            self.assertEqual(batch.failures, 1)
            self.assertEqual(batch.successes, 2)
            self.assertEqual(batch.suppressed_serials, [])

    def test_persisted_submit_success_wins_over_cleanup_watchdog_timeout(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root, 1)
            success_result = {
                "status": "success",
                "submission_completed": True,
                "submission_state": "CONFIRMED",
                "submit_attempted": True,
                "ui_confirmation_observed": True,
                "settlement_completed": True,
                "confirmation_source": "tiktok_ui",
                "backend_acceptance": "unknown",
                "stage": "WORKFLOW_COMPLETE",
                "timings": {"SUBMIT": 0.2},
            }
            metadata = {"tiktok_package": "com.ss.android.ugc.trill"}
            with patch.object(loop_runner, "build_worker_config", return_value=root / "worker.json"), \
                 patch.object(loop_runner, "run_process_quiet", return_value=(1, [], False, True)), \
                 patch.object(loop_runner, "find_latest_json", side_effect=[(success_result, None), (metadata, None), (success_result, None)]), \
                 patch.object(loop_runner, "force_stop_tiktok_after_forced_child_exit"), \
                 patch.object(loop_runner, "cleanup_uiautomator_after_forced_child_exit"), \
                 patch.object(loop_runner, "write_minimal_result"), \
                 patch.object(loop_runner, "workflow_template", return_value={"selectors": {}}), \
                 patch.object(loop_runner, "safe_print") as output:
                outcome = loop_runner.run_worker_job(
                    config=config,
                    cycle_id="timeout_after_success",
                    serial="device:5555",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    action_choice="3",
                    exclusions=make_exclusions(root),
                )
            self.assertEqual(outcome.status, "success")
            self.assertTrue(outcome.submission_completed)
            self.assertNotEqual(outcome.error_code, "WORKER_JOB_TIMEOUT")
            self.assertFalse(any(
                "FAILED" in str(call.args[0])
                for call in output.call_args_list
                if call.args
            ))

    def test_incomplete_submit_holds_until_cleanup_deadline(self) -> None:
        clock = [100.0]

        def advance(seconds):
            clock[0] += seconds

        journal = {
            "submit_attempted": True,
            "submission_state": "WAITING_CONFIRMATION",
            "submit_dispatch_epoch": 100.0,
            "cleanup_not_before_epoch": 135.0,
        }
        with patch.object(loop_runner.time, "time", side_effect=lambda: clock[0]), \
             patch.object(loop_runner.time, "sleep", side_effect=advance):
            loop_runner.wait_for_incomplete_submission_hold(journal)
        self.assertGreaterEqual(clock[0], 135.0)

    def test_legacy_success_without_settlement_contract_is_rejected(self) -> None:
        fields = loop_runner.submission_outcome_fields(
            {"submission_completed": True}, {}
        )
        self.assertFalse(loop_runner.settled_submission_confirmed(fields))



class ConfigurationTests(unittest.TestCase):
    def test_runtime_config_uses_watchlist_and_preserves_performance_controls(self) -> None:
        values = loop_runner.CONFIG
        serialized = json.dumps(values).casefold()
        self.assertEqual(values["list_urls_file"], "list_urls.txt")
        self.assertNotIn("live_urls_file", values)
        self.assertNotIn("queue_poll_interval_seconds", values)
        for obsolete in ("priorities", "live_search", "minimum_live_viewers"):
            self.assertNotIn(obsolete, serialized)
        self.assertEqual(values["max_parallel"], 16)
        self.assertEqual(values["proxy_parallel_setup"], 4)
        self.assertEqual(values["worker_job_timeout_seconds"], 180)
        self.assertTrue(values["proxy_fail_closed"])
        self.assertEqual(values["proxy_submit_proof_timeout_seconds"], 1.5)
        self.assertEqual(values["proxy_early_proof_timeout_seconds"], 2.5)
        self.assertEqual(values["proxy_adb_control_timeout_seconds"], 8)
        self.assertEqual(values["proxy_setup_stagger_seconds"], 0.05)
        self.assertEqual(values["live_precheck_timeout_seconds"], 100)
        self.assertEqual(values["adb_host_timeout_seconds"], 15)
        self.assertEqual(values["device_refresh_timeout_seconds"], 15)
        self.assertEqual(values["adb_device_cache_seconds"], 10)
        self.assertEqual(values["adb_failure_threshold"], 3)
        self.assertEqual(values["adb_first_retry_seconds"], 5)
        self.assertEqual(values["adb_second_retry_seconds"], 15)
        self.assertEqual(values["adb_recovery_cooldown_seconds"], 60)
        self.assertEqual(values["adb_server_start_settle_seconds"], 5)
        self.assertEqual(values["adb_health_stable_interval_seconds"], 2)
        self.assertEqual(values["adb_no_devices_retry_seconds"], 30)
        self.assertEqual(values["adb_server_port"], 5037)
        self.assertTrue(Path(values["adb_executable"]).is_absolute())
        self.assertTrue(Path(values["adb_executable"]).is_file())

    def test_runtime_config_rejects_missing_adb_executable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            payload = json.loads(loop_runner.CONFIG_FILE.read_text(encoding="utf-8"))
            payload["adb_executable"] = str(root / "missing-adb.exe")
            path = root / "loop_config.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(SystemExit, "adb_executable is not a file"):
                loop_runner.load_runtime_settings(path)

    def test_physical_watchlist_rename_and_fifo_log_terms(self) -> None:
        self.assertTrue((loop_runner.BASE_DIR / "list_urls.txt").is_file())
        self.assertFalse((loop_runner.BASE_DIR / "live_urls.txt").exists())
        source = (loop_runner.BASE_DIR / "loop_runner.py").read_text(encoding="utf-8")
        for stale_log in ("[QUEUE]", "DEQUEUE", "CONSUMED", "TARGET REMOVED"):
            self.assertNotIn(stale_log, source.upper())

    def test_diagnostics_and_detailed_logging_are_forwarded_to_both_modes(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = make_config(root)
            config.update({"diagnostics_enabled": True, "detailed_logging": True})
            with patch.object(loop_runner, "RUNTIME_ROOT", root / "runtime"), patch.object(
                loop_runner, "workflow_template", return_value={"selectors": {}}
            ):
                path = loop_runner.build_worker_config(
                    config=config,
                    serial="checker:5555",
                    live_url="https://www.tiktok.com/@target.fx/live",
                    action_choice="3",
                    cycle_id="config",
                    temp_job_root=root / "job",
                    workflow_mode="live_precheck",
                )
                payload = json.loads(path.read_text(encoding="utf-8"))

            self.assertTrue(payload["diagnostics_enabled"])
            self.assertTrue(payload["detailed_logging"])
            self.assertEqual(payload["workflow_mode"], "live_precheck")
            self.assertEqual(payload["live_precheck_timeout_seconds"], 100)


if __name__ == "__main__":
    unittest.main()
