from __future__ import annotations

import json
import concurrent.futures
import tempfile
import threading
import time
import unittest
from pathlib import Path
from subprocess import CompletedProcess, TimeoutExpired
from unittest.mock import Mock, patch

from proxy_manager import ProxyEndpoint, ProxyManager, ProxyRotationState


class FakeRelay:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.verified: dict[str, int] = {}
        self.failed: dict[str, int] = {}

    def verified_target_connections(self, target: str) -> int:
        with self._lock:
            return self.verified.get(target, 0)

    def failed_target_connections(self, target: str) -> int:
        with self._lock:
            return self.failed.get(target, 0)

    def mark_verified_connection(self, target: str) -> None:
        with self._lock:
            self.verified[target] = self.verified.get(target, 0) + 1

    def mark_failed_connection(self, target: str) -> None:
        with self._lock:
            self.failed[target] = self.failed.get(target, 0) + 1

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "verified_connections": sum(self.verified.values()),
                "failed_connections": sum(self.failed.values()),
                "last_target": next(reversed(self.verified), ""),
            }


def completed(command, **_kwargs):
    return CompletedProcess(command, 0, stdout="", stderr="")


class ProxyOnUseTests(unittest.TestCase):
    def make_manager(self, root: Path, *, deadline: float = 2.0) -> ProxyManager:
        proxy_file = root / "proxy_list.txt"
        proxy_file.write_text(
            "192.0.2.10:8000:user1:password1\n"
            "192.0.2.11:8001:user2:password2\n"
            "192.0.2.12:8002:user3:password3\n",
            encoding="utf-8",
        )
        return ProxyManager(
            {
                "proxy_enabled": True,
                "proxy_fail_closed": True,
                "proxy_list_file": str(proxy_file),
                "proxy_startup_health_check": False,
                "proxy_connect_timeout_seconds": 2,
                "proxy_confirmation_deadline_seconds": deadline,
                "proxy_assignment_max_attempts": 3,
                "proxy_health_cache_seconds": 300,
                "proxy_rotation_state_file": str(root / "rotation.json"),
                "proxy_health_state_file": str(root / "health.json"),
                "proxy_error_log_file": str(root / "errors.jsonl"),
                "proxy_usage_log_file": str(root / "usage.jsonl"),
                "proxy_assignment_log_file": str(root / "assignments.jsonl"),
            },
            root,
            log=Mock(),
            adb_runner=completed,
        )

    def delayed_probe(self, delay: float, *, deadline: float = 2.0) -> tuple[bool, float]:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory), deadline=deadline)
            relay = FakeRelay()
            timer = threading.Timer(
                delay, relay.mark_verified_connection, args=(manager.probe_target,)
            )
            timer.start()
            started = time.monotonic()
            try:
                passed = manager._probe_device("device:5555", relay)
                elapsed = time.monotonic() - started
            finally:
                timer.cancel()
                timer.join(timeout=0.1)
                manager.close()
            return passed, elapsed


    def test_tiktok_proof_is_written_only_after_arm_for_matching_domain(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            manager.verify_tiktok_traffic = True
            manager.tiktok_domain_suffixes = ("tiktok.com", "tiktokv.com")
            serial = "device:5555"
            proof = root / "proof.json"
            manager._workflow_baselines[serial] = time.time() - 1
            try:
                manager.arm_tiktok_proof(serial, proof)
                manager._observe_tiktok_target(serial, "api.example.com:443")
                self.assertFalse(proof.exists())
                manager._observe_tiktok_target(serial, "webcast.tiktokv.com:443")
                self.assertTrue(proof.exists())
                payload = __import__("json").loads(proof.read_text(encoding="utf-8"))
                self.assertTrue(payload["verified"])
                self.assertEqual(payload["serial"], serial)
                self.assertEqual(payload["target"], "webcast.tiktokv.com:443")
            finally:
                manager.disarm_tiktok_proof(serial)
                manager.close()

    def test_concurrent_tiktok_targets_have_exactly_one_proof_writer(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            manager.verify_tiktok_traffic = True
            manager.tiktok_domain_suffixes = ("tiktok.com", "tiktokv.com")
            serial = "device:5555"
            proof = root / "proof.json"
            manager._workflow_baselines[serial] = time.time() - 1
            original_write_text = Path.write_text
            write_count = 0
            write_lock = threading.Lock()
            start = threading.Barrier(20)

            def slow_write(path: Path, *args, **kwargs):
                nonlocal write_count
                if path.name.startswith("proof.json.tmp-"):
                    with write_lock:
                        write_count += 1
                    time.sleep(0.05)
                return original_write_text(path, *args, **kwargs)

            def observe(index: int) -> None:
                start.wait(timeout=2)
                manager._observe_tiktok_target(
                    serial, f"api{index}.tiktokv.com:443"
                )

            try:
                manager.arm_tiktok_proof(serial, proof)
                with patch.object(Path, "write_text", new=slow_write):
                    threads = [
                        threading.Thread(target=observe, args=(index,))
                        for index in range(20)
                    ]
                    for thread in threads:
                        thread.start()
                    for thread in threads:
                        thread.join(timeout=3)
                self.assertTrue(proof.exists())
                payload = __import__("json").loads(proof.read_text(encoding="utf-8"))
                self.assertTrue(payload["verified"])
                self.assertEqual(payload["serial"], serial)
                self.assertEqual(write_count, 1)
                self.assertEqual(list(root.glob("proof.json.tmp-*")), [])
            finally:
                manager.disarm_tiktok_proof(serial)
                manager.close()

    def test_failed_single_proof_write_rearms_for_next_tiktok_connection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            manager.verify_tiktok_traffic = True
            manager.tiktok_domain_suffixes = ("tiktok.com", "tiktokv.com")
            serial = "device:5555"
            proof = root / "proof.json"
            manager._workflow_baselines[serial] = time.time() - 1
            original_write_text = Path.write_text
            failed_once = False

            def fail_first_temp_write(path: Path, *args, **kwargs):
                nonlocal failed_once
                if path.name.startswith("proof.json.tmp-") and not failed_once:
                    failed_once = True
                    raise PermissionError("simulated Windows proof-file lock")
                return original_write_text(path, *args, **kwargs)

            try:
                manager.arm_tiktok_proof(serial, proof)
                with patch.object(Path, "write_text", new=fail_first_temp_write):
                    manager._observe_tiktok_target(serial, "api.tiktokv.com:443")
                    self.assertFalse(proof.exists())
                    self.assertIn(serial, manager._tiktok_proof_arms)
                    manager._observe_tiktok_target(serial, "webcast.tiktokv.com:443")
                self.assertTrue(proof.exists())
                payload = __import__("json").loads(proof.read_text(encoding="utf-8"))
                self.assertEqual(payload["target"], "webcast.tiktokv.com:443")
                self.assertNotIn(serial, manager._tiktok_proof_arms)
                self.assertEqual(list(root.glob("proof.json.tmp-*")), [])
            finally:
                manager.disarm_tiktok_proof(serial)
                manager.close()

    def test_no_mandatory_full_proxy_health_sweep(self) -> None:
        with tempfile.TemporaryDirectory() as directory, patch.object(
            ProxyManager, "refresh_health", autospec=True
        ) as sweep:
            manager = self.make_manager(Path(directory))
            try:
                self.assertTrue(manager.begin_round(1))
                sweep.assert_not_called()
                self.assertEqual(len(manager.available_endpoints()), 3)
            finally:
                manager.close()

    def test_each_round_reloads_the_current_proxy_list(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            replacement = (
                "198.51.100.10:9000:new1:secret1\n"
                "198.51.100.11:9001:new2:secret2\n"
                "198.51.100.12:9002:new3:secret3\n"
                "198.51.100.13:9003:new4:secret4\n"
            )
            (root / "proxy_list.txt").write_text(replacement, encoding="utf-8")
            try:
                self.assertTrue(manager.begin_round(7))
                self.assertEqual(
                    [endpoint.redacted for endpoint in manager.endpoints],
                    [
                        "198.51.100.10:9000",
                        "198.51.100.11:9001",
                        "198.51.100.12:9002",
                        "198.51.100.13:9003",
                    ],
                )
                output = "\n".join(str(item.args[0]) for item in manager.log.call_args_list)
                self.assertIn("[PROXY ROUND] round=7 | loaded=4 | unique_ips=4", output)
            finally:
                manager.close()

    def test_invalid_proxy_list_skips_round_and_logs_retry_next_round(self) -> None:
        for compact in (True, False):
            with self.subTest(compact=compact), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                manager = self.make_manager(root)
                manager.compact_logging = compact
                (root / "proxy_list.txt").write_text("invalid proxy\n", encoding="utf-8")
                try:
                    self.assertFalse(manager.begin_round(8))
                    output = "\n".join(str(item.args[0]) for item in manager.log.call_args_list)
                    self.assertIn("[PROXY ERROR] round=8", output)
                    self.assertIn("action=SKIP_ROUND", output)
                    self.assertIn("retry=NEXT_ROUND", output)
                    event = json.loads(
                        (root / "errors.jsonl").read_text(encoding="utf-8").splitlines()[-1]
                    )
                    self.assertEqual(event["stage"], "proxy_list_reload")
                finally:
                    manager.close()

    def test_random_rotation_blocks_only_the_immediately_previous_proxy_ip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state = ProxyRotationState(Path(directory) / "rotation.json")
            first = ProxyEndpoint("192.0.2.10", 8000, "u1", "p1")
            same_ip = ProxyEndpoint("192.0.2.10", 8001, "u2", "p2")
            second = ProxyEndpoint("192.0.2.11", 8002, "u3", "p3")
            endpoints = [first, same_ip, second]
            serial = "192.168.100.10:5555"

            state.commit({serial: first}, endpoints)
            after_first = state.candidate_order(serial, endpoints)
            self.assertEqual(after_first, [second])

            state.commit({serial: second}, endpoints)
            after_second = state.candidate_order(serial, endpoints)
            self.assertEqual({item.host for item in after_second}, {"192.0.2.10"})
            self.assertEqual(len(after_second), 2)

            persisted = json.loads((Path(directory) / "rotation.json").read_text(encoding="utf-8"))
            self.assertEqual(
                persisted["devices"][serial]["last_proxy_host"], "192.0.2.11"
            )

    def test_persisted_failed_health_does_not_control_eligibility(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = self.make_manager(root)
            identity = first.endpoints[0].identity
            first.close()
            (root / "health.json").write_text(
                '{"version":1,"proxies":{"'
                + identity
                + '":{"status":"quarantined","last_checked_epoch":9999999999}}}',
                encoding="utf-8",
            )
            manager = self.make_manager(root)
            try:
                self.assertEqual(len(manager.available_endpoints()), 3)
            finally:
                manager.close()

    def test_proxy_confirmation_delays_inside_deadline_pass(self) -> None:
        for delay in (0.10, 0.45, 0.60, 1.00):
            with self.subTest(delay=delay):
                passed, elapsed = self.delayed_probe(delay)
                self.assertTrue(passed)
                self.assertLess(elapsed, 1.5)

    def test_successful_proxy_continues_before_deadline(self) -> None:
        passed, elapsed = self.delayed_probe(0.10)
        self.assertTrue(passed)
        self.assertLess(elapsed, 0.5)

    def test_silent_synthetic_probe_is_inconclusive_not_a_false_rejection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory), deadline=0.12)
            try:
                started = time.monotonic()
                self.assertTrue(manager._probe_device("device:5555", FakeRelay()))
                elapsed = time.monotonic() - started
                self.assertGreaterEqual(elapsed, 0.10)
                self.assertLess(elapsed, 0.5)
            finally:
                manager.close()

    def test_unrelated_relay_traffic_does_not_become_target_confirmation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory), deadline=0.12)
            relay = FakeRelay()
            timer = threading.Timer(
                0.03, relay.mark_verified_connection, args=("api.example.com:443",)
            )
            timer.start()
            try:
                self.assertTrue(manager._probe_device("device:5555", relay))
                diagnostics = manager._probe_diagnostics["device:5555"]
                self.assertFalse(diagnostics["expected_target_confirmed"])
                self.assertTrue(diagnostics["synthetic_probe_inconclusive"])
            finally:
                timer.join(timeout=0.2)
                manager.close()

    def test_expected_connect_target_creates_pass(self) -> None:
        passed, _elapsed = self.delayed_probe(0.03, deadline=0.2)
        self.assertTrue(passed)

    def test_relay_observed_target_failure_is_genuine_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory), deadline=0.2)
            relay = FakeRelay()
            timer = threading.Timer(
                0.03, relay.mark_failed_connection, args=(manager.probe_target,)
            )
            timer.start()
            try:
                self.assertFalse(manager._probe_device("device:5555", relay))
            finally:
                timer.join(timeout=0.2)
                manager.close()


    def test_prepare_one_classifies_adb_timeout_as_device_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            endpoint = manager.endpoints[0]
            relay = Mock()
            try:
                with patch.object(manager, "_relay_for", return_value=relay), patch.object(
                    manager, "_configure_device", side_effect=TimeoutExpired(["adb"], 4)
                ):
                    _serial, prepared, _error = manager._prepare_one(
                        "device:5555", endpoint, "adb-timeout"
                    )
                self.assertIsNone(prepared)
                self.assertEqual(manager._prepare_failure_scopes["device:5555"], "device")
            finally:
                manager.close()

    def test_prepare_one_classifies_relay_observed_connect_failure_as_proxy_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            endpoint = manager.endpoints[0]
            relay = Mock()
            relay.snapshot.return_value = {"failed_connections": 0}
            try:
                manager._probe_diagnostics["device:5555"] = {"expected_target_failed": True}
                with patch.object(manager, "_relay_for", return_value=relay), patch.object(
                    manager, "_configure_device"
                ), patch.object(manager, "_probe_device", return_value=False):
                    _serial, prepared, _error = manager._prepare_one(
                        "device:5555", endpoint, "proxy-failure"
                    )
                self.assertIsNone(prepared)
                self.assertEqual(manager._prepare_failure_scopes["device:5555"], "proxy")
            finally:
                manager.close()

    def test_device_adb_failure_does_not_blacklist_or_rotate_proxy(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            first = manager.endpoints[0]
            attempts: list[ProxyEndpoint] = []

            def prepare(serial, endpoint, _context):
                attempts.append(endpoint)
                manager._prepare_failure_scopes[serial] = "device"
                return serial, None, "ADB settings read timed out"

            try:
                with patch.object(
                    manager.rotation,
                    "candidate_order",
                    return_value=[first] + manager.endpoints[1:],
                ), patch.object(manager, "_prepare_one", side_effect=prepare):
                    _serial, endpoint, error = manager._prepare_with_fallback(
                        "device:5555", "adb-failure"
                    )
                self.assertIsNone(endpoint)
                self.assertIn("device/ADB preparation failure", error)
                self.assertEqual(attempts, [first])
                self.assertIn(first, manager.available_endpoints())
                self.assertEqual(manager.health_counts()["round_failed"], 0)
            finally:
                manager.close()

    def test_failed_proxy_is_skipped_for_round_and_another_is_selected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            original = (root / "proxy_list.txt").read_text(encoding="utf-8")
            first, second = manager.endpoints[:2]
            attempts: list[ProxyEndpoint] = []

            def choose(_serial, available):
                preferred = first if first in available else second
                return [preferred] + [item for item in available if item != preferred]

            def prepare(serial, endpoint, _context):
                attempts.append(endpoint)
                return (
                    (serial, None, "temporary CONNECT failure")
                    if endpoint == first
                    else (serial, endpoint, "")
                )

            try:
                with patch.object(
                    manager.rotation, "candidate_order", side_effect=choose
                ), patch.object(manager, "_prepare_one", side_effect=prepare):
                    serial, endpoint, error = manager._prepare_with_fallback(
                        "device:5555", "test"
                    )
                self.assertEqual(serial, "device:5555")
                self.assertEqual(endpoint, second)
                self.assertEqual(error, "")
                self.assertEqual(attempts, [first, second])
                self.assertNotIn(first, manager.available_endpoints())
                self.assertEqual(
                    (root / "proxy_list.txt").read_text(encoding="utf-8"), original
                )
                manager.begin_round(2)
                self.assertIn(first, manager.available_endpoints())
                self.assertEqual(
                    (root / "proxy_list.txt").read_text(encoding="utf-8"), original
                )
            finally:
                manager.close()

    def test_assignment_uses_random_candidate_order(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            selected = manager.endpoints[-1]
            try:
                with patch.object(
                    manager.rotation,
                    "candidate_order",
                    return_value=[selected] + manager.endpoints[:-1],
                ) as randomized, patch.object(
                    manager,
                    "_prepare_one",
                    return_value=("device:5555", selected, ""),
                ):
                    _serial, endpoint, _error = manager._prepare_with_fallback(
                        "device:5555", "test"
                    )
                randomized.assert_called_once()
                self.assertEqual(endpoint, selected)
            finally:
                manager.close()

    def test_successful_batch_uses_every_proxy_before_reusing_one(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            selected: list[ProxyEndpoint] = []

            def prepare(serial, endpoint, _context):
                selected.append(endpoint)
                return serial, endpoint, ""

            try:
                (root / "proxy_list.txt").write_text(
                    "".join(
                        f"198.51.100.{index}:8{index:03d}:user{index}:pass{index}\n"
                        for index in range(1, 21)
                    ),
                    encoding="utf-8",
                )
                self.assertTrue(manager.begin_round(1))
                with patch.object(manager, "_prepare_one", side_effect=prepare):
                    for index in range(77):
                        serial, endpoint, error = manager._prepare_with_fallback(
                            f"192.168.100.{index + 10}:5555", "distribution"
                        )
                        self.assertEqual(serial, f"192.168.100.{index + 10}:5555")
                        self.assertIsNotNone(endpoint)
                        self.assertEqual(error, "")
                        manager._release_proxy_lease(serial)

                expected = {endpoint.identity for endpoint in manager.endpoints}
                self.assertEqual(len(expected), 20)
                for offset in (0, 20, 40):
                    self.assertEqual(
                        {endpoint.identity for endpoint in selected[offset : offset + 20]},
                        expected,
                    )
                counts = {
                    identity: sum(endpoint.identity == identity for endpoint in selected)
                    for identity in expected
                }
                self.assertLessEqual(max(counts.values()) - min(counts.values()), 1)
            finally:
                manager.close()

    def test_active_devices_receive_distinct_proxy_hosts(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            barrier = threading.Barrier(3)

            def prepare(serial, endpoint, _context):
                barrier.wait(timeout=2)
                return serial, endpoint, ""

            serials = [f"device-{index}:5555" for index in range(3)]
            try:
                with patch.object(manager, "_prepare_one", side_effect=prepare):
                    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                        results = list(
                            executor.map(
                                lambda serial: manager._prepare_with_fallback(
                                    serial, "exclusive"
                                ),
                                serials,
                            )
                        )
                endpoints = [result[1] for result in results]
                self.assertTrue(all(endpoint is not None for endpoint in endpoints))
                self.assertEqual(len({endpoint.host for endpoint in endpoints}), 3)
                self.assertEqual(len(manager._active_proxy_leases), 3)
                self.assertEqual(len(manager._device_proxy_leases), 3)
            finally:
                for serial in serials:
                    manager._release_proxy_lease(serial)
                manager.close()

    def test_next_device_waits_until_an_active_proxy_is_released(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            (root / "proxy_list.txt").write_text(
                "192.0.2.10:8000:user1:password1\n"
                "192.0.2.11:8001:user2:password2\n",
                encoding="utf-8",
            )
            manager.begin_round(1)
            manager.max_active_leases = 2
            completed = threading.Event()
            result_holder = []

            def prepare(serial, endpoint, _context):
                return serial, endpoint, ""

            try:
                with patch.object(manager, "_prepare_one", side_effect=prepare):
                    first = manager._prepare_with_fallback("device-1:5555", "exclusive")
                    second = manager._prepare_with_fallback("device-2:5555", "exclusive")

                    def prepare_third() -> None:
                        result_holder.append(
                            manager._prepare_with_fallback("device-3:5555", "exclusive")
                        )
                        completed.set()

                    thread = threading.Thread(target=prepare_third)
                    thread.start()
                    self.assertFalse(completed.wait(0.15))
                    manager._release_proxy_lease("device-1:5555")
                    self.assertTrue(completed.wait(2))
                    thread.join(timeout=1)

                self.assertIsNotNone(first[1])
                self.assertIsNotNone(second[1])
                self.assertIsNotNone(result_holder[0][1])
                self.assertEqual(
                    result_holder[0][1].host,
                    first[1].host,
                )
                self.assertEqual(len(manager._active_proxy_leases), 2)
            finally:
                for serial in ("device-1:5555", "device-2:5555", "device-3:5555"):
                    manager._release_proxy_lease(serial)
                manager.close()

    def test_active_lease_count_never_exceeds_configured_concurrency(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            manager.max_active_leases = 2
            completed = threading.Event()
            result_holder = []
            try:
                with patch.object(
                    manager,
                    "_prepare_one",
                    side_effect=lambda serial, endpoint, _context: (serial, endpoint, ""),
                ):
                    manager._prepare_with_fallback("device-1:5555", "capacity")
                    manager._prepare_with_fallback("device-2:5555", "capacity")

                    def prepare_third() -> None:
                        result_holder.append(
                            manager._prepare_with_fallback("device-3:5555", "capacity")
                        )
                        completed.set()

                    thread = threading.Thread(target=prepare_third)
                    thread.start()
                    self.assertFalse(completed.wait(0.15))
                    self.assertEqual(len(manager._device_proxy_leases), 2)
                    self.assertEqual(len(manager.available_endpoints()), 1)
                    manager._release_proxy_lease("device-1:5555")
                    self.assertTrue(completed.wait(2))
                    thread.join(timeout=1)

                self.assertIsNotNone(result_holder[0][1])
                self.assertEqual(len(manager._device_proxy_leases), 2)
            finally:
                for serial in ("device-1:5555", "device-2:5555", "device-3:5555"):
                    manager._release_proxy_lease(serial)
                manager.close()

    def test_device_waits_for_a_non_repeating_proxy_instead_of_reusing_its_last_ip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            (root / "proxy_list.txt").write_text(
                "192.0.2.10:8000:user1:password1\n"
                "192.0.2.11:8001:user2:password2\n",
                encoding="utf-8",
            )
            manager.begin_round(1)
            first, second = manager.endpoints
            serial = "device-1:5555"
            blocker = "device-2:5555"
            completed = threading.Event()
            result_holder = []
            manager.rotation.commit({serial: first}, manager.endpoints)
            with manager._lease_condition:
                manager._reserve_proxy_lease_locked(blocker, second)

            try:
                with patch.object(
                    manager,
                    "_prepare_one",
                    side_effect=lambda device, endpoint, _context: (
                        device,
                        endpoint,
                        "",
                    ),
                ):
                    thread = threading.Thread(
                        target=lambda: (
                            result_holder.append(
                                manager._prepare_with_fallback(serial, "no-repeat")
                            ),
                            completed.set(),
                        )
                    )
                    thread.start()
                    self.assertFalse(completed.wait(0.15))
                    manager._release_proxy_lease(blocker)
                    self.assertTrue(completed.wait(2))
                    thread.join(timeout=1)

                self.assertEqual(result_holder[0][1], second)
            finally:
                manager._release_proxy_lease(serial)
                manager._release_proxy_lease(blocker)
                manager.close()

    def test_release_keeps_lease_until_proxy_and_reverse_cleanup_finishes(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            serial = "device:5555"
            endpoint = manager.endpoints[0]
            cleanup_entered = threading.Event()
            allow_cleanup = threading.Event()

            def restore(*_args, **_kwargs):
                cleanup_entered.set()
                allow_cleanup.wait(timeout=2)
                return []

            with manager._lease_condition:
                manager._reserve_proxy_lease_locked(serial, endpoint)
            try:
                with patch.object(manager, "_restore_device_proxy", side_effect=restore):
                    thread = threading.Thread(target=manager.release_device, args=(serial,))
                    thread.start()
                    self.assertTrue(cleanup_entered.wait(1))
                    self.assertEqual(manager._active_proxy_leases[endpoint.host], serial)
                    self.assertIn(serial, manager._device_proxy_leases)
                    allow_cleanup.set()
                    thread.join(timeout=2)
                self.assertFalse(thread.is_alive())
                self.assertNotIn(endpoint.host, manager._active_proxy_leases)
                self.assertNotIn(serial, manager._device_proxy_leases)
            finally:
                allow_cleanup.set()
                manager.close()

    def test_failed_preparation_cleans_up_before_releasing_lease(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            serial = "device:5555"
            cleanup_saw_lease = []

            def prepare(_serial, _endpoint, _context):
                manager._prepare_failure_scopes[serial] = "device"
                return serial, None, "ADB setup failed"

            def restore(*_args, **_kwargs):
                cleanup_saw_lease.append(serial in manager._device_proxy_leases)
                return []

            try:
                with patch.object(manager, "_prepare_one", side_effect=prepare), patch.object(
                    manager, "_restore_device_proxy", side_effect=restore
                ):
                    _serial, endpoint, error = manager._prepare_with_fallback(
                        serial, "failed-setup"
                    )
                self.assertIsNone(endpoint)
                self.assertIn("device/ADB preparation failure", error)
                self.assertEqual(cleanup_saw_lease, [True])
                self.assertNotIn(serial, manager._device_proxy_leases)
                self.assertEqual(manager._active_proxy_leases, {})
            finally:
                manager.close()

    def test_shutdown_wakes_device_waiting_for_proxy_lease(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            manager.max_active_leases = 1
            result_holder = []
            try:
                with patch.object(
                    manager,
                    "_prepare_one",
                    side_effect=lambda serial, endpoint, _context: (serial, endpoint, ""),
                ):
                    manager._prepare_with_fallback("device-1:5555", "exclusive")

                    thread = threading.Thread(
                        target=lambda: result_holder.append(
                            manager._prepare_with_fallback("device-2:5555", "exclusive")
                        )
                    )
                    thread.start()
                    time.sleep(0.05)
                    manager.request_stop()
                    thread.join(timeout=1)

                self.assertFalse(thread.is_alive())
                self.assertEqual(result_holder[0][2], "cancelled by shutdown")
            finally:
                manager._release_proxy_lease("device-1:5555")
                manager.close()

    def test_all_bounded_proxy_attempts_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            try:
                with patch.object(
                    manager,
                    "_prepare_one",
                    side_effect=lambda serial, endpoint, context: (
                        serial,
                        None,
                        "failed",
                    ),
                ):
                    _serial, endpoint, error = manager._prepare_with_fallback(
                        "device:5555", "test"
                    )
                self.assertIsNone(endpoint)
                self.assertIn("failed", error)
                self.assertEqual(manager.health_counts()["round_failed"], 3)
                self.assertEqual(manager.available_endpoints(), [])
                manager.begin_round(2)
                self.assertEqual(len(manager.available_endpoints()), 3)
            finally:
                manager.close()

    def test_proxy_credentials_are_not_written_to_assignment_logs(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            selected = manager.endpoints[0]
            try:
                with patch.object(
                    manager.rotation,
                    "candidate_order",
                    return_value=[selected] + manager.endpoints[1:],
                ), patch.object(
                    manager,
                    "_prepare_one",
                    return_value=("device:5555", selected, ""),
                ):
                    manager._prepare_with_fallback("device:5555", "credential-test")
                output = "\n".join(
                    str(call.args[0]) for call in manager.log.call_args_list if call.args
                )
                self.assertNotIn("user1", output)
                self.assertNotIn("password1", output)
                self.assertIn(selected.redacted, output)
            finally:
                manager.close()

    def test_successful_assignment_is_clear_in_compact_and_detailed_logs(self) -> None:
        for compact in (True, False):
            with self.subTest(compact=compact), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                manager = self.make_manager(root)
                manager.compact_logging = compact
                selected = manager.endpoints[0]
                manager.health[selected.identity] = manager._health_record(
                    selected,
                    "healthy",
                    time.time(),
                    exit_ip="198.51.100.25",
                )
                try:
                    with patch.object(
                        manager.rotation,
                        "candidate_order",
                        return_value=[selected] + manager.endpoints[1:],
                    ), patch.object(
                        manager,
                        "_prepare_one",
                        return_value=("192.168.100.12:5555", selected, ""),
                    ):
                        manager._prepare_with_fallback(
                            "192.168.100.12:5555", "cycle-1 @target"
                        )

                    messages = [
                        str(item.args[0])
                        for item in manager.log.call_args_list
                        if item.args and str(item.args[0]).startswith("[PROXY ASSIGN]")
                    ]
                    self.assertEqual(len(messages), 1)
                    self.assertIn("device=192.168.100.12:5555", messages[0])
                    self.assertIn("device_ip=192.168.100.12", messages[0])
                    self.assertIn(f"proxy={selected.redacted}", messages[0])
                    self.assertIn(f"proxy_ip={selected.host}", messages[0])
                    self.assertIn("exit_ip=198.51.100.25", messages[0])
                    self.assertIn("context=cycle-1 @target", messages[0])
                    self.assertNotIn(selected.username, messages[0])
                    self.assertNotIn(selected.password, messages[0])

                    event = json.loads(
                        (root / "assignments.jsonl").read_text(encoding="utf-8").splitlines()[-1]
                    )
                    self.assertEqual(event["device_ip"], "192.168.100.12")
                    self.assertEqual(event["proxy_ip"], selected.host)
                    self.assertEqual(event["proxy_port"], selected.port)
                    self.assertEqual(event["exit_ip"], "198.51.100.25")
                    self.assertNotIn("username", event)
                    self.assertNotIn("password", event)
                finally:
                    manager.close()

    def test_cycle_log_contains_readable_assignment_files(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = self.make_manager(root)
            selected = manager.endpoints[0]
            try:
                manager._record_proxy_assignment(
                    context="cycle-2 LIVE precheck",
                    serial="192.168.100.40:5555",
                    endpoint=selected,
                )
                cycle = root / "cycle"
                manager.write_health_log(cycle, finalize_cycle=True)
                payload = json.loads(
                    (cycle / "PROXY_ASSIGNMENTS.json").read_text(encoding="utf-8")
                )
                text_log = (cycle / "PROXY_ASSIGNMENTS.txt").read_text(encoding="utf-8")
                self.assertEqual(len(payload), 1)
                self.assertEqual(payload[0]["device"], "192.168.100.40:5555")
                self.assertIn("device_ip=192.168.100.40", text_log)
                self.assertIn(f"proxy={selected.redacted}", text_log)
                self.assertIn("exit_ip=not_checked", text_log)
                self.assertEqual(len(manager._assignment_events), 0)
            finally:
                manager.close()


    def test_prepare_stream_uses_rolling_window_not_queue_all_first(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            manager.parallel_setup = 4
            manager.setup_stagger_seconds = 0.05
            endpoint = ProxyEndpoint("192.0.2.10", 8000, "user", "pass")
            submitted: list[str] = []

            def prepare(serial: str, _context: str):
                submitted.append(serial)
                return serial, endpoint, ""

            manager._prepare_with_fallback = prepare
            try:
                stream = manager.prepare_stream(
                    [f"device-{index}:5555" for index in range(20)], "rolling"
                )
                first = next(stream)
                self.assertTrue(first[1])
                # Only the active four-slot window may have been submitted before
                # the first ready result is yielded.
                self.assertLessEqual(len(submitted), 4)
                stream.close()
            finally:
                manager.close()

    def test_shutdown_stops_proxy_stream_before_new_work_is_queued(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manager = self.make_manager(Path(directory))
            manager.request_stop()
            with patch.object(manager, "_prepare_with_fallback") as prepare:
                results = list(manager.prepare_stream(
                    ["device-1:5555", "device-2:5555"], "shutdown"
                ))
            self.assertEqual(results, [])
            prepare.assert_not_called()
            manager.close()

    def test_release_device_restores_and_verifies_in_exact_order(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            calls = []

            def adb_runner(command, **kwargs):
                calls.append((list(command), kwargs.get("timeout")))
                stdout = ""
                if command[-5:] == [
                    "shell", "settings", "get", "global", "http_proxy"
                ]:
                    stdout = ":0\n"
                return CompletedProcess(command, 0, stdout=stdout, stderr="")

            manager = self.make_manager(root)
            manager._adb_runner = adb_runner
            serial = "device:5555"
            relay = Mock()
            relay.endpoint = ProxyEndpoint("192.0.2.10", 8000, "u", "p")
            manager._original_proxy[serial] = ":0"
            manager._configured_relays[serial] = 12345
            manager._relays[serial] = relay
            try:
                errors = manager.release_device(serial)
                self.assertEqual(errors, [])
                suffixes = [command[3:] for command, _ in calls]
                self.assertEqual(
                    suffixes,
                    [
                        ["shell", "settings", "put", "global", "http_proxy", ":0"],
                        ["shell", "settings", "get", "global", "http_proxy"],
                        ["reverse", "--remove", f"tcp:{manager.device_port}"],
                        ["reverse", "--list"],
                    ],
                )
                self.assertTrue(all(timeout == 2 for _, timeout in calls))
                relay.close_active_connections.assert_called_once_with()
                self.assertNotIn(serial, manager._original_proxy)
                self.assertNotIn(serial, manager._configured_relays)
            finally:
                manager.close()

if __name__ == "__main__":
    unittest.main()
