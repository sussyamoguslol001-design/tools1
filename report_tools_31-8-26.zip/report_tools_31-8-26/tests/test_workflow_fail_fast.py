from __future__ import annotations

import inspect
import json
import logging
import tempfile
import time
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import Mock, call, patch

from _shared.workflow_engine import (
    active_live_room_from_hierarchy,
    ordinary_video_detail_from_hierarchy,
    DestinationUnknownError,
    LiveUnavailableError,
    LiveEndedDuringWorkflow,
    LocatedElement,
    SearchResultCandidate,
    SelectorSpec,
    TikTokSelectorWorkflow,
    WorkflowError,
    normalize_search_username,
    profile_identity_state,
    search_result_candidates_from_hierarchy,
    live_search_result_candidates_from_hierarchy,
    live_search_result_rows_from_hierarchy,
    live_marked_top_search_result_from_hierarchy,
    live_search_tab_click_bounds_from_hierarchy,
    live_search_tab_selected_in_hierarchy,
    select_search_result,
    top_live_search_result_row_from_hierarchy,
    top_search_tab_selected_in_hierarchy,
    top_user_row_from_hierarchy,
    verification_overlay_present,
    target_profile_semantic_evidence,
    live_host_control_from_hierarchy,
    exact_target_search_result_from_hierarchy,
    profile_live_entry_from_hierarchy,
    tiktok_network_retry_present,
    tiktok_anr_present,
    tiktok_location_permission_dialog_present,
)


LIVE_RESULTS_XML = """<hierarchy>
  <node class="android.widget.FrameLayout" bounds="[0,100][1080,350]">
    <node class="android.widget.ImageView" bounds="[30,140][170,280]" />
    <node class="android.widget.TextView" text="LIVE" bounds="[105,245][185,290]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@top.live" bounds="[210,160][600,220]" />
  </node>
  <node class="android.widget.FrameLayout" bounds="[0,350][1080,600]">
    <node class="android.widget.ImageView" bounds="[30,390][170,530]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@offline.user" bounds="[210,410][600,470]" />
  </node>
</hierarchy>"""

LIVE_TAB_RESULTS_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" bounds="[0,160][1080,300]">
    <node class="android.widget.LinearLayout" text="" clickable="true" selected="false" bounds="[280,180][480,280]">
      <node class="android.widget.TextView" text="Users" bounds="[320,200][440,260]" />
    </node>
    <node class="android.widget.LinearLayout" text="" clickable="true" selected="true" bounds="[500,180][700,280]">
      <node class="android.widget.TextView" text="LIVE" bounds="[550,200][650,260]" />
    </node>
  </node>
  <node class="android.widget.Button" clickable="true" bounds="[0,360][1080,620]">
    <node class="android.widget.ImageView" bounds="[35,390][260,590]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@mlbb.top" bounds="[290,420][700,480]" />
    <node class="android.widget.TextView" text="LIVE" bounds="[170,545][250,590]" />
  </node>
  <node class="android.widget.Button" clickable="true" bounds="[0,640][1080,900]">
    <node class="android.widget.ImageView" bounds="[35,670][260,870]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@mlbb.second" bounds="[290,700][700,760]" />
  </node>
</hierarchy>"""


LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" bounds="[0,160][1080,300]">
    <node class="android.widget.LinearLayout" clickable="true" selected="false" bounds="[280,180][480,280]">
      <node class="android.widget.TextView" text="Users" bounds="[320,200][440,260]" />
    </node>
    <node class="android.widget.LinearLayout" clickable="false" selected="true" bounds="[500,180][700,280]">
      <node class="android.widget.TextView" text="LIVE" selected="true" bounds="[550,200][650,260]" />
    </node>
  </node>
  <node class="android.widget.Button" clickable="true" bounds="[0,360][1080,620]">
    <node class="android.widget.ImageView" bounds="[35,390][260,590]" />
    <node class="android.widget.TextView" text="Mobile Legends ranked" bounds="[290,420][800,480]" />
  </node>
  <node class="android.widget.Button" clickable="true" bounds="[0,640][1080,900]">
    <node class="android.widget.ImageView" bounds="[35,670][260,870]" />
    <node class="android.widget.TextView" text="MLBB second stream" bounds="[290,700][800,760]" />
  </node>
</hierarchy>"""


TOP_TAB_LIVE_GRID_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" bounds="[0,256][1080,376]">
    <node class="android.widget.FrameLayout" content-desc="Top" clickable="false" selected="true" bounds="[174,256][330,376]">
      <node class="android.widget.TextView" text="Top" selected="true" bounds="[204,256][300,376]" />
    </node>
    <node class="android.widget.FrameLayout" content-desc="LIVE" clickable="true" selected="false" bounds="[330,256][486,376]" />
    <node class="android.widget.FrameLayout" content-desc="Users" clickable="true" selected="false" bounds="[486,256][667,376]" />
  </node>
  <node class="android.widget.LinearLayout" clickable="true" enabled="true" bounds="[0,376][1080,490]">
    <node class="android.widget.TextView" text="LIVE" bounds="[36,397][130,469]" />
    <node class="android.widget.TextView" text="View all" bounds="[890,397][1044,469]" />
  </node>
  <node class="android.widget.GridView" bounds="[0,376][1080,1776]">
    <node class="android.widget.LinearLayout" clickable="true" enabled="true" bounds="[12,388][534,1457]">
      <node class="android.widget.TextView" resource-id="com.ss.android.ugc.trill:id/lwv" text="LIVE" bounds="[48,415][126,460]" />
      <node class="android.widget.TextView" text="Mobile Legends ranked" bounds="[36,1241][498,1355]" />
    </node>
    <node class="android.widget.FrameLayout" clickable="true" enabled="true" bounds="[546,388][1068,1475]">
      <node class="android.widget.TextView" text="Top liked" bounds="[570,412][755,463]" />
    </node>
  </node>
</hierarchy>"""

# Reduced layouts from failed_logs/20260905_173645_269888_000003. Keep the
# disabled parent layouts: Android still exposes enabled children beneath them.
LIVE_TAB_UNLABELED_GRID_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" bounds="[0,256][1080,376]">
    <node class="android.widget.FrameLayout" content-desc="Users" clickable="true" bounds="[254,256][462,376]" />
    <node class="android.widget.FrameLayout" content-desc="LIVE" clickable="false" selected="true" bounds="[462,256][618,376]">
      <node class="android.widget.TextView" text="LIVE" selected="true" bounds="[492,256][588,376]" />
    </node>
  </node>
  <node class="android.view.ViewGroup" enabled="false" bounds="[0,376][1080,1776]">
    <node class="android.widget.GridView" enabled="true" bounds="[0,376][1080,1776]">
      <node class="android.widget.FrameLayout" clickable="false" bounds="[0,376][1080,400]" />
      <node class="android.widget.FrameLayout" clickable="false" bounds="[24,400][552,1409]">
        <node class="android.view.ViewGroup" bounds="[24,400][552,1409]">
          <node class="android.view.ViewGroup" bounds="[24,400][528,1385]">
            <node class="android.widget.ImageView" bounds="[159,432][195,468]" />
          </node>
        </node>
      </node>
      <node class="android.widget.FrameLayout" clickable="false" bounds="[552,400][1080,1409]">
        <node class="android.view.ViewGroup" bounds="[552,400][1056,1385]" />
      </node>
      <node class="android.widget.FrameLayout" clickable="false" bounds="[24,1409][552,1776]" />
      <node class="android.widget.FrameLayout" clickable="false" bounds="[552,1409][1080,1776]" />
    </node>
  </node>
</hierarchy>"""

DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML = """<hierarchy>
  <node class="android.view.ViewGroup" enabled="false" bounds="[0,0][1080,1776]">
    <node resource-id="com.ss.android.ugc.trill:id/user_info_container" class="android.view.ViewGroup" bounds="[36,124][555,232]">
      <node resource-id="com.ss.android.ugc.trill:id/ayg" class="android.widget.Button" clickable="true" enabled="true" content-desc="Shine,0" bounds="[36,124][555,232]" />
      <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="Shine" bounds="[156,131][318,182]" />
      <node class="android.widget.Button" content-desc="Follow Shine" bounds="[330,136][543,220]" />
    </node>
    <node resource-id="com.ss.android.ugc.trill:id/b9k" class="android.view.ViewGroup" bounds="[591,124][948,232]" />
    <node resource-id="com.ss.android.ugc.trill:id/e16" class="android.widget.ImageView" content-desc="@2131840551" clickable="true" bounds="[984,142][1056,214]" />
    <node resource-id="com.ss.android.ugc.trill:id/tv_ranking_entrance_text" class="android.widget.TextView" text="Gaming Ranking" bounds="[36,250][360,304]" />
    <node resource-id="com.ss.android.ugc.trill:id/viewer_wishes_root_layout" class="android.view.ViewGroup" bounds="[0,514][1080,932]" />
    <node resource-id="com.ss.android.ugc.trill:id/text" class="android.widget.TextView" text="viewer123 joined" bounds="[138,1503][512,1558]" />
    <node resource-id="com.ss.android.ugc.trill:id/gn2" class="android.widget.TextView" text="Type..." bounds="[36,1632][612,1740]" />
  </node>
</hierarchy>"""

DISCOVERY_BROADCASTER_SHEET_XML = """<node class="android.view.ViewGroup" bounds="[0,900][1080,1776]">
  <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@shine.mlbb" bounds="[100,1000][600,1080]" />
  <node class="android.widget.Button" text="Report" bounds="[100,1200][600,1280]" />
</node>"""


TOP_TAB_LIVE_GRID_WITHOUT_LIVE_TAB_XML = TOP_TAB_LIVE_GRID_XML.replace(
    '    <node class="android.widget.FrameLayout" content-desc="LIVE" clickable="true" selected="false" bounds="[330,256][486,376]" />\n',
    '    <node class="android.widget.FrameLayout" content-desc="Videos" clickable="true" selected="false" bounds="[330,256][538,376]" />\n',
)


DETAIL_ACTIVITY_LIVE_XML = """<hierarchy>
  <node resource-id="com.ss.android.ugc.trill:id/user_info_container" class="android.view.ViewGroup" bounds="[36,124][648,232]">
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="RIXI ID" bounds="[156,131][411,182]" />
  </node>
  <node resource-id="com.ss.android.ugc.trill:id/tv_online_audience_num" class="android.widget.TextView" text="541" visible-to-user="true" bounds="[861,157][921,200]" />
</hierarchy>"""


DETAIL_ACTIVITY_EMBEDDED_LIVE_XML = """<hierarchy>
  <node resource-id="com.ss.android.ugc.trill:id/user_info_container" class="android.view.ViewGroup" bounds="[36,124][645,232]">
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="RizkySaberReal" bounds="[156,131][408,182]" />
  </node>
  <node resource-id="com.ss.android.ugc.trill:id/pgz" class="android.view.ViewGroup" content-desc="1.3K views" bounds="[831,142][948,214]" />
  <node resource-id="com.ss.android.ugc.trill:id/viewer_wishes_root_layout" class="android.view.ViewGroup" bounds="[0,490][1080,1776]" />
  <node resource-id="com.ss.android.ugc.trill:id/text" class="android.widget.TextView" text="farissyafiq13 joined" bounds="[36,1500][800,1560]" />
  <node resource-id="com.ss.android.ugc.trill:id/gjv" class="android.widget.TextView" text="Type..." bounds="[36,1632][480,1740]" />
</hierarchy>"""


ORDINARY_DETAIL_VIDEO_XML = """<hierarchy>
  <node resource-id="com.ss.android.ugc.trill:id/user_info_container" class="android.view.ViewGroup" bounds="[36,124][645,232]">
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="VideoAuthor" bounds="[156,131][408,182]" />
  </node>
  <node class="android.view.ViewGroup" content-desc="1.3K views" bounds="[831,142][948,214]" />
  <node class="android.widget.TextView" text="Add comment..." bounds="[36,1632][480,1740]" />
  <node class="android.widget.Button" content-desc="4 shares. Share video" bounds="[900,1500][1060,1700]" />
</hierarchy>"""


LIVE_TAB_SELECTED_NONCLICKABLE_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" scrollable="true" bounds="[0,256][1080,376]">
    <node class="android.widget.LinearLayout" bounds="[0,256][1080,376]">
      <node class="android.widget.FrameLayout" content-desc="Top" clickable="true" selected="false" bounds="[174,256][330,376]">
        <node class="android.widget.TextView" text="Top" selected="false" bounds="[204,256][300,376]" />
      </node>
      <node class="android.widget.FrameLayout" content-desc="LIVE" clickable="false" selected="true" bounds="[330,256][486,376]">
        <node class="android.widget.TextView" text="LIVE" clickable="false" selected="true" bounds="[360,256][456,376]" />
      </node>
      <node class="android.widget.FrameLayout" content-desc="Users" clickable="true" selected="false" bounds="[486,256][667,376]">
        <node class="android.widget.TextView" text="Users" selected="false" bounds="[516,256][637,376]" />
      </node>
      <node class="android.widget.FrameLayout" content-desc="Videos" clickable="true" selected="false" bounds="[667,256][875,376]" />
    </node>
  </node>
</hierarchy>"""


LIVE_TAB_SCROLLED_PAST_LIVE_XML = """<hierarchy>
  <node class="android.widget.HorizontalScrollView" scrollable="true" bounds="[0,256][1080,376]">
    <node class="android.widget.LinearLayout" bounds="[-400,256][1080,376]">
      <node class="android.widget.FrameLayout" content-desc="Users" clickable="true" selected="false" bounds="[20,256][201,376]">
        <node class="android.widget.TextView" text="Users" bounds="[50,256][171,376]" />
      </node>
      <node class="android.widget.FrameLayout" content-desc="Shop" clickable="true" selected="false" bounds="[201,256][374,376]" />
      <node class="android.widget.FrameLayout" content-desc="Sounds" clickable="true" selected="false" bounds="[374,256][596,376]" />
    </node>
  </node>
</hierarchy>"""


RESULTS_XML = """<hierarchy>
  <node class="android.widget.FrameLayout" bounds="[0,100][1080,350]">
    <node class="android.widget.ImageView" bounds="[30,140][170,280]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@abc1234" bounds="[210,160][600,220]" />
  </node>
  <node class="android.widget.FrameLayout" bounds="[0,350][1080,600]">
    <node class="android.widget.ImageView" bounds="[30,390][170,530]" />
    <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="@abc123" bounds="[210,410][600,470]" />
  </node>
</hierarchy>"""

EXACT_PROFILE_XML = """<hierarchy><node
 resource-id="com.ss.android.ugc.trill:id/user_name"
 class="android.widget.TextView" text="@abc123" bounds="[100,100][500,180]"
/></hierarchy>"""

WRONG_PROFILE_XML = """<hierarchy><node
 resource-id="com.ss.android.ugc.trill:id/user_name"
 class="android.widget.TextView" text="@wrong.account" bounds="[100,100][500,180]"
/></hierarchy>"""

OVERLAY_XML = """<hierarchy>
 <node resource-id="com.ss.android.ugc.trill:id/verify_cardview" class="android.widget.FrameLayout" bounds="[100,600][900,1500]">
  <node class="android.webkit.WebView" text="verify captcha" bounds="[100,600][900,1500]" />
  <node resource-id="verify-bar-close" class="android.widget.Button" text="Close" bounds="[800,600][900,700]" />
 </node>
</hierarchy>"""

CLEAR_XML = "<hierarchy><node class=\"android.widget.FrameLayout\" bounds=\"[0,0][1080,2200]\" /></hierarchy>"


class DeferredSearchTarget:
    def __init__(self, ready_after: int) -> None:
        self.ready_after = ready_after
        self.count_checks = 0
        self.click = Mock()

    @property
    def count(self) -> int:
        self.count_checks += 1
        return int(self.count_checks >= self.ready_after)

    @property
    def info(self) -> dict:
        return {
            "resourceName": "",
            "text": "",
            "contentDescription": "Search",
            "className": "android.widget.Button",
            "visibleBounds": {"left": 0, "top": 0, "right": 100, "bottom": 40},
            "clickable": True,
            "enabled": True,
        }


def located(name: str = "control", class_name: str = "android.widget.Button") -> LocatedElement:
    return LocatedElement(
        action=name,
        selector=SelectorSpec("text", "ui-selector", {"text": name}),
        selector_count=1,
        resource_id="",
        text=name,
        description="",
        class_name=class_name,
        bounds=(0, 0, 100, 40),
        clickable=True,
        enabled=True,
    )


class SearchWorkflowTests(unittest.TestCase):
    def bare_workflow(self) -> TikTokSelectorWorkflow:
        workflow = TikTokSelectorWorkflow.__new__(TikTokSelectorWorkflow)
        workflow.config = {
            "poll_interval_seconds": 0.001,
            "post_submit_settlement_seconds": 0,
            "submit_rpc_timeout_seconds": 0.01,
            "destination_classification_timeout_seconds": 0.01,
            "live_identity_timeout_seconds": 0.01,
            "live_stabilization_seconds": 0,
            "profile_live_entry_timeout_seconds": 0.02,
            "live_handoff_final_grace_seconds": 0.01,
            "adb_keyevent_timeout_seconds": 0.02,
            "search_launch_timeout_seconds": 0.02,
            "precheck_ui_readiness_before_recovery_seconds": 0.01,
            "selectors": {
                "search_button": {
                    "description": "Search",
                    "alternate_descriptions": ["Cari"],
                    "text": "Search",
                    "alternate_texts": ["Cari"],
                    "timeout_seconds": 0.02,
                },
                "search_input": {
                    "resource_id": "com.ss.android.ugc.trill:id/ho3",
                    "class_name": "android.widget.EditText",
                    "allow_unique_class_only": True,
                    "timeout_seconds": 0.02,
                },
                "users_tab": {"text": "Users", "timeout_seconds": 0.02},
                "host_profile": {"text": "host", "timeout_seconds": 0.01},
                "report_button": {"text": "Report"},
                "verification_close": {
                    "resource_id": "verify-bar-close",
                    "text": "Close",
                    "timeout_seconds": 0.01,
                    "after_timeout_seconds": 0.01,
                },
                "select_reason_title": {"text": "Select a reason"},
                "report_description_title": {"text": "Report Description"},
                "report_reason": {"text": "Frauds and scams"},
                "submit_button": {
                    "text": "Submit",
                    "timeout_seconds": 0.01,
                    "after_timeout_seconds": 0.01,
                },
                "thanks_title": {"text": "Thanks for reporting"},
            },
            "profile_activity_contains": ["UserProfileActivity", ".profile."],
        }
        workflow.serial = "device:5555"
        workflow.live_url = "https://www.tiktok.com/@abc123/live"
        workflow.live_username = "abc123"
        workflow.workflow_mode = "report"
        workflow.package = "com.ss.android.ugc.trill"
        workflow.device = Mock()
        workflow.logger = Mock(spec=logging.Logger)
        workflow.current_stage = "INIT"
        workflow.current_action = ""
        workflow.stage_timings = {}
        workflow._stage_started = workflow._workflow_started = time.monotonic()
        workflow._live_precheck_deadline = None
        workflow._ready_search_control = None
        workflow.tiktok_launch_mode = "not-started"
        workflow.diagnostics_enabled = False
        workflow.submit_completed = False
        workflow.submit_completion_detection = ""
        workflow.submission_state = "NOT_SUBMITTED"
        workflow.submit_attempted = False
        workflow.ui_confirmation_observed = False
        workflow.settlement_completed = False
        workflow.confirmation_source = ""
        workflow.backend_acceptance = "unknown"
        workflow.confirmation_wait_seconds = 0.0
        workflow.settlement_seconds = 0.0
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        workflow._test_tempdir = temporary
        workflow.run_dir = Path(temporary.name)
        workflow.live_identity_verified = False
        workflow.live_profile_sheet_ready = False
        workflow.search_result_candidates = []
        workflow.search_selected_result = {}
        workflow.search_used_top_fallback = False
        workflow.observed_destination_usernames = []
        workflow.broadcaster_identity_candidates = []
        workflow.last_selector_diagnostics = []
        workflow.last_selector_failure_kind = ""
        workflow.save_state = Mock()
        workflow._uiautomator_recovery_used = False
        workflow.uiautomator_repairs = []
        workflow._network_retry_used = False
        workflow._anr_wait_used = False
        workflow._location_permission_handled = False
        workflow.adb = Mock(return_value=Mock(returncode=0, stdout="", stderr=""))
        return workflow

    def test_live_search_result_candidates_returns_top_live_marked_row(self) -> None:
        candidates = live_search_result_candidates_from_hierarchy(LIVE_RESULTS_XML)
        self.assertEqual([candidate.username for candidate in candidates], ["top.live"])

    def test_live_search_tab_helpers_use_search_tab_not_result_live_badge(self) -> None:
        self.assertTrue(live_search_tab_selected_in_hierarchy(LIVE_TAB_RESULTS_XML))
        self.assertEqual(
            live_search_tab_click_bounds_from_hierarchy(LIVE_TAB_RESULTS_XML),
            (500, 180, 700, 280),
        )

    def test_selected_live_tab_can_be_nonclickable_on_real_tiktok_search_ui(self) -> None:
        self.assertTrue(live_search_tab_selected_in_hierarchy(LIVE_TAB_SELECTED_NONCLICKABLE_XML))
        self.assertIsNone(live_search_tab_click_bounds_from_hierarchy(LIVE_TAB_SELECTED_NONCLICKABLE_XML))

    def test_keyword_discovery_accepts_already_selected_nonclickable_live_tab(self) -> None:
        workflow = self.bare_workflow()
        workflow.search_query = "mobile legend"
        workflow._dump_hierarchy = Mock(return_value=LIVE_TAB_SELECTED_NONCLICKABLE_XML)
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()

        workflow.select_live_search_tab()

        workflow.device.click.assert_not_called()
        workflow.device.swipe.assert_not_called()

    def test_keyword_discovery_switches_from_users_to_live_tab(self) -> None:
        users_selected = LIVE_TAB_RESULTS_XML.replace(
            'selected="false" bounds="[280,180][480,280]"',
            'selected="true" bounds="[280,180][480,280]"',
        ).replace(
            'selected="true" bounds="[500,180][700,280]"',
            'selected="false" bounds="[500,180][700,280]"',
        )
        workflow = self.bare_workflow()
        workflow.search_query = "mobile legend"
        workflow._dump_hierarchy = Mock(
            side_effect=[users_selected, LIVE_TAB_RESULTS_XML]
        )
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()

        workflow.select_live_search_tab()

        workflow.device.click.assert_called_once_with(600, 230)

    def test_keyword_discovery_reveals_live_tab_to_left(self) -> None:
        workflow = self.bare_workflow()
        workflow.search_query = "mobile legend"
        workflow._dump_hierarchy = Mock(
            side_effect=[LIVE_TAB_SCROLLED_PAST_LIVE_XML, LIVE_TAB_SELECTED_NONCLICKABLE_XML]
        )
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()
        workflow.device.window_size.return_value = (1080, 1920)

        workflow.select_live_search_tab()

        workflow.device.swipe.assert_called_once_with(302, 316, 885, 316, 0.2)
        workflow.device.click.assert_not_called()

    def test_live_tab_structural_result_uses_first_row_without_username(self) -> None:
        selected = top_live_search_result_row_from_hierarchy(
            LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML
        )

        self.assertIsNotNone(selected)
        assert selected is not None
        self.assertEqual(selected.row_bounds, (0, 360, 1080, 620))
        self.assertEqual(selected.avatar_point, (147, 490))

    def test_live_tab_structural_results_are_bounded_in_screen_order(self) -> None:
        rows = live_search_result_rows_from_hierarchy(
            LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML, maximum=2
        )

        self.assertEqual(len(rows), 2)
        self.assertEqual(
            [row.row_bounds for row in rows],
            [(0, 360, 1080, 620), (0, 640, 1080, 900)],
        )

    def test_top_fallback_selects_first_explicit_live_marked_card(self) -> None:
        self.assertTrue(top_search_tab_selected_in_hierarchy(TOP_TAB_LIVE_GRID_XML))

        selected = live_marked_top_search_result_from_hierarchy(
            TOP_TAB_LIVE_GRID_XML
        )

        self.assertIsNotNone(selected)
        assert selected is not None
        self.assertEqual(selected.row_bounds, (12, 388, 534, 1457))
        self.assertEqual(selected.avatar_point, (273, 922))
        self.assertIn("LIVE", selected.texts)

    def test_live_grid_without_labels_or_clickable_nodes_selects_three_distinct_tiles(self) -> None:
        rows = live_search_result_rows_from_hierarchy(LIVE_TAB_UNLABELED_GRID_XML)
        self.assertEqual([row.row_bounds for row in rows], [
            (24, 400, 552, 1409), (552, 400, 1080, 1409), (24, 1409, 552, 1776),
        ])
        self.assertEqual([row.avatar_point for row in rows], [(288, 664), (816, 664), (288, 1592)])
        self.assertTrue(all(row.texts == () for row in rows))
        self.assertEqual(top_live_search_result_row_from_hierarchy(LIVE_TAB_UNLABELED_GRID_XML), rows[0])
        self.assertEqual(live_search_result_rows_from_hierarchy(LIVE_TAB_UNLABELED_GRID_XML, maximum=1), rows[:1])
        self.assertIsNone(top_user_row_from_hierarchy(LIVE_TAB_UNLABELED_GRID_XML))

    def test_live_grid_requires_selected_live_tab_and_visible_usable_tiles(self) -> None:
        for xml in (
            LIVE_TAB_UNLABELED_GRID_XML.replace('selected="true"', 'selected="false"'),
            LIVE_TAB_UNLABELED_GRID_XML.replace('"LIVE"', '"Videos"'),
            LIVE_TAB_UNLABELED_GRID_XML.replace('class="android.widget.GridView"', 'visible-to-user="false" class="android.widget.GridView"'),
            LIVE_TAB_UNLABELED_GRID_XML.replace('clickable="false" bounds=', 'enabled="false" clickable="false" bounds='),
            LIVE_TAB_UNLABELED_GRID_XML.replace('class="android.view.ViewGroup" enabled="false"', 'visible-to-user="false" class="android.view.ViewGroup" enabled="false"'),
            "<broken",
        ):
            with self.subTest(xml=xml[:100]):
                self.assertEqual(live_search_result_rows_from_hierarchy(xml), [])

    def test_no_count_live_room_requires_chat_wishes_ranking_and_host(self) -> None:
        self.assertTrue(active_live_room_from_hierarchy(DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML))
        self.assertFalse(ordinary_video_detail_from_hierarchy(DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML))
        for original, replacement in (
            ('text="Shine"', 'text=""'),
            ('text="Type..."', 'text="Add comment..."'),
            ('id/viewer_wishes_root_layout', 'id/ordinary_container'),
            ('id/tv_ranking_entrance_text', 'id/video_ranking'),
            ('clickable="true"', 'clickable="false"'),
            ('text="Gaming Ranking"', 'visible-to-user="false" text="Gaming Ranking"'),
        ):
            with self.subTest(missing=original):
                self.assertFalse(active_live_room_from_hierarchy(
                    DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML.replace(original, replacement)
                ))

    def test_grid_discovery_enters_room_clicks_host_and_reads_sheet_username(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.search_query = "mobile legend"
        workflow.live_username = ""
        workflow.config.update({"precheck_destination_classification_timeout_seconds": 1, "live_identity_timeout_seconds": 1})
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.target_is_excluded = Mock(return_value=False)
        workflow.select_top_search_tab_for_live_fallback = Mock()
        state = {"screen": "results"}
        events = []
        screens = {
            "results": LIVE_TAB_UNLABELED_GRID_XML,
            "room": DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML,
            # The underlying LIVE header can remain visible below the sheet.
            "sheet": DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML.replace("</hierarchy>", DISCOVERY_BROADCASTER_SHEET_XML + "</hierarchy>"),
        }
        workflow._dump_hierarchy = Mock(side_effect=lambda _context: screens[state["screen"]])
        workflow.current_app = Mock(side_effect=lambda: {
            "package": workflow.package,
            "activity": "SearchActivity" if state["screen"] == "results" else "com.ss.android.ugc.aweme.detail.ui.DetailActivity",
        })

        def open_preview(x, y):
            self.assertEqual((x, y), (288, 664))
            events.append("preview")
            state["screen"] = "room"

        def open_host():
            self.assertEqual(state["screen"], "room")
            events.append("host")
            state["screen"] = "sheet"

        workflow.device.click.side_effect = open_preview
        host = Mock(count=1)
        host.info = {"enabled": True, "bounds": {"left": 36, "top": 124, "right": 555, "bottom": 232}}
        host.click.side_effect = open_host
        workflow.device.return_value = host

        self.assertEqual(workflow.discover_top_live_user_from_search(), "shine.mlbb")
        self.assertEqual(events, ["preview", "host"])
        self.assertEqual(workflow.discovered_live_url, "https://www.tiktok.com/@shine.mlbb/live")
        self.assertEqual(workflow.search_selected_result["username"], "shine.mlbb")
        workflow.device.assert_called_once_with(resourceId="com.ss.android.ugc.trill:id/ayg", className="android.widget.Button", clickable=True)
        workflow.select_top_search_tab_for_live_fallback.assert_not_called()

    def test_discovery_rejects_missing_or_ambiguous_sheet_identity(self) -> None:
        for sheet, expected_error in (
            ("", "DISCOVERY_IDENTITY_UNAVAILABLE"),
            (DISCOVERY_BROADCASTER_SHEET_XML.replace('text="Report"', 'text="Share"'), "DISCOVERY_IDENTITY_UNAVAILABLE"),
            (DISCOVERY_BROADCASTER_SHEET_XML.replace('text="@shine.mlbb"', 'visible-to-user="false" text="@shine.mlbb"'), "DISCOVERY_IDENTITY_UNAVAILABLE"),
            (DISCOVERY_BROADCASTER_SHEET_XML + DISCOVERY_BROADCASTER_SHEET_XML.replace("shine.mlbb", "another.host"), "DISCOVERY_IDENTITY_AMBIGUOUS"),
        ):
            with self.subTest(expected_error=expected_error, sheet=sheet):
                workflow = self.bare_workflow()
                workflow.workflow_mode = "live_discovery"
                workflow.live_context_ok = Mock(return_value=True)
                workflow.recover_known_blocking_state = Mock(return_value=False)
                host = Mock()
                workflow._structural_live_host_target = Mock(return_value=(host, {}))
                workflow._dump_hierarchy = Mock(return_value=DETAIL_ACTIVITY_LIVE_WITHOUT_COUNT_XML.replace("</hierarchy>", sheet + "</hierarchy>"))
                with self.assertRaisesRegex(DestinationUnknownError, expected_error):
                    workflow.discover_open_live_broadcaster_username()
                host.click.assert_called_once_with()

    def test_new_detail_activity_requires_host_and_live_audience_structure(self) -> None:
        self.assertTrue(active_live_room_from_hierarchy(DETAIL_ACTIVITY_LIVE_XML))
        self.assertFalse(
            active_live_room_from_hierarchy(
                DETAIL_ACTIVITY_LIVE_XML.replace("tv_online_audience_num", "view_count")
            )
        )

    def test_embedded_detail_live_requires_audience_chat_and_live_surface(self) -> None:
        self.assertTrue(active_live_room_from_hierarchy(DETAIL_ACTIVITY_EMBEDDED_LIVE_XML))
        self.assertFalse(
            active_live_room_from_hierarchy(
                DETAIL_ACTIVITY_EMBEDDED_LIVE_XML.replace("Type...", "Add comment...")
            )
        )
        self.assertFalse(active_live_room_from_hierarchy(ORDINARY_DETAIL_VIDEO_XML))
        self.assertTrue(ordinary_video_detail_from_hierarchy(ORDINARY_DETAIL_VIDEO_XML))
        self.assertFalse(
            ordinary_video_detail_from_hierarchy(DETAIL_ACTIVITY_EMBEDDED_LIVE_XML)
        )

    def test_live_discovery_top_fallback_clicks_top_tab_once(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow._live_precheck_deadline = time.monotonic() + 1
        workflow._dump_hierarchy = Mock(
            side_effect=[LIVE_TAB_SELECTED_NONCLICKABLE_XML, TOP_TAB_LIVE_GRID_XML]
        )

        workflow.select_top_search_tab_for_live_fallback()

        workflow.device.click.assert_called_once_with(252, 316)

    def test_missing_live_tab_uses_explicit_live_card_already_on_top(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.search_query = "mobile legend"
        workflow._dump_hierarchy = Mock(
            return_value=TOP_TAB_LIVE_GRID_WITHOUT_LIVE_TAB_XML
        )
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()

        workflow.select_live_search_tab()

        self.assertTrue(workflow._live_tab_unavailable_top_ready)
        workflow.device.click.assert_not_called()
        workflow.device.swipe.assert_not_called()

    def test_live_tab_discovery_clicks_only_one_row_then_reads_opened_identity(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.search_query = "mobile legend"
        workflow._dump_hierarchy = Mock(return_value=LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML)
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()
        workflow.target_is_excluded = Mock(return_value=False)
        workflow.open_top_live_search_row = Mock()
        workflow.classify_top_user_precheck_destination = Mock(return_value="LIVE")
        workflow.discover_open_live_broadcaster_username = Mock(return_value="mlbb.top")

        username = workflow.discover_top_live_user_from_search()

        self.assertEqual(username, "mlbb.top")
        self.assertEqual(workflow.discovered_username, "mlbb.top")
        self.assertEqual(workflow.discovered_live_url, "https://www.tiktok.com/@mlbb.top/live")
        workflow.open_top_live_search_row.assert_called_once()
        selected = workflow.open_top_live_search_row.call_args.args[0]
        self.assertEqual(selected.row_bounds, (0, 360, 1080, 620))
        workflow.discover_open_live_broadcaster_username.assert_called_once_with()

    def test_discovery_tries_second_visible_candidate_after_first_is_stale(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.config["live_discovery_candidate_limit"] = 3
        rows = live_search_result_rows_from_hierarchy(
            LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML, maximum=3
        )
        workflow.complete_structural_live_discovery = Mock(
            side_effect=[
                LiveUnavailableError(
                    "DISCOVERY_STALE_LIVE_RESULT: first card resolved stale"
                ),
                "mlbb.second",
            ]
        )
        workflow.recover_discovery_results_after_stale = Mock(
            return_value=LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML
        )

        username = workflow.try_structural_live_candidates(
            rows,
            source="structural-live-tab-row",
            selection="first-usable-search-live-tab-result",
        )

        self.assertEqual(username, "mlbb.second")
        self.assertEqual(workflow.complete_structural_live_discovery.call_count, 2)
        attempted = [
            call.args[0].row_bounds
            for call in workflow.complete_structural_live_discovery.call_args_list
        ]
        self.assertEqual(
            attempted,
            [(0, 360, 1080, 620), (0, 640, 1080, 900)],
        )
        workflow.recover_discovery_results_after_stale.assert_called_once_with(
            source="structural-live-tab-row"
        )

    def test_discovery_stale_candidate_attempts_respect_configured_bound(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.config["live_discovery_candidate_limit"] = 2
        rows = live_search_result_rows_from_hierarchy(
            LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML, maximum=3
        )
        workflow.complete_structural_live_discovery = Mock(
            side_effect=LiveUnavailableError(
                "DISCOVERY_STALE_LIVE_RESULT: candidate resolved stale"
            )
        )
        workflow.recover_discovery_results_after_stale = Mock(
            return_value=LIVE_TAB_RESULTS_WITHOUT_USERNAME_XML
        )

        with self.assertRaisesRegex(
            LiveUnavailableError, r"DISCOVERY_STALE_LIVE_RESULT.*attempted=2"
        ):
            workflow.try_structural_live_candidates(
                rows,
                source="structural-live-tab-row",
                selection="first-usable-search-live-tab-result",
            )

        self.assertEqual(workflow.complete_structural_live_discovery.call_count, 2)

    def test_discovery_reads_username_only_after_opening_live_broadcaster_sheet(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow._live_precheck_deadline = time.monotonic() + 1
        workflow.live_context_ok = Mock(return_value=True)
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()
        target = Mock()
        workflow._structural_live_host_target = Mock(
            return_value=(target, {"bounds": (0, 0, 500, 200)})
        )
        live_without_identity = '<hierarchy><node class="android.widget.FrameLayout" bounds="[0,0][1080,1920]"/></hierarchy>'
        opened_sheet = """<hierarchy><node
          resource-id="com.ss.android.ugc.trill:id/user_name"
          class="android.widget.TextView" text="@mlbb.top"
          bounds="[100,100][500,180]"/><node class="android.widget.Button"
          text="Report" bounds="[100,300][500,380]"/></hierarchy>"""
        workflow._dump_hierarchy = Mock(
            side_effect=[live_without_identity, opened_sheet]
        )

        username = workflow.discover_open_live_broadcaster_username()

        self.assertEqual(username, "mlbb.top")
        target.click.assert_called_once_with()

    def test_discovery_does_not_treat_live_header_display_name_as_username(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow._live_precheck_deadline = time.monotonic() + 1
        workflow.live_context_ok = Mock(return_value=True)
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()
        target = Mock()
        workflow._structural_live_host_target = Mock(
            return_value=(target, {"bounds": (0, 0, 500, 200)})
        )
        live_header = """<hierarchy><node
          resource-id="com.ss.android.ugc.trill:id/user_name"
          class="android.widget.TextView" text="RizkySaberReal"
          bounds="[100,100][500,180]"/></hierarchy>"""
        opened_sheet = """<hierarchy><node
          resource-id="com.ss.android.ugc.trill:id/user_name"
          class="android.widget.TextView" text="@rizky.real"
          bounds="[100,100][500,180]"/><node class="android.widget.Button"
          text="Report" bounds="[100,300][500,380]"/></hierarchy>"""
        workflow._dump_hierarchy = Mock(side_effect=[live_header, opened_sheet])

        username = workflow.discover_open_live_broadcaster_username()

        self.assertEqual(username, "rizky.real")
        target.click.assert_called_once_with()

    def test_live_discovery_does_not_select_users_tab_before_live_tab(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.search_query = "mobile legend"
        workflow._initialize_live_precheck_deadline = Mock()
        workflow._raise_if_live_precheck_expired = Mock()
        workflow.launch_tiktok_normally = Mock()
        workflow.open_users_search = Mock()
        workflow.select_live_search_tab = Mock()
        workflow.discover_top_live_user_from_search = Mock(return_value="mlbb.top")

        workflow.run_live_discovery()

        workflow.open_users_search.assert_called_once_with(select_users_tab=False)
        workflow.select_live_search_tab.assert_called_once_with()

    def test_uiautomator_already_registered_is_targeted_reset_then_one_reconnect(self) -> None:
        workflow = self.bare_workflow()
        workflow.config.update({
            "adb_executable": "adb",
            "uiautomator_device_lock_timeout_seconds": 1,
            "uiautomator_reset_settle_seconds": 0.2,
        })
        fake_device = Mock()
        fake_device.window_size.return_value = (1080, 1920)
        conflict = RuntimeError(
            "AccessibilityServiceAlreadyRegisteredError: UiAutomationService already registered"
        )
        repair = {
            "before": ["123 com.wetest.uia2.Main"],
            "killed_pids": ["123"],
            "after": [],
        }
        with patch("_shared.workflow_engine.device_control_lease", return_value=nullcontext()), \
             patch("_shared.workflow_engine.uiautomator_process_snapshot", return_value=repair["before"]), \
             patch("_shared.workflow_engine.stop_our_uiautomator_processes", return_value=repair), \
             patch("_shared.workflow_engine.u2") as fake_u2:
            fake_u2.connect.side_effect = [conflict, fake_device]
            self.assertEqual(
                workflow._connect_uiautomator_with_repair(context="CONNECT_ADB"),
                (1080, 1920),
            )
        self.assertEqual(fake_u2.connect.call_count, 2)
        self.assertEqual(workflow.device, fake_device)
        self.assertEqual(workflow.uiautomator_repairs[0]["repair"]["killed_pids"], ["123"])

    def test_real_connect_persists_metadata_and_detect_package_keeps_it(self) -> None:
        workflow = self.bare_workflow()
        with tempfile.TemporaryDirectory() as directory:
            workflow.run_dir = Path(directory)
            workflow.config.update({
                "adb_executable": "adb",
                "adb_host_validated": True,
                "cached_device_metadata": {
                    "manufacturer": "samsung",
                    "model": "SM-F721U1",
                },
                "tiktok_package": "com.ss.android.ugc.trill",
            })
            workflow.device_metadata = dict(workflow.config["cached_device_metadata"])
            workflow._connect_uiautomator_with_repair = Mock(return_value=(1080, 1920))
            workflow.adb = Mock(return_value=Mock(returncode=0, stdout="device", stderr=""))

            workflow.connect()
            workflow.detect_package()

            payload = json.loads(
                (workflow.run_dir / "device_metadata.json").read_text(encoding="utf-8")
            )
            self.assertEqual(payload["manufacturer"], "samsung")
            self.assertEqual(payload["model"], "SM-F721U1")
            self.assertEqual(payload["adb_serial"], "device:5555")
            self.assertEqual(payload["window_width"], 1080)
            self.assertEqual(payload["window_height"], 1920)
            self.assertEqual(payload["tiktok_package"], "com.ss.android.ugc.trill")

    def test_missing_program_attribute_is_internal_program_error(self) -> None:
        workflow = self.bare_workflow()
        code, cause, solution = workflow.classify_error(
            AttributeError("missing internal helper")
        )
        self.assertEqual(code, "INTERNAL_PROGRAM_ERROR")
        self.assertIn("programming error", cause)
        self.assertIn("Stop the watchlist loop", solution)

    def test_tiktok_location_permission_is_handled_during_foreground_wait(self) -> None:
        workflow = self.bare_workflow()
        workflow.package = "com.ss.android.ugc.trill"
        permission_xml = """<hierarchy>
        <node text="Allow TikTok to access this device's location?"/>
        <node resource-id="com.android.permissioncontroller:id/permission_deny_button" text="Don't allow" clickable="true"/>
        </hierarchy>"""
        workflow.current_app = Mock(side_effect=[
            {"package": "com.google.android.packageinstaller", "activity": "GrantPermissionsActivity"},
            {"package": workflow.package, "activity": "MainActivity"},
        ])
        workflow._dump_hierarchy = Mock(return_value=permission_xml)
        workflow.handle_tiktok_location_permission_dialog = Mock(return_value=True)
        workflow._wait_for_tiktok_foreground(0.2)
        workflow.handle_tiktok_location_permission_dialog.assert_called_once_with(permission_xml)

    def test_username_normalization(self) -> None:
        for value in (
            "abc123",
            "@abc123",
            "https://www.tiktok.com/@abc123/live",
        ):
            with self.subTest(value=value):
                self.assertEqual(normalize_search_username(value), "abc123")

    def test_foreground_ready_tiktok_is_force_stopped_and_cold_started(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        workflow.locate_unique = Mock(
            return_value=(Mock(), located("Search"))
        )
        workflow.launch_tiktok_normally()
        workflow.device.app_start.assert_called_once_with(
            workflow.package, stop=True
        )
        self.assertEqual(workflow.tiktok_launch_mode, "cold-start")

    def test_background_tiktok_is_force_stopped_and_cold_started(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        workflow.locate_unique = Mock(
            return_value=(Mock(), located("Search"))
        )
        workflow.launch_tiktok_normally()
        workflow.device.app_start.assert_called_once_with(
            workflow.package, stop=True
        )
        self.assertEqual(workflow.tiktok_launch_mode, "cold-start")

    def test_foreground_package_without_search_is_not_ui_ready(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        target = DeferredSearchTarget(ready_after=10_000)
        workflow.device.side_effect = lambda **_values: target
        with self.assertRaisesRegex(DestinationUnknownError, "TIKTOK_UI_NOT_READY"):
            workflow.launch_tiktok_normally()
        self.assertEqual(workflow.current_stage, "SEARCH_LAUNCH")
        self.assertIsNone(workflow._ready_search_control)
        self.assertEqual(
            workflow.device.app_start.call_args_list,
            [call(workflow.package, stop=True), call(workflow.package, stop=True)],
        )

    def test_launch_waits_until_search_appears_then_returns(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        target = DeferredSearchTarget(ready_after=10)
        workflow.device.side_effect = lambda **_values: target
        with patch(
            "_shared.workflow_engine.time.sleep", wraps=time.sleep
        ) as sleeper:
            workflow.launch_tiktok_normally()
        self.assertGreaterEqual(target.count_checks, 10)
        sleeper.assert_called()
        self.assertIs(workflow._ready_search_control[0], target)

    def test_launch_readiness_respects_shared_precheck_deadline(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow._live_precheck_deadline = time.monotonic() + 0.005
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        target = DeferredSearchTarget(ready_after=10_000)
        workflow.device.side_effect = lambda **_values: target
        with self.assertRaisesRegex(
            WorkflowError, "LIVE_PRECHECK_TIMEOUT: stage=SEARCH_LAUNCH"
        ):
            workflow.launch_tiktok_normally()

    def test_search_already_visible_has_no_fixed_startup_sleep(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        target = DeferredSearchTarget(ready_after=1)
        workflow.device.side_effect = lambda **_values: target
        with patch("_shared.workflow_engine.time.sleep") as sleeper:
            workflow.launch_tiktok_normally()
        sleeper.assert_not_called()
        workflow.device.app_start.assert_called_once_with(
            workflow.package, stop=True
        )
        self.assertEqual(workflow.tiktok_launch_mode, "cold-start")

    def test_ready_search_control_is_reused_without_duplicate_search_wait(self) -> None:
        workflow = self.bare_workflow()
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "MainActivity"}
        )
        search_target = Mock()
        input_target = Mock()
        input_target.info = {"text": "abc123"}
        users_target = Mock()
        workflow.locate_unique = Mock(
            side_effect=[
                (search_target, located("Search")),
                (input_target, located("Search input", "android.widget.EditText")),
                (users_target, located("Users")),
            ]
        )
        workflow.selector_exists = Mock(return_value=True)
        workflow.launch_tiktok_normally()
        self.assertEqual(workflow.current_stage, "SEARCH_LAUNCH")
        workflow.open_users_search()
        self.assertEqual(workflow.locate_unique.call_count, 3)
        search_target.click.assert_called_once_with()
        input_target.set_text.assert_called_once_with("abc123")
        users_target.click.assert_called_once_with()

    def test_wrong_stale_search_text_is_never_submitted(self) -> None:
        workflow = self.bare_workflow()
        search_target = Mock()
        input_target = Mock()
        input_target.info = {"text": "byon andi vs jhon"}
        users_target = Mock()
        workflow.device.send_keys = None
        workflow.locate_unique = Mock(
            side_effect=[
                (input_target, located("Search input", "android.widget.EditText")),
                (users_target, located("Users")),
            ]
        )
        workflow._ready_search_control = (search_target, located("Search"))

        with self.assertRaisesRegex(
            DestinationUnknownError, "SEARCH_QUERY_FAILED.*expected='abc123'"
        ):
            workflow.open_users_search()

        workflow.adb.assert_not_called()
        users_target.click.assert_not_called()
        workflow.save_state.assert_called_once_with("error_search_query_mismatch")

    def test_stale_search_text_uses_safe_focused_input_fallback_then_submits(self) -> None:
        workflow = self.bare_workflow()
        search_target = Mock()
        input_target = Mock()
        input_target.info = {"text": "byon andi vs jhon"}
        users_target = Mock()

        def set_text(value: str) -> None:
            # Simulate a TikTok build that ignores the first direct username
            # write but accepts the explicit empty-field replacement.
            if value == "":
                input_target.info = {"text": ""}

        def send_keys(value: str, clear: bool = False) -> None:
            self.assertEqual(value, "abc123")
            self.assertFalse(clear)
            input_target.info = {"text": "abc123"}

        input_target.set_text.side_effect = set_text
        workflow.device.send_keys.side_effect = send_keys
        workflow.locate_unique = Mock(
            side_effect=[
                (input_target, located("Search input", "android.widget.EditText")),
                (users_target, located("Users")),
            ]
        )
        workflow._ready_search_control = (search_target, located("Search"))

        workflow.open_users_search()

        workflow.device.send_keys.assert_called_once_with("abc123", clear=False)
        workflow.adb.assert_called_once_with(
            "shell",
            "input",
            "keyevent",
            "KEYCODE_ENTER",
            timeout=0.5,
        )
        users_target.click.assert_called_once_with()

    def test_search_input_selector_never_uses_search_description_icon(self) -> None:
        workflow = self.bare_workflow()
        specs = workflow.selector_specs(workflow.config["selectors"]["search_input"])
        self.assertTrue(specs)
        self.assertTrue(
            all(spec.values.get("description") not in {"Search", "Cari"} for spec in specs)
        )
        self.assertTrue(
            any(spec.values.get("className") == "android.widget.EditText" for spec in specs)
        )

    def test_exact_username_is_selected_when_visible(self) -> None:
        candidates = search_result_candidates_from_hierarchy(RESULTS_XML)
        selected, exact = select_search_result(candidates, "ABC123")
        self.assertTrue(exact)
        self.assertEqual(selected.username, "abc123")
        self.assertEqual(selected.avatar_bounds, (30, 390, 170, 530))

    def test_similar_username_is_rejected_as_exact(self) -> None:
        candidates = search_result_candidates_from_hierarchy(RESULTS_XML, maximum=1)
        selected, exact = select_search_result(candidates, "abc123")
        self.assertFalse(exact)
        self.assertEqual(selected.username, "abc1234")

    def test_missing_exact_uses_top_result_number_one(self) -> None:
        candidates = search_result_candidates_from_hierarchy(RESULTS_XML)
        selected, exact = select_search_result(candidates, "missing.user")
        self.assertFalse(exact)
        self.assertEqual(selected.username, "abc1234")

    def test_top_fallback_avatar_opens_destination(self) -> None:
        workflow = self.bare_workflow()
        candidate = SearchResultCandidate(
            "abc1234",
            (210, 160, 600, 220),
            (30, 140, 170, 280),
            (0, 100, 1080, 350),
            "canonical-text",
        )
        workflow.open_search_result_avatar(candidate)
        workflow.device.click.assert_called_once_with(100, 210)

    def test_active_live_handoff_does_not_reverify_profile_identity(self) -> None:
        workflow = self.bare_workflow()
        workflow.search_used_top_fallback = True
        workflow.navigate_via_search = Mock(return_value="LIVE")
        workflow.verify_live_broadcaster = Mock(
            side_effect=AssertionError("old identity verifier must not run")
        )

        def report_ready() -> None:
            workflow.live_profile_sheet_ready = True

        workflow.open_live_report_sheet = Mock(side_effect=report_ready)
        workflow.handle_optional_verification_overlay = Mock()
        workflow.exact_text_exists = Mock(return_value=True)
        def confirm_on_submit(**kwargs):
            if kwargs.get("selector_key") == "submit_button":
                workflow.submit_completed = True
                workflow.submission_state = "CONFIRMED"

        workflow.click_action = Mock(side_effect=confirm_on_submit)
        with patch("_shared.workflow_engine.time.sleep"):
            workflow.run_workflow()

        workflow.verify_live_broadcaster.assert_not_called()
        workflow.open_live_report_sheet.assert_called_once_with()
        self.assertTrue(workflow.submit_completed)

    def test_live_destination_classification(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=True)
        self.assertEqual(workflow.classify_search_destination(), "LIVE")

    def test_normal_exact_profile_is_offline(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(
            return_value={
                "package": workflow.package,
                "activity": "com.ss.android.ugc.aweme.profile.ui.UserProfileActivity",
            }
        )
        workflow.device.dump_hierarchy.return_value = EXACT_PROFILE_XML
        self.assertEqual(workflow.classify_search_destination(), "OFFLINE")

    def test_ambiguous_destination_is_unknown(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "UnknownActivity"}
        )
        workflow.device.dump_hierarchy.return_value = CLEAR_XML
        with self.assertRaisesRegex(DestinationUnknownError, "DESTINATION_UNKNOWN"):
            workflow.classify_search_destination()

    def test_profile_identity_mismatch_is_explicit(self) -> None:
        state, observed = profile_identity_state(WRONG_PROFILE_XML, "abc123")
        self.assertEqual(state, "mismatch")
        self.assertEqual(observed, ["wrong.account"])

    def test_precheck_does_not_wait_for_stabilization(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.navigate_via_search = Mock(return_value="LIVE")

        def verified(*, require_report_ready):
            self.assertFalse(require_report_ready)
            workflow.live_identity_verified = True

        workflow.verify_live_broadcaster = Mock(side_effect=verified)
        with patch("_shared.workflow_engine.time.sleep") as sleeper:
            workflow.run_live_precheck()
        sleeper.assert_not_called()

    def test_precheck_stage_timeout_is_clamped_to_shared_remaining_time(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.current_stage = "SEARCH_USERS_TAB"
        workflow._live_precheck_deadline = time.monotonic() + 0.05
        timeout = workflow._bounded_stage_timeout(5)
        self.assertGreater(timeout, 0)
        self.assertLessEqual(timeout, 0.05)

    def test_eighty_second_outer_budget_creates_one_shared_inner_deadline(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.config["live_precheck_timeout_seconds"] = 80
        workflow._workflow_started = time.monotonic()
        workflow._live_precheck_deadline = None
        workflow._initialize_live_precheck_deadline()
        inner_budget = workflow._live_precheck_deadline - workflow._workflow_started
        self.assertAlmostEqual(inner_budget, 79.0, places=6)

    def test_precheck_timeout_records_actual_current_stage(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.current_stage = "DESTINATION_CLASSIFICATION"
        workflow._live_precheck_deadline = time.monotonic() - 0.01
        with self.assertRaisesRegex(
            WorkflowError,
            "LIVE_PRECHECK_TIMEOUT: stage=DESTINATION_CLASSIFICATION",
        ):
            workflow._raise_if_live_precheck_expired()

    def test_failed_precheck_always_force_stops_tiktok_after_task(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.workflow_mode = "live_precheck"
            workflow.run_dir = Path(directory)
            workflow.target_is_excluded = Mock(return_value=False)
            workflow.connect = Mock()
            workflow.detect_package = Mock()
            workflow.run_live_precheck = Mock(
                side_effect=WorkflowError("TIKTOK_UI_NOT_READY: unavailable")
            )
            workflow.classify_error = Mock(
                return_value=("TIKTOK_UI_NOT_READY", "cause", "solution")
            )
            workflow.close_tiktok = Mock()

            self.assertEqual(workflow.execute(), 1)
            workflow.close_tiktok.assert_called_once_with()

    def test_failed_normal_worker_force_stops_tiktok_after_task(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.run_dir = Path(directory)
            workflow.target_is_excluded = Mock(return_value=False)
            workflow.connect = Mock()
            workflow.detect_package = Mock()
            workflow.run_workflow = Mock(side_effect=WorkflowError("worker failed"))
            workflow.classify_error = Mock(
                return_value=("WORKFLOW_ERROR", "cause", "solution")
            )
            workflow.close_tiktok = Mock()

            self.assertEqual(workflow.execute(), 1)
            workflow.close_tiktok.assert_called_once_with()

    def test_mid_workflow_live_ended_is_persisted_as_non_error_non_success(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.run_dir = Path(directory)
            workflow.target_is_excluded = Mock(return_value=False)
            workflow.connect = Mock()
            workflow.detect_package = Mock()
            workflow.run_workflow = Mock(
                side_effect=LiveEndedDuringWorkflow(
                    "LIVE_ENDED_DURING_WORKFLOW: TikTok explicitly showed LIVE has ended"
                )
            )
            workflow.close_tiktok = Mock()

            self.assertEqual(workflow.execute(), 0)
            payload = json.loads((Path(directory) / "result.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["status"], "live_ended")
            self.assertEqual(payload["error_code"], "LIVE_ENDED_DURING_WORKFLOW")
            self.assertFalse(payload["submission_completed"])
            workflow.close_tiktok.assert_called_once_with()

    def test_successful_precheck_force_stops_tiktok_after_task(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.workflow_mode = "live_precheck"
            workflow.run_dir = Path(directory)
            workflow.target_is_excluded = Mock(return_value=False)
            workflow.connect = Mock()
            workflow.detect_package = Mock()
            workflow.run_live_precheck = Mock()
            workflow.close_tiktok = Mock()

            self.assertEqual(workflow.execute(), 0)
            workflow.close_tiktok.assert_called_once_with()

    def test_successful_report_force_stops_tiktok_after_task(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.run_dir = Path(directory)
            workflow.target_is_excluded = Mock(return_value=False)
            workflow.connect = Mock()
            workflow.detect_package = Mock()
            def confirmed_report():
                workflow.submit_completed = True
                workflow.submission_state = "CONFIRMED"
                workflow.ui_confirmation_observed = True
                workflow.settlement_completed = True
                workflow.confirmation_source = "tiktok_ui"

            workflow.run_workflow = Mock(side_effect=confirmed_report)
            workflow.close_tiktok = Mock()

            self.assertEqual(workflow.execute(), 0)
            workflow.close_tiktok.assert_called_once_with()

    def test_normal_worker_has_no_fixed_live_stabilization_sleep(self) -> None:
        workflow = self.bare_workflow()
        workflow.navigate_via_search = Mock(return_value="LIVE")

        def report_ready():
            workflow.live_profile_sheet_ready = True

        workflow.open_live_report_sheet = Mock(side_effect=report_ready)
        workflow.handle_optional_verification_overlay = Mock()
        workflow.exact_text_exists = Mock(return_value=True)
        def confirm_on_submit(**kwargs):
            if kwargs.get("selector_key") == "submit_button":
                workflow.submit_completed = True
                workflow.submission_state = "CONFIRMED"

        workflow.click_action = Mock(side_effect=confirm_on_submit)
        with patch("_shared.workflow_engine.time.sleep") as sleeper:
            workflow.run_workflow()
        sleeper.assert_not_called()
        self.assertTrue(workflow.submit_completed)

    def test_precheck_detail_activity_recovers_once_then_classifies_exact_profile_offline(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.config["precheck_destination_classification_timeout_seconds"] = 0.02
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(side_effect=[
            {"package": workflow.package, "activity": "com.ss.android.ugc.aweme.detail.ui.DetailActivity"},
            {"package": workflow.package, "activity": "com.ss.android.ugc.aweme.profile.ui.UserProfileActivity"},
        ])
        workflow.recover_precheck_detail_activity = Mock()
        workflow._dump_hierarchy = Mock(return_value=EXACT_PROFILE_XML)
        workflow.recover_known_blocking_state = Mock(return_value=False)
        workflow.handle_optional_verification_overlay = Mock()

        self.assertEqual(workflow.classify_top_user_precheck_destination(), "OFFLINE")
        workflow.recover_precheck_detail_activity.assert_called_once_with()

    def test_precheck_detail_activity_is_not_blindly_classified_offline(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_precheck"
        workflow.config["precheck_destination_classification_timeout_seconds"] = 0.02
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(return_value={
            "package": workflow.package,
            "activity": "com.ss.android.ugc.aweme.detail.ui.DetailActivity",
        })
        workflow.recover_precheck_detail_activity = Mock()
        with self.assertRaisesRegex(DestinationUnknownError, "PRECHECK_DETAIL_ACTIVITY_PERSISTENT"):
            workflow.classify_top_user_precheck_destination()
        workflow.recover_precheck_detail_activity.assert_called_once_with()

    def test_discovery_detail_activity_does_not_require_unknown_exact_user(self) -> None:
        workflow = self.bare_workflow()
        workflow.workflow_mode = "live_discovery"
        workflow.config["precheck_destination_classification_timeout_seconds"] = 0.02
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(return_value={
            "package": workflow.package,
            "activity": "com.ss.android.ugc.aweme.detail.ui.DetailActivity",
        })
        workflow.recover_precheck_detail_activity = Mock()
        workflow._dump_hierarchy = Mock(return_value=CLEAR_XML)
        workflow.recover_known_blocking_state = Mock(return_value=False)

        with self.assertRaisesRegex(DestinationUnknownError, "DESTINATION_CLASSIFICATION_TIMEOUT"):
            workflow.classify_top_user_precheck_destination()
        workflow.recover_precheck_detail_activity.assert_not_called()

    def test_report_destination_timeout_is_unknown_not_live_ended(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(
            return_value={"package": workflow.package, "activity": "SearchActivity"}
        )
        workflow.device.dump_hierarchy.return_value = CLEAR_XML
        with self.assertRaisesRegex(DestinationUnknownError, "DESTINATION_CLASSIFICATION_TIMEOUT"):
            workflow.classify_top_user_report_destination()

    def test_report_destination_normal_profile_is_local_not_live_destination(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(
            return_value={
                "package": workflow.package,
                "activity": "com.ss.android.ugc.aweme.profile.ui.UserProfileActivity",
            }
        )
        workflow.device.dump_hierarchy.return_value = EXACT_PROFILE_XML
        with self.assertRaisesRegex(LiveEndedDuringWorkflow, "LIVE_ENDED_DURING_WORKFLOW"):
            workflow.classify_top_user_report_destination()


    def test_layout_fallback_normal_profile_is_unknown_not_live_ended(self) -> None:
        workflow = self.bare_workflow()
        workflow.top_user_click_source = "layout_fallback"
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(
            return_value={
                "package": workflow.package,
                "activity": "com.ss.android.ugc.aweme.profile.ui.UserProfileActivity",
            }
        )
        workflow.device.dump_hierarchy.return_value = EXACT_PROFILE_XML
        with self.assertRaisesRegex(DestinationUnknownError, "layout-only"):
            workflow.classify_top_user_report_destination()

    def test_proxy_proof_gate_accepts_matching_tiktok_proof(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.serial = "device:5555"
            proof = Path(directory) / "proof.json"
            proof.write_text(
                '{"verified":true,"serial":"device:5555","target":"api.tiktokv.com:443","proxy":"192.0.2.10:8000"}',
                encoding="utf-8",
            )
            workflow.config.update(
                {
                    "proxy_require_tiktok_proof_before_submit": True,
                    "proxy_tiktok_proof_file": str(proof),
                    "proxy_submit_proof_timeout_seconds": 0.1,
                }
            )
            workflow.require_proxy_tiktok_proof_before_submit()

    def test_proxy_proof_gate_fails_closed_before_submit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.serial = "device:5555"
            workflow.config.update(
                {
                    "proxy_require_tiktok_proof_before_submit": True,
                    "proxy_tiktok_proof_file": str(Path(directory) / "missing.json"),
                    "proxy_submit_proof_timeout_seconds": 0.1,
                }
            )
            with self.assertRaisesRegex(WorkflowError, "PROXY_TIKTOK_TRAFFIC_UNVERIFIED"):
                workflow.require_proxy_tiktok_proof_before_submit()

    def test_policy_update_popup_is_dismissed_before_report_handoff(self) -> None:
        workflow = self.bare_workflow()
        popup_xml = (
            '<hierarchy><node text="Virtual Items and Rewards Policies update" />'
            '<node text="Got it" class="android.widget.Button" bounds="[0,0][100,40]" />'
            '</hierarchy>'
        )
        got_it = Mock()
        got_it.count = 1
        got_it.info = {
            "enabled": True,
            "bounds": {"left": 0, "top": 0, "right": 100, "bottom": 40},
        }
        workflow.device.side_effect = lambda **values: got_it
        workflow._dump_hierarchy = Mock(side_effect=[popup_xml, CLEAR_XML])
        workflow.dismiss_optional_live_policy_popup()
        got_it.click.assert_called_once_with()

    def test_verification_absent_continues(self) -> None:
        workflow = self.bare_workflow()
        workflow.device.dump_hierarchy.return_value = CLEAR_XML
        workflow.locate_unique = Mock()
        workflow.handle_optional_verification_overlay()
        workflow.locate_unique.assert_not_called()

    def test_verification_present_closes_once(self) -> None:
        workflow = self.bare_workflow()
        close = Mock()
        workflow.device.dump_hierarchy.side_effect = [OVERLAY_XML, CLEAR_XML]
        workflow.locate_unique = Mock(return_value=(close, located("Close")))
        workflow.handle_optional_verification_overlay()
        close.click.assert_called_once_with()

    def test_unresolved_verification_stops(self) -> None:
        workflow = self.bare_workflow()
        close = Mock()
        workflow.device.dump_hierarchy.return_value = OVERLAY_XML
        workflow.locate_unique = Mock(return_value=(close, located("Close")))
        with self.assertRaisesRegex(WorkflowError, "VERIFY_OVERLAY_STILL_PRESENT"):
            workflow.handle_optional_verification_overlay()
        close.click.assert_called_once_with()

    def test_verification_markers_are_evidence_based(self) -> None:
        self.assertTrue(verification_overlay_present(OVERLAY_XML))
        self.assertFalse(verification_overlay_present(CLEAR_XML))

    def test_no_active_direct_live_navigation(self) -> None:
        source = Path(inspect.getsourcefile(TikTokSelectorWorkflow)).read_text(
            encoding="utf-8"
        )
        self.assertNotIn("android.intent.action.VIEW", source)
        self.assertNotIn("try_open_live_via_verified_deep_link", source)
        self.assertNotIn("direct_live", source.casefold())

    def test_top_user_row_ignores_small_more_button_when_root_has_no_bounds(self) -> None:
        hierarchy = """<hierarchy>
        <node class="android.widget.Button" clickable="true" content-desc="More" bounds="[942,118][1050,238]">
          <node class="android.widget.ImageView" bounds="[960,140][1030,210]"/>
          <node text="More" bounds="[950,180][1040,220]"/>
        </node>
        <node class="android.widget.Button" clickable="true" bounds="[0,400][1080,622]">
          <node class="android.widget.ImageView" bounds="[51,427][219,595]"/>
          <node text="abc123" bounds="[258,491][732,539]"/>
          <node text="Follow" bounds="[768,460][1032,556]"/>
        </node>
        </hierarchy>"""
        row = top_user_row_from_hierarchy(hierarchy, "abc123")
        self.assertIsNotNone(row)
        self.assertEqual(row.row_bounds, (0, 400, 1080, 622))
        self.assertEqual(row.avatar_point, (135, 511))

    def test_top_user_click_waits_for_selected_users_tab_and_real_row(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["search_result_timeout_seconds"] = 0.2
        stale = """<hierarchy><node text="Users" selected="false" bounds="[0,0][1080,100]"/>
        <node class="android.widget.Button" clickable="true" bounds="[0,400][1080,650]">
        <node class="android.widget.ImageView" bounds="[30,430][170,570]"/>
        <node resource-id="com.ss.android.ugc.trill:id/tv_aweme_id" text="abc123" bounds="[210,450][600,510]"/>
        </node></hierarchy>"""
        ready = """<hierarchy><node content-desc="Users" selected="true" bounds="[300,200][500,320]"/>
        <node class="android.widget.Button" clickable="true" bounds="[0,400][1080,650]">
        <node class="android.widget.ImageView" bounds="[30,430][170,570]"/>
        <node resource-id="com.ss.android.ugc.trill:id/tv_aweme_id" text="abc123" bounds="[210,450][600,510]"/>
        </node></hierarchy>"""
        workflow._dump_hierarchy = Mock(side_effect=[stale, ready])
        workflow.open_top_user_avatar_for_precheck()
        workflow.device.click.assert_called_once()
        self.assertEqual(workflow.top_user_click_source, "hierarchy")


    def test_top_user_click_rejects_nonmatching_first_users_row(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["search_result_timeout_seconds"] = 0.005
        wrong = """<hierarchy><node content-desc="Users" selected="true" bounds="[300,200][500,320]"/>
        <node class="android.widget.Button" clickable="true" bounds="[0,400][1080,650]">
        <node class="android.widget.ImageView" bounds="[30,430][170,570]"/>
        <node resource-id="com.ss.android.ugc.trill:id/tv_aweme_id" text="different_user" bounds="[210,450][600,510]"/>
        </node></hierarchy>"""
        workflow._dump_hierarchy = Mock(return_value=wrong)
        with self.assertRaisesRegex(DestinationUnknownError, "USERS_EXACT_TARGET_NOT_FOUND"):
            workflow.open_top_user_avatar_for_precheck()
        workflow.device.click.assert_not_called()

    def test_live_handoff_handles_verification_that_appears_before_host_control(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["live_identity_timeout_seconds"] = 0.05
        workflow.live_context_ok = Mock(return_value=True)
        workflow.dismiss_optional_live_policy_popup = Mock()
        workflow.handle_optional_verification_overlay = Mock()
        workflow._dump_hierarchy = Mock(side_effect=[OVERLAY_XML, CLEAR_XML])
        host = Mock()
        workflow.locate_unique = Mock(return_value=(host, located("host")))
        calls = {"report": 0}

        def selector_exists(key, timeout=0.1):
            if key == "report_button":
                calls["report"] += 1
                return calls["report"] >= 3
            if key == "host_profile":
                return True
            return False

        workflow.selector_exists = Mock(side_effect=selector_exists)
        workflow.open_live_report_sheet()
        workflow.handle_optional_verification_overlay.assert_called_once_with()
        host.click.assert_called_once_with()
        self.assertTrue(workflow.live_profile_sheet_ready)

    def test_report_action_uses_one_final_postcondition_check_at_deadline(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["report_button"].update(
            {"timeout_seconds": 0.01, "after_timeout_seconds": 0.1}
        )
        target = Mock()
        workflow.locate_unique = Mock(return_value=(target, located("Report")))
        workflow._dump_hierarchy = Mock(return_value=CLEAR_XML)
        expected = Mock(return_value=True)
        with patch("_shared.workflow_engine.time.monotonic", side_effect=[0.0, 1.0]):
            workflow.click_action(
                action="Buka menu Report",
                selector_key="report_button",
                expected_after=expected,
            )
        target.click.assert_called_once_with()
        expected.assert_called_once_with()

    def test_top_user_click_never_guesses_coordinates_without_real_users_row(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["search_result_timeout_seconds"] = 0.005
        selected_without_row = (
            '<hierarchy><node content-desc="Users" selected="true" '
            'bounds="[300,200][500,320]"/></hierarchy>'
        )
        workflow._dump_hierarchy = Mock(return_value=selected_without_row)
        with self.assertRaisesRegex(DestinationUnknownError, "USERS_RESULTS_LOAD_TIMEOUT"):
            workflow.open_top_user_avatar_for_precheck()
        workflow.device.click.assert_not_called()

    def test_report_reason_screen_accepts_hierarchy_evidence(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["report_reason"] = {"text": "Frauds and scams"}
        workflow.exact_text_exists = Mock(return_value=False)
        workflow.selector_exists = Mock(return_value=False)
        workflow._dump_hierarchy = Mock(
            return_value='<hierarchy><node text="Frauds and scams" bounds="[0,0][100,50]"/></hierarchy>'
        )
        self.assertTrue(workflow.report_reason_screen_ready())

    def test_click_action_closes_late_verification_once_without_retrying_action(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["report_button"].update(
            {"timeout_seconds": 0.01, "after_timeout_seconds": 0.03}
        )
        target = Mock()
        workflow.locate_unique = Mock(return_value=(target, located("Report")))
        expected = Mock(side_effect=[False, True])
        workflow._dump_hierarchy = Mock(side_effect=[CLEAR_XML, OVERLAY_XML])
        workflow.handle_optional_verification_overlay = Mock()
        workflow.click_action(
            action="Buka menu Report",
            selector_key="report_button",
            expected_after=expected,
        )
        target.click.assert_called_once_with()
        workflow.handle_optional_verification_overlay.assert_called_once_with()

    def test_click_action_classifies_mid_workflow_live_ended_as_local_outcome(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["report_button"].update(
            {"timeout_seconds": 0.01, "after_timeout_seconds": 0.03}
        )
        target = Mock()
        workflow.locate_unique = Mock(return_value=(target, located("Report")))
        clear = '<hierarchy><node text="Report" bounds="[0,0][100,50]"/></hierarchy>'
        ended = '<hierarchy><node text="LIVE has ended" bounds="[0,0][100,50]"/></hierarchy>'
        workflow._dump_hierarchy = Mock(side_effect=[clear, ended])
        with self.assertRaisesRegex(LiveEndedDuringWorkflow, "LIVE_ENDED_DURING_WORKFLOW"):
            workflow.click_action(
                action="Buka menu Report",
                selector_key="report_button",
                expected_after=lambda: False,
            )
        target.click.assert_called_once_with()

    def test_semantic_profile_recognizes_obfuscated_tiktok_profile(self) -> None:
        hierarchy = """<hierarchy>
        <node text="@abc123" resource-id="com.ss.android.ugc.trill:id/rv1" class="android.widget.Button" bounds="[36,379][345,424]"/>
        <node text="Following" class="android.widget.TextView" bounds="[36,523][197,568]"/>
        <node text="Followers" class="android.widget.TextView" bounds="[233,523][394,568]"/>
        <node text="Likes" class="android.widget.TextView" bounds="[430,523][542,568]"/>
        <node text="Follow" class="android.widget.TextView" bounds="[36,616][756,736]"/>
        <node content-desc="Videos" selected="true" class="android.widget.RelativeLayout" bounds="[48,1015][540,1135]"/>
        </hierarchy>"""
        matched, evidence = target_profile_semantic_evidence(hierarchy, "abc123")
        self.assertTrue(matched)
        self.assertTrue(evidence["exact_username"])
        self.assertIn("followers", evidence["profile_markers"])

    def test_structural_live_host_accepts_new_obfuscated_button_id(self) -> None:
        hierarchy = """<hierarchy>
        <node resource-id="com.ss.android.ugc.trill:id/user_info_container" class="android.view.ViewGroup" bounds="[36,96][648,204]">
          <node resource-id="com.ss.android.ugc.trill:id/b22" class="android.widget.Button" content-desc="MAZ PRICE ACTION,38.9K" clickable="true" enabled="true" bounds="[36,96][648,204]">
            <node resource-id="com.ss.android.ugc.trill:id/user_name" class="android.widget.TextView" text="MAZ PRICE ACTION" bounds="[156,103][411,154]"/>
          </node>
          <node resource-id="com.ss.android.ugc.trill:id/ip5" class="android.widget.Button" content-desc="Follow MAZ PRICE ACTION" clickable="false" enabled="true" bounds="[423,108][636,192]"/>
        </node>
        </hierarchy>"""
        evidence = live_host_control_from_hierarchy(hierarchy)
        self.assertIsNotNone(evidence)
        self.assertEqual(evidence["resource_id"], "com.ss.android.ugc.trill:id/b22")

    def test_search_button_default_requires_clickable_control(self) -> None:
        import json as _json
        defaults = _json.loads((Path(__file__).parents[1] / "_shared" / "workflow_defaults.json").read_text(encoding="utf-8"))
        self.assertTrue(defaults["selectors"]["search_button"]["require_clickable"])

    def test_destination_classification_closes_verification_then_recognizes_profile(self) -> None:
        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(return_value=False)
        workflow.current_app = Mock(return_value={"package": workflow.package, "activity": "TikTokHostActivity"})
        semantic_profile = """<hierarchy>
        <node text="@abc123" bounds="[36,379][345,424]"/>
        <node text="Following" bounds="[36,523][197,568]"/>
        <node text="Followers" bounds="[233,523][394,568]"/>
        <node text="Likes" bounds="[430,523][542,568]"/>
        <node content-desc="Videos" bounds="[48,1015][540,1135]"/>
        </hierarchy>"""
        observations = iter([OVERLAY_XML])
        workflow._dump_hierarchy = Mock(
            side_effect=lambda *_args, **_kwargs: next(observations, semantic_profile)
        )
        workflow.handle_optional_verification_overlay = Mock()
        with self.assertRaisesRegex(LiveEndedDuringWorkflow, "LIVE_ENDED_DURING_WORKFLOW"):
            workflow.classify_top_user_report_destination()
        workflow.handle_optional_verification_overlay.assert_called_once_with()

    def test_early_proxy_gate_accepts_current_assignment_proof(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workflow = self.bare_workflow()
            workflow.serial = "device:5555"
            proof = Path(directory) / "proof.json"
            proof.write_text(
                '{"verified": true, "serial": "device:5555", "target": "api.tiktokv.com:443", "proxy": "192.0.2.1:8000"}',
                encoding="utf-8",
            )
            workflow.config.update({
                "proxy_require_tiktok_proof_before_submit": True,
                "proxy_tiktok_proof_file": str(proof),
                "proxy_early_proof_timeout_seconds": 0.01,
            })
            workflow.require_proxy_tiktok_proof_after_search()


    def test_users_tab_is_reselected_once_when_first_click_is_not_acknowledged(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["search_result_timeout_seconds"] = 8
        workflow.config["poll_interval_seconds"] = 0.5
        stale = '<hierarchy><node text="Users" clickable="true" selected="false" bounds="[300,200][500,320]"/></hierarchy>'
        ready = """<hierarchy><node content-desc="Users" clickable="true" selected="true" bounds="[300,200][500,320]"/>
        <node class="android.widget.Button" clickable="true" bounds="[0,400][1080,650]">
        <node class="android.widget.ImageView" bounds="[30,430][170,570]"/>
        <node resource-id="com.ss.android.ugc.trill:id/tv_aweme_id" text="abc123" bounds="[210,450][600,510]"/>
        </node></hierarchy>"""
        state = {"reselected": False, "now": 0.0}
        workflow._dump_hierarchy = Mock(side_effect=lambda _action: ready if state["reselected"] else stale)
        users_target = Mock()
        users_target.click.side_effect = lambda: state.__setitem__("reselected", True)
        workflow.locate_unique = Mock(return_value=(users_target, located("Users")))

        def fake_sleep(requested, deadline):
            state["now"] = min(deadline, state["now"] + max(0.5, requested))

        workflow._bounded_poll_sleep = Mock(side_effect=fake_sleep)
        with patch("_shared.workflow_engine.time.monotonic", side_effect=lambda: state["now"]):
            workflow.open_top_user_avatar_for_precheck()
        users_target.click.assert_called_once_with()
        workflow.device.click.assert_called_once()

    def test_exact_target_can_be_selected_below_similar_first_user(self) -> None:
        hierarchy = """<hierarchy>
        <node content-desc="Users" selected="true" bounds="[300,200][500,320]"/>
        <node class="android.widget.Button" clickable="true" bounds="[0,376][1080,598]">
          <node class="android.widget.ImageView" bounds="[51,403][219,571]"/>
          <node resource-id="com.ss.android.ugc.trill:id/tv_username" text="RFX" bounds="[258,420][732,468]"/>
          <node resource-id="com.ss.android.ugc.trill:id/z3y" text="rfxgold1" bounds="[258,477][732,525]"/>
        </node>
        <node class="android.widget.Button" clickable="true" bounds="[0,622][1080,844]">
          <node class="android.widget.ImageView" bounds="[51,649][219,817]"/>
          <node resource-id="com.ss.android.ugc.trill:id/tv_username" text="RONE GOLD FX" bounds="[258,656][732,704]"/>
          <node resource-id="com.ss.android.ugc.trill:id/z3y" text="r1goldfx" bounds="[258,713][732,761]"/>
        </node>
        </hierarchy>"""
        candidate = exact_target_search_result_from_hierarchy(hierarchy, "r1goldfx")
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate.username_bounds, (258, 713, 732, 761))
        self.assertEqual(candidate.avatar_bounds, (51, 649, 219, 817))
        self.assertEqual(candidate.row_bounds, (0, 622, 1080, 844))

    def test_exact_profile_live_entry_uses_header_live_badge_not_avatar_or_tab(self) -> None:
        hierarchy = """<hierarchy>
        <node text="@abc123" bounds="[36,379][345,424]"/>
        <node text="Following" bounds="[36,523][197,568]"/>
        <node text="Followers" bounds="[233,523][394,568]"/>
        <node text="Likes" bounds="[430,523][542,568]"/>
        <node class="android.widget.FrameLayout" clickable="true" enabled="true" bounds="[366,142][714,538]">
          <node class="android.widget.ImageView" bounds="[414,238][666,490]"/>
        </node>
        <node class="android.widget.FrameLayout" content-desc="LIVE" clickable="true" enabled="true" bounds="[719,256][875,376]"/>
        <node class="android.widget.HorizontalScrollView" bounds="[0,900][1080,1100]">
          <node class="android.widget.LinearLayout" clickable="true" enabled="true" bounds="[36,946][229,1033]">
            <node class="android.widget.TextView" text="LIVE" clickable="false" bounds="[111,964][202,1015]"/>
          </node>
        </node>
        </hierarchy>"""
        evidence = profile_live_entry_from_hierarchy(hierarchy)
        self.assertIsNotNone(evidence)
        self.assertEqual(evidence["bounds"], (719, 256, 875, 376))
        self.assertEqual(evidence["source"], "profile-header-live-badge")

        workflow = self.bare_workflow()
        workflow.live_context_ok = Mock(side_effect=[False, True])
        workflow.enter_live_from_exact_profile(hierarchy)
        workflow.device.click.assert_called_once_with(797, 316)

    def test_profile_live_content_tab_is_never_used_as_live_entry(self) -> None:
        hierarchy = """<hierarchy>
        <node text="@abc123" bounds="[36,379][345,424]"/>
        <node text="Following" bounds="[36,523][197,568]"/>
        <node text="Followers" bounds="[233,523][394,568]"/>
        <node text="Likes" bounds="[430,523][542,568]"/>
        <node class="android.widget.HorizontalScrollView" bounds="[0,900][1080,1100]">
          <node class="android.widget.LinearLayout" clickable="true" enabled="true" bounds="[36,946][229,1033]">
            <node class="android.widget.TextView" text="LIVE" clickable="false" bounds="[111,964][202,1015]"/>
          </node>
        </node>
        </hierarchy>"""
        self.assertIsNone(profile_live_entry_from_hierarchy(hierarchy))

    def test_tiktok_location_permission_dialog_is_recognized_without_other_permissions(self) -> None:
        location = """<hierarchy>
        <node text="Allow TikTok to access this device's location?"/>
        <node resource-id="com.android.permissioncontroller:id/permission_deny_button" text="Don't allow" clickable="true"/>
        </hierarchy>"""
        camera = """<hierarchy>
        <node text="Allow TikTok to take pictures and record video?"/>
        <node text="Don't allow" clickable="true"/>
        </hierarchy>"""
        self.assertTrue(tiktok_location_permission_dialog_present(location))
        self.assertFalse(tiktok_location_permission_dialog_present(camera))

    def test_submit_final_hierarchy_success_is_not_false_failure(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"].update(
            {"timeout_seconds": 0.01, "after_timeout_seconds": 0.03}
        )
        target = Mock()
        workflow.locate_unique = Mock(return_value=(target, located("Submit")))
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        thanks = '<hierarchy><node text="Thanks for reporting" bounds="[0,0][500,80]"/></hierarchy>'
        workflow._dump_hierarchy = Mock(return_value=CLEAR_XML)
        workflow._submission_rpc_available = Mock(return_value=True)
        workflow._submission_rpc_once = Mock(side_effect=[submit, None, thanks])
        workflow.click_action(
            action="Kirim laporan",
            selector_key="submit_button",
            expected_after=lambda: False,
        )
        target.click.assert_not_called()
        self.assertEqual(workflow.submission_state, "CONFIRMED")
        self.assertEqual(workflow.submit_completion_detection, "thanks_title_fresh_hierarchy")

    @staticmethod
    def submission_rpc(workflow, dumps, *, click_error=None):
        values = iter(dumps)
        calls = []

        def invoke(method, params, timeout):
            calls.append((method, params, timeout))
            if method == "click":
                if click_error is not None:
                    raise click_error
                return None
            return next(values)

        workflow._submission_rpc_available = Mock(return_value=True)
        workflow._submission_rpc_once = Mock(side_effect=invoke)
        return calls

    def test_submit_acknowledgement_requires_settlement(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"]["after_timeout_seconds"] = 0.05
        workflow.config["post_submit_settlement_seconds"] = 0.02
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        thanks = '<hierarchy><node text="Thanks for reporting" bounds="[0,0][500,80]"/></hierarchy>'
        self.submission_rpc(workflow, [submit] + [thanks] * 100)
        started = time.monotonic()
        workflow._run_submit_lifecycle(located("Submit"))
        self.assertGreaterEqual(time.monotonic() - started, 0.018)
        self.assertTrue(workflow.settlement_completed)
        self.assertTrue(workflow.submit_completed)

    def test_submit_timeout_is_unconfirmed_and_never_replayed(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"]["after_timeout_seconds"] = 0.02
        workflow.config["post_submit_settlement_seconds"] = 0.01
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        calls = self.submission_rpc(workflow, [submit] * 100)
        workflow._run_submit_lifecycle(located("Submit"))
        self.assertEqual(workflow.submission_state, "UNCONFIRMED")
        self.assertFalse(workflow.submit_completed)
        self.assertEqual(sum(method == "click" for method, _, _ in calls), 1)

    def test_submit_rpc_exception_observes_without_replay(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"]["after_timeout_seconds"] = 0.04
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        thanks = '<hierarchy><node text="Thanks for reporting" bounds="[0,0][500,80]"/></hierarchy>'
        calls = self.submission_rpc(
            workflow, [submit, thanks], click_error=TimeoutError("ambiguous")
        )
        workflow._run_submit_lifecycle(located("Submit"))
        self.assertEqual(workflow.submission_state, "CONFIRMED")
        self.assertEqual(sum(method == "click" for method, _, _ in calls), 1)

    def test_stale_thanks_blocks_submit_dispatch(self) -> None:
        workflow = self.bare_workflow()
        stale = '<hierarchy><node text="Thanks for reporting" bounds="[0,0][500,80]"/></hierarchy>'
        calls = self.submission_rpc(workflow, [stale])
        with self.assertRaisesRegex(WorkflowError, "STALE_SUBMIT_CONFIRMATION"):
            workflow._run_submit_lifecycle(located("Submit"))
        self.assertFalse(any(method == "click" for method, _, _ in calls))

    def test_hidden_thanks_and_submit_disappearance_do_not_confirm(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"]["after_timeout_seconds"] = 0.015
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        hidden = '<hierarchy><node text="Thanks for reporting" visible-to-user="false" bounds="[0,0][500,80]"/></hierarchy>'
        calls = self.submission_rpc(workflow, [submit] + [hidden] * 100)
        workflow._run_submit_lifecycle(located("Submit"))
        self.assertEqual(workflow.submission_state, "UNCONFIRMED")
        self.assertEqual(sum(method == "click" for method, _, _ in calls), 1)

    def test_post_submit_blocker_does_not_trigger_recovery(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["selectors"]["submit_button"]["after_timeout_seconds"] = 0.015
        submit = '<hierarchy><node text="Submit" bounds="[0,0][500,80]"/></hierarchy>'
        blocker = '<hierarchy><node text="Something went wrong"/><node text="Retry" clickable="true" bounds="[0,0][100,50]"/></hierarchy>'
        self.submission_rpc(workflow, [submit] + [blocker] * 100)
        workflow.recover_known_blocking_state = Mock()
        workflow._run_submit_lifecycle(located("Submit"))
        self.assertEqual(workflow.submission_state, "UNCONFIRMED")
        workflow.recover_known_blocking_state.assert_not_called()

    def test_submit_requires_reserved_worker_budget(self) -> None:
        workflow = self.bare_workflow()
        workflow.config["worker_deadline_monotonic"] = time.monotonic() + 44
        workflow._submission_rpc_available = Mock(return_value=True)
        workflow._submission_rpc_once = Mock()
        with self.assertRaisesRegex(WorkflowError, "INSUFFICIENT_SUBMIT_BUDGET"):
            workflow._run_submit_lifecycle(located("Submit"))
        workflow._submission_rpc_once.assert_not_called()

    def test_proxy_proof_is_checked_after_navigation_not_during_search(self) -> None:
        workflow = self.bare_workflow()
        workflow.navigate_via_search = Mock(return_value="LIVE")
        workflow.require_proxy_tiktok_proof_before_report = Mock()

        def report_ready() -> None:
            workflow.live_profile_sheet_ready = True

        workflow.open_live_report_sheet = Mock(side_effect=report_ready)
        workflow.require_proxy_tiktok_proof_before_submit = Mock()
        workflow.click_action = Mock()
        workflow.run_workflow()
        workflow.navigate_via_search.assert_called_once_with()
        workflow.require_proxy_tiktok_proof_before_report.assert_called_once_with()
        workflow.open_live_report_sheet.assert_called_once_with()

    def test_known_network_and_anr_states_are_explicit(self) -> None:
        network = '<hierarchy><node text="Something went wrong"/><node text="Retry" clickable="true"/></hierarchy>'
        anr = '<hierarchy><node text="TikTok isn\'t responding"/><node text="Wait" clickable="true"/><node text="Close app" clickable="true"/></hierarchy>'
        self.assertTrue(tiktok_network_retry_present(network))
        self.assertTrue(tiktok_anr_present(anr))


if __name__ == "__main__":
    unittest.main()
