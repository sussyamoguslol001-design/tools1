"""Shared workflow implementation and defaults."""
