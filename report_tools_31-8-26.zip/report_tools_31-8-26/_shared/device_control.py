from __future__ import annotations

import os
import re
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _safe_serial(serial: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(serial or "device"))


@contextmanager
def device_control_lease(
    serial: str,
    *,
    timeout_seconds: float = 6.0,
    lock_root: Path | None = None,
) -> Iterator[None]:
    """Cross-process lock for start/reset operations on one Android device.

    Normal workflow actions are not serialized by this lock. It protects only
    the small critical sections that start, reconnect, or reset UiAutomator so
    separate worker processes cannot race the same device-side service.
    """
    root = lock_root or (PROJECT_ROOT / "state" / "uiautomator_locks")
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{_safe_serial(serial)}.lock"
    path.touch(exist_ok=True)
    handle = open(path, "r+b")
    acquired = False
    deadline = time.monotonic() + max(0.1, float(timeout_seconds))
    try:
        while not acquired:
            try:
                if os.name == "nt":
                    import msvcrt

                    handle.seek(0, os.SEEK_END)
                    if handle.tell() == 0:
                        handle.write(b"0")
                        handle.flush()
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except (OSError, BlockingIOError):
                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        f"device-control lease timeout for {serial} after {timeout_seconds:g}s"
                    )
                time.sleep(0.05)
        handle.seek(0)
        handle.truncate()
        handle.write(f"pid={os.getpid()} serial={serial} acquired={time.time()}\n".encode("utf-8"))
        handle.flush()
        yield
    finally:
        if acquired:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
        handle.close()


def is_uiautomator_registration_conflict(value: object) -> bool:
    folded = str(value or "").casefold()
    return any(
        marker in folded
        for marker in (
            "accessibilityservicealreadyregisterederror",
            "uiautomationservice",
            "already registered",
            "uiautomation not connected",
        )
    )


def is_uiautomator_transport_error(value: object) -> bool:
    folded = str(value or "").casefold()
    return any(
        marker in folded
        for marker in (
            "remotedisconnected",
            "remote end closed connection",
            "connection reset",
            "connection aborted",
            "broken pipe",
            "uiautomation not connected",
            "httpconnectionpool",
            "max retries exceeded",
        )
    )


def _run_adb(
    adb_executable: str,
    serial: str,
    *args: str,
    timeout: float = 4.0,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [adb_executable, "-s", serial, *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=max(0.5, timeout),
        check=False,
        creationflags=(
            subprocess.CREATE_NO_WINDOW
            if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW")
            else 0
        ),
    )


def uiautomator_process_snapshot(
    adb_executable: str,
    serial: str,
    *,
    timeout: float = 4.0,
) -> list[str]:
    """Return only process rows attributable to this project's uiautomator2 server."""
    commands = (
        ("shell", "ps", "-A", "-o", "PID,ARGS"),
        ("shell", "ps", "-A", "-o", "PID,NAME,ARGS"),
        ("shell", "ps", "-A"),
    )
    markers = ("com.wetest.uia2.main", "/data/local/tmp/u2.jar", "com.github.uiautomator")
    for command in commands:
        try:
            result = _run_adb(adb_executable, serial, *command, timeout=timeout)
        except (OSError, subprocess.SubprocessError):
            continue
        if result.returncode != 0:
            continue
        rows = [
            line.strip()
            for line in result.stdout.splitlines()
            if any(marker in line.casefold() for marker in markers)
        ]
        return rows
    return []


def _pid_from_process_row(row: str) -> str:
    # Modern `ps -o PID,ARGS` starts with PID. Legacy Android `ps -A` usually
    # starts with USER then PID. Accept either shape without guessing names.
    parts = row.split()
    if not parts:
        return ""
    if parts[0].isdigit():
        return parts[0]
    if len(parts) > 1 and parts[1].isdigit():
        return parts[1]
    return ""


def stop_our_uiautomator_processes(
    adb_executable: str,
    serial: str,
    *,
    timeout: float = 4.0,
    settle_seconds: float = 0.6,
) -> dict[str, object]:
    """Kill only device-side uiautomator2 processes attributable to u2.jar.

    This intentionally does not kill arbitrary accessibility/test automation
    owned by other applications. If another framework owns UiAutomation, the
    caller will see the registration conflict persist after this targeted reset.
    """
    before = uiautomator_process_snapshot(adb_executable, serial, timeout=timeout)
    killed: list[str] = []
    for row in before:
        pid = _pid_from_process_row(row)
        if not pid:
            continue
        try:
            result = _run_adb(
                adb_executable,
                serial,
                "shell",
                "kill",
                "-9",
                pid,
                timeout=timeout,
            )
            if result.returncode == 0:
                killed.append(pid)
        except (OSError, subprocess.SubprocessError):
            continue
    if settle_seconds > 0:
        time.sleep(settle_seconds)
    after = uiautomator_process_snapshot(adb_executable, serial, timeout=timeout)
    return {"before": before, "killed_pids": killed, "after": after}
