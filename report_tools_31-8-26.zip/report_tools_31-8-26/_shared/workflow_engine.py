#!/usr/bin/env python3
"""Fail-fast semantic TikTok Search/LIVE report workflow over TCP ADB.

Targets are entered through TikTok's normal in-app Search UI. Canonical
identity is verified before a worker can reach any report control, and explicit
Submit acknowledgement plus the bounded settlement period is the success boundary.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from settings import load_workflow_config
from _shared.device_control import (
    device_control_lease,
    is_uiautomator_registration_conflict,
    is_uiautomator_transport_error,
    stop_our_uiautomator_processes,
    uiautomator_process_snapshot,
)


def configure_utf8_streams() -> None:
    """Allow console logging of TikTok names containing emoji/Unicode."""
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
        except (OSError, ValueError):
            pass


configure_utf8_streams()

try:
    import uiautomator2 as u2
    from uiautomator2.core import _jsonrpc_call as u2_jsonrpc_call_once
except ImportError:
    u2 = None
    u2_jsonrpc_call_once = None


class WorkflowError(RuntimeError):
    pass


class LiveUnavailableError(WorkflowError):
    """Raised when the requested TikTok LIVE is no longer active during precheck."""


class LiveEndedDuringWorkflow(WorkflowError):
    """A real external outcome: the LIVE explicitly ended after initial precheck."""


class DestinationUnknownError(WorkflowError):
    """Raised when Search navigation cannot safely classify the destination."""


@dataclass
class SelectorSpec:
    name: str
    method: str
    values: dict[str, Any]


@dataclass
class LocatedElement:
    action: str
    selector: SelectorSpec
    selector_count: int
    resource_id: str
    text: str
    description: str
    class_name: str
    bounds: tuple[int, int, int, int]
    clickable: bool
    enabled: bool


@dataclass(frozen=True)
class SearchResultCandidate:
    """One visible canonical TikTok user result and its associated avatar."""

    username: str
    username_bounds: tuple[int, int, int, int]
    avatar_bounds: Optional[tuple[int, int, int, int]]
    row_bounds: tuple[int, int, int, int]
    source: str


@dataclass(frozen=True)
class TopUserRowEvidence:
    """Visible Users result #1 with exact-text evidence and avatar point."""

    avatar_point: tuple[int, int]
    row_bounds: tuple[int, int, int, int]
    texts: tuple[str, ...]


def normalize(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def normalize_identity(value: Any) -> str:
    """Normalize a username/display name for report-history comparison."""
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = "".join(
        character
        for character in text
        if unicodedata.category(character) != "Cf"
    )
    text = text.casefold().replace("@", "")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_search_username(value: Any) -> str:
    """Normalize ``username``, ``@username``, or a compatible LIVE URL."""
    raw = normalize(value)
    url_match = re.fullmatch(
        r"https?://(?:www\.|m\.)?tiktok\.com/@([A-Za-z0-9._]{2,32})/live/?",
        raw,
        flags=re.IGNORECASE,
    )
    username = url_match.group(1) if url_match else raw.lstrip("@").strip()
    if not re.fullmatch(r"[A-Za-z0-9._]{2,32}", username):
        raise WorkflowError(
            "target harus berupa username TikTok, @username, atau URL LIVE kompatibel"
        )
    return username


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", normalize(value))
    return value[:90] or "unknown"


def parse_live_url(url: str) -> str:
    """Keep LIVE URL compatibility as identity input, never as navigation."""
    return normalize_search_username(url)


def _node_bounds(node: ET.Element) -> Optional[tuple[int, int, int, int]]:
    return parse_bounds(node.attrib.get("bounds", ""))


def _canonical_username_from_node(node: ET.Element) -> tuple[str, str] | None:
    """Extract only evidence that represents a canonical username."""
    resource_tail = normalize(node.attrib.get("resource-id", "")).rpartition("/")[2]
    values = (
        ("text", normalize(node.attrib.get("text", ""))),
        ("description", normalize(node.attrib.get("content-desc", ""))),
    )
    for attribute, raw in values:
        direct = re.fullmatch(r"@([A-Za-z0-9._]{2,32})", raw)
        if direct:
            return direct.group(1), f"canonical-{attribute}"
        if resource_tail in {"user_name", "tv_aweme_id", "z3y"}:
            username = raw.lstrip("@").strip(".")
            if re.fullmatch(r"[A-Za-z0-9._]{2,32}", username):
                return username, f"observed-{resource_tail}-resource"
    return None


def canonical_usernames_from_hierarchy(hierarchy: str) -> list[str]:
    """Return deduplicated canonical usernames from profile/Search evidence."""
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []
    values: list[str] = []
    seen: set[str] = set()
    for node in root.iter("node"):
        evidence = _canonical_username_from_node(node)
        if evidence is None:
            continue
        username, _source = evidence
        key = username.casefold()
        if key not in seen:
            seen.add(key)
            values.append(username)
    return values


def search_result_candidates_from_hierarchy(
    hierarchy: str, *, maximum: int = 12
) -> list[SearchResultCandidate]:
    """Discover bounded visible user rows using canonical username evidence."""
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []
    parent = {child: owner for owner in root.iter() for child in owner}
    candidates: list[SearchResultCandidate] = []
    seen: set[tuple[str, tuple[int, int, int, int]]] = set()

    for node in root.iter("node"):
        evidence = _canonical_username_from_node(node)
        username_bounds = _node_bounds(node)
        if evidence is None or username_bounds is None:
            continue
        username, source = evidence
        key = (username.casefold(), username_bounds)
        if key in seen:
            continue

        avatar_bounds: Optional[tuple[int, int, int, int]] = None
        row_bounds = username_bounds
        owner = parent.get(node)
        depth = 0
        while owner is not None and depth < 5:
            owner_bounds = _node_bounds(owner)
            if owner_bounds is not None:
                row_bounds = owner_bounds
            image_choices: list[tuple[int, tuple[int, int, int, int]]] = []
            username_center_y = (username_bounds[1] + username_bounds[3]) // 2
            for descendant in owner.iter("node"):
                class_name = normalize(descendant.attrib.get("class", ""))
                image_bounds = _node_bounds(descendant)
                if image_bounds is None or not class_name.endswith(("ImageView", "Image")):
                    continue
                image_center_y = (image_bounds[1] + image_bounds[3]) // 2
                if image_bounds[2] > username_bounds[0] or not (
                    row_bounds[1] <= image_center_y <= row_bounds[3]
                ):
                    continue
                distance = abs(username_center_y - image_center_y) + abs(
                    username_bounds[0] - image_bounds[2]
                )
                image_choices.append((distance, image_bounds))
            if image_choices:
                avatar_bounds = min(image_choices, key=lambda item: item[0])[1]
                break
            owner = parent.get(owner)
            depth += 1

        seen.add(key)
        candidates.append(
            SearchResultCandidate(
                username=username,
                username_bounds=username_bounds,
                avatar_bounds=avatar_bounds,
                row_bounds=row_bounds,
                source=source,
            )
        )

    candidates.sort(key=lambda item: (item.username_bounds[1], item.username_bounds[0]))
    return candidates[: max(1, int(maximum))]


def _node_live_marker(node: ET.Element) -> bool:
    """Return True only for explicit LIVE-badge style accessibility evidence."""
    resource_tail = normalize(node.attrib.get("resource-id", "")).rpartition("/")[2].casefold()
    values = [
        normalize(node.attrib.get("text", "")).casefold(),
        normalize(node.attrib.get("content-desc", "")).casefold(),
    ]
    explicit = {
        "live",
        "live now",
        "sedang live",
        "siaran langsung",
        "siaran langsung sekarang",
    }
    if any(value in explicit for value in values if value):
        return True
    return resource_tail in {"live", "live_badge", "live_tag", "live_label"}


def live_search_result_candidates_from_hierarchy(
    hierarchy: str, *, maximum: int = 12
) -> list[SearchResultCandidate]:
    """Return visible Users rows that carry an explicit LIVE marker, top first."""
    candidates = search_result_candidates_from_hierarchy(
        hierarchy, maximum=maximum
    )
    if not candidates:
        return []
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []

    markers: list[tuple[int, int]] = []
    for node in root.iter("node"):
        if not _node_live_marker(node):
            continue
        bounds = _node_bounds(node)
        if bounds is None:
            continue
        markers.append(((bounds[0] + bounds[2]) // 2, (bounds[1] + bounds[3]) // 2))

    live_candidates: list[SearchResultCandidate] = []
    for candidate in candidates:
        row_left, row_top, row_right, row_bottom = candidate.row_bounds
        user_center_y = (candidate.username_bounds[1] + candidate.username_bounds[3]) // 2
        row_height = max(1, row_bottom - row_top)
        for marker_x, marker_y in markers:
            # TikTok's LIVE badge can sit on the avatar edge, so allow a small
            # horizontal margin while requiring it to align with this result row.
            if (
                row_left - 24 <= marker_x <= row_right + 24
                and row_top <= marker_y <= row_bottom
                and abs(marker_y - user_center_y) <= max(row_height, 180)
            ):
                live_candidates.append(candidate)
                break
    return live_candidates[: max(1, int(maximum))]


def select_search_result(
    candidates: Sequence[SearchResultCandidate], target_username: str
) -> tuple[SearchResultCandidate | None, bool]:
    """Prefer exact canonical identity, otherwise return visible result #1."""
    expected = normalize_identity(target_username)
    for candidate in candidates:
        if normalize_identity(candidate.username) == expected:
            return candidate, True
    return (candidates[0], False) if candidates else (None, False)


def exact_target_search_result_from_hierarchy(
    hierarchy: str, target_username: str
) -> SearchResultCandidate | None:
    """Find the exact requested username row independent of obfuscated IDs.

    TikTok has been observed exposing canonical usernames under changing IDs
    such as ``tv_aweme_id`` and ``z3y``.  This target-specific resolver does not
    trust a resource ID: it requires the exact requested username text and then
    proves that text belongs to a visible clickable user-result row containing
    an avatar/image.
    """
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return None
    expected = normalize_identity(target_username)
    if not expected:
        return None
    parent = {child: owner for owner in root.iter() for child in owner}
    matches: list[SearchResultCandidate] = []
    for node in root.iter("node"):
        class_name = normalize(node.attrib.get("class", ""))
        if class_name.endswith("EditText"):
            continue
        raw_values = (
            normalize(node.attrib.get("text", "")),
            normalize(node.attrib.get("content-desc", "")),
        )
        if not any(value and normalize_identity(value) == expected for value in raw_values):
            continue
        username_bounds = _node_bounds(node)
        if username_bounds is None:
            continue

        owner = parent.get(node)
        depth = 0
        while owner is not None and depth < 5:
            row_bounds = _node_bounds(owner)
            if (
                row_bounds is not None
                and normalize(owner.attrib.get("clickable", "")).casefold() == "true"
                and (row_bounds[2] - row_bounds[0]) >= 500
                and (row_bounds[3] - row_bounds[1]) >= 80
            ):
                images: list[tuple[int, tuple[int, int, int, int]]] = []
                username_cy = (username_bounds[1] + username_bounds[3]) // 2
                for descendant in owner.iter("node"):
                    image_bounds = _node_bounds(descendant)
                    desc_class = normalize(descendant.attrib.get("class", ""))
                    if image_bounds is None or not desc_class.endswith(("ImageView", "Image")):
                        continue
                    image_cy = (image_bounds[1] + image_bounds[3]) // 2
                    if image_bounds[2] > username_bounds[0]:
                        continue
                    distance = abs(username_cy - image_cy) + abs(
                        username_bounds[0] - image_bounds[2]
                    )
                    images.append((distance, image_bounds))
                avatar_bounds = min(images, key=lambda item: item[0])[1] if images else None
                matches.append(
                    SearchResultCandidate(
                        username=target_username,
                        username_bounds=username_bounds,
                        avatar_bounds=avatar_bounds,
                        row_bounds=row_bounds,
                        source="exact-target-structural-row",
                    )
                )
                break
            owner = parent.get(owner)
            depth += 1

    if not matches:
        return None
    return min(matches, key=lambda item: (item.username_bounds[1], item.username_bounds[0]))


def top_user_rows_from_hierarchy(
    hierarchy: str,
    target_username: str = "",
    *,
    minimum_top: int = 0,
    maximum: int = 3,
) -> list[TopUserRowEvidence]:
    """Return bounded visible full-width user rows and their avatar points.

    The Users tab must already be selected by the caller. Rows are discovered
    from current hierarchy geometry instead of fixed screen coordinates. When a
    target username is supplied, the caller can require exact text evidence from
    each row before clicking it.
    """
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []

    all_bounds = [
        bounds
        for node in root.iter("node")
        for bounds in [_node_bounds(node)]
        if bounds is not None
    ]
    if all_bounds:
        screen_left = min(bounds[0] for bounds in all_bounds)
        screen_right = max(bounds[2] for bounds in all_bounds)
        screen_width = max(1, screen_right - screen_left)
    else:
        screen_width = 1080

    candidates: list[tuple[int, int, ET.Element, tuple[int, int, int, int]]] = []
    for node in root.iter("node"):
        bounds = _node_bounds(node)
        if bounds is None:
            continue
        if bounds[1] < max(0, int(minimum_top)):
            continue
        if normalize(node.attrib.get("clickable", "")).casefold() != "true":
            continue
        width = bounds[2] - bounds[0]
        height = bounds[3] - bounds[1]
        if width < int(screen_width * 0.70) or height < 80:
            continue
        text_nodes = [
            child
            for child in node.iter("node")
            if (normalize(child.attrib.get("text", "")) or normalize(child.attrib.get("content-desc", "")))
            and _node_bounds(child) is not None
        ]
        image_nodes = [
            child
            for child in node.iter("node")
            if normalize(child.attrib.get("class", "")).endswith(("ImageView", "Image"))
            and _node_bounds(child) is not None
        ]
        if not text_nodes or not image_nodes:
            continue
        # Prefer the outer Button row over nested full-width clickable containers.
        class_name = normalize(node.attrib.get("class", ""))
        class_rank = 0 if class_name.endswith("Button") else 1
        candidates.append((bounds[1], class_rank, node, bounds))

    if not candidates:
        return []

    # Nested clickable containers can describe the same visual row. Keep the
    # best-ranked outer candidate for each vertical result band, then continue
    # downward so discovery can try at most a few distinct visible rows.
    distinct: list[tuple[int, int, ET.Element, tuple[int, int, int, int]]] = []
    for candidate in sorted(
        candidates,
        key=lambda item: (item[0], item[1], -(item[3][2] - item[3][0]), -(item[3][3] - item[3][1])),
    ):
        bounds = candidate[3]
        center_y = (bounds[1] + bounds[3]) // 2
        if any(existing[3][1] <= center_y <= existing[3][3] for existing in distinct):
            continue
        distinct.append(candidate)
        if len(distinct) >= max(1, int(maximum)):
            break

    results: list[TopUserRowEvidence] = []
    for _top, _rank, row, row_bounds in distinct:
        texts: list[str] = []
        text_nodes: list[tuple[str, tuple[int, int, int, int]]] = []
        for descendant in row.iter("node"):
            bounds = _node_bounds(descendant)
            if bounds is None:
                continue
            for raw in (
                descendant.attrib.get("text", ""),
                descendant.attrib.get("content-desc", ""),
            ):
                value = normalize(raw)
                if not value:
                    continue
                texts.append(value)
                text_nodes.append((value, bounds))

        expected = normalize_identity(target_username)
        reference_bounds: Optional[tuple[int, int, int, int]] = None
        if expected:
            exact_nodes = [
                bounds
                for value, bounds in text_nodes
                if normalize_identity(value) == expected
            ]
            if exact_nodes:
                reference_bounds = min(exact_nodes, key=lambda item: (item[1], item[0]))
        if reference_bounds is None and text_nodes:
            reference_bounds = min(
                (bounds for _value, bounds in text_nodes),
                key=lambda item: (item[1], item[0]),
            )

        image_choices: list[tuple[int, int, tuple[int, int, int, int]]] = []
        row_center_y = (row_bounds[1] + row_bounds[3]) // 2
        reference_left = reference_bounds[0] if reference_bounds else row_bounds[2]
        reference_center_y = (
            (reference_bounds[1] + reference_bounds[3]) // 2
            if reference_bounds
            else row_center_y
        )
        for descendant in row.iter("node"):
            class_name = normalize(descendant.attrib.get("class", ""))
            image_bounds = _node_bounds(descendant)
            if image_bounds is None or not class_name.endswith(("ImageView", "Image")):
                continue
            if image_bounds[2] > reference_left:
                continue
            center_y = (image_bounds[1] + image_bounds[3]) // 2
            if not (row_bounds[1] <= center_y <= row_bounds[3]):
                continue
            area = max(1, image_bounds[2] - image_bounds[0]) * max(
                1, image_bounds[3] - image_bounds[1]
            )
            distance = abs(reference_center_y - center_y) + abs(
                reference_left - image_bounds[2]
            )
            image_choices.append((distance, -area, image_bounds))

        if image_choices:
            avatar = min(image_choices, key=lambda item: (item[0], item[1]))[2]
            point = (
                (avatar[0] + avatar[2]) // 2,
                (avatar[1] + avatar[3]) // 2,
            )
        else:
            # This remains row-relative, never a blind fixed screen coordinate.
            point = (
                row_bounds[0]
                + max(24, min(140, (row_bounds[2] - row_bounds[0]) // 8)),
                (row_bounds[1] + row_bounds[3]) // 2,
            )

        results.append(
            TopUserRowEvidence(
                avatar_point=point,
                row_bounds=row_bounds,
                texts=tuple(dict.fromkeys(texts)),
            )
        )
    return results


def top_user_row_from_hierarchy(
    hierarchy: str, target_username: str = "", *, minimum_top: int = 0
) -> Optional[TopUserRowEvidence]:
    """Return the actual visible Users result #1 and its avatar point."""
    rows = top_user_rows_from_hierarchy(
        hierarchy,
        target_username,
        minimum_top=minimum_top,
        maximum=1,
    )
    return rows[0] if rows else None


def top_user_avatar_point_from_hierarchy(
    hierarchy: str,
) -> Optional[tuple[int, int]]:
    """Compatibility helper returning Users result #1 avatar point."""
    row = top_user_row_from_hierarchy(hierarchy)
    return row.avatar_point if row is not None else None

def users_tab_selected_in_hierarchy(hierarchy: str) -> bool:
    """Return True only when TikTok exposes Users/Pengguna as the selected Search tab."""
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False
    accepted = {"users", "pengguna"}
    for node in root.iter("node"):
        text = normalize(node.attrib.get("text", "")).casefold()
        desc = normalize(node.attrib.get("content-desc", "")).casefold()
        if text not in accepted and desc not in accepted:
            continue
        if normalize(node.attrib.get("selected", "")).casefold() == "true":
            return True
        # TikTok commonly marks the tab container selected while the child text
        # itself is not. Accept a selected direct/near ancestor.
        parent = {child: owner for owner in root.iter() for child in owner}
        owner = parent.get(node)
        depth = 0
        while owner is not None and depth < 3:
            if normalize(owner.attrib.get("selected", "")).casefold() == "true":
                return True
            owner = parent.get(owner)
            depth += 1
    return False


def users_tab_available_in_hierarchy(hierarchy: str) -> bool:
    """Return True when a visible enabled clickable Users/Pengguna tab exists."""
    if not isinstance(hierarchy, str):
        return False
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False
    accepted = {"users", "pengguna"}
    parent = {child: owner for owner in root.iter() for child in owner}
    for node in root.iter("node"):
        text = normalize(node.attrib.get("text", "")).casefold()
        desc = normalize(node.attrib.get("content-desc", "")).casefold()
        if text not in accepted and desc not in accepted:
            continue
        owner = node
        depth = 0
        while owner is not None and depth < 4:
            if (
                normalize(owner.attrib.get("clickable", "")).casefold() == "true"
                and normalize(owner.attrib.get("enabled", "true")).casefold() != "false"
                and _node_bounds(owner) is not None
            ):
                return True
            owner = parent.get(owner)
            depth += 1
    return False



def _search_tab_control_from_hierarchy(
    hierarchy: str,
    *,
    labels: set[str],
    anchor_labels: set[str] | None = None,
    allow_selected_nonclickable: bool = False,
) -> tuple[tuple[int, int, int, int], bool] | None:
    """Resolve a visible Search-tab clickable container from hierarchy geometry.

    When ``anchor_labels`` is supplied, the requested tab must be horizontally
    aligned with that Search tab. This prevents a LIVE badge in a result row or
    on a profile from being mistaken for TikTok's Search ``LIVE`` tab.
    """
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return None
    parent = {child: owner for owner in root.iter() for child in owner}

    def control_for(node: ET.Element) -> tuple[tuple[int, int, int, int], bool] | None:
        owner: ET.Element | None = node
        depth = 0
        selected = False
        selected_bounds: tuple[int, int, int, int] | None = None
        while owner is not None and depth < 4:
            owner_selected = normalize(owner.attrib.get("selected", "")).casefold() == "true"
            selected = selected or owner_selected
            bounds = _node_bounds(owner)
            enabled = normalize(owner.attrib.get("enabled", "true")).casefold() != "false"
            if owner_selected and bounds is not None and enabled:
                # TikTok 46.x can make the currently selected Search tab
                # non-clickable. Keep its geometry as valid selected-state
                # evidence, but never use it as a click target.
                if selected_bounds is None or (bounds[2] - bounds[0]) > (selected_bounds[2] - selected_bounds[0]):
                    selected_bounds = bounds
            if (
                bounds is not None
                and normalize(owner.attrib.get("clickable", "")).casefold() == "true"
                and enabled
            ):
                return bounds, selected
            owner = parent.get(owner)
            depth += 1
        if allow_selected_nonclickable and selected_bounds is not None:
            return selected_bounds, True
        return None

    def matching_controls(accepted: set[str]) -> list[tuple[tuple[int, int, int, int], bool]]:
        matches: list[tuple[tuple[int, int, int, int], bool]] = []
        seen: set[tuple[int, int, int, int]] = set()
        for node in root.iter("node"):
            values = {
                normalize(node.attrib.get("text", "")).casefold(),
                normalize(node.attrib.get("content-desc", "")).casefold(),
            }
            if not any(value in accepted for value in values if value):
                continue
            control = control_for(node)
            if control is None or control[0] in seen:
                continue
            seen.add(control[0])
            matches.append(control)
        return matches

    requested = matching_controls({value.casefold() for value in labels})
    if not requested:
        return None
    if not anchor_labels:
        return min(requested, key=lambda item: (item[0][1], item[0][0]))

    anchors = matching_controls({value.casefold() for value in anchor_labels})
    if not anchors:
        return None
    selected_anchors = [item for item in anchors if item[1]]
    anchor_bounds = min(
        selected_anchors or anchors,
        key=lambda item: (item[0][1], item[0][0]),
    )[0]
    aligned: list[tuple[tuple[int, int, int, int], bool]] = []
    for item in requested:
        bounds = item[0]
        # Search tabs share the same horizontal strip, so their clickable
        # rectangles must vertically overlap. A LIVE badge inside a result row
        # is lower on screen and therefore cannot satisfy this requirement.
        vertical_overlap = min(anchor_bounds[3], bounds[3]) - max(anchor_bounds[1], bounds[1])
        if vertical_overlap > 0:
            aligned.append(item)
    if not aligned:
        return None
    return min(aligned, key=lambda item: (0 if item[1] else 1, item[0][0]))


def live_search_tab_selected_in_hierarchy(hierarchy: str) -> bool:
    """Return True only when Search's LIVE tab is visibly selected."""
    control = _search_tab_control_from_hierarchy(
        hierarchy,
        labels={"live", "siaran langsung"},
        anchor_labels={"top", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
        allow_selected_nonclickable=True,
    )
    return bool(control and control[1])


def live_search_tab_click_bounds_from_hierarchy(
    hierarchy: str,
) -> Optional[tuple[int, int, int, int]]:
    """Return the clickable bounds of Search's LIVE tab, never a result badge."""
    control = _search_tab_control_from_hierarchy(
        hierarchy,
        labels={"live", "siaran langsung"},
        anchor_labels={"top", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
    )
    return control[0] if control else None


def top_live_search_result_row_from_hierarchy(
    hierarchy: str,
) -> Optional[TopUserRowEvidence]:
    """Return one top structural result row below the selected Search LIVE tab.

    TikTok does not consistently expose a canonical username in LIVE-tab result
    rows. Discovery therefore resolves the first usable row from its current
    hierarchy geometry and defers canonical identity collection until after the
    selected stream opens.
    """
    rows = live_search_result_rows_from_hierarchy(hierarchy, maximum=1)
    return rows[0] if rows else None


def _visible_hierarchy_nodes(root: ET.Element) -> list[ET.Element]:
    """Exclude hidden subtrees; disabled layout parents can have enabled children."""
    nodes: list[ET.Element] = []
    pending = [root]
    while pending:
        node = pending.pop()
        if normalize(node.attrib.get("visible-to-user", "true")).casefold() == "false":
            continue
        if node.tag == "node":
            nodes.append(node)
        pending.extend(reversed(list(node)))
    return nodes


def _live_search_grid_rows_from_hierarchy(
    hierarchy: str, *, minimum_top: int, maximum: int
) -> list[TopUserRowEvidence]:
    """Find preview tiles only after the caller has proved Search LIVE selected.

    Some builds expose two-column previews as unlabeled, non-clickable layout
    nodes. Their current grid bounds supply a provisional tap target; only the
    opened room and broadcaster sheet can prove LIVE and canonical identity.
    """
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []
    nodes = _visible_hierarchy_nodes(root)
    visible = set(nodes)
    candidates: dict[tuple[int, int, int, int], TopUserRowEvidence] = {}
    for grid in nodes:
        if not normalize(grid.attrib.get("class", "")).endswith("GridView"):
            continue
        viewport = _node_bounds(grid)
        if (
            viewport is None or viewport[1] < minimum_top
            or normalize(grid.attrib.get("enabled", "true")).casefold() == "false"
        ):
            continue
        grid_width = viewport[2] - viewport[0]
        # Direct children are tiles; nested preview layouts describe the same
        # tile and must not consume additional candidate slots.
        for tile in grid.findall("node"):
            bounds = _node_bounds(tile)
            if (
                tile not in visible or bounds is None
                or normalize(tile.attrib.get("enabled", "true")).casefold() == "false"
            ):
                continue
            left, top, right, bottom = bounds
            width = right - left
            top, bottom = max(top, viewport[1]), min(bottom, viewport[3])
            if (
                left < viewport[0] or right > viewport[2]
                or not grid_width * 0.30 <= width <= grid_width * 0.65
                or bottom - top < width * 0.50
            ):
                continue
            # Skip full-width headers, thin spacers and barely visible tiles.
            # Tap the preview area rather than any title/profile below it.
            bounds = (left, top, right, bottom)
            texts = tuple(dict.fromkeys(
                value
                for descendant in tile.iter("node") if descendant in visible
                for raw in (descendant.attrib.get("text", ""), descendant.attrib.get("content-desc", ""))
                if (value := normalize(raw))
            ))
            candidates[bounds] = TopUserRowEvidence(
                avatar_point=((left + right) // 2, top + min(width, bottom - top) // 2),
                row_bounds=bounds,
                texts=texts,
            )
    ordered = sorted(candidates.values(), key=lambda row: (row.row_bounds[1], row.row_bounds[0]))
    return ordered[:max(1, int(maximum))]


def live_search_result_rows_from_hierarchy(
    hierarchy: str, *, maximum: int = 3
) -> list[TopUserRowEvidence]:
    """Return bounded rows or preview tiles below the selected Search LIVE tab."""
    control = _search_tab_control_from_hierarchy(
        hierarchy,
        labels={"live", "siaran langsung"},
        anchor_labels={"top", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
        allow_selected_nonclickable=True,
    )
    if control is None or not control[1]:
        return []
    rows = top_user_rows_from_hierarchy(
        hierarchy,
        minimum_top=control[0][3],
        maximum=maximum,
    )
    return rows or _live_search_grid_rows_from_hierarchy(
        hierarchy, minimum_top=control[0][3], maximum=maximum
    )


def top_search_tab_selected_in_hierarchy(hierarchy: str) -> bool:
    """Return True only when Search's Top tab is visibly selected."""
    control = _search_tab_control_from_hierarchy(
        hierarchy,
        labels={"top"},
        anchor_labels={"live", "siaran langsung", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
        allow_selected_nonclickable=True,
    )
    return bool(control and control[1])


def live_marked_top_search_results_from_hierarchy(
    hierarchy: str, *, maximum: int = 3
) -> list[TopUserRowEvidence]:
    """Return bounded Top-tab result cards carrying explicit LIVE badges."""
    control = _search_tab_control_from_hierarchy(
        hierarchy,
        labels={"top"},
        anchor_labels={"live", "siaran langsung", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
        allow_selected_nonclickable=True,
    )
    if control is None or not control[1]:
        return []
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []

    tab_bottom = control[0][3]
    parent = {child: owner for owner in root.iter() for child in owner}
    cards: list[tuple[int, int, TopUserRowEvidence]] = []
    seen: set[tuple[int, int, int, int]] = set()
    for marker in root.iter("node"):
        marker_bounds = _node_bounds(marker)
        if (
            marker_bounds is None
            or marker_bounds[1] < tab_bottom
            or not _node_live_marker(marker)
        ):
            continue
        owner = parent.get(marker)
        depth = 0
        while owner is not None and depth < 8:
            bounds = _node_bounds(owner)
            if (
                bounds is not None
                and bounds[1] >= tab_bottom
                and normalize(owner.attrib.get("clickable", "")).casefold() == "true"
                and normalize(owner.attrib.get("enabled", "true")).casefold() != "false"
            ):
                if bounds in seen:
                    break
                seen.add(bounds)
                texts: list[str] = []
                for descendant in owner.iter("node"):
                    for raw in (
                        descendant.attrib.get("text", ""),
                        descendant.attrib.get("content-desc", ""),
                    ):
                        value = normalize(raw)
                        if value and value not in texts:
                            texts.append(value)

                # TikTok can expose a full-width clickable section heading as
                # "LIVE / View all".  It is navigation to the LIVE tab, not a
                # broadcaster result, so never treat that heading as the one
                # card requested by discovery.
                folded_texts = {value.casefold() for value in texts}
                if folded_texts.intersection(
                    {"view all", "see all", "lihat semua", "tampilkan semua"}
                ):
                    break

                # The card center lands in its LIVE preview. Text beneath the
                # preview can open an ordinary video DetailActivity instead.
                point = (
                    (bounds[0] + bounds[2]) // 2,
                    (bounds[1] + bounds[3]) // 2,
                )
                cards.append(
                    (
                        bounds[1],
                        bounds[0],
                        TopUserRowEvidence(
                            avatar_point=point,
                            row_bounds=bounds,
                            texts=tuple(texts),
                        ),
                    )
                )
                break
            owner = parent.get(owner)
            depth += 1

    if not cards:
        return []
    return [
        item[2]
        for item in sorted(cards, key=lambda item: (item[0], item[1]))[
            : max(1, int(maximum))
        ]
    ]


def live_marked_top_search_result_from_hierarchy(
    hierarchy: str,
) -> Optional[TopUserRowEvidence]:
    """Return one top-left Top-tab result card carrying an explicit LIVE badge."""
    rows = live_marked_top_search_results_from_hierarchy(hierarchy, maximum=1)
    return rows[0] if rows else None


def search_input_present_in_hierarchy(hierarchy: str) -> bool:
    """Recognize TikTok's actual Search EditText after the Search button click."""
    if not isinstance(hierarchy, str):
        return False
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False
    for node in root.iter("node"):
        if not normalize(node.attrib.get("class", "")).endswith("EditText"):
            continue
        if normalize(node.attrib.get("enabled", "true")).casefold() == "false":
            continue
        bounds = _node_bounds(node)
        if bounds is None:
            continue
        return True
    return False


def configured_text_visible_in_hierarchy(
    hierarchy: str, selector_config: dict[str, Any]
) -> bool:
    """Fallback visibility check using the current hierarchy, without clicking."""
    if not isinstance(hierarchy, str):
        return False
    expected: set[str] = set()
    for key in ("text", "description"):
        value = normalize(selector_config.get(key))
        if value:
            expected.add(value.casefold())
    for key in ("alternate_texts", "alternate_descriptions"):
        for raw in selector_config.get(key, []):
            value = normalize(raw)
            if value:
                expected.add(value.casefold())
    if not expected:
        return False
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False
    for node in root.iter("node"):
        text = normalize(node.attrib.get("text", "")).casefold()
        desc = normalize(node.attrib.get("content-desc", "")).casefold()
        if text in expected or desc in expected:
            return True
    return False


def explicit_live_ended_in_hierarchy(hierarchy: str) -> bool:
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    return any(
        marker in folded
        for marker in (
            "live has ended",
            "this live has ended",
            "live is unavailable",
            "live unavailable",
            "siaran live telah berakhir",
            "live telah berakhir",
            "siaran langsung telah berakhir",
        )
    )


def verification_overlay_present(hierarchy: str) -> bool:
    """Recognize only verification evidence observed in project diagnostics."""
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    return any(
        marker in folded
        for marker in (
            "verify-bar-close",
            "verify_cardview",
            "verify_webview_frame",
            "verify captcha",
            "captcha-verify-image",
            "verify to continue",
        )
    )


def target_profile_semantic_evidence(
    hierarchy: str, target_username: str
) -> tuple[bool, dict[str, Any]]:
    """Recognize the exact target's normal profile without TikTok resource IDs.

    TikTok frequently serves profile pages inside TikTokHostActivity and obfuscates
    resource IDs.  The stable evidence is the exact visible @username plus normal
    profile semantics (metrics/tabs/actions).
    """
    if not isinstance(hierarchy, str):
        return False, {}
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False, {}

    expected = "@" + normalize(target_username).lstrip("@").casefold()
    exact_username = False
    observed: list[str] = []
    profile_markers: set[str] = set()
    for node in root.iter("node"):
        for raw in (node.attrib.get("text", ""), node.attrib.get("content-desc", "")):
            value = normalize(raw)
            if not value:
                continue
            folded = value.casefold()
            observed.append(value)
            if folded == expected:
                exact_username = True
            if folded in {"following", "followers", "likes"}:
                profile_markers.add(folded)
            elif folded in {"videos", "reposted videos", "liked videos"}:
                profile_markers.add("profile-tabs")
            elif folded in {"follow", "message", "edit profile"}:
                profile_markers.add("profile-actions")

    metric_count = len(profile_markers.intersection({"following", "followers", "likes"}))
    semantic_strength = metric_count >= 2 or (
        metric_count >= 1
        and bool(profile_markers.intersection({"profile-tabs", "profile-actions"}))
    )
    evidence = {
        "exact_username": exact_username,
        "profile_markers": sorted(profile_markers),
        "observed_preview": observed[:20],
    }
    return bool(exact_username and semantic_strength), evidence


def live_host_control_from_hierarchy(hierarchy: str) -> dict[str, Any] | None:
    """Find the broadcaster header structurally, independent of obfuscated IDs.

    Prefer a clickable Button inside ``user_info_container``.  If that container
    ID changes, accept a top-screen clickable Button that contains a user_name
    descendant.  Follow/Report/Close controls are explicitly excluded.
    """
    if not isinstance(hierarchy, str):
        return None
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return None

    bounds_all = [b for n in root.iter("node") for b in [_node_bounds(n)] if b is not None]
    screen_h = max((b[3] for b in bounds_all), default=1920)
    top_limit = max(260, int(screen_h * 0.22))

    containers = [
        node for node in root.iter("node")
        if normalize(node.attrib.get("resource-id", "")).rpartition("/")[2] == "user_info_container"
    ]

    def valid_button(node: ET.Element, *, require_username_descendant: bool = False) -> bool:
        if not normalize(node.attrib.get("class", "")).endswith("Button"):
            return False
        if normalize(node.attrib.get("clickable", "")).casefold() != "true":
            return False
        if normalize(node.attrib.get("enabled", "true")).casefold() == "false":
            return False
        bounds = _node_bounds(node)
        if bounds is None or bounds[1] > top_limit:
            return False
        combined = " ".join(
            filter(None, (normalize(node.attrib.get("text", "")), normalize(node.attrib.get("content-desc", ""))))
        ).casefold()
        if combined.startswith(("follow ", "report", "close", "got it")) or combined in {"follow", "report", "close"}:
            return False
        descendants = list(node.iter("node"))
        has_user_name = any(
            normalize(child.attrib.get("resource-id", "")).rpartition("/")[2] == "user_name"
            for child in descendants
        )
        if require_username_descendant and not has_user_name:
            return False
        return has_user_name or bool(combined)

    candidates: list[ET.Element] = []
    for container in containers:
        candidates.extend(node for node in container.iter("node") if valid_button(node))
    if not candidates:
        candidates = [node for node in root.iter("node") if valid_button(node, require_username_descendant=True)]
    if not candidates:
        return None

    def score(node: ET.Element) -> tuple[int, int, int]:
        b = _node_bounds(node) or (0, 9999, 0, 9999)
        rid = normalize(node.attrib.get("resource-id", ""))
        return (b[1], 0 if rid else 1, -(b[2] - b[0]))

    node = min(candidates, key=score)
    return {
        "resource_id": normalize(node.attrib.get("resource-id", "")),
        "description": normalize(node.attrib.get("content-desc", "")),
        "text": normalize(node.attrib.get("text", "")),
        "class_name": normalize(node.attrib.get("class", "")),
        "bounds": _node_bounds(node),
    }


def active_live_room_from_hierarchy(hierarchy: str) -> bool:
    """Prove the newer DetailActivity is rendering an active LIVE room.

    An ordinary video detail can also expose an author and Follow control.  The
    a non-empty host label must appear with LIVE-only audience or room controls.
    The label can be a display name; canonical identity is resolved separately
    from the opened broadcaster sheet before normal workflow handoff.
    """
    if not isinstance(hierarchy, str):
        return False
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False

    nodes = _visible_hierarchy_nodes(root)
    visible = set(nodes)
    has_online_audience = any(
        normalize(node.attrib.get("resource-id", "")).rpartition("/")[2]
        == "tv_online_audience_num"
        and normalize(node.attrib.get("visible-to-user", "true")).casefold()
        != "false"
        for node in nodes
    )
    has_host = False
    for container in nodes:
        if (
            normalize(container.attrib.get("resource-id", "")).rpartition("/")[2]
            != "user_info_container"
        ):
            continue
        for descendant in container.iter("node"):
            if descendant not in visible:
                continue
            if (
                normalize(descendant.attrib.get("resource-id", "")).rpartition("/")[2]
                != "user_name"
            ):
                continue
            if normalize(descendant.attrib.get("text", "")):
                has_host = True
                break
        if has_host:
            break
    if not has_host:
        return False
    if has_online_audience:
        return True

    # TikTok 2026 builds can embed an active LIVE preview in DetailActivity
    # without ``tv_online_audience_num``.  Real-device evidence instead exposes
    # the audience as an accessibility description such as ``1.3K views`` and
    # renders the LIVE chat composer together with the viewer-wishes surface.
    # All three are required: an ordinary video can have an author and view
    # count, but it does not expose this LIVE-chat/viewer-surface combination.
    values = {
        normalize(raw).casefold()
        for node in nodes
        for raw in (
            node.attrib.get("text", ""),
            node.attrib.get("content-desc", ""),
        )
        if normalize(raw)
    }
    has_audience_views = any(
        re.fullmatch(r"\d+(?:[.,]\d+)?[kmb]?\s+views?", value)
        for value in values
    )
    has_live_chat_composer = bool(
        values.intersection({"type...", "type…", "ketik...", "ketik…"})
    )
    resource_tails = {
        normalize(node.attrib.get("resource-id", "")).rpartition("/")[2]
        for node in nodes
    }
    has_live_viewer_surface = bool(
        resource_tails.intersection(
            {
                "wish_list_container",
                "viewer_wishes_container",
                "viewer_wishes_root_layout",
            }
        )
    )
    has_live_join_event = any(
        value.endswith(" joined") or value.endswith(" bergabung")
        for value in values
    )
    audience_live = bool(
        has_audience_views
        and has_live_chat_composer
        and (has_live_viewer_surface or has_live_join_event)
    )
    # The 2026-09-05 failed discovery already reached a LIVE room whose
    # audience container was empty. Its broadcaster button, LIVE chat, wishes
    # surface and Gaming Ranking entrance still prove the room type. Neither
    # a header alone nor an ordinary video's author/view count is sufficient.
    has_live_ranking = any(
        normalize(node.attrib.get("resource-id", "")).rpartition("/")[2]
        == "tv_ranking_entrance_text"
        and normalize(node.attrib.get("text", ""))
        for node in nodes
    )
    return audience_live or bool(
        has_live_chat_composer
        and has_live_viewer_surface
        and has_live_ranking
        and live_host_control_from_hierarchy(hierarchy) is not None
    )


def ordinary_video_detail_from_hierarchy(hierarchy: str) -> bool:
    """Recognize a stable ordinary-video DetailActivity during discovery.

    This is deliberately narrower than the inverse of active-LIVE detection.
    Ambiguous/loading screens remain UNKNOWN.  Only an ordinary comment composer
    plus video views/share semantics, with no LIVE surface, is classified stale.
    """
    if not isinstance(hierarchy, str):
        return False
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return False
    nodes = list(root.iter("node"))
    values = {
        normalize(raw).casefold()
        for node in nodes
        for raw in (
            node.attrib.get("text", ""),
            node.attrib.get("content-desc", ""),
        )
        if normalize(raw)
    }
    has_comment_composer = any(
        value in {
            "add comment",
            "add comment...",
            "add comment…",
            "tambahkan komentar",
            "tambahkan komentar...",
            "tambahkan komentar…",
        }
        for value in values
    )
    has_video_views = any(
        re.fullmatch(r"\d+(?:[.,]\d+)?[kmb]?\s+views?", value)
        for value in values
    )
    has_share_video = any("share video" in value for value in values)
    return bool(
        has_comment_composer
        and has_video_views
        and has_share_video
        and not active_live_room_from_hierarchy(hierarchy)
    )


def blocking_destination_reason(hierarchy: str) -> str:
    """Return a concise reason for a security/loading state, if recognized."""
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    if verification_overlay_present(hierarchy):
        return "security verification challenge"
    for marker in (
        "network error",
        "no internet connection",
        "something went wrong",
        "couldn't load",
        "could not load",
    ):
        if marker in folded:
            return "network or loading error"
    for marker in ("log in to tiktok", "sign up for tiktok", "login required"):
        if marker in folded:
            return "login required"
    return ""


def tiktok_network_retry_present(hierarchy: str) -> bool:
    """Recognize the explicit TikTok transient-network screen seen in diagnostics."""
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    has_error = any(
        marker in folded
        for marker in (
            "something went wrong",
            "network error",
            "no internet connection",
            "couldn't load",
            "could not load",
        )
    )
    has_retry = any(
        marker in folded
        for marker in (
            'text="retry"',
            'content-desc="retry"',
            'text="coba lagi"',
            'content-desc="coba lagi"',
        )
    )
    return bool(has_error and has_retry)


def tiktok_location_permission_dialog_present(hierarchy: str) -> bool:
    """Recognize only TikTok's Android location-permission prompt."""
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    has_tiktok = "tiktok" in folded
    has_location = any(marker in folded for marker in ("location", "lokasi"))
    has_permission_wording = any(
        marker in folded
        for marker in (
            "allow tiktok",
            "access this device's location",
            "access this device’s location",
            "izinkan tiktok",
            "mengakses lokasi",
        )
    )
    has_deny = any(
        marker in folded
        for marker in (
            'text="deny"',
            'text="don\'t allow"',
            'text="don’t allow"',
            'text="jangan izinkan"',
            'text="tolak"',
            'resource-id="com.android.permissioncontroller:id/permission_deny_button"',
            'resource-id="com.google.android.permissioncontroller:id/permission_deny_button"',
            'resource-id="com.android.packageinstaller:id/permission_deny_button"',
        )
    )
    return bool(has_tiktok and has_location and has_permission_wording and has_deny)


def tiktok_anr_present(hierarchy: str) -> bool:
    """Recognize Android's explicit TikTok ANR dialog."""
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    return bool(
        ("tiktok isn't responding" in folded or "tiktok is not responding" in folded)
        and (
            "close app" in folded
            or 'text="wait"' in folded
            or 'content-desc="wait"' in folded
            or 'text="tunggu"' in folded
            or 'content-desc="tunggu"' in folded
        )
    )


def unexpected_live_sheet_present(hierarchy: str) -> bool:
    """Recognize the chat/group sheet observed after an unintended LIVE-header tap."""
    if not isinstance(hierarchy, str):
        return False
    folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
    strong = ("name this group" in folded or "open camera" in folded)
    supporting = sum(
        marker in folded
        for marker in ("new messages", "stickers", "message", "open camera")
    )
    return bool(strong and supporting >= 2)


def profile_live_entry_from_hierarchy(hierarchy: str) -> dict[str, Any] | None:
    """Find the active-LIVE badge attached to the profile header.

    TikTok exposes multiple LIVE-labelled controls. The lower profile content
    tab opens SparkActivity and the avatar itself opens EnlargeAvatarActivity.
    Recovery therefore accepts only an upper-profile LIVE-labelled clickable
    node/ancestor and rejects anything inside a lower HorizontalScrollView/tab
    strip. Resource IDs are intentionally not required.
    """
    if not isinstance(hierarchy, str):
        return None
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return None

    parent = {child: owner for owner in root.iter() for child in owner}
    all_bounds = [
        bounds
        for node in root.iter("node")
        for bounds in [_node_bounds(node)]
        if bounds is not None
    ]
    screen_h = max(1920, max((b[3] for b in all_bounds), default=0))

    metric_bottoms: list[int] = []
    for node in root.iter("node"):
        label = normalize(node.attrib.get("text", "")).casefold()
        if label in {"following", "followers", "likes"}:
            bounds = _node_bounds(node)
            if bounds is not None:
                metric_bottoms.append(bounds[3])
    header_limit = int(screen_h * 0.50)
    if metric_bottoms:
        header_limit = min(
            header_limit,
            max(metric_bottoms) + max(100, int(screen_h * 0.05)),
        )

    candidates: list[tuple[tuple[int, ...], ET.Element, tuple[int, int, int, int]]] = []
    for node in root.iter("node"):
        text = normalize(node.attrib.get("text", "")).casefold()
        desc = normalize(node.attrib.get("content-desc", "")).casefold()
        if text != "live" and desc != "live":
            continue

        owner = node
        depth = 0
        excluded_tab_ancestry = False
        while owner is not None and depth < 5:
            class_name = normalize(owner.attrib.get("class", ""))
            if (
                class_name.endswith("HorizontalScrollView")
                or "TabLayout" in class_name
                or class_name.endswith("ViewPager")
            ):
                excluded_tab_ancestry = True
                break
            bounds = _node_bounds(owner)
            if (
                bounds is not None
                and normalize(owner.attrib.get("clickable", "")).casefold() == "true"
                and normalize(owner.attrib.get("enabled", "true")).casefold() != "false"
            ):
                if bounds[1] >= header_limit:
                    break
                direct_desc = normalize(owner.attrib.get("content-desc", "")).casefold() == "live"
                direct_text = normalize(owner.attrib.get("text", "")).casefold() == "live"
                # Prefer a directly-labelled clickable header badge (the exact
                # shape observed in diagnostics), then the nearest ancestor.
                score = (
                    0 if direct_desc else 1,
                    0 if direct_text else 1,
                    depth,
                    bounds[1],
                    bounds[0],
                )
                candidates.append((score, owner, bounds))
                break
            owner = parent.get(owner)
            depth += 1
        if excluded_tab_ancestry:
            continue

    if not candidates:
        return None
    _score, node, bounds = min(candidates, key=lambda item: item[0])
    return {
        "bounds": bounds,
        "resource_id": normalize(node.attrib.get("resource-id", "")),
        "class_name": normalize(node.attrib.get("class", "")),
        "text": normalize(node.attrib.get("text", "")),
        "description": normalize(node.attrib.get("content-desc", "")),
        "source": "profile-header-live-badge",
    }


def profile_identity_state(hierarchy: str, target_username: str) -> tuple[str, list[str]]:
    """Classify canonical profile identity as exact, mismatch, or unknown."""
    observed = canonical_usernames_from_hierarchy(hierarchy)
    expected = normalize_identity(target_username)
    if any(normalize_identity(value) == expected for value in observed):
        return "exact", observed
    if observed:
        return "mismatch", observed
    return "unknown", observed


def profile_sheet_usernames_from_hierarchy(
    hierarchy: str, *, exclude_live_header: bool = False
) -> list[str]:
    """Return canonical usernames only from TikTok's profile user_name field."""
    try:
        root = ET.fromstring(hierarchy)
    except ET.ParseError:
        return []
    header_nodes = {
        descendant
        for container in root.iter("node")
        if normalize(container.attrib.get("resource-id", "")).rpartition("/")[2]
        == "user_info_container"
        for descendant in container.iter("node")
    } if exclude_live_header else set()
    nodes = _visible_hierarchy_nodes(root) if exclude_live_header else root.iter("node")
    usernames: list[str] = []
    seen: set[str] = set()
    for node in nodes:
        if node in header_nodes:
            continue
        resource_id = normalize(node.attrib.get("resource-id", ""))
        if resource_id.rpartition("/")[2] != "user_name":
            continue
        username = normalize(node.attrib.get("text", "")).lstrip("@").strip(".")
        key = username.casefold()
        if not re.fullmatch(r"[A-Za-z0-9._]{2,32}", username) or key in seen:
            continue
        seen.add(key)
        usernames.append(username)
    return usernames


def parse_bounds(raw: Any) -> Optional[tuple[int, int, int, int]]:
    if isinstance(raw, dict):
        try:
            left = int(raw["left"])
            top = int(raw["top"])
            right = int(raw["right"])
            bottom = int(raw["bottom"])
        except (KeyError, TypeError, ValueError):
            return None
        if right > left and bottom > top:
            return left, top, right, bottom
        return None

    match = re.fullmatch(
        r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]",
        normalize(raw),
    )
    if not match:
        return None
    left, top, right, bottom = map(int, match.groups())
    if right <= left or bottom <= top:
        return None
    return left, top, right, bottom


class TikTokSelectorWorkflow:
    def __init__(self, config_path: Path) -> None:
        self.config_path = config_path.resolve()
        self.base_dir = self.config_path.parent
        self.config = self.load_config(self.config_path)

        self.serial = normalize(self.config["adb_serial"])
        self.live_url = normalize(self.config["live_url"])
        self.live_username = normalize_search_username(self.live_url)
        self.workflow_mode = normalize(
            self.config.get("workflow_mode", "report")
        ).casefold()
        if self.workflow_mode not in {"report", "live_precheck", "live_discovery"}:
            raise SystemExit(
                "workflow_mode must be 'report', 'live_precheck', or 'live_discovery'"
            )
        self.search_query = normalize(
            self.config.get("search_query", self.live_username)
        ) or self.live_username
        self.discovered_username = ""
        self.discovered_live_url = ""
        self.live_identity_verified = False
        self.live_profile_sheet_ready = False
        self._discovery_detail_live_verified = False
        self.search_result_candidates: list[dict[str, Any]] = []
        self.search_selected_result: dict[str, Any] = {}
        self.search_used_top_fallback = False
        self._live_tab_unavailable_top_ready = False
        self.top_user_click_source = "none"
        self.observed_destination_usernames: list[str] = []
        self._ready_search_control: tuple[Any, LocatedElement] | None = None
        self.tiktok_launch_mode = "not-started"

        self.package: Optional[str] = None
        cached_metadata = self.config.get("cached_device_metadata", {})
        self.device_metadata: dict[str, Any] = (
            dict(cached_metadata) if isinstance(cached_metadata, dict) else {}
        )
        self.device = None
        self.current_stage = "INIT"
        self.current_action = ""
        self.last_selector_diagnostics: list[dict[str, Any]] = []
        self.installed_packages: list[str] = []
        self.last_selector_failure_kind = ""
        self.broadcaster_identity_candidates: list[str] = []
        self.last_error_evidence = ""
        # Completion becomes True only after acknowledgement and settlement.
        self.submit_completed = False
        self.submit_completion_detection = ""
        self.submission_state = "NOT_SUBMITTED"
        self.submit_attempted = False
        self.ui_confirmation_observed = False
        self.settlement_completed = False
        self.confirmation_source = ""
        self.backend_acceptance = "unknown"
        self.confirmation_wait_seconds = 0.0
        self.settlement_seconds = 0.0
        self.fixed_coordinates_used = False
        self.coordinate_ratios_used = False
        self.diagnostics_enabled = bool(
            self.config.get("diagnostics_enabled", False)
        )
        self.detailed_logging = bool(
            self.config.get("detailed_logging", False)
        )
        self.stage_timings: dict[str, float] = {}
        self._stage_started = time.monotonic()
        self._workflow_started = self._stage_started
        self._live_precheck_deadline: float | None = None
        self._uiautomator_recovery_used = False
        self.uiautomator_repairs: list[dict[str, Any]] = []
        self._network_retry_used = False
        self._anr_wait_used = False
        self._location_permission_handled = False

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_root = self.resolve_path(
            self.config.get("log_root", "logs")
        )
        self.run_dir = log_root / f"run_{timestamp}"
        self.run_dir.mkdir(parents=True, exist_ok=True)

        self.logger = self.create_logger()

    @staticmethod
    def load_config(path: Path) -> dict[str, Any]:
        if not path.exists():
            raise SystemExit(f"Config tidak ditemukan: {path}")

        try:
            config = load_workflow_config(
                path,
                Path(__file__).resolve().parent / "workflow_defaults.json",
            )
        except json.JSONDecodeError as exc:
            raise SystemExit(
                f"config.json tidak valid pada baris "
                f"{exc.lineno}, kolom {exc.colno}: {exc.msg}"
            ) from exc

        for key in ("adb_serial", "live_url"):
            if not normalize(config.get(key)):
                raise SystemExit(
                    f"Nilai config wajib tidak tersedia: {key}"
                )

        return config

    def resolve_path(self, value: str) -> Path:
        path = Path(value)
        if path.is_absolute():
            return path
        return self.base_dir / path

    def create_logger(self) -> logging.Logger:
        logger = logging.getLogger(
            f"tiktok_selector_workflow_{id(self)}"
        )
        logger.handlers.clear()
        logger.setLevel(logging.INFO)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        console = logging.StreamHandler(sys.stdout)
        console.setLevel(logging.INFO if self.detailed_logging else logging.WARNING)
        console.setFormatter(formatter)
        logger.addHandler(console)
        if self.diagnostics_enabled:
            file_handler = logging.FileHandler(
                self.run_dir / "automation.log",
                encoding="utf-8",
            )
            file_handler.setLevel(logging.INFO)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        logger.propagate = False
        return logger

    def run_process(
        self,
        command: Sequence[str],
        *,
        timeout: int = 4,
        check: bool = False,
        binary: bool = False,
    ):
        display_command = subprocess.list2cmdline(
            [str(part) for part in command]
        )

        try:
            result = subprocess.run(
                [str(part) for part in command],
                capture_output=True,
                text=not binary,
                encoding=None if binary else "utf-8",
                errors=None if binary else "replace",
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            raise WorkflowError(
                f"Executable tidak ditemukan: {command[0]}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise WorkflowError(
                f"Command timeout setelah {timeout} detik: "
                f"{display_command}"
            ) from exc

        if check and result.returncode != 0:
            raise WorkflowError(
                f"Command gagal: {display_command}\n"
                f"{result.stderr or result.stdout}"
            )

        return result

    def adb(
        self,
        *args: str,
        timeout: int = 4,
        check: bool = False,
        include_serial: bool = True,
        binary: bool = False,
    ):
        command = [normalize(self.config.get("adb_executable", "adb")) or "adb"]
        if include_serial:
            command.extend(["-s", self.serial])
        command.extend(args)
        return self.run_process(
            command,
            timeout=timeout,
            check=check,
            binary=binary,
        )

    def set_stage(self, code: str, label: str) -> None:
        now = time.monotonic()
        if self.current_stage != "INIT":
            self.stage_timings[self.current_stage] = (
                self.stage_timings.get(self.current_stage, 0.0)
                + now - self._stage_started
            )
        self._stage_started = now
        self.current_stage = code
        self.current_action = label
        self.logger.info("STEP | %s | %s", code, label)

    def safe_adb_text(
        self,
        *args: str,
        timeout: int = 4,
        default: str = "unknown",
    ) -> str:
        try:
            result = self.adb(*args, timeout=timeout)
            value = normalize(result.stdout)
            return value or default
        except Exception as exc:
            self.logger.warning(
                "ADB metadata unavailable | command=%s | error=%s",
                " ".join(args),
                exc,
            )
            return default

    def _configure_uiautomator_device(self) -> tuple[int, int]:
        assert self.device is not None
        width, height = self.device.window_size()
        try:
            self.device.jsonrpc.setConfigurator(
                {"waitForIdleTimeout": 0, "waitForSelectorTimeout": 0}
            )
        except Exception as exc:
            self.logger.warning("Tidak dapat menonaktifkan idle wait: %s", exc)
        return width, height

    def _connect_uiautomator_with_repair(self, *, context: str) -> tuple[int, int]:
        """Connect under a per-device process lock and repair only stale u2.jar state.

        `AccessibilityServiceAlreadyRegisteredError` means Android still has a
        UiAutomation owner while the new uiautomator2 server is starting. We do
        one targeted cleanup of this project's own `com.wetest.uia2.Main`
        process, then reconnect exactly once. Arbitrary third-party accessibility
        automation is never killed.
        """
        if u2 is None:
            raise WorkflowError(
                "UIAUTOMATOR_NOT_INSTALLED: install uiautomator2 before running workers"
            )
        adb_executable = normalize(self.config.get("adb_executable", "adb")) or "adb"
        lock_timeout = max(
            0.5, float(self.config.get("uiautomator_device_lock_timeout_seconds", 6))
        )
        try:
            lease = device_control_lease(
                self.serial,
                timeout_seconds=lock_timeout,
            )
            with lease:
                try:
                    self.device = u2.connect(self.serial)
                    return self._configure_uiautomator_device()
                except Exception as first_exc:
                    if not is_uiautomator_registration_conflict(first_exc):
                        raise

                    before = uiautomator_process_snapshot(
                        adb_executable,
                        self.serial,
                        timeout=min(4.0, lock_timeout),
                    )
                    self.logger.warning(
                        "UIAUTOMATOR | registration conflict | context=%s | device=%s | u2_processes=%s",
                        context,
                        self.serial,
                        before or "none-visible",
                    )
                    repair = stop_our_uiautomator_processes(
                        adb_executable,
                        self.serial,
                        timeout=min(4.0, lock_timeout),
                        settle_seconds=max(
                            0.2,
                            float(self.config.get("uiautomator_reset_settle_seconds", 0.8)),
                        ),
                    )
                    self.uiautomator_repairs.append(
                        {
                            "context": context,
                            "first_error": f"{type(first_exc).__name__}: {first_exc}",
                            "repair": repair,
                        }
                    )
                    try:
                        self.device = u2.connect(self.serial)
                        size = self._configure_uiautomator_device()
                        self.logger.info(
                            "UIAUTOMATOR | stale service repaired | context=%s | killed=%s",
                            context,
                            repair.get("killed_pids", []),
                        )
                        return size
                    except Exception as second_exc:
                        if is_uiautomator_registration_conflict(second_exc):
                            visible_after = repair.get("after", [])
                            if not repair.get("killed_pids") and not visible_after:
                                raise WorkflowError(
                                    "UIAUTOMATOR_REGISTRATION_BUSY_UNOWNED: Android UiAutomation is already registered, "
                                    "but no com.wetest.uia2.Main process owned by this program was found to reset"
                                ) from second_exc
                            raise WorkflowError(
                                "UIAUTOMATOR_STALE_SERVICE_RESET_FAILED: targeted uiautomator2 reset completed "
                                f"but Android still reports an existing UiAutomation registration: {second_exc}"
                            ) from second_exc
                        raise
        except TimeoutError as exc:
            raise WorkflowError(
                f"UIAUTOMATOR_DEVICE_LOCK_TIMEOUT: {exc}"
            ) from exc

    def _repair_uiautomator_after_transport_failure(self, *, context: str) -> None:
        """Repair one dropped UiAutomator HTTP/control channel per worker."""
        if getattr(self, "_uiautomator_recovery_used", False):
            raise DestinationUnknownError(
                f"UIAUTOMATOR_TRANSPORT_RECOVERY_EXHAUSTED: second control-channel failure during {context}"
            )
        self._uiautomator_recovery_used = True
        self.logger.warning(
            "UIAUTOMATOR | transport failure | one control-channel repair | context=%s",
            context,
        )
        try:
            self._connect_uiautomator_with_repair(context=context)
        except Exception as exc:
            raise DestinationUnknownError(
                f"UIAUTOMATOR_TRANSPORT_REPAIR_FAILED: {context}: {type(exc).__name__}: {exc}"
            ) from exc

    def write_device_metadata(self) -> Path:
        """Persist the single authoritative per-device metadata object atomically."""
        path = self.run_dir / "device_metadata.json"
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(
            json.dumps(self.device_metadata, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        temporary.replace(path)
        return path

    def connect(self) -> None:
        adb_executable = normalize(self.config.get("adb_executable", "adb")) or "adb"
        if not bool(self.config.get("adb_host_validated", False)) and shutil.which(
            adb_executable
        ) is None:
            raise WorkflowError(
                f"ADB executable tidak ditemukan: {adb_executable}"
            )
        self.logger.info("ADB target: %s", self.serial)
        try:
            state_result = self.adb("get-state", timeout=3)
        except Exception as exc:
            raise WorkflowError(
                f"ADB_GET_STATE_FAILED: {type(exc).__name__}: {exc}"
            ) from exc
        if state_result.returncode != 0 or normalize(state_result.stdout) != "device":
            raise WorkflowError(
                "ADB_DEVICE_OFFLINE: adb get-state did not return 'device'"
            )

        try:
            width, height = self._connect_uiautomator_with_repair(context="CONNECT_ADB")
        except WorkflowError:
            raise
        except Exception as exc:
            raise WorkflowError(
                f"UIAUTOMATOR_CONNECTION_FAILED: {type(exc).__name__}: {exc}"
            ) from exc

        cached = bool(self.device_metadata)
        metadata = self.device_metadata
        metadata.update({
            "connected_at": datetime.now().isoformat(timespec="milliseconds"),
            "adb_serial": self.serial,
            "window_width": width,
            "window_height": height,
            "fixed_coordinates_used": False,
            "coordinate_ratios_used": False,
            "report_execution_mode": "submit_acknowledgement_is_final_success",
            "uiautomator_repairs": list(self.uiautomator_repairs),
        })
        if not cached:
            properties: dict[str, str] = {}
            try:
                prop_result = self.adb("shell", "getprop", timeout=4)
                if prop_result.returncode == 0:
                    for line in prop_result.stdout.splitlines():
                        match = re.fullmatch(r"\[(.+?)\]: \[(.*?)\]", line.strip())
                        if match:
                            properties[match.group(1)] = match.group(2)
            except Exception as exc:
                self.logger.warning("Tidak dapat mengambil getprop: %s", exc)

            metadata.update({
                "manufacturer": properties.get("ro.product.manufacturer", "unknown"),
                "model": properties.get("ro.product.model", "unknown"),
                "device": properties.get("ro.product.device", "unknown"),
                "product": properties.get("ro.product.name", "unknown"),
                "android_release": properties.get("ro.build.version.release", "unknown"),
                "sdk": properties.get("ro.build.version.sdk", "unknown"),
                "density": self.safe_adb_text(
                    "shell", "wm", "density", timeout=4, default="unknown"
                ),
            })

        self.device_metadata = metadata
        self.write_device_metadata()

    def detect_package(self) -> str:
        configured = normalize(self.config.get("tiktok_package", "auto"))
        if configured and configured != "auto":
            self.package = configured
        else:
            result = self.adb(
                "shell", "pm", "list", "packages", timeout=4, check=True
            )
            installed = sorted(
                {
                    line.split(":", 1)[1].strip()
                    for line in result.stdout.splitlines()
                    if line.startswith("package:")
                }
            )
            self.installed_packages = installed
            configured_packages = tuple(
                normalize(value)
                for value in self.config.get("tiktok_packages", [])
                if normalize(value)
            )
            self.package = next(
                (
                    candidate
                    for candidate in configured_packages
                    if candidate in installed
                ),
                None,
            )

            if not self.package:
                markers = tuple(
                    normalize(value).lower()
                    for value in self.config.get("tiktok_package_markers", [])
                    if normalize(value)
                )
                heuristic = [
                    package
                    for package in installed
                    if any(marker in package.lower() for marker in markers)
                ]
                if len(heuristic) == 1:
                    self.package = heuristic[0]
                    self.logger.warning(
                        "TikTok package detected heuristically: %s",
                        self.package,
                    )

        if not self.package:
            related = [
                package
                for package in installed
                if any(
                    marker in package.lower()
                    for marker in ("tiktok", "musically", "aweme", "trill")
                )
            ]
            related_text = ", ".join(related[:20]) or "none"
            raise WorkflowError(
                "Package TikTok tidak ditemukan. TikTok mungkin belum "
                "terpasang atau menggunakan package name baru. "
                f"Paket terkait yang ditemukan: {related_text}"
            )

        self.device_metadata["tiktok_package"] = self.package
        self.write_device_metadata()

        self.logger.info("Package TikTok: %s", self.package)
        return self.package

    def current_app(self) -> dict[str, str]:
        assert self.device is not None
        try:
            current = self.device.app_current()
            return {
                "package": normalize(current.get("package")),
                "activity": normalize(current.get("activity")),
            }
        except Exception:
            return {
                "package": "",
                "activity": "",
            }

    def save_state(self, prefix: str) -> None:
        # Keep successful runs compact. Capture UI state only for an explicit
        # failure/skip and only when diagnostics mode is enabled.
        if not self.diagnostics_enabled or not prefix.startswith(("error_", "skip_")):
            return

        assert self.device is not None

        try:
            self.device.screenshot(
                str(self.run_dir / f"{safe_name(prefix)}_screen.png")
            )
        except Exception as exc:
            self.logger.warning(
                "Screenshot diagnostic unavailable | prefix=%s | error=%s",
                prefix,
                exc,
            )

        lines = [
            f"timestamp={datetime.now().isoformat(timespec='milliseconds')}",
            f"adb_serial={self.serial}",
            f"live_url={self.live_url}",
            f"search_username=@{self.live_username}",
            f"current_app={json.dumps(self.current_app(), ensure_ascii=False)}",
            f"tiktok_launch_mode={self.tiktok_launch_mode}",
            "search_candidates="
            + json.dumps(self.search_result_candidates, ensure_ascii=False),
            "selected_search_result="
            + json.dumps(self.search_selected_result, ensure_ascii=False),
            "observed_destination_usernames="
            + json.dumps(self.observed_destination_usernames, ensure_ascii=False),
            "",
            "VISIBLE UI NODES",
            "resource_id | class | text | description | bounds | clickable | enabled",
        ]

        try:
            hierarchy = self.device.dump_hierarchy(compressed=False)
            (self.run_dir / f"{safe_name(prefix)}_ui.xml").write_text(
                hierarchy,
                encoding="utf-8",
            )
            root = ET.fromstring(hierarchy)

            node_count = 0
            for node in root.iter("node"):
                resource_id = normalize(node.attrib.get("resource-id"))
                class_name = normalize(node.attrib.get("class"))
                text = normalize(node.attrib.get("text"))
                description = normalize(
                    node.attrib.get("content-desc")
                )
                bounds = normalize(node.attrib.get("bounds"))
                clickable = normalize(node.attrib.get("clickable"))
                enabled = normalize(node.attrib.get("enabled"))

                if not (resource_id or text or description):
                    continue

                lines.append(
                    f"{resource_id} | {class_name} | {text!r} | "
                    f"{description!r} | {bounds} | "
                    f"{clickable} | {enabled}"
                )
                node_count += 1

                if node_count >= 300:
                    lines.append("... diagnostic truncated at 300 nodes ...")
                    break

        except Exception as exc:
            lines.append(f"UI hierarchy unavailable: {exc}")

        diagnostic_path = (
            self.run_dir / f"{safe_name(prefix)}_ui.txt"
        )
        diagnostic_path.write_text(
            "\n".join(lines) + "\n",
            encoding="utf-8",
        )
        self.logger.info(
            "Diagnostik UI teks disimpan: %s",
            diagnostic_path,
        )

    def live_unavailable_reason(self) -> str:
        """Read the current UI once and identify a finished LIVE screen."""
        assert self.device is not None

        try:
            hierarchy = self.device.dump_hierarchy(
                compressed=True,
            ).lower()
        except Exception:
            return ""

        markers = (
            ("live has ended", "LIVE has ended"),
            ("this live has ended", "LIVE has ended"),
            ("live is unavailable", "LIVE is unavailable"),
            ("live unavailable", "LIVE is unavailable"),
            ("siaran live telah berakhir", "Siaran LIVE telah berakhir"),
            ("live telah berakhir", "Siaran LIVE telah berakhir"),
            ("siaran langsung telah berakhir", "Siaran LIVE telah berakhir"),
        )

        for marker, label in markers:
            if marker in hierarchy:
                return label

        return ""

    def _dump_hierarchy(self, action: str) -> str:
        assert self.device is not None
        try:
            hierarchy = self.device.dump_hierarchy(compressed=False)
        except Exception as exc:
            # Recover the control channel once per worker. The reconnect/reset
            # critical section is protected by the per-device process lease so
            # a second worker cannot race UiAutomator startup on the same phone.
            if (
                not getattr(self, "_uiautomator_recovery_used", False)
                and u2 is not None
                and is_uiautomator_transport_error(exc)
            ):
                self.logger.warning(
                    "UIAUTOMATOR | hierarchy transport failure | action=%s | error=%s",
                    action,
                    exc,
                )
                try:
                    self._repair_uiautomator_after_transport_failure(
                        context=f"hierarchy:{action}"
                    )
                    assert self.device is not None
                    hierarchy = self.device.dump_hierarchy(compressed=False)
                except Exception as reconnect_exc:
                    raise DestinationUnknownError(
                        "HIERARCHY_UNAVAILABLE: "
                        f"{action}: uiautomator repair failed: "
                        f"{type(reconnect_exc).__name__}: {reconnect_exc}"
                    ) from reconnect_exc
            else:
                raise DestinationUnknownError(
                    f"HIERARCHY_UNAVAILABLE: {action}: {type(exc).__name__}: {exc}"
                ) from exc
        if not normalize(hierarchy):
            raise DestinationUnknownError(f"HIERARCHY_UNAVAILABLE: {action}: empty XML")
        return hierarchy

    def _wait_for_tiktok_foreground(self, timeout: float) -> None:
        deadline = time.monotonic() + self._bounded_stage_timeout(timeout)
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        permission_handled_at: float | None = None
        last_app = {"package": "", "activity": ""}
        while time.monotonic() < deadline:
            last_app = self.current_app()
            if last_app["package"] == self.package:
                return

            package = normalize(last_app.get("package", "")).casefold()
            if any(
                marker in package
                for marker in (
                    "permissioncontroller",
                    "packageinstaller",
                )
            ):
                hierarchy = self._dump_hierarchy(
                    "classify Android permission dialog during TikTok launch"
                )
                if tiktok_location_permission_dialog_present(hierarchy):
                    if self._location_permission_handled:
                        dismiss_grace = max(
                            0.2,
                            float(self.config.get("permission_dismiss_grace_seconds", 1.5)),
                        )
                        if (
                            permission_handled_at is not None
                            and time.monotonic() - permission_handled_at < dismiss_grace
                        ):
                            self._bounded_poll_sleep(poll, deadline)
                            continue
                        raise DestinationUnknownError(
                            "TIKTOK_LOCATION_PERMISSION_PERSISTENT: TikTok location permission remained after one deterministic Deny action"
                        )
                    self.handle_tiktok_location_permission_dialog(hierarchy)
                    self._location_permission_handled = True
                    permission_handled_at = time.monotonic()
                    self._bounded_poll_sleep(poll, deadline)
                    continue

            self._bounded_poll_sleep(poll, deadline)
        self._raise_if_live_precheck_expired()
        raise DestinationUnknownError(
            "TIKTOK_LAUNCH_TIMEOUT: TikTok did not become foreground; "
            f"blocking_app={last_app.get('package', '-')}/{last_app.get('activity', '-')}"
        )

    def _wait_for_search_readiness(
        self, selector_config: dict[str, Any], timeout: float
    ) -> None:
        self._ready_search_control = self.locate_unique(
            action="Wait for TikTok Search/Cari UI readiness",
            selector_config=selector_config,
            timeout=self._bounded_stage_timeout(timeout),
            handle_interruptions=True,
        )

    def launch_tiktok_normally(self) -> None:
        """Force-stop TikTok before every task, then cold-start with one bounded recovery."""
        assert self.device is not None
        assert self.package
        self.set_stage(
            "SEARCH_LAUNCH",
            "Force-stop TikTok and cold-start a fresh session",
        )
        self._ready_search_control = None
        self.tiktok_launch_mode = "cold-start"
        self.logger.info(
            "[SEARCH] @%s | force-stop TikTok before fresh launch",
            self.live_username,
        )
        launch_timeout = max(
            0.001, float(self.config.get("search_launch_timeout_seconds", 5))
        )
        search_config = self.config["selectors"]["search_button"]
        search_timeout = max(
            0.001, float(search_config.get("timeout_seconds", 4))
        )

        first_error: Exception | None = None
        try:
            # stop=True force-stops any existing TikTok process before launch.
            # This deliberately prevents state/session reuse between usernames.
            self.device.app_start(self.package, stop=True)
            self.logger.info(
                "[SEARCH] @%s | TikTok cold-started", self.live_username
            )
            self._wait_for_tiktok_foreground(launch_timeout)
            readiness_timeout = launch_timeout + search_timeout
            if self.workflow_mode in {"live_precheck", "live_discovery"}:
                readiness_timeout = float(
                    self.config.get(
                        "precheck_ui_readiness_before_recovery_seconds", 30
                    )
                )
            self._wait_for_search_readiness(
                search_config, max(0.001, readiness_timeout)
            )
        except WorkflowError as exc:
            first_error = exc
            self._raise_if_live_precheck_expired()
        except Exception as exc:
            first_error = DestinationUnknownError(
                f"TIKTOK_LAUNCH_FAILED: {type(exc).__name__}: {exc}"
            )

        if first_error is None:
            self.logger.info("[SEARCH] @%s | TikTok UI ready", self.live_username)
            return

        # Preserve the existing single bounded cold-start recovery. It can never
        # reuse the prior task because stop=True force-stops TikTok again.
        self.tiktok_launch_mode = "force-stop-recovery"
        self.logger.warning(
            "[SEARCH] @%s | TikTok unusable | one force-stop recovery",
            self.live_username,
        )
        try:
            self.device.app_start(self.package, stop=True)
            self._wait_for_tiktok_foreground(launch_timeout)
            recovery_timeout = launch_timeout + search_timeout
            remaining = self._remaining_live_precheck_time()
            if self.workflow_mode in {"live_precheck", "live_discovery"}:
                recovery_timeout = float(
                    self.config.get("precheck_ui_recovery_timeout_seconds", 10)
                )
                if remaining is not None:
                    recovery_timeout = min(recovery_timeout, remaining)
            elif remaining is not None:
                recovery_timeout = remaining
            self._wait_for_search_readiness(
                search_config, max(0.001, recovery_timeout)
            )
        except Exception as exc:
            self.save_state("error_tiktok_ui_not_ready")
            self._raise_if_live_precheck_expired()
            raise DestinationUnknownError(
                "TIKTOK_UI_NOT_READY: cold start and one bounded recovery did "
                f"not expose usable Search/Cari UI: {exc}"
            ) from exc
        self.logger.info("[SEARCH] @%s | TikTok UI ready", self.live_username)

    def _initialize_live_precheck_deadline(self) -> None:
        if (
            getattr(self, "workflow_mode", "report") not in {"live_precheck", "live_discovery"}
            or getattr(self, "_live_precheck_deadline", None) is not None
        ):
            return
        outer_budget = max(
            0.1, float(self.config.get("live_precheck_timeout_seconds", 80))
        )
        # Leave a small result-writing margin inside the runner's unchanged hard
        # process deadline so the current stage reaches result.json.
        result_margin = min(1.0, outer_budget * 0.1)
        self._live_precheck_deadline = self._workflow_started + max(
            0.05, outer_budget - result_margin
        )

    def _remaining_live_precheck_time(self) -> float | None:
        if getattr(self, "workflow_mode", "report") not in {"live_precheck", "live_discovery"}:
            return None
        self._initialize_live_precheck_deadline()
        assert self._live_precheck_deadline is not None
        return self._live_precheck_deadline - time.monotonic()

    def _raise_if_live_precheck_expired(self) -> None:
        remaining = self._remaining_live_precheck_time()
        if remaining is not None and remaining <= 0:
            raise WorkflowError(
                f"LIVE_PRECHECK_TIMEOUT: stage={self.current_stage}; shared deadline exhausted"
            )

    def _bounded_stage_timeout(self, requested: float) -> float:
        requested = max(0.001, float(requested))
        remaining = self._remaining_live_precheck_time()
        if remaining is None:
            return requested
        if remaining <= 0.001:
            self._raise_if_live_precheck_expired()
            raise WorkflowError(
                f"LIVE_PRECHECK_TIMEOUT: stage={self.current_stage}; insufficient time remaining"
            )
        return min(requested, remaining)

    def _bounded_poll_sleep(self, requested: float, local_deadline: float) -> None:
        remaining = max(0.0, local_deadline - time.monotonic())
        precheck_remaining = self._remaining_live_precheck_time()
        if precheck_remaining is not None:
            remaining = min(remaining, max(0.0, precheck_remaining))
        if remaining > 0:
            time.sleep(min(max(0.0, requested), remaining))

    @staticmethod
    def _click_once(target: Any, error_code: str) -> None:
        try:
            target.click()
        except Exception as exc:
            raise DestinationUnknownError(
                f"{error_code}: {type(exc).__name__}: {exc}"
            ) from exc

    def open_users_search(self, *, select_users_tab: bool = True) -> None:
        """Open Search, enter the configured query, and optionally select Users."""
        assert self.device is not None
        search_query = normalize(getattr(self, "search_query", "")) or self.live_username
        search_config = self.config["selectors"]["search_button"]
        ready = self._ready_search_control
        self._ready_search_control = None
        if ready is None:
            self.set_stage("SEARCH_READY", "Wait for TikTok Search/Cari UI readiness")
            ready = self.locate_unique(
                action="Wait for TikTok Search/Cari UI readiness",
                selector_config=search_config,
                timeout=self._bounded_stage_timeout(
                    float(search_config.get("timeout_seconds", 4))
                ),
            )
        target, _located = ready
        self.set_stage("SEARCH_OPEN", "Open TikTok Search")
        self.logger.info("[SEARCH] @%s | opening Search", self.live_username)
        try:
            self._click_once(target, "SEARCH_BUTTON_CLICK_FAILED")
        except DestinationUnknownError as exc:
            if not is_uiautomator_transport_error(exc):
                raise
            self._repair_uiautomator_after_transport_failure(
                context="Search button click"
            )
            hierarchy = self._dump_hierarchy(
                "verify Search state after click transport failure"
            )
            if not search_input_present_in_hierarchy(hierarchy):
                # The first click was not acknowledged. Re-resolve the idempotent
                # Search entry once after proving we are still on the pre-Search UI.
                retry_target, _retry_located = self.locate_unique(
                    action="Re-resolve TikTok Search after control-channel failure",
                    selector_config=search_config,
                    timeout=min(1.0, self._bounded_stage_timeout(1.0)),
                    handle_interruptions=True,
                )
                self._click_once(retry_target, "SEARCH_BUTTON_CLICK_FAILED")
        self.logger.info("[SEARCH] @%s | Search opened", self.live_username)

        self.set_stage("SEARCH_QUERY", f"Search query {search_query!r}")
        input_config = self.config["selectors"]["search_input"]
        input_target, input_located = self.locate_unique(
            action="Locate TikTok Search input",
            selector_config=input_config,
            timeout=self._bounded_stage_timeout(
                float(input_config.get("timeout_seconds", 4))
            ),
        )

        # Search input must be an actual EditText. TikTok also exposes a
        # Search ImageView with description="Search"; treating that icon as the
        # input causes false empty-query verification and stale searches.
        exact_input = input_target
        if input_located.class_name != "android.widget.EditText":
            exact_input = None

        if input_located.resource_id:
            try:
                by_id = self.device(
                    resourceId=input_located.resource_id,
                    className="android.widget.EditText",
                )
                if int(by_id.count) == 1:
                    exact_input = by_id
            except Exception:
                pass

        if exact_input is None:
            try:
                unique_edit_text = self.device(
                    className="android.widget.EditText",
                )
                if int(unique_edit_text.count) == 1:
                    exact_input = unique_edit_text
            except Exception:
                pass

        if exact_input is None:
            self.save_state("error_search_input_not_edittext")
            raise DestinationUnknownError(
                "SEARCH_QUERY_FAILED: TikTok Search input did not resolve to "
                "a unique android.widget.EditText"
            )

        def current_search_text() -> str:
            try:
                return normalize(exact_input.info.get("text"))
            except Exception:
                return ""

        try:
            exact_input.click()
            exact_input.set_text(search_query)
            observed_query = current_search_text()

            # Some builds can silently ignore the first set_text(). Use one
            # bounded fallback without clear=True/clearInputText: first prove
            # the real EditText can be emptied, then type into that focused
            # empty field. Never append to unverified stale text.
            if observed_query.casefold() != search_query.casefold():
                exact_input.click()
                exact_input.set_text("")
                if current_search_text() == "":
                    send_keys = getattr(self.device, "send_keys", None)
                    if callable(send_keys):
                        send_keys(search_query, clear=False)
                    else:
                        exact_input.set_text(search_query)
                observed_query = current_search_text()

            if observed_query.casefold() != search_query.casefold():
                self.save_state("error_search_query_mismatch")
                raise DestinationUnknownError(
                    "SEARCH_QUERY_FAILED: search field does not contain the "
                    f"requested query; expected={search_query!r}, "
                    f"observed={observed_query!r}"
                )

            self.logger.info(
                "[SEARCH] query=%r | query verified", search_query
            )
            # Avoid an unbounded uiautomator2 key RPC. ADB keyevent has an
            # explicit host timeout and cannot hang the whole worker for tens
            # of seconds if UiAutomation is unhealthy.
            key_timeout = max(
                0.5, float(self.config.get("adb_keyevent_timeout_seconds", 8))
            )
            try:
                key_result = self.adb(
                    "shell",
                    "input",
                    "keyevent",
                    "KEYCODE_ENTER",
                    timeout=key_timeout,
                )
            except WorkflowError as exc:
                # ADB can time out after Android already consumed the keyevent.
                # Observe the UI before declaring failure; never send Enter twice.
                hierarchy = self._dump_hierarchy(
                    "verify Search state after bounded ADB Enter timeout"
                )
                if users_tab_available_in_hierarchy(hierarchy):
                    self.logger.warning(
                        "[SEARCH] @%s | ADB Enter timed out but Search results UI is present; continuing without a second Enter",
                        self.live_username,
                    )
                    key_result = None
                else:
                    raise DestinationUnknownError(
                        f"SEARCH_QUERY_SUBMIT_TIMEOUT: bounded ADB KEYCODE_ENTER timed out and Search results UI was not observed: {exc}"
                    ) from exc
            if key_result is not None and key_result.returncode != 0:
                hierarchy = self._dump_hierarchy(
                    "verify Search state after failed ADB Enter"
                )
                if not users_tab_available_in_hierarchy(hierarchy):
                    raise DestinationUnknownError(
                        "SEARCH_QUERY_SUBMIT_FAILED: adb KEYCODE_ENTER returned non-zero and Search results UI was not observed"
                    )
        except DestinationUnknownError:
            raise
        except Exception as exc:
            raise DestinationUnknownError(
                f"SEARCH_QUERY_FAILED: {type(exc).__name__}: {exc}"
            ) from exc

        if not select_users_tab:
            return

        self.set_stage("SEARCH_USERS_TAB", "Select TikTok Users results")
        users_config = dict(self.config["selectors"]["users_tab"])
        # Click only the actual clickable Users/Pengguna tab container. Generic
        # text nodes are not accepted because TikTok can keep a stale tab view.
        users_config["require_clickable"] = True
        try:
            users_target, _located = self.locate_unique(
                action="Select TikTok Users tab",
                selector_config=users_config,
                timeout=self._bounded_stage_timeout(
                    float(users_config.get("timeout_seconds", 5))
                ),
                handle_interruptions=True,
            )
        except WorkflowError as exc:
            # TikTok can expose the real clickable tab at the exact selector
            # deadline. Resolve once more only after a fresh hierarchy proves
            # that the Users control is now present.
            hierarchy = self._dump_hierarchy("final Users tab availability check")
            if users_tab_selected_in_hierarchy(hierarchy):
                self.logger.info(
                    "[SEARCH] @%s | Users became selected at selector deadline; no click needed",
                    self.live_username,
                )
                return
            if not users_tab_available_in_hierarchy(hierarchy):
                raise
            users_target, _located = self.locate_unique(
                action="Select TikTok Users tab after final availability check",
                selector_config=users_config,
                timeout=min(0.75, self._bounded_stage_timeout(0.75)),
                handle_interruptions=True,
            )

        try:
            self._click_once(users_target, "USERS_TAB_CLICK_FAILED")
        except DestinationUnknownError as exc:
            # A lost UiAutomator RPC does not prove the click failed. Reconnect
            # through a fresh hierarchy and accept the state if Users is already
            # selected. Otherwise re-resolve this idempotent tab action once.
            hierarchy = self._dump_hierarchy("verify Users state after click RPC failure")
            if users_tab_selected_in_hierarchy(hierarchy):
                self.logger.warning(
                    "[SEARCH] @%s | Users click RPC failed but selected state is confirmed",
                    self.live_username,
                )
                return
            if not users_tab_available_in_hierarchy(hierarchy):
                raise
            retry_target, _retry_located = self.locate_unique(
                action="Re-resolve Users tab after control-channel failure",
                selector_config=users_config,
                timeout=min(0.75, self._bounded_stage_timeout(0.75)),
                handle_interruptions=True,
            )
            self._click_once(retry_target, "USERS_TAB_CLICK_FAILED")

    def inspect_search_results(self) -> tuple[SearchResultCandidate, bool]:
        """Inspect one bounded visible result set; never scroll indefinitely."""
        assert self.device is not None
        self.set_stage("SEARCH_RESULTS", "Inspect bounded canonical Users results")
        deadline = time.monotonic() + self._bounded_stage_timeout(
            float(self.config.get("search_result_timeout_seconds", 5))
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        maximum = max(1, int(self.config.get("search_result_max_candidates", 12)))
        last_candidates: list[SearchResultCandidate] = []
        selected: SearchResultCandidate | None = None
        exact = False
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy("inspect Search results")
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"SEARCH_STATE_UNKNOWN: {reason}")
            last_candidates = search_result_candidates_from_hierarchy(
                hierarchy, maximum=maximum
            )
            selected, exact = select_search_result(last_candidates, self.live_username)
            if exact:
                break
            self._bounded_poll_sleep(poll, deadline)

        self._raise_if_live_precheck_expired()

        self.search_result_candidates = [
            {
                "username": item.username,
                "username_bounds": item.username_bounds,
                "avatar_bounds": item.avatar_bounds,
                "row_bounds": item.row_bounds,
                "source": item.source,
            }
            for item in last_candidates
        ]
        selected, exact = select_search_result(last_candidates, self.live_username)
        if selected is None:
            self.save_state("error_search_results_missing")
            raise DestinationUnknownError(
                "SEARCH_RESULTS_EMPTY: no canonical visible Users result was found"
            )
        self.search_used_top_fallback = not exact
        self.search_selected_result = {
            "username": selected.username,
            "username_bounds": selected.username_bounds,
            "avatar_bounds": selected.avatar_bounds,
            "row_bounds": selected.row_bounds,
            "source": selected.source,
            "selection": "exact" if exact else "top-result-fallback",
        }
        if exact:
            self.logger.info("[SEARCH] @%s | exact result found", self.live_username)
        else:
            self.logger.info(
                "[SEARCH] @%s | exact result not found | using top result fallback",
                self.live_username,
            )
        return selected, exact

    def open_search_result_avatar(self, selected: SearchResultCandidate) -> None:
        """Click the selected row's image, or a row-relative avatar position."""
        assert self.device is not None
        self._raise_if_live_precheck_expired()
        bounds = selected.avatar_bounds
        click_method = "associated-image"
        if bounds is None:
            left, top, _right, bottom = selected.username_bounds
            row_left, row_top, _row_right, row_bottom = selected.row_bounds
            username_height = max(1, bottom - top)
            x = max(row_left + 1, left - max(24, username_height * 2))
            y = max(row_top + 1, min(row_bottom - 1, (top + bottom) // 2))
            click_method = "row-relative-avatar"
        else:
            x = (bounds[0] + bounds[2]) // 2
            y = (bounds[1] + bounds[3]) // 2
        try:
            self.device.click(x, y)
        except Exception as exc:
            if not is_uiautomator_transport_error(exc):
                raise DestinationUnknownError(
                    f"SEARCH_AVATAR_CLICK_FAILED: {type(exc).__name__}: {exc}"
                ) from exc
            self._repair_uiautomator_after_transport_failure(
                context="exact user avatar click"
            )
            # Never blind-click twice. First inspect whether the original click
            # already navigated to LIVE/profile despite the dropped HTTP response.
            if self.live_context_ok():
                self.search_selected_result["click_method"] = click_method + "-transport-ack-live"
                self.search_selected_result["click_point"] = [x, y]
                return
            hierarchy = self._dump_hierarchy(
                "verify destination after avatar click transport failure"
            )
            is_profile, evidence = target_profile_semantic_evidence(
                hierarchy, self.live_username
            )
            if is_profile or evidence.get("exact_username"):
                self.search_selected_result["click_method"] = click_method + "-transport-ack-profile"
                self.search_selected_result["click_point"] = [x, y]
                return

            exact = exact_target_search_result_from_hierarchy(
                hierarchy, self.live_username
            )
            if not users_tab_selected_in_hierarchy(hierarchy) or exact is None:
                raise DestinationUnknownError(
                    "SEARCH_AVATAR_CLICK_UNACKNOWLEDGED: control channel dropped and neither destination nor exact Users row could be verified afterward"
                ) from exc
            retry_bounds = exact.avatar_bounds
            if retry_bounds is None:
                left, top, _right, bottom = exact.username_bounds
                row_left, row_top, _row_right, row_bottom = exact.row_bounds
                username_height = max(1, bottom - top)
                retry_x = max(row_left + 1, left - max(24, username_height * 2))
                retry_y = max(row_top + 1, min(row_bottom - 1, (top + bottom) // 2))
            else:
                retry_x = (retry_bounds[0] + retry_bounds[2]) // 2
                retry_y = (retry_bounds[1] + retry_bounds[3]) // 2
            try:
                self.device.click(retry_x, retry_y)
            except Exception as retry_exc:
                raise DestinationUnknownError(
                    f"SEARCH_AVATAR_CLICK_FAILED: re-resolved exact avatar click failed: {type(retry_exc).__name__}: {retry_exc}"
                ) from retry_exc
            x, y = retry_x, retry_y
            click_method = "re-resolved-exact-avatar-after-transport-failure"
        self.search_selected_result["click_method"] = click_method
        self.search_selected_result["click_point"] = [x, y]

    def normal_profile_context_ok(self, activity: str) -> bool:
        return any(
            normalize(fragment).casefold() in activity.casefold()
            for fragment in self.config.get(
                "profile_activity_contains", ["UserProfileActivity", ".profile."]
            )
        )

    def classify_search_destination(self) -> str:
        """Return LIVE/OFFLINE or raise UNKNOWN with concrete evidence."""
        assert self.package
        self.set_stage(
            "DESTINATION_CLASSIFICATION", "Classify Search-opened destination"
        )
        deadline = time.monotonic() + self._bounded_stage_timeout(
            float(self.config.get("destination_classification_timeout_seconds", 8))
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        last_activity = ""
        last_observed: list[str] = []
        while time.monotonic() < deadline:
            current = self.current_app()
            last_activity = current["activity"]
            if self.live_context_ok():
                self.logger.info("[CHECK] @%s | LIVE", self.live_username)
                return "LIVE"
            hierarchy = self._dump_hierarchy("classify Search destination")
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"DESTINATION_UNKNOWN: {reason}")
            identity, observed = profile_identity_state(hierarchy, self.live_username)
            last_observed = observed
            self.observed_destination_usernames = list(observed)
            if identity == "mismatch" and self.normal_profile_context_ok(last_activity):
                raise DestinationUnknownError(
                    "IDENTITY_MISMATCH: "
                    f"expected=@{self.live_username}, observed={observed}"
                )
            if identity == "exact" and self.normal_profile_context_ok(last_activity):
                self.logger.info("[CHECK] @%s | OFFLINE", self.live_username)
                return "OFFLINE"
            self._bounded_poll_sleep(poll, deadline)
        self._raise_if_live_precheck_expired()
        raise DestinationUnknownError(
            "DESTINATION_UNKNOWN: state remained ambiguous; "
            f"activity={last_activity or '-'}; observed={last_observed}"
        )

    def open_top_user_avatar_for_precheck(self) -> None:
        """Open the exact requested user from the visible Users results.

        TikTok ranking is not stable across phones.  The exact requested account
        can be row #2/#3 even when result #1 is a similar username, so the worker
        inspects the bounded visible Users rows and clicks only the exact canonical
        username.  No top-result fallback is used for reporting/precheck identity.
        """
        assert self.device is not None
        self.set_stage("SEARCH_EXACT_USER", "Wait for Users tab then open exact requested user")
        result_timeout_key = (
            "precheck_search_result_timeout_seconds"
            if self.workflow_mode == "live_precheck"
            else "search_result_timeout_seconds"
        )
        timeout = self._bounded_stage_timeout(
            float(
                self.config.get(
                    result_timeout_key,
                    self.config.get("search_result_timeout_seconds", 12),
                )
            )
        )
        started = time.monotonic()
        deadline = started + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        maximum = max(1, int(self.config.get("search_result_max_candidates", 12)))
        selected: SearchResultCandidate | None = None
        last_users_selected = False
        last_candidates: list[SearchResultCandidate] = []
        reselection_attempted = False
        reselection_after = min(1.5, max(0.4, timeout * 0.25))

        def inspect_once() -> SearchResultCandidate | None:
            nonlocal last_users_selected, last_candidates
            hierarchy = self._dump_hierarchy(
                "wait for selected Users tab and exact requested user"
            )
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                return None
            if self.recover_known_blocking_state(
                hierarchy, context="Users result loading"
            ):
                return None
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"SEARCH_STATE_BLOCKED: {reason}")
            last_users_selected = users_tab_selected_in_hierarchy(hierarchy)
            if not last_users_selected:
                return None
            last_candidates = search_result_candidates_from_hierarchy(
                hierarchy, maximum=maximum
            )
            self.search_result_candidates = [
                {
                    "username": item.username,
                    "username_bounds": item.username_bounds,
                    "avatar_bounds": item.avatar_bounds,
                    "row_bounds": item.row_bounds,
                    "source": item.source,
                }
                for item in last_candidates
            ]
            expected = normalize_identity(self.live_username)
            exact_structural = exact_target_search_result_from_hierarchy(
                hierarchy, self.live_username
            )
            if exact_structural is not None:
                if not any(
                    normalize_identity(item.username) == expected
                    and item.username_bounds == exact_structural.username_bounds
                    for item in last_candidates
                ):
                    last_candidates.append(exact_structural)
                    last_candidates.sort(
                        key=lambda item: (item.username_bounds[1], item.username_bounds[0])
                    )
                    self.search_result_candidates = [
                        {
                            "username": item.username,
                            "username_bounds": item.username_bounds,
                            "avatar_bounds": item.avatar_bounds,
                            "row_bounds": item.row_bounds,
                            "source": item.source,
                        }
                        for item in last_candidates[:maximum]
                    ]
                return exact_structural
            return next(
                (
                    item
                    for item in last_candidates
                    if normalize_identity(item.username) == expected
                ),
                None,
            )

        while time.monotonic() < deadline:
            selected = inspect_once()
            if selected is not None:
                break

            if (
                not last_users_selected
                and not reselection_attempted
                and time.monotonic() - started >= reselection_after
            ):
                reselection_attempted = True
                users_config = dict(self.config["selectors"]["users_tab"])
                users_config["require_clickable"] = True
                remaining = max(0.05, deadline - time.monotonic())
                try:
                    users_target, _located = self.locate_unique(
                        action="Re-select TikTok Users tab after unacknowledged first click",
                        selector_config=users_config,
                        timeout=min(1.5, remaining),
                    )
                    self._click_once(users_target, "USERS_TAB_RESELECT_FAILED")
                    self.logger.info(
                        "[SEARCH] @%s | first Users click not acknowledged | re-selected once",
                        self.live_username,
                    )
                except (WorkflowError, DestinationUnknownError) as exc:
                    # The first Users click may finish asynchronously while the
                    # re-selection selector is being resolved. Re-observe state
                    # before calling this a re-selection failure.
                    fresh = self._dump_hierarchy(
                        "verify Users state after re-selection resolution failure"
                    )
                    if users_tab_selected_in_hierarchy(fresh):
                        last_users_selected = True
                        self.logger.info(
                            "[SEARCH] @%s | Users became selected during re-selection race; continuing",
                            self.live_username,
                        )
                    else:
                        self.save_state("error_users_tab_reselect")
                        raise DestinationUnknownError(
                            f"USERS_TAB_RESELECT_FAILED: {type(exc).__name__}: {exc}"
                        ) from exc
            self._bounded_poll_sleep(poll, deadline)

        if selected is None:
            selected = inspect_once()

        # If Users is selected but the server-backed rows arrive exactly at the
        # normal deadline, allow a small passive observation grace. No search,
        # tab click or scroll is repeated.
        if selected is None and last_users_selected and not last_candidates:
            grace = max(
                0.0, float(self.config.get("users_results_final_grace_seconds", 1.5))
            )
            if grace > 0:
                grace_deadline = time.monotonic() + self._bounded_stage_timeout(grace)
                while time.monotonic() < grace_deadline and selected is None:
                    selected = inspect_once()
                    if selected is not None:
                        break
                    self._bounded_poll_sleep(poll, grace_deadline)
                if selected is None:
                    selected = inspect_once()

        self._raise_if_live_precheck_expired()
        if selected is None:
            self.save_state("error_search_users_not_ready")
            if not last_users_selected:
                raise DestinationUnknownError(
                    "USERS_TAB_CLICK_NOT_ACKNOWLEDGED: TikTok remained on another Search "
                    "tab after the initial Users click and one verified re-selection"
                )
            if last_candidates:
                observed = [item.username for item in last_candidates]
                raise DestinationUnknownError(
                    "USERS_EXACT_TARGET_NOT_FOUND: exact requested username "
                    f"@{self.live_username} was not present in the bounded visible Users rows; "
                    f"observed={observed}"
                )
            raise DestinationUnknownError(
                "USERS_RESULTS_LOAD_TIMEOUT: Users tab was selected but no canonical user rows "
                "became available before the bounded result deadline"
            )

        self.top_user_click_source = "hierarchy"
        self.search_used_top_fallback = False
        self.search_selected_result = {
            "username": selected.username,
            "username_bounds": selected.username_bounds,
            "avatar_bounds": selected.avatar_bounds,
            "row_bounds": selected.row_bounds,
            "source": selected.source,
            "selection": "exact-visible-user-row",
        }
        self.open_search_result_avatar(selected)
        self.logger.info(
            "[SEARCH] @%s | Users selected | exact requested row opened | observed_rows=%s",
            self.live_username,
            [item.username for item in last_candidates],
        )

    def detail_activity_context_ok(self, activity: str) -> bool:
        folded = normalize(activity).casefold()
        return "detailactivity" in folded or ".detail." in folded

    def recover_precheck_detail_activity(self) -> None:
        """Recover one stale Search->video redirect without guessing LIVE state.

        When TikTok keeps a stale Watch LIVE result after a broadcaster ends, an
        exact result click can open DetailActivity. We go Back once, require the
        same exact Users row again, then click the username text (profile side)
        rather than the avatar/LIVE affordance. The next normal classifier must
        still prove LIVE, exact profile, or explicit ended state.
        """
        assert self.device is not None
        self.set_stage(
            "PRECHECK_DETAIL_RECOVERY",
            "Recover stale DetailActivity by reopening exact target profile",
        )
        key_timeout = max(
            0.5, float(self.config.get("adb_keyevent_timeout_seconds", 8))
        )
        result = self.adb(
            "shell", "input", "keyevent", "KEYCODE_BACK", timeout=key_timeout
        )
        if result.returncode != 0:
            raise DestinationUnknownError(
                "PRECHECK_DETAIL_RECOVERY_FAILED: ADB Back returned non-zero"
            )

        timeout = self._bounded_stage_timeout(
            float(self.config.get("precheck_detail_recovery_timeout_seconds", 4))
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy(
                "recover exact Users row after stale DetailActivity"
            )
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="precheck stale DetailActivity recovery"
            ):
                continue
            if users_tab_selected_in_hierarchy(hierarchy):
                exact = exact_target_search_result_from_hierarchy(
                    hierarchy, self.live_username
                )
                if exact is not None:
                    left, top, right, bottom = exact.username_bounds
                    try:
                        self.device.click((left + right) // 2, (top + bottom) // 2)
                    except Exception as exc:
                        raise DestinationUnknownError(
                            f"PRECHECK_DETAIL_RECOVERY_FAILED: exact username profile click failed: {type(exc).__name__}: {exc}"
                        ) from exc
                    self.logger.info(
                        "[CHECK] @%s | stale DetailActivity recovered | reopened exact username profile side",
                        self.live_username,
                    )
                    return
            self._bounded_poll_sleep(poll, deadline)

        raise DestinationUnknownError(
            "PRECHECK_DETAIL_RECOVERY_FAILED: stale DetailActivity returned to Search, but the exact requested Users row did not become usable before deadline"
        )

    def classify_top_user_precheck_destination(self) -> str:
        """Classify the selected exact user as LIVE or the exact target profile."""
        assert self.package
        self.set_stage(
            "DESTINATION_CLASSIFICATION",
            "Classify selected exact user as LIVE or exact target profile",
        )
        classification_timeout = float(
            self.config.get(
                "precheck_destination_classification_timeout_seconds",
                self.config.get("destination_classification_timeout_seconds", 8),
            )
        )
        deadline = time.monotonic() + self._bounded_stage_timeout(
            classification_timeout
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        last_activity = ""
        overlay_closed = False
        detail_recovery_used = False
        ordinary_video_observations = 0
        last_profile_evidence: dict[str, Any] = {}
        while time.monotonic() < deadline:
            current = self.current_app()
            last_activity = current["activity"]
            if self.live_context_ok():
                self.logger.info("[CHECK] @%s | LIVE via selected exact user", self.live_username)
                return "LIVE"

            # Exact-username prechecks can recover a stale video detail by
            # returning to the same Users row. Keyword discovery has no exact
            # username yet, so that recovery is impossible and would always
            # discard the selected LIVE result. Let discovery inspect the
            # destination UI instead.
            if (
                self.workflow_mode != "live_discovery"
                and self.detail_activity_context_ok(last_activity)
            ):
                if detail_recovery_used:
                    raise DestinationUnknownError(
                        "PRECHECK_DETAIL_ACTIVITY_PERSISTENT: exact target returned to DetailActivity after one stale-state recovery"
                    )
                detail_recovery_used = True
                self.recover_precheck_detail_activity()
                self.set_stage(
                    "DESTINATION_CLASSIFICATION",
                    "Classify selected exact user as LIVE or exact target profile",
                )
                deadline = time.monotonic() + self._bounded_stage_timeout(
                    classification_timeout
                )
                continue

            hierarchy = self._dump_hierarchy("classify selected exact user destination")
            if explicit_live_ended_in_hierarchy(hierarchy):
                self.logger.info("[CHECK] @%s | OFFLINE via explicit ended screen", self.live_username)
                return "OFFLINE"
            if (
                self.workflow_mode == "live_discovery"
                and self.detail_activity_context_ok(last_activity)
                and active_live_room_from_hierarchy(hierarchy)
            ):
                self._discovery_detail_live_verified = True
                self.logger.info(
                    "[DISCOVERY] active LIVE proved in DetailActivity by broadcaster and LIVE-room structure"
                )
                return "LIVE"
            if (
                self.workflow_mode == "live_discovery"
                and self.detail_activity_context_ok(last_activity)
                and ordinary_video_detail_from_hierarchy(hierarchy)
            ):
                ordinary_video_observations += 1
                if ordinary_video_observations >= 2:
                    self.logger.info(
                        "[DISCOVERY] selected result resolved to a stable ordinary video; trying another LIVE candidate"
                    )
                    return "STALE"
            else:
                ordinary_video_observations = 0
            if verification_overlay_present(hierarchy):
                if overlay_closed:
                    raise DestinationUnknownError(
                        "VERIFY_OVERLAY_STILL_PRESENT: verification returned during destination classification"
                    )
                self.handle_optional_verification_overlay()
                overlay_closed = True
                continue

            if self.recover_known_blocking_state(
                hierarchy, context="report destination classification"
            ):
                continue

            is_profile, evidence = target_profile_semantic_evidence(
                hierarchy, self.live_username
            )
            last_profile_evidence = evidence
            profile_activity_exact = bool(
                self.normal_profile_context_ok(last_activity) and evidence.get("exact_username")
            )
            if is_profile or profile_activity_exact:
                self.logger.info(
                    "[CHECK] @%s | OFFLINE via exact target profile evidence",
                    self.live_username,
                )
                return "OFFLINE"

            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"DESTINATION_BLOCKED: {reason}")
            self._bounded_poll_sleep(poll, deadline)

        self._raise_if_live_precheck_expired()
        raise DestinationUnknownError(
            "DESTINATION_CLASSIFICATION_TIMEOUT: selected exact user reached neither active LIVE, "
            "explicit ended state, nor the exact target profile before deadline; "
            f"activity={last_activity or '-'}; profile_evidence={last_profile_evidence}"
        )

    def navigate_top_user_for_precheck(self) -> str:
        """Search Users, open the exact requested user, and classify LIVE vs profile."""
        self.launch_tiktok_normally()
        self.open_users_search()
        self.open_top_user_avatar_for_precheck()
        return self.classify_top_user_precheck_destination()

    def enter_live_from_exact_profile(self, hierarchy: str) -> bool:
        """Enter an active LIVE from the exact target profile without touching avatar/tab.

        Recovery waits for a profile-header LIVE badge and clicks it once. The
        avatar itself is never clicked (it opens EnlargeAvatarActivity), and a
        lower LIVE content tab is rejected structurally. If the exact target
        profile remains but no active-LIVE badge appears before the bounded
        deadline, that is treated as a device-local LIVE-ended outcome rather
        than a program failure.
        """
        assert self.device is not None
        self.set_stage(
            "PROFILE_LIVE_ENTRY",
            "Open profile-header LIVE badge from exact target profile",
        )
        timeout = self._bounded_stage_timeout(
            float(self.config.get("profile_live_entry_timeout_seconds", 8))
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        current_hierarchy = hierarchy
        clicked = False
        overlay_closed = False
        last_exact_profile = False

        while time.monotonic() < deadline:
            if self.live_context_ok():
                self.logger.info(
                    "[LIVE] @%s | profile-header LIVE badge reached active LivePlayActivity",
                    self.live_username,
                )
                return True

            self._raise_if_live_ended_during_workflow(
                current_hierarchy, context="profile-to-LIVE recovery"
            )
            is_profile, profile_evidence = target_profile_semantic_evidence(
                current_hierarchy, self.live_username
            )
            last_exact_profile = bool(is_profile or profile_evidence.get("exact_username"))

            if verification_overlay_present(current_hierarchy):
                if overlay_closed:
                    raise DestinationUnknownError(
                        "VERIFY_OVERLAY_STILL_PRESENT: verification returned during profile-to-LIVE recovery"
                    )
                self.handle_optional_verification_overlay()
                overlay_closed = True
            elif self.recover_known_blocking_state(
                current_hierarchy, context="profile-to-LIVE recovery"
            ):
                pass
            elif not clicked:
                evidence = profile_live_entry_from_hierarchy(current_hierarchy)
                if evidence is not None:
                    bounds = evidence["bounds"]
                    x = (bounds[0] + bounds[2]) // 2
                    y = (bounds[1] + bounds[3]) // 2
                    try:
                        self.device.click(x, y)
                    except Exception as exc:
                        if is_uiautomator_transport_error(exc):
                            self._repair_uiautomator_after_transport_failure(
                                context="profile LIVE badge click"
                            )
                            # Re-observe before deciding whether the original click
                            # succeeded. Never blind-click the badge a second time.
                            if self.live_context_ok():
                                return True
                            current_hierarchy = self._dump_hierarchy(
                                "verify profile LIVE state after click transport failure"
                            )
                            if self.live_context_ok():
                                return True
                            raise DestinationUnknownError(
                                "PROFILE_LIVE_ENTRY_CLICK_UNACKNOWLEDGED: control channel dropped and active LIVE was not observed afterward"
                            ) from exc
                        raise DestinationUnknownError(
                            f"PROFILE_LIVE_ENTRY_CLICK_FAILED: {type(exc).__name__}: {exc}"
                        ) from exc
                    clicked = True
                    self.logger.info(
                        "[LIVE] @%s | exact profile opened first | clicked profile-header LIVE badge | bounds=%s",
                        self.live_username,
                        bounds,
                    )

            self._bounded_poll_sleep(poll, deadline)
            current_hierarchy = self._dump_hierarchy(
                "wait for profile-header LIVE destination"
            )

        if self.live_context_ok():
            return True
        final_hierarchy = self._dump_hierarchy(
            "final profile-header LIVE recovery state"
        )
        self._raise_if_live_ended_during_workflow(
            final_hierarchy, context="profile-to-LIVE recovery"
        )
        final_profile, final_evidence = target_profile_semantic_evidence(
            final_hierarchy, self.live_username
        )
        final_live_badge = profile_live_entry_from_hierarchy(final_hierarchy)
        if (
            not clicked
            and final_live_badge is None
            and (final_profile or final_evidence.get("exact_username") or last_exact_profile)
        ):
            raise LiveEndedDuringWorkflow(
                "LIVE_ENDED_DURING_WORKFLOW: exact target profile remained visible after the initial LIVE precheck, but no profile-header active-LIVE badge appeared before the bounded deadline"
            )
        raise DestinationUnknownError(
            "PROFILE_LIVE_ENTRY_NOT_ACTIVE: profile-header LIVE recovery did not reach an active LIVE session before the bounded deadline"
        )

    def classify_top_user_report_destination(self) -> str:
        """Classify the selected exact user using positive destination evidence only."""
        assert self.package
        self.set_stage(
            "DESTINATION_CLASSIFICATION",
            "Classify selected exact user for report workflow",
        )
        deadline = time.monotonic() + self._bounded_stage_timeout(
            float(self.config.get("destination_classification_timeout_seconds", 8))
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        last_activity = ""
        overlay_closed = False
        last_profile_evidence: dict[str, Any] = {}
        while time.monotonic() < deadline:
            current = self.current_app()
            last_activity = current["activity"]

            if self.live_context_ok():
                self.logger.info(
                    "[CHECK] @%s | LIVE via selected exact user | continue normal workflow",
                    self.live_username,
                )
                return "LIVE"

            hierarchy = self._dump_hierarchy("classify top Users report destination")
            self._raise_if_live_ended_during_workflow(
                hierarchy, context="destination classification"
            )

            if verification_overlay_present(hierarchy):
                if overlay_closed:
                    raise DestinationUnknownError(
                        "VERIFY_OVERLAY_STILL_PRESENT: verification returned during destination classification"
                    )
                self.handle_optional_verification_overlay()
                overlay_closed = True
                continue

            if self.recover_known_blocking_state(
                hierarchy, context="report destination classification"
            ):
                continue

            is_profile, evidence = target_profile_semantic_evidence(
                hierarchy, self.live_username
            )
            last_profile_evidence = evidence
            profile_activity_exact = bool(
                self.normal_profile_context_ok(last_activity) and evidence.get("exact_username")
            )
            if is_profile or profile_activity_exact:
                if getattr(self, "top_user_click_source", "hierarchy") != "hierarchy":
                    raise DestinationUnknownError(
                        "TARGET_PROFILE_AFTER_UNVERIFIED_CLICK: exact profile opened after a "
                        "layout-only/non-hierarchy result click; not strong enough for global LIVE-ended evidence"
                    )
                if self.enter_live_from_exact_profile(hierarchy):
                    return "LIVE"
                raise DestinationUnknownError(
                    f"REPORT_DESTINATION_NOT_LIVE: exact target profile @{self.live_username} "
                    "opened without a usable active LIVE entry after the initial LIVE precheck"
                )

            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"DESTINATION_BLOCKED: {reason}")
            self._bounded_poll_sleep(poll, deadline)

        raise DestinationUnknownError(
            "DESTINATION_CLASSIFICATION_TIMEOUT: selected exact user did not reach active LIVE, "
            "the exact target profile, or an explicit LIVE-ended screen before deadline; "
            f"activity={last_activity or '-'}; profile_evidence={last_profile_evidence}"
        )

    def navigate_top_user_for_report(self) -> str:
        """Search Users, open the exact requested user, then continue into reporting."""
        self.live_identity_verified = False
        self.live_profile_sheet_ready = False
        self.launch_tiktok_normally()
        self.open_users_search()
        self.open_top_user_avatar_for_precheck()
        return self.classify_top_user_report_destination()

    def navigate_via_search(self) -> str:
        """Complete TikTok Search navigation for the active workflow mode."""
        if self.workflow_mode == "live_precheck":
            return self.navigate_top_user_for_precheck()
        return self.navigate_top_user_for_report()

    def verify_live_broadcaster(self, *, require_report_ready: bool) -> None:
        """Verify exact LIVE identity; fallback navigation never bypasses this."""
        assert self.device is not None
        self.set_stage(
            "IDENTITY_VERIFICATION",
            "Verify exact LIVE broadcaster identity",
        )
        if not self.live_context_ok():
            raise DestinationUnknownError("DESTINATION_UNKNOWN: LIVE context was lost")
        initial_hierarchy = self._dump_hierarchy("verify LIVE broadcaster")
        reason = blocking_destination_reason(initial_hierarchy)
        if reason:
            raise DestinationUnknownError(f"DESTINATION_UNKNOWN: {reason}")
        selector_config = dict(self.config["selectors"]["host_profile"])
        target, located = self.locate_unique(
            action="Verify Search-opened LIVE broadcaster identity",
            selector_config=selector_config,
            timeout=self._bounded_stage_timeout(
                float(selector_config.get("timeout_seconds", 4))
            ),
        )
        self._click_once(target, "IDENTITY_PROFILE_CLICK_FAILED")

        deadline = time.monotonic() + self._bounded_stage_timeout(
            float(self.config.get("live_identity_timeout_seconds", 4))
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        candidates: list[str] = []
        report_ready = False
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy("read LIVE profile identity")
            candidates = profile_sheet_usernames_from_hierarchy(hierarchy)
            report_ready = (
                self.selector_exists("report_button", timeout=0.1)
                if require_report_ready
                else False
            )
            if candidates and (report_ready or not require_report_ready):
                break
            self._bounded_poll_sleep(poll, deadline)

        self._raise_if_live_precheck_expired()

        exact = (
            len(candidates) == 1
            and normalize_identity(candidates[0]) == normalize_identity(self.live_username)
        )
        if not exact:
            raise DestinationUnknownError(
                "IDENTITY_MISMATCH: "
                f"expected=@{self.live_username}, observed={candidates}"
            )
        if require_report_ready and not report_ready:
            raise WorkflowError(
                "REPORT_BUTTON_TIMEOUT: exact broadcaster profile did not expose Report"
            )
        self.remember_broadcaster_identity(located)
        self.live_identity_verified = True
        self.live_profile_sheet_ready = bool(report_ready)

    def dismiss_optional_live_policy_popup(self) -> None:
        """Dismiss the observed TikTok policy-update modal once, if present."""
        assert self.device is not None
        hierarchy = self._dump_hierarchy("check LIVE policy update popup")
        folded = unicodedata.normalize("NFKC", hierarchy or "").casefold()
        if "virtual items and rewards policies update" not in folded:
            return

        try:
            target = self.device(text="Got it", className="android.widget.Button")
            if int(target.count) != 1:
                raise WorkflowError(
                    "LIVE_POLICY_POPUP_DISMISS_FAILED: expected one visible 'Got it' button"
                )
            info = target.info
            if info.get("enabled") is False or parse_bounds(
                info.get("visibleBounds") or info.get("bounds")
            ) is None:
                raise WorkflowError(
                    "LIVE_POLICY_POPUP_DISMISS_FAILED: 'Got it' button is not usable"
                )
            target.click()
        except WorkflowError:
            raise
        except Exception as exc:
            raise WorkflowError(
                f"LIVE_POLICY_POPUP_DISMISS_FAILED: {type(exc).__name__}: {exc}"
            ) from exc

        deadline = time.monotonic() + 2.0
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            current = self._dump_hierarchy("confirm LIVE policy popup dismissed")
            if "virtual items and rewards policies update" not in unicodedata.normalize(
                "NFKC", current or ""
            ).casefold():
                self.logger.info(
                    "[LIVE] @%s | policy update popup dismissed", self.live_username
                )
                return
            time.sleep(poll)
        raise WorkflowError(
            "LIVE_POLICY_POPUP_DISMISS_FAILED: policy popup remained after one click"
        )

    def _structural_live_host_target(self, hierarchy: str) -> tuple[Any, dict[str, Any]] | None:
        """Resolve the broadcaster header from current LIVE structure, never fixed coordinates."""
        assert self.device is not None
        evidence = live_host_control_from_hierarchy(hierarchy)
        if evidence is None:
            return None
        class_name = normalize(evidence.get("class_name")) or "android.widget.Button"
        resource_id = normalize(evidence.get("resource_id"))
        description = normalize(evidence.get("description"))
        text = normalize(evidence.get("text"))
        lookups: list[dict[str, Any]] = []
        if resource_id:
            lookups.append({"resourceId": resource_id, "className": class_name, "clickable": True})
        if description:
            lookups.append({"description": description, "className": class_name, "clickable": True})
        if text:
            lookups.append({"text": text, "className": class_name, "clickable": True})
        for values in lookups:
            try:
                target = self.device(**values)
                if int(target.count) != 1:
                    continue
                info = target.info
                if info.get("enabled") is False:
                    continue
                if parse_bounds(info.get("visibleBounds") or info.get("bounds")) is None:
                    continue
                return target, evidence
            except Exception:
                continue
        return None

    def open_live_report_sheet(self) -> None:
        """Reach Report through one bounded state-aware LIVE handoff loop."""
        if not self.live_context_ok():
            hierarchy = self._dump_hierarchy("classify lost LIVE context before Report")
            self._raise_if_live_ended_during_workflow(
                hierarchy, context="LIVE-to-Report handoff"
            )
            raise DestinationUnknownError(
                "LIVE_CONTEXT_LOST: TikTok left LivePlayActivity before opening Report"
            )

        self.set_stage(
            "LIVE_REPORT_HANDOFF",
            "Prepare active LIVE broadcaster sheet for normal report workflow",
        )
        self.dismiss_optional_live_policy_popup()

        host_config = dict(self.config["selectors"]["host_profile"])
        total_timeout = self._bounded_stage_timeout(
            float(host_config.get("timeout_seconds", 4))
            + float(self.config.get("live_identity_timeout_seconds", 4))
        )
        deadline = time.monotonic() + total_timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        host_clicked = False
        host_reresolve_used = False
        overlay_closed = False
        wrong_panel_recovery_used = False

        while time.monotonic() < deadline:
            if self.selector_exists("report_button", timeout=min(0.12, max(0.02, deadline - time.monotonic()))):
                self.live_profile_sheet_ready = True
                self.logger.info(
                    "[LIVE] @%s | broadcaster sheet ready for Report",
                    self.live_username,
                )
                return

            hierarchy = self._dump_hierarchy("state-aware LIVE Report handoff")
            self._raise_if_live_ended_during_workflow(
                hierarchy, context="LIVE-to-Report handoff"
            )

            if unexpected_live_sheet_present(hierarchy):
                if wrong_panel_recovery_used:
                    raise WorkflowError(
                        "BROADCASTER_SHEET_WRONG_DESTINATION: TikTok reopened the unexpected chat/group sheet after one bounded recovery"
                    )
                wrong_panel_recovery_used = True
                try:
                    back_result = self.adb(
                        "shell", "input", "keyevent", "KEYCODE_BACK",
                        timeout=max(1, int(float(self.config.get("adb_keyevent_timeout_seconds", 8)))),
                    )
                except WorkflowError as exc:
                    raise WorkflowError(
                        f"BROADCASTER_SHEET_WRONG_DESTINATION: unexpected chat/group sheet could not be closed: {exc}"
                    ) from exc
                if back_result.returncode != 0:
                    raise WorkflowError(
                        "BROADCASTER_SHEET_WRONG_DESTINATION: ADB Back returned non-zero while closing unexpected chat/group sheet"
                    )
                host_clicked = False
                self.logger.warning(
                    "[LIVE] @%s | unexpected chat/group sheet closed once; re-resolving broadcaster header",
                    self.live_username,
                )
                continue

            if verification_overlay_present(hierarchy):
                if not overlay_closed:
                    self.handle_optional_verification_overlay()
                    overlay_closed = True
                    continue
                raise WorkflowError(
                    "VERIFY_OVERLAY_STILL_PRESENT: verification returned during LIVE handoff"
                )

            if self.recover_known_blocking_state(
                hierarchy, context="LIVE Report handoff"
            ):
                continue

            if not host_clicked:
                structural = self._structural_live_host_target(hierarchy)
                if structural is not None:
                    target, evidence = structural
                    self.logger.info(
                        "[LIVE] @%s | structural broadcaster header | id=%s | desc=%r | bounds=%s",
                        self.live_username,
                        normalize(evidence.get("resource_id")) or "-",
                        normalize(evidence.get("description")),
                        evidence.get("bounds"),
                    )
                    try:
                        self._click_once(target, "LIVE_PROFILE_CLICK_FAILED")
                    except DestinationUnknownError:
                        # TikTok can redraw the header between hierarchy resolve
                        # and click dispatch. Re-resolve once only when the first
                        # UiObject vanished before the click could be delivered.
                        if host_reresolve_used:
                            raise
                        host_reresolve_used = True
                        fresh_hierarchy = self._dump_hierarchy(
                            "re-resolve stale LIVE broadcaster header"
                        )
                        fresh_structural = self._structural_live_host_target(
                            fresh_hierarchy
                        )
                        if fresh_structural is None:
                            raise
                        target, evidence = fresh_structural
                        self._click_once(target, "LIVE_PROFILE_CLICK_FAILED")
                        self.logger.info(
                            "[LIVE] @%s | stale broadcaster UiObject re-resolved once",
                            self.live_username,
                        )
                    host_clicked = True
                    continue

                if self.selector_exists(
                    "host_profile", timeout=min(0.12, max(0.02, deadline - time.monotonic()))
                ):
                    remaining = max(0.05, deadline - time.monotonic())
                    try:
                        target, _located = self.locate_unique(
                            action="Open LIVE broadcaster profile sheet for Report",
                            selector_config=host_config,
                            timeout=min(0.35, remaining),
                        )
                    except WorkflowError:
                        target = None
                    if target is not None:
                        self._click_once(target, "LIVE_PROFILE_CLICK_FAILED")
                        host_clicked = True
                        continue

            self._bounded_poll_sleep(poll, deadline)

        # Final state observation catches controls that appear exactly at the
        # edge of the handoff deadline.
        hierarchy = self._dump_hierarchy("final LIVE Report handoff state")
        self._raise_if_live_ended_during_workflow(
            hierarchy, context="LIVE-to-Report handoff"
        )
        if self._selector_visible_with_hierarchy_fallback(
            "report_button", timeout=0.05, hierarchy=hierarchy
        ):
            self.live_profile_sheet_ready = True
            self.logger.info(
                "[LIVE] @%s | broadcaster sheet ready for Report at final state check",
                self.live_username,
            )
            return

        # If the broadcaster header itself appeared only at the deadline and we
        # have not clicked it yet, dispatch that one intended click and give the
        # sheet a short bounded grace window. This is not a repeated action.
        if not host_clicked:
            structural = self._structural_live_host_target(hierarchy)
            if structural is not None:
                target, evidence = structural
                self._click_once(target, "LIVE_PROFILE_CLICK_FAILED")
                host_clicked = True
                self.logger.info(
                    "[LIVE] @%s | broadcaster header appeared at deadline | one final click | bounds=%s",
                    self.live_username,
                    evidence.get("bounds"),
                )
                grace = max(
                    0.1,
                    float(self.config.get("live_handoff_final_grace_seconds", 2.0)),
                )
                grace_deadline = time.monotonic() + grace
                while time.monotonic() < grace_deadline:
                    if self.selector_exists(
                        "report_button",
                        timeout=min(0.12, max(0.02, grace_deadline - time.monotonic())),
                    ):
                        self.live_profile_sheet_ready = True
                        self.logger.info(
                            "[LIVE] @%s | Report ready during final handoff grace",
                            self.live_username,
                        )
                        return
                    grace_hierarchy = self._dump_hierarchy(
                        "final LIVE Report handoff grace"
                    )
                    self._raise_if_live_ended_during_workflow(
                        grace_hierarchy, context="final LIVE-to-Report grace"
                    )
                    if verification_overlay_present(grace_hierarchy):
                        self.handle_optional_verification_overlay()
                        continue
                    if self.recover_known_blocking_state(
                        grace_hierarchy, context="final LIVE Report handoff grace"
                    ):
                        continue
                    self._bounded_poll_sleep(poll, grace_deadline)

        final_app = self.current_app()
        self.save_state("error_live_report_handoff")
        if not self.live_context_ok():
            final_hierarchy = self._dump_hierarchy("classify final lost LIVE context")
            self._raise_if_live_ended_during_workflow(
                final_hierarchy, context="LIVE-to-Report handoff"
            )
            raise DestinationUnknownError(
                "LIVE_CONTEXT_LOST: TikTok left the active LIVE before Report became usable; "
                f"activity={final_app.get('activity', '-') or '-'}"
            )
        if not host_clicked:
            raise WorkflowError(
                "SELECTOR_TIMEOUT: LIVE broadcaster control did not become usable before the bounded handoff deadline"
            )
        raise WorkflowError(
            "REPORT_BUTTON_TIMEOUT: active LIVE broadcaster sheet did not expose Report"
        )

    def handle_optional_verification_overlay(self) -> None:
        """Dismiss one recognized TikTok verification overlay, without solving it."""
        assert self.device is not None
        hierarchy = self._dump_hierarchy("check optional verification overlay")
        if not verification_overlay_present(hierarchy):
            self.logger.info(
                "[VERIFY] @%s | no overlay | continuing workflow", self.live_username
            )
            return
        close_config = self.config["selectors"]["verification_close"]
        try:
            close_target, _located = self.locate_unique(
                action="Close TikTok verification overlay",
                selector_config=close_config,
                timeout=float(close_config.get("timeout_seconds", 2)),
            )
        except WorkflowError as exc:
            raise WorkflowError("VERIFY_OVERLAY_CLOSE_NOT_FOUND: " + str(exc)) from exc
        try:
            close_target.click()
        except Exception as exc:
            raise WorkflowError(
                f"VERIFY_OVERLAY_CLOSE_FAILED: {type(exc).__name__}: {exc}"
            ) from exc
        deadline = time.monotonic() + max(
            0.1, float(close_config.get("after_timeout_seconds", 3))
        )
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            try:
                current = self.device.dump_hierarchy(compressed=False)
            except Exception as exc:
                raise WorkflowError(
                    f"VERIFY_OVERLAY_STATE_UNKNOWN: {type(exc).__name__}: {exc}"
                ) from exc
            if not verification_overlay_present(current):
                self.logger.info(
                    "[VERIFY] @%s | overlay closed | continuing workflow",
                    self.live_username,
                )
                return
            time.sleep(poll)
        raise WorkflowError("VERIFY_OVERLAY_STILL_PRESENT: Close was clicked once")

    def handle_tiktok_location_permission_dialog(self, hierarchy: str) -> bool:
        """Deny TikTok location once when Android permission UI blocks launch.

        Location is not required by this workflow, and denying it avoids exposing
        device GPS location that could conflict with the configured network path.
        Other permission types are intentionally left untouched.
        """
        if not tiktok_location_permission_dialog_present(hierarchy):
            return False
        assert self.device is not None
        candidates = (
            {"resourceId": "com.android.permissioncontroller:id/permission_deny_button"},
            {"resourceId": "com.google.android.permissioncontroller:id/permission_deny_button"},
            {"resourceId": "com.android.packageinstaller:id/permission_deny_button"},
            {"text": "Don't allow"},
            {"text": "Don’t allow"},
            {"text": "Deny"},
            {"text": "Jangan izinkan"},
            {"text": "Tolak"},
        )
        target = None
        for values in candidates:
            try:
                candidate = self.device(**values)
                if int(candidate.count) == 1:
                    target = candidate
                    break
            except Exception:
                continue
        if target is None:
            raise DestinationUnknownError(
                "TIKTOK_LOCATION_PERMISSION_CONTROL_MISSING: Android showed TikTok location permission but no deterministic Deny control was usable"
            )
        self._click_once(target, "TIKTOK_LOCATION_PERMISSION_DENY_FAILED")
        self.logger.info(
            "[RECOVERY] TikTok location permission denied once so launch can continue"
        )
        return True

    def recover_known_blocking_state(self, hierarchy: str, *, context: str) -> bool:
        """Recover one explicit TikTok/system interruption without replaying workflow actions.

        Only states positively observed in diagnostics are handled: the TikTok
        network Retry screen and Android's TikTok ANR dialog. Each recovery is
        allowed once per worker. Returning True means one recovery action was
        dispatched and the caller should re-observe its current state.
        """
        assert self.device is not None

        if tiktok_location_permission_dialog_present(hierarchy):
            if getattr(self, "_location_permission_handled", False):
                raise DestinationUnknownError(
                    f"TIKTOK_LOCATION_PERMISSION_PERSISTENT: location permission returned during {context}"
                )
            self.handle_tiktok_location_permission_dialog(hierarchy)
            self._location_permission_handled = True
            return True

        if tiktok_network_retry_present(hierarchy):
            if getattr(self, "_network_retry_used", False):
                raise DestinationUnknownError(
                    f"TIKTOK_NETWORK_RETRY_PERSISTENT: explicit Retry screen remained during {context}"
                )
            self._network_retry_used = True
            target = None
            for values in (
                {"text": "Retry", "clickable": True},
                {"description": "Retry", "clickable": True},
                {"text": "Coba lagi", "clickable": True},
                {"description": "Coba lagi", "clickable": True},
            ):
                try:
                    candidate = self.device(**values)
                    if int(candidate.count) == 1:
                        target = candidate
                        break
                except Exception:
                    continue
            if target is None:
                raise DestinationUnknownError(
                    f"TIKTOK_NETWORK_RETRY_CONTROL_MISSING: explicit network error had no usable Retry control during {context}"
                )
            self._click_once(target, "TIKTOK_NETWORK_RETRY_CLICK_FAILED")
            self.logger.info("[RECOVERY] TikTok network Retry clicked once | context=%s", context)
            return True

        if tiktok_anr_present(hierarchy):
            if getattr(self, "_anr_wait_used", False):
                raise DestinationUnknownError(
                    f"TIKTOK_ANR_PERSISTENT: Android ANR dialog returned during {context}"
                )
            self._anr_wait_used = True
            target = None
            for values in (
                {"text": "Wait", "clickable": True},
                {"description": "Wait", "clickable": True},
                {"text": "Tunggu", "clickable": True},
                {"description": "Tunggu", "clickable": True},
            ):
                try:
                    candidate = self.device(**values)
                    if int(candidate.count) == 1:
                        target = candidate
                        break
                except Exception:
                    continue
            if target is None:
                raise DestinationUnknownError(
                    f"TIKTOK_ANR_WAIT_CONTROL_MISSING: Android ANR dialog had no usable Wait control during {context}"
                )
            self._click_once(target, "TIKTOK_ANR_WAIT_CLICK_FAILED")
            self.logger.info("[RECOVERY] Android TikTok ANR Wait clicked once | context=%s", context)
            return True

        return False

    def selector_specs(
        self,
        selector_config: dict[str, Any],
    ) -> list[SelectorSpec]:
        specs = []

        resource_id = normalize(
            selector_config.get("resource_id")
        )
        description = normalize(
            selector_config.get("description")
        )
        text = normalize(
            selector_config.get("text")
        )
        class_name = normalize(
            selector_config.get("class_name")
        )

        if resource_id and description:
            specs.append(
                SelectorSpec(
                    name="resource_id+description",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "description": description,
                    },
                )
            )

        if resource_id and text:
            specs.append(
                SelectorSpec(
                    name="resource_id+text",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "text": text,
                    },
                )
            )

        if resource_id and class_name:
            specs.append(
                SelectorSpec(
                    name="resource_id+class",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "className": class_name,
                    },
                )
            )

        if resource_id:
            specs.append(
                SelectorSpec(
                    name="resource_id",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                    },
                )
            )

        if description and class_name:
            specs.append(
                SelectorSpec(
                    name="description+class",
                    method="ui-selector",
                    values={
                        "description": description,
                        "className": class_name,
                    },
                )
            )

        if text and class_name:
            specs.append(
                SelectorSpec(
                    name="text+class",
                    method="ui-selector",
                    values={
                        "text": text,
                        "className": class_name,
                    },
                )
            )

        for alternate_resource_id in selector_config.get(
            "alternate_resource_ids",
            [],
        ):
            alternate_resource_id = normalize(alternate_resource_id)
            if not alternate_resource_id:
                continue
            if class_name:
                specs.append(
                    SelectorSpec(
                        name="alternate-resource-id+class",
                        method="ui-selector",
                        values={
                            "resourceId": alternate_resource_id,
                            "className": class_name,
                        },
                    )
                )
            specs.append(
                SelectorSpec(
                    name="alternate-resource-id",
                    method="ui-selector",
                    values={"resourceId": alternate_resource_id},
                )
            )

        if selector_config.get(
            "use_live_username_as_description_contains",
            False,
        ):
            username_variants = []
            for username_variant in (
                self.live_username,
                self.live_username.upper(),
            ):
                if username_variant and username_variant not in username_variants:
                    username_variants.append(username_variant)
            for username_variant in username_variants:
                values = {"descriptionContains": username_variant}
                if class_name:
                    values["className"] = class_name
                specs.append(
                    SelectorSpec(
                        name="live-username-description-contains",
                        method="ui-selector",
                        values=values,
                    )
                )

        if selector_config.get(
            "use_live_username_as_text_contains",
            False,
        ):
            # Disabled by default in config. A broad textContains selector can
            # match comments or profile text instead of the host button.
            values = {"textContains": self.live_username}
            if class_name:
                values["className"] = class_name
            specs.append(
                SelectorSpec(
                    name="live-username-text-contains",
                    method="ui-selector",
                    values=values,
                )
            )

        if description:
            specs.append(
                SelectorSpec(
                    name="description",
                    method="ui-selector",
                    values={
                        "description": description,
                    },
                )
            )

        for alternate_description in selector_config.get(
            "alternate_descriptions",
            [],
        ):
            alternate_description = normalize(alternate_description)
            if not alternate_description:
                continue
            if class_name:
                specs.append(
                    SelectorSpec(
                        name="alternate-description+class",
                        method="ui-selector",
                        values={
                            "description": alternate_description,
                            "className": class_name,
                        },
                    )
                )
            specs.append(
                SelectorSpec(
                    name="alternate-description",
                    method="ui-selector",
                    values={"description": alternate_description},
                )
            )

        if text:
            specs.append(
                SelectorSpec(
                    name="text",
                    method="ui-selector",
                    values={
                        "text": text,
                    },
                )
            )

        for alternate in selector_config.get(
            "alternate_texts",
            [],
        ):
            alternate = normalize(alternate)
            if alternate:
                specs.append(
                    SelectorSpec(
                        name="alternate-text",
                        method="ui-selector",
                        values={"text": alternate},
                    )
                )

        if class_name and selector_config.get(
            "allow_unique_class_only",
            False,
        ):
            specs.append(
                SelectorSpec(
                    name="unique-class",
                    method="ui-selector",
                    values={"className": class_name},
                )
            )

        if selector_config.get("require_clickable", False):
            for spec in specs:
                spec.values["clickable"] = True

        return specs

    def locate_unique(
        self,
        *,
        action: str,
        selector_config: dict[str, Any],
        timeout: float,
        handle_interruptions: bool = False,
    ) -> tuple[Any, LocatedElement]:
        assert self.device is not None
        self.current_action = action

        deadline = time.monotonic() + timeout
        poll_interval = float(
            self.config.get(
                "poll_interval_seconds",
                0.4,
            )
        )
        specs = self.selector_specs(selector_config)

        if not specs:
            raise WorkflowError(
                f"{action}: konfigurasi selector kosong."
            )

        last_diagnostics = []
        while time.monotonic() < deadline:
            last_diagnostics = []

            for spec in specs:
                try:
                    target = self.device(**spec.values)
                    count = int(target.count)

                    last_diagnostics.append(
                        {
                            "selector": spec.name,
                            "values": spec.values,
                            "count": count,
                        }
                    )

                    if count != 1:
                        continue

                    info = target.info
                    bounds = parse_bounds(
                        info.get("visibleBounds")
                        or info.get("bounds")
                    )

                    if bounds is None:
                        continue

                    if info.get("enabled") is False:
                        continue

                    located = LocatedElement(
                        action=action,
                        selector=spec,
                        selector_count=count,
                        resource_id=normalize(
                            info.get("resourceName")
                        ),
                        text=normalize(
                            info.get("text")
                        ),
                        description=normalize(
                            info.get(
                                "contentDescription"
                            )
                        ),
                        class_name=normalize(
                            info.get("className")
                        ),
                        bounds=bounds,
                        clickable=bool(
                            info.get("clickable", False)
                        ),
                        enabled=bool(
                            info.get("enabled", True)
                        ),
                    )

                    self.last_selector_diagnostics = list(last_diagnostics)
                    self.last_selector_diagnostics.append(
                        {
                            "selected": spec.name,
                            "resource_id": located.resource_id,
                            "text": located.text,
                            "description": located.description,
                            "class_name": located.class_name,
                            "bounds": located.bounds,
                            "clickable": located.clickable,
                        }
                    )
                    return target, located

                except Exception as exc:
                    last_diagnostics.append(
                        {
                            "selector": spec.name,
                            "values": spec.values,
                            "error": str(exc),
                        }
                    )

            for container_resource_id in selector_config.get(
                "clickable_child_of_resource_ids",
                [],
            ):
                container_resource_id = normalize(container_resource_id)
                if not container_resource_id:
                    continue
                try:
                    container = self.device(
                        resourceId=container_resource_id
                    )
                    container_count = int(container.count)
                    last_diagnostics.append(
                        {
                            "selector": "clickable-child-container",
                            "values": {"resourceId": container_resource_id},
                            "container_count": container_count,
                        }
                    )
                    if container_count != 1:
                        continue
                    child_values = {}
                    configured_class = normalize(
                        selector_config.get("class_name")
                    )
                    if configured_class:
                        child_values["className"] = configured_class
                    child_values["clickable"] = True
                    child_values["enabled"] = True
                    target = container.child(**child_values)
                    count = int(target.count)
                    last_diagnostics[-1]["child_count"] = count
                    if count != 1:
                        continue
                    info = target.info
                    bounds = parse_bounds(
                        info.get("visibleBounds") or info.get("bounds")
                    )
                    if bounds is None or info.get("enabled") is False:
                        continue
                    located = LocatedElement(
                        action=action,
                        selector=SelectorSpec(
                            name="clickable-child-of-container",
                            method="ui-selector-child",
                            values={
                                "containerResourceId": container_resource_id,
                                **child_values,
                            },
                        ),
                        selector_count=count,
                        resource_id=normalize(info.get("resourceName")),
                        text=normalize(info.get("text")),
                        description=normalize(
                            info.get("contentDescription")
                        ),
                        class_name=normalize(info.get("className")),
                        bounds=bounds,
                        clickable=bool(info.get("clickable", False)),
                        enabled=bool(info.get("enabled", True)),
                    )
                    if not located.clickable:
                        continue
                    self.last_selector_diagnostics = list(last_diagnostics)
                    self.last_selector_diagnostics.append(
                        {
                            "selected": located.selector.name,
                            "resource_id": located.resource_id,
                            "description": located.description,
                            "bounds": located.bounds,
                        }
                    )
                    return target, located
                except Exception as exc:
                    last_diagnostics.append(
                        {
                            "selector": "clickable-child-container",
                            "values": {"resourceId": container_resource_id},
                            "error": str(exc),
                        }
                    )

            if handle_interruptions:
                try:
                    hierarchy = self._dump_hierarchy(
                        f"state while locating {action}"
                    )
                except DestinationUnknownError:
                    hierarchy = ""
                if hierarchy:
                    if self.current_stage in {
                        "DESTINATION_CLASSIFICATION",
                        "PROFILE_LIVE_ENTRY",
                        "PROXY_PATH_VERIFY",
                        "LIVE_REPORT_HANDOFF",
                        "REPORT_MENU",
                        "REPORT_REASON",
                        "REPORT_SUBREASON",
                        "SUBMIT",
                    }:
                        self._raise_if_live_ended_during_workflow(
                            hierarchy, context=f"locating {action}"
                        )
                    if verification_overlay_present(hierarchy):
                        self.handle_optional_verification_overlay()
                        continue
                    if self.recover_known_blocking_state(
                        hierarchy, context=f"locating {action}"
                    ):
                        continue

            self._bounded_poll_sleep(poll_interval, deadline)

        self.last_selector_diagnostics = list(last_diagnostics)
        self._raise_if_live_precheck_expired()

        if action == "Buka profil host LIVE":
            unavailable = self.live_unavailable_reason()
            if unavailable:
                raise LiveUnavailableError(
                    f"{unavailable}: {self.live_url}"
                )

        self.save_state(
            "error_"
            + safe_name(action)
        )

        if self.diagnostics_enabled:
            (self.run_dir / (
                "error_"
                + safe_name(action)
                + "_selectors.json"
            )).write_text(
                json.dumps(
                    last_diagnostics,
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )

        observed_counts: list[int] = []
        for item in last_diagnostics:
            for key in ("count", "child_count", "container_count"):
                value = item.get(key)
                if isinstance(value, int):
                    observed_counts.append(value)

        ambiguous_counts = [value for value in observed_counts if value > 1]
        if ambiguous_counts:
            self.last_selector_failure_kind = "ambiguous"
            maximum = max(ambiguous_counts)
            raise WorkflowError(
                f"{action}: selector ambigu ({maximum} kandidat cocok); "
                "tidak aman memilih salah satu secara acak. "
                "Tidak ada koordinat fallback."
            )

        self.last_selector_failure_kind = "missing"
        raise WorkflowError(
            f"{action}: selector tidak ditemukan (0 kandidat cocok) "
            "sebelum timeout. Tidak ada koordinat fallback."
        )


    def remember_broadcaster_identity(self, located: LocatedElement) -> None:
        """Store passive identity candidates for the commented history check."""
        raw_values = [
            self.live_username,
            "@" + self.live_username,
            located.text,
            located.description,
        ]
        for raw in raw_values:
            value = normalize(raw)
            if not value:
                continue
            candidates = [value]
            # TikTok accessibility descriptions often append follower counts,
            # for example: "Display name,23.5K". Keep both forms.
            stripped = re.sub(
                r",\s*[0-9][0-9.,]*\s*[KMBkmb]?$",
                "",
                value,
            ).strip()
            if stripped and stripped != value:
                candidates.append(stripped)
            for candidate in candidates:
                normalized = normalize_identity(candidate)
                if len(normalized) < 3:
                    continue
                if normalized not in self.broadcaster_identity_candidates:
                    self.broadcaster_identity_candidates.append(normalized)
        self.logger.info(
            "BROADCASTER IDENTITY | candidates=%s",
            json.dumps(self.broadcaster_identity_candidates, ensure_ascii=False),
        )

    def _selector_visible_with_hierarchy_fallback(
        self, selector_key: str, *, timeout: float = 0.1, hierarchy: str | None = None
    ) -> bool:
        if self.exact_text_exists(selector_key, timeout=timeout):
            return True
        if self.selector_exists(selector_key, timeout=timeout):
            return True
        if hierarchy is None:
            try:
                hierarchy = self._dump_hierarchy(f"verify visible {selector_key}")
            except DestinationUnknownError:
                return False
        return configured_text_visible_in_hierarchy(
            hierarchy, self.config["selectors"][selector_key]
        )

    def report_reason_screen_ready(self) -> bool:
        try:
            hierarchy = self._dump_hierarchy("verify report reason screen")
        except DestinationUnknownError:
            hierarchy = ""
        return (
            self._selector_visible_with_hierarchy_fallback(
                "select_reason_title", timeout=0.05, hierarchy=hierarchy
            )
            or self._selector_visible_with_hierarchy_fallback(
                "report_reason", timeout=0.05, hierarchy=hierarchy
            )
        )

    def _postcondition_visible_in_hierarchy(
        self, selector_key: str, hierarchy: str
    ) -> bool:
        """Evaluate the transition using the hierarchy already captured.

        This prevents a false failure when TikTok renders the next screen at the
        exact deadline and the diagnostic XML already proves the transition.
        """
        if not hierarchy:
            return False
        if selector_key == "report_button":
            return configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["select_reason_title"]
            ) or configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["report_reason"]
            )
        if selector_key == "report_reason":
            if "report_subreason" in self.config["selectors"]:
                return configured_text_visible_in_hierarchy(
                    hierarchy, self.config["selectors"]["report_subreason"]
                )
            return configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["report_description_title"]
            ) or configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["submit_button"]
            )
        if selector_key == "report_subreason":
            return configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["report_description_title"]
            ) or configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["submit_button"]
            )
        if selector_key == "submit_button":
            return configured_text_visible_in_hierarchy(
                hierarchy, self.config["selectors"]["thanks_title"]
            )
        return False

    @staticmethod
    def _configured_values(selector_config: dict[str, Any]) -> set[str]:
        values: set[str] = set()
        for key in ("text", "description"):
            value = normalize(selector_config.get(key)).casefold()
            if value:
                values.add(value)
        for key in ("alternate_texts", "alternate_descriptions"):
            for raw in selector_config.get(key, []):
                value = normalize(raw).casefold()
                if value:
                    values.add(value)
        return values

    def _visible_configured_node(
        self, hierarchy: str, selector_key: str
    ) -> dict[str, Any] | None:
        """Return one usable exact text/description match from a fresh XML dump."""
        accepted = self._configured_values(self.config["selectors"][selector_key])
        if not accepted or not hierarchy:
            return None
        try:
            root = ET.fromstring(hierarchy)
        except ET.ParseError:
            return None
        for node in root.iter("node"):
            if normalize(node.attrib.get("visible-to-user", "true")).casefold() == "false":
                continue
            text = normalize(node.attrib.get("text", ""))
            description = normalize(node.attrib.get("content-desc", ""))
            if text.casefold() not in accepted and description.casefold() not in accepted:
                continue
            bounds = parse_bounds(node.attrib.get("bounds"))
            if bounds is None or bounds[2] <= bounds[0] or bounds[3] <= bounds[1]:
                continue
            return {
                "text": text,
                "description": description,
                "bounds": bounds,
            }
        return None

    def _submission_confirmation(
        self, hierarchy: str
    ) -> dict[str, Any] | None:
        thanks = self._visible_configured_node(hierarchy, "thanks_title")
        if thanks is None:
            return None
        if self._visible_configured_node(hierarchy, "submit_button") is not None:
            return None
        return thanks

    def _write_submission_state(self, **updates: Any) -> None:
        """Persist a crash-readable submission journal by atomic replacement."""
        for key, value in updates.items():
            setattr(self, key, value)
        payload = {
            "timestamp": datetime.now().isoformat(timespec="milliseconds"),
            "adb_serial": self.serial,
            "submission_state": self.submission_state,
            "submission_completed": bool(self.submit_completed),
            "submit_attempted": bool(self.submit_attempted),
            "ui_confirmation_observed": bool(self.ui_confirmation_observed),
            "settlement_completed": bool(self.settlement_completed),
            "confirmation_source": self.confirmation_source,
            "backend_acceptance": self.backend_acceptance,
            "confirmation_wait_seconds": float(self.confirmation_wait_seconds),
            "settlement_seconds": float(self.settlement_seconds),
            "submit_dispatch_monotonic": float(
                getattr(self, "submit_dispatch_monotonic", 0.0)
            ),
            "submit_dispatch_epoch": float(getattr(self, "submit_dispatch_epoch", 0.0)),
            "confirmation_deadline_monotonic": float(
                getattr(self, "confirmation_deadline_monotonic", 0.0)
            ),
            "cleanup_not_before_epoch": float(
                getattr(self, "cleanup_not_before_epoch", 0.0)
            ),
            "reason": normalize(getattr(self, "submission_reason", "")),
        }
        path = self.run_dir / "submission_state.json"
        temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
        temporary.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        os.replace(temporary, path)

    def _submission_rpc_available(self) -> bool:
        return bool(
            u2_jsonrpc_call_once is not None
            and self.device is not None
            and hasattr(self.device, "_dev")
            and hasattr(self.device, "_device_server_port")
        )

    def _submission_rpc_once(
        self, method: str, params: list[Any], timeout: float
    ) -> Any:
        if not self._submission_rpc_available():
            raise WorkflowError(
                "SUBMISSION_OBSERVER_UNAVAILABLE: bounded non-retrying UI RPC adapter unavailable"
            )
        assert u2_jsonrpc_call_once is not None
        assert self.device is not None
        return u2_jsonrpc_call_once(
            self.device._dev,
            int(self.device._device_server_port),
            method,
            params,
            max(0.05, float(timeout)),
            bool(getattr(self.device, "_debug", False)),
        )

    def _observe_submission_ui(self, deadline: float) -> str:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("submission observation deadline expired")
        timeout = min(
            max(0.05, float(self.config.get("submit_rpc_timeout_seconds", 2))),
            remaining,
        )
        value = self._submission_rpc_once(
            "dumpWindowHierarchy", [False, 50], timeout
        )
        if not normalize(value):
            raise WorkflowError("SUBMISSION_OBSERVER_UNAVAILABLE: empty UI hierarchy")
        return str(value)

    def _remaining_worker_time(self) -> float | None:
        raw = self.config.get("worker_deadline_monotonic")
        if raw in (None, ""):
            return None
        try:
            return float(raw) - time.monotonic()
        except (TypeError, ValueError):
            return None

    def _settle_submission(
        self, *, confirmed: bool, reason: str, last_hierarchy: str
    ) -> bool:
        settlement_started = time.monotonic()
        settlement_seconds = max(
            0.0, float(self.config.get("post_submit_settlement_seconds", 5))
        )
        settlement_deadline = settlement_started + settlement_seconds
        reliable = True
        self.set_stage("SUBMIT_SETTLEMENT", "Hold app and proxy after Submit")
        self.logger.info(
            "SETTLEMENT_STARTED | seconds=%.1f | confirmed=%s",
            settlement_seconds,
            confirmed,
        )
        try:
            self._write_submission_state(
                submission_state="SETTLING",
                submission_reason=reason,
                settlement_seconds=settlement_seconds,
            )
        except OSError as exc:
            reliable = False
            self.logger.warning("SUBMISSION JOURNAL UPDATE FAILED | %s", exc)

        hierarchy = last_hierarchy
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < settlement_deadline:
            try:
                hierarchy = self._observe_submission_ui(settlement_deadline)
                if verification_overlay_present(hierarchy):
                    reliable = False
                    reason = "verification overlay appeared after Submit"
                elif tiktok_network_retry_present(hierarchy):
                    reliable = False
                    reason = "TikTok network Retry screen appeared after Submit"
                elif tiktok_anr_present(hierarchy):
                    reliable = False
                    reason = "TikTok ANR appeared after Submit"
                elif not confirmed and explicit_live_ended_in_hierarchy(hierarchy):
                    reason = "LIVE ended before submission acknowledgement"
            except Exception as exc:
                reliable = False
                reason = f"submission settlement observation failed: {type(exc).__name__}: {exc}"
            remaining = settlement_deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(poll, remaining))

        self.settlement_completed = True
        final_confirmed = bool(confirmed and reliable)
        self.submit_completed = final_confirmed
        final_state = "CONFIRMED" if final_confirmed else "UNCONFIRMED"
        self.submission_reason = reason
        try:
            self._write_submission_state(
                submission_state=final_state,
                submit_completed=final_confirmed,
                settlement_completed=True,
                submission_reason=reason,
            )
        except OSError as exc:
            final_confirmed = False
            self.submit_completed = False
            self.submission_state = "UNCONFIRMED"
            self.submission_reason = f"final submission journal failed: {exc}"
            self.logger.warning("SUBMISSION JOURNAL FINALIZE FAILED | %s", exc)
        self.logger.info(
            "SETTLEMENT_COMPLETED | elapsed=%.3f | reliable=%s",
            time.monotonic() - settlement_started,
            reliable,
        )
        self.logger.info(
            "SUBMISSION_RESULT | state=%s | backend_acceptance=unknown | reason=%s",
            self.submission_state,
            self.submission_reason or "none",
        )
        return final_confirmed

    def _run_submit_lifecycle(self, located: LocatedElement) -> None:
        if not self._submission_rpc_available():
            raise WorkflowError(
                "SUBMISSION_OBSERVER_UNAVAILABLE: bounded non-retrying UI RPC adapter unavailable"
            )
        remaining = self._remaining_worker_time()
        if remaining is not None and remaining < 45:
            raise WorkflowError(
                f"INSUFFICIENT_SUBMIT_BUDGET: {remaining:.3f}s remains; 45s required"
            )

        preflight_deadline = time.monotonic() + max(
            0.05, float(self.config.get("submit_rpc_timeout_seconds", 2))
        )
        preflight = self._observe_submission_ui(preflight_deadline)
        if self._visible_configured_node(preflight, "thanks_title") is not None:
            raise WorkflowError(
                "STALE_SUBMIT_CONFIRMATION: acknowledgement was visible before Submit"
            )
        if self._visible_configured_node(preflight, "submit_button") is None:
            raise WorkflowError("SUBMIT_PRECONDITION_LOST: Submit was not visible at dispatch")

        started = time.monotonic()
        started_epoch = time.time()
        after_timeout = max(
            0.1,
            float(
                self.config["selectors"]["submit_button"].get(
                    "after_timeout_seconds", 30
                )
            ),
        )
        deadline = started + after_timeout
        settlement = max(
            0.0, float(self.config.get("post_submit_settlement_seconds", 5))
        )
        self.submit_dispatch_monotonic = started
        self.submit_dispatch_epoch = started_epoch
        self.confirmation_deadline_monotonic = deadline
        self.cleanup_not_before_epoch = started_epoch + after_timeout + settlement
        self.submission_reason = ""
        self._write_submission_state(
            submission_state="SUBMIT_DISPATCHING",
            submit_attempted=True,
        )
        self.logger.info(
            "SUBMIT_DISPATCHING | attempt=1 | bounds=%s | confirmation_timeout=%.1f",
            located.bounds,
            after_timeout,
        )
        left, top, right, bottom = located.bounds
        click_error = ""
        try:
            self._submission_rpc_once(
                "click",
                [int((left + right) / 2), int((top + bottom) / 2)],
                min(
                    max(0.05, float(self.config.get("submit_rpc_timeout_seconds", 2))),
                    max(0.05, deadline - time.monotonic()),
                ),
            )
        except Exception as exc:
            click_error = f"{type(exc).__name__}: {exc}"
            self.logger.warning(
                "SUBMIT_TAPPED | RPC outcome ambiguous; observing without replay | error=%s",
                click_error,
            )
        else:
            self.logger.info("SUBMIT_TAPPED | attempt=1 | bounds=%s", located.bounds)
        try:
            self._write_submission_state(
                submission_state="WAITING_CONFIRMATION",
                submission_reason=click_error,
            )
        except OSError as exc:
            click_error = click_error or f"submission journal update failed: {exc}"
        self.logger.info("WAITING_CONFIRMATION | timeout=%.1f", after_timeout)

        confirmed = False
        confirmation_blocked = False
        last_hierarchy = preflight
        reason = click_error or "TikTok acknowledgement was not observed"
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            try:
                last_hierarchy = self._observe_submission_ui(deadline)
                marker = self._submission_confirmation(last_hierarchy)
                if marker is not None and not confirmation_blocked:
                    confirmed = True
                    self.ui_confirmation_observed = True
                    self.confirmation_source = "tiktok_ui"
                    self.confirmation_wait_seconds = time.monotonic() - started
                    self.submit_completion_detection = "thanks_title_fresh_hierarchy"
                    reason = ""
                    self.logger.info(
                        "UI_CONFIRMATION_OBSERVED | elapsed=%.3f | text=%r | desc=%r | bounds=%s",
                        self.confirmation_wait_seconds,
                        marker["text"],
                        marker["description"],
                        marker["bounds"],
                    )
                    break
                if verification_overlay_present(last_hierarchy):
                    reason = "verification overlay appeared after Submit"
                    confirmation_blocked = True
                elif tiktok_network_retry_present(last_hierarchy):
                    reason = "TikTok network Retry screen appeared after Submit"
                    confirmation_blocked = True
                elif tiktok_anr_present(last_hierarchy):
                    reason = "TikTok ANR appeared after Submit"
                    confirmation_blocked = True
                elif explicit_live_ended_in_hierarchy(last_hierarchy):
                    reason = "LIVE ended before submission acknowledgement"
                    confirmation_blocked = True
            except Exception as exc:
                reason = f"submission confirmation observation failed: {type(exc).__name__}: {exc}"
            remaining = deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(poll, remaining))

        self.confirmation_wait_seconds = max(
            self.confirmation_wait_seconds, time.monotonic() - started
        )
        self.submit_completed = self._settle_submission(
            confirmed=confirmed,
            reason=reason,
            last_hierarchy=last_hierarchy,
        )

    def click_action(
        self,
        *,
        action: str,
        selector_key: str,
        expected_before: Optional[Callable[[], bool]] = None,
        expected_after: Optional[Callable[[], bool]] = None,
    ) -> None:
        """Resolve once, click once, and enforce one bounded state-aware postcondition.

        Reporting actions are never blindly retried. Deadline-edge recovery is
        observation-only: a fresh hierarchy can confirm success, verification,
        an explicit LIVE-ended outcome, or a known TikTok/system interruption.
        """
        assert self.device is not None

        def acknowledge_submit(method: str) -> None:
            if selector_key != "submit_button":
                return
            self.submit_completion_detection = method
            self.logger.info("SUBMIT CLICK ACKNOWLEDGED | method=%s", method)

        # Verification or an explicit LIVE-ended screen can appear between any
        # two reporting stages. LIVE-ended is a local external outcome only; it
        # never suppresses or stops other workers.
        try:
            hierarchy = self._dump_hierarchy(f"check state before {action}")
        except DestinationUnknownError:
            hierarchy = ""
        self._raise_if_live_ended_during_workflow(hierarchy, context=action)
        if verification_overlay_present(hierarchy):
            self.handle_optional_verification_overlay()

        if expected_before is not None and not expected_before():
            hierarchy = self._dump_hierarchy(f"check precondition for {action}")
            self._raise_if_live_ended_during_workflow(hierarchy, context=action)
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
            if expected_before is not None and not expected_before():
                # Re-observe once after any overlay close before declaring a real
                # precondition failure. No reporting action is repeated.
                hierarchy = self._dump_hierarchy(
                    f"final precondition observation for {action}"
                )
                self._raise_if_live_ended_during_workflow(hierarchy, context=action)
                if expected_before is not None and not expected_before():
                    self.save_state("error_precondition_" + safe_name(action))
                    raise WorkflowError(f"{action}: precondition tidak terpenuhi.")

        selector_config = self.config["selectors"][selector_key]
        target, located = self.locate_unique(
            action=action,
            selector_config=selector_config,
            timeout=float(
                selector_config.get(
                    "timeout_seconds",
                    self.config.get("selector_timeout_seconds", 4),
                )
            ),
            handle_interruptions=True,
        )

        self.logger.info(
            "SELECTOR | %s | %s | id=%s | text=%r | desc=%r | bounds=%s",
            action,
            located.selector.name,
            located.resource_id,
            located.text,
            located.description,
            located.bounds,
        )
        if selector_key == "host_profile":
            self.remember_broadcaster_identity(located)

        if selector_key == "submit_button":
            self.current_action = action
            self._run_submit_lifecycle(located)
            return

        try:
            target.click()
        except Exception as exc:
            raise WorkflowError(
                f"{action}: STALE_OR_FAILED_CLICK: {type(exc).__name__}: {exc}"
            ) from exc

        self.current_action = action

        if expected_after is None:
            return

        poll_interval = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        after_timeout = max(0.1, float(selector_config.get("after_timeout_seconds", 4)))
        deadline = time.monotonic() + after_timeout
        overlay_closed = False

        def observe_postcondition(label: str) -> bool:
            nonlocal overlay_closed
            if expected_after():
                acknowledge_submit("submit_click_success_marker")
                return True
            try:
                observed = self._dump_hierarchy(label)
            except DestinationUnknownError:
                observed = ""
            if self._postcondition_visible_in_hierarchy(selector_key, observed):
                acknowledge_submit("submit_click_success_marker_hierarchy")
                return True
            # Explicit success wins even if the LIVE ends immediately afterward.
            self._raise_if_live_ended_during_workflow(observed, context=action)
            if verification_overlay_present(observed):
                if overlay_closed:
                    raise WorkflowError(
                        f"VERIFY_OVERLAY_STILL_PRESENT: verification returned during {action}"
                    )
                self.handle_optional_verification_overlay()
                overlay_closed = True
                return False
            if observed and self.recover_known_blocking_state(
                observed, context=f"postcondition for {action}"
            ):
                return False
            return False

        while time.monotonic() < deadline:
            if observe_postcondition(f"verify postcondition for {action}"):
                return
            self._bounded_poll_sleep(poll_interval, deadline)

        # Final deadline-edge observation. This has no click side effects.
        if observe_postcondition(f"final postcondition for {action}"):
            if selector_key == "submit_button":
                self.submit_completion_detection = (
                    "submit_click_success_marker_final_hierarchy"
                )
            return

        # TikTok transitions in the supplied diagnostics sometimes completed a
        # fraction after the nominal postcondition window. Give only the state
        # observation a small bounded grace; the action itself is never retried.
        grace = max(
            0.0, float(self.config.get("transition_final_grace_seconds", 1.5))
        )
        if grace > 0:
            grace_deadline = time.monotonic() + self._bounded_stage_timeout(grace)
            while time.monotonic() < grace_deadline:
                if observe_postcondition(f"deadline-edge grace for {action}"):
                    if selector_key == "submit_button":
                        self.submit_completion_detection = (
                            "submit_click_success_marker_deadline_grace"
                        )
                    return
                self._bounded_poll_sleep(poll_interval, grace_deadline)
            if observe_postcondition(f"final deadline-edge state for {action}"):
                if selector_key == "submit_button":
                    self.submit_completion_detection = (
                        "submit_click_success_marker_final_grace"
                    )
                return

        self.save_state("error_postcondition_" + safe_name(action))
        if selector_key == "submit_button":
            raise WorkflowError(
                f"{action}: SUBMIT_CLICK_NOT_ACKNOWLEDGED; no explicit success "
                "marker appeared after the one intentional Submit click."
            )
        raise WorkflowError(
            f"{action}: layar berikutnya tidak terverifikasi setelah satu klik."
        )

    def exact_text_exists(
        self,
        selector_key: str,
        timeout: float = 0.2,
    ) -> bool:
        assert self.device is not None

        selector_config = self.config[
            "selectors"
        ][selector_key]

        values = []
        primary = normalize(
            selector_config.get("text")
        )
        if primary:
            values.append(primary)

        values.extend(
            normalize(value)
            for value in selector_config.get(
                "alternate_texts",
                [],
            )
            if normalize(value)
        )

        for value in values:
            try:
                if self.device(
                    text=value
                ).exists(timeout=timeout):
                    return True
            except Exception:
                continue

        return False

    def selector_exists(
        self,
        selector_key: str,
        timeout: float = 0.3,
    ) -> bool:
        """Check every configured selector variant without clicking it."""
        assert self.device is not None
        selector_config = self.config["selectors"][selector_key]
        deadline = time.monotonic() + timeout
        specs = self.selector_specs(selector_config)
        while time.monotonic() < deadline:
            for spec in specs:
                try:
                    target = self.device(**spec.values)
                    count = int(target.count)
                    if count < 1:
                        continue
                    for index in range(min(count, 5)):
                        item = target if count == 1 else target[index]
                        info = item.info
                        if info.get("enabled") is False:
                            continue
                        if parse_bounds(
                            info.get("visibleBounds") or info.get("bounds")
                        ) is not None:
                            return True
                except Exception:
                    continue
            time.sleep(0.1)
        return False

    def classify_error(self, exc: Exception) -> tuple[str, str, str]:
        message = str(exc)
        folded = message.casefold()
        prefix = message.partition(":")[0].strip()
        embedded_codes = (
            "SUBMIT_CLICK_NOT_ACKNOWLEDGED",
            "ADB_DEVICE_OFFLINE",
            "ADB_GET_STATE_FAILED",
            "UIAUTOMATOR_CONNECTION_FAILED",
            "UIAUTOMATOR_DEVICE_LOCK_TIMEOUT",
            "UIAUTOMATOR_REGISTRATION_BUSY_UNOWNED",
            "UIAUTOMATOR_STALE_SERVICE_RESET_FAILED",
            "UIAUTOMATOR_TRANSPORT_RECOVERY_EXHAUSTED",
            "UIAUTOMATOR_TRANSPORT_REPAIR_FAILED",
            "TIKTOK_LAUNCH_FAILED",
            "TIKTOK_LAUNCH_TIMEOUT",
            "TIKTOK_UI_NOT_READY",
            "TIKTOK_LOCATION_PERMISSION_PERSISTENT",
            "TIKTOK_LOCATION_PERMISSION_CONTROL_MISSING",
            "TIKTOK_LOCATION_PERMISSION_DENY_FAILED",
            "LIVE_PRECHECK_TIMEOUT",
            "SEARCH_QUERY_FAILED",
            "SEARCH_QUERY_SUBMIT_FAILED",
            "SEARCH_QUERY_SUBMIT_TIMEOUT",
            "SEARCH_RESULTS_EMPTY",
            "SEARCH_AVATAR_CLICK_FAILED",
            "SEARCH_AVATAR_CLICK_UNACKNOWLEDGED",
            "USERS_TAB_CLICK_NOT_ACKNOWLEDGED",
            "USERS_TAB_RESELECT_FAILED",
            "USERS_RESULTS_LOAD_TIMEOUT",
            "USERS_EXACT_TARGET_NOT_FOUND",
            "DESTINATION_CLASSIFICATION_TIMEOUT",
            "DESTINATION_BLOCKED",
            "TARGET_PROFILE_AFTER_UNVERIFIED_CLICK",
            "REPORT_DESTINATION_NOT_LIVE",
            "PROFILE_LIVE_ENTRY_CLICK_FAILED",
            "PROFILE_LIVE_ENTRY_CLICK_UNACKNOWLEDGED",
            "PROFILE_LIVE_ENTRY_NOT_ACTIVE",
            "DESTINATION_UNKNOWN",
            "HIERARCHY_UNAVAILABLE",
            "IDENTITY_PROFILE_CLICK_FAILED",
            "IDENTITY_HIERARCHY_FAILED",
            "IDENTITY_MISMATCH",
            "LIVE_CONTEXT_LOST",
            "LIVE_PROFILE_CLICK_FAILED",
            "REPORT_BUTTON_TIMEOUT",
            "BROADCASTER_SHEET_WRONG_DESTINATION",
            "PROFILE_SHEET_NOT_READY",
            "VERIFY_OVERLAY_CLOSE_NOT_FOUND",
            "VERIFY_OVERLAY_CLOSE_FAILED",
            "VERIFY_OVERLAY_STILL_PRESENT",
            "VERIFY_OVERLAY_STATE_UNKNOWN",
            "TIKTOK_NETWORK_RETRY_PERSISTENT",
            "TIKTOK_NETWORK_RETRY_CONTROL_MISSING",
            "TIKTOK_NETWORK_RETRY_CLICK_FAILED",
            "TIKTOK_ANR_PERSISTENT",
            "TIKTOK_ANR_WAIT_CONTROL_MISSING",
            "TIKTOK_ANR_WAIT_CLICK_FAILED",
            "STALE_OR_FAILED_CLICK",
        )
        embedded = next((code for code in embedded_codes if code in message), "")
        internal_exception = isinstance(
            exc,
            (AttributeError, NameError, ImportError, AssertionError, TypeError),
        ) and not isinstance(exc, WorkflowError)
        if internal_exception:
            error_code = "INTERNAL_PROGRAM_ERROR"
        elif embedded:
            error_code = embedded
        elif re.fullmatch(r"[A-Z][A-Z0-9_]+", prefix):
            error_code = prefix
        elif "selector ambigu" in folded:
            error_code = "SELECTOR_AMBIGUOUS"
        elif "selector tidak ditemukan" in folded:
            error_code = "SELECTOR_TIMEOUT"
        elif "timeout" in folded:
            error_code = "TIMEOUT"
        elif "uiautomator" in folded or "jsonrpc" in folded:
            error_code = "UIAUTOMATOR_ERROR"
        elif "adb" in folded:
            error_code = "ADB_ERROR"
        else:
            error_code = "WORKFLOW_ERROR"

        cause_by_code = {
            "ADB_DEVICE_OFFLINE": "The TCP ADB device was not ready.",
            "ADB_GET_STATE_FAILED": "The one-shot ADB state check failed.",
            "UIAUTOMATOR_CONNECTION_FAILED": "The uiautomator2 connection failed before a recognized repair condition could be applied.",
            "UIAUTOMATOR_DEVICE_LOCK_TIMEOUT": "Another process held the same phone's UiAutomator start/reset lease beyond the bounded lock deadline.",
            "UIAUTOMATOR_REGISTRATION_BUSY_UNOWNED": "Android UiAutomation remained registered but no project-owned com.wetest.uia2.Main process was visible; the owner is unconfirmed and is not killed blindly.",
            "UIAUTOMATOR_STALE_SERVICE_RESET_FAILED": "A stale project-owned uiautomator2 service was targeted for reset, but Android still reported the UiAutomation registration afterward.",
            "UIAUTOMATOR_TRANSPORT_RECOVERY_EXHAUSTED": "The phone lost the UiAutomator control channel more than once in the same worker.",
            "UIAUTOMATOR_TRANSPORT_REPAIR_FAILED": "The one bounded UiAutomator control-channel repair could not restore the device connection.",
            "TIKTOK_LAUNCH_TIMEOUT": "TikTok did not reach the foreground before the bounded launch deadline.",
            "TIKTOK_UI_NOT_READY": "TikTok was foreground, but its Search/Cari UI was not usable before the bounded readiness deadline.",
            "TIKTOK_LOCATION_PERMISSION_PERSISTENT": "Android's TikTok location permission prompt remained after one deterministic Deny action.",
            "TIKTOK_LOCATION_PERMISSION_CONTROL_MISSING": "The TikTok location permission prompt was recognized but no deterministic Deny control was exposed.",
            "TIKTOK_LOCATION_PERMISSION_DENY_FAILED": "The recognized TikTok location permission Deny action could not be delivered.",
            "SEARCH_QUERY_SUBMIT_FAILED": "The exact Search query was verified, but ADB Enter returned non-zero and Search results were not observed.",
            "SEARCH_QUERY_SUBMIT_TIMEOUT": "The bounded ADB Enter command timed out and Search results were not observed afterward.",
            "SEARCH_RESULTS_EMPTY": "TikTok Users results exposed no canonical username evidence.",
            "SEARCH_AVATAR_CLICK_UNACKNOWLEDGED": "The exact-user avatar click lost the control channel and neither the destination nor the original exact row state could be confirmed afterward.",
            "USERS_TAB_CLICK_NOT_ACKNOWLEDGED": "TikTok did not switch to Users after the initial click and one verified re-selection.",
            "USERS_TAB_RESELECT_FAILED": "The one controlled Users-tab acknowledgement click could not be resolved or dispatched.",
            "USERS_RESULTS_LOAD_TIMEOUT": "Users was selected but TikTok did not expose a real result row before the bounded deadline.",
            "USERS_EXACT_TARGET_NOT_FOUND": "The exact requested username was not present in the bounded visible Users rows.",
            "DESTINATION_CLASSIFICATION_TIMEOUT": "The selected exact user did not reach LIVE, the exact target profile, or an explicit ended state before the destination deadline.",
            "DESTINATION_BLOCKED": "A recognized TikTok security/network/login state blocked destination classification.",
            "TARGET_PROFILE_AFTER_UNVERIFIED_CLICK": "The target profile appeared after a non-hierarchy click source and is not strong enough for global LIVE-ended evidence.",
            "REPORT_DESTINATION_NOT_LIVE": "The reporting worker reached the exact target profile but could not enter an active LIVE from that profile.",
            "PROFILE_LIVE_ENTRY_CLICK_FAILED": "The exact target profile exposed a header LIVE badge, but the one hierarchy-derived badge click could not be dispatched.",
            "PROFILE_LIVE_ENTRY_CLICK_UNACKNOWLEDGED": "The profile-header LIVE badge click lost the control channel and active LIVE was not confirmed afterward.",
            "PROFILE_LIVE_ENTRY_NOT_ACTIVE": "The profile-header LIVE badge path did not reach LivePlayActivity before the bounded deadline.",
            "DESTINATION_UNKNOWN": "The Search destination could not be classified safely.",
            "IDENTITY_MISMATCH": "The visible canonical broadcaster did not match the target.",
            "LIVE_CONTEXT_LOST": "TikTok left LivePlayActivity before the Report handoff completed.",
            "LIVE_PROFILE_CLICK_FAILED": "The LIVE broadcaster header was resolved, but the click could not be delivered even after one stale-object re-resolution.",
            "REPORT_BUTTON_TIMEOUT": "The active LIVE broadcaster sheet did not expose Report before the bounded deadline.",
            "BROADCASTER_SHEET_WRONG_DESTINATION": "TikTok opened an unexpected chat/group sheet from the broadcaster header and one bounded Back recovery did not restore the Report path.",
            "TIKTOK_NETWORK_RETRY_PERSISTENT": "TikTok's explicit network error returned after one bounded Retry action.",
            "TIKTOK_NETWORK_RETRY_CONTROL_MISSING": "TikTok showed an explicit network error but no usable Retry control was exposed.",
            "TIKTOK_NETWORK_RETRY_CLICK_FAILED": "TikTok showed an explicit network error, but its Retry control could not be clicked.",
            "TIKTOK_ANR_PERSISTENT": "Android's TikTok-not-responding dialog returned after one bounded Wait recovery.",
            "TIKTOK_ANR_WAIT_CONTROL_MISSING": "Android showed the TikTok-not-responding dialog but no usable Wait control was exposed.",
            "TIKTOK_ANR_WAIT_CLICK_FAILED": "Android showed the TikTok-not-responding dialog, but the Wait control could not be clicked.",
            "SUBMIT_CLICK_NOT_ACKNOWLEDGED": "Submit was clicked once but no explicit acknowledgement appeared.",
            "SELECTOR_TIMEOUT": "The required semantic selector did not appear before its short deadline.",
            "SELECTOR_AMBIGUOUS": "More than one semantic selector candidate was visible.",
            "INTERNAL_PROGRAM_ERROR": "The workflow hit a deterministic Python/programming error rather than an external phone, TikTok, ADB, or proxy condition.",
        }
        cause = cause_by_code.get(error_code, message or type(exc).__name__)
        if error_code == "INTERNAL_PROGRAM_ERROR":
            solution = (
                "Stop the watchlist loop because repeating other usernames would execute the same broken program path; inspect the traceback and fix the code before restarting."
            )
        else:
            solution = (
                "The fail-fast worker is terminal for this device and target; inspect "
                "diagnostics only when diagnostics_enabled=true."
            )
        return error_code, cause, solution

    def build_concise_error_evidence(self, error_code: str) -> str:
        current = {"package": "", "activity": ""}
        if self.device is not None:
            try:
                current = self.current_app()
            except Exception:
                pass
        counts: list[str] = []
        for item in self.last_selector_diagnostics[-12:]:
            if "count" in item:
                counts.append(
                    f"{item.get('selector', 'selector')}={item.get('count')}"
                )
        selector_counts = ",".join(counts) or "none"
        return (
            f"code={error_code}; stage={self.current_stage}; "
            f"action={self.current_action}; app={current.get('package', '')}/"
            f"{current.get('activity', '')}; selector_counts={selector_counts}; "
            f"submit_completed={self.submit_completed}"
        )

    def write_ui_identifier_inventory(
        self,
        hierarchy: str,
    ) -> tuple[Path, Path]:
        """Persist every resource ID plus target-row relationships on error."""
        text_path = self.run_dir / "error_ui_identifiers.txt"
        json_path = self.run_dir / "error_ui_identifiers.json"
        payload: dict[str, Any] = {
            "timestamp": datetime.now().isoformat(timespec="milliseconds"),
            "adb_serial": self.serial,
            "live_url": self.live_url,
            "target_username": self.live_username,
            "parse_status": "unavailable",
            "resource_ids": [],
            "target_identity_relationships": [],
            "semantic_nodes": [],
        }

        def node_record(node: ET.Element) -> dict[str, str]:
            attributes = node.attrib
            return {
                "resource_id": normalize(attributes.get("resource-id")),
                "package": normalize(attributes.get("package")),
                "class_name": normalize(attributes.get("class")),
                "text": normalize(attributes.get("text")),
                "description": normalize(attributes.get("content-desc")),
                "bounds": normalize(attributes.get("bounds")),
                "clickable": normalize(attributes.get("clickable")),
                "enabled": normalize(attributes.get("enabled")),
                "visible": normalize(attributes.get("visible-to-user")),
            }

        try:
            root = ET.fromstring(hierarchy)
            parent_map = {
                child: parent
                for parent in root.iter()
                for child in parent
            }
            resource_map: dict[str, dict[str, Any]] = {}
            relationships: list[dict[str, Any]] = []
            semantic_nodes: list[dict[str, str]] = []
            wanted_identity = normalize_identity(self.live_username)
            semantic_tokens = (
                "live", "report", "lapor", "submit", "kirim",
                "verify", "verifikasi",
            )

            for node in root.iter("node"):
                record = node_record(node)
                resource_id = record["resource_id"]
                if resource_id:
                    item = resource_map.setdefault(
                        resource_id,
                        {
                            "resource_id": resource_id,
                            "count": 0,
                            "examples": [],
                        },
                    )
                    item["count"] += 1
                    example = {
                        key: value
                        for key, value in record.items()
                        if key != "resource_id" and value
                    }
                    if example not in item["examples"] and len(
                        item["examples"]
                    ) < 4:
                        item["examples"].append(example)

                searchable = " ".join(
                    (
                        record["resource_id"],
                        record["text"],
                        record["description"],
                    )
                ).casefold()
                if any(token in searchable for token in semantic_tokens):
                    semantic_nodes.append(record)

                identity_attribute = ""
                identity_value = ""
                for attribute_name, value in (
                    ("text", record["text"]),
                    ("content-desc", record["description"]),
                ):
                    if value and normalize_identity(value) == wanted_identity:
                        identity_attribute = attribute_name
                        identity_value = value
                        break
                if not identity_attribute:
                    continue

                clickable_row = node
                while (
                    clickable_row is not None
                    and clickable_row.attrib.get("clickable", "false")
                    != "true"
                ):
                    clickable_row = parent_map.get(clickable_row)

                ancestor_chain: list[dict[str, str]] = []
                ancestor = node
                while ancestor is not None and len(ancestor_chain) < 10:
                    if ancestor.tag == "node":
                        ancestor_chain.append(node_record(ancestor))
                    ancestor = parent_map.get(ancestor)

                row_context: list[dict[str, str]] = []
                if clickable_row is not None:
                    for related in clickable_row.iter("node"):
                        related_record = node_record(related)
                        if not (
                            related_record["resource_id"]
                            or related_record["text"]
                            or related_record["description"]
                        ):
                            continue
                        row_context.append(related_record)
                        if len(row_context) >= 80:
                            break

                relationships.append(
                    {
                        "identity_attribute": identity_attribute,
                        "identity_value": identity_value,
                        "identity_node": record,
                        "nearest_clickable_row": (
                            node_record(clickable_row)
                            if clickable_row is not None
                            else None
                        ),
                        "ancestor_chain": ancestor_chain,
                        "row_context": row_context,
                    }
                )

            payload["parse_status"] = "ok"
            payload["resource_ids"] = sorted(
                resource_map.values(),
                key=lambda item: item["resource_id"],
            )
            payload["target_identity_relationships"] = relationships
            payload["semantic_nodes"] = semantic_nodes[:300]
            payload["resource_id_count"] = len(resource_map)
            payload["target_relationship_count"] = len(relationships)
        except Exception as exc:
            payload["parse_status"] = f"failed: {exc}"

        text_lines = [
            "ERROR UI IDENTIFIER INVENTORY",
            "=" * 72,
            f"timestamp: {payload['timestamp']}",
            f"device: {self.serial}",
            f"live: @{self.live_username}",
            f"parse_status: {payload['parse_status']}",
            f"resource_id_count: {payload.get('resource_id_count', 0)}",
            f"target_relationship_count: "
            f"{payload.get('target_relationship_count', 0)}",
            "",
            "TARGET IDENTITY RELATIONSHIPS",
        ]
        relationships = payload["target_identity_relationships"]
        if not relationships:
            text_lines.append("none found")
        for index, relationship in enumerate(relationships, start=1):
            identity = relationship["identity_node"]
            row = relationship["nearest_clickable_row"] or {}
            text_lines.extend(
                [
                    f"[{index}] identity={relationship['identity_value']!r}",
                    f"    identity_id={identity.get('resource_id', '')}",
                    f"    identity_class={identity.get('class_name', '')}",
                    f"    identity_bounds={identity.get('bounds', '')}",
                    f"    clickable_row_id={row.get('resource_id', '')}",
                    f"    clickable_row_class={row.get('class_name', '')}",
                    f"    clickable_row_bounds={row.get('bounds', '')}",
                    "    row_context:",
                ]
            )
            for related in relationship["row_context"]:
                text_lines.append(
                    "      - "
                    f"id={related.get('resource_id', '')} | "
                    f"class={related.get('class_name', '')} | "
                    f"text={related.get('text', '')!r} | "
                    f"desc={related.get('description', '')!r} | "
                    f"clickable={related.get('clickable', '')}"
                )

        text_lines.extend(["", "ALL RESOURCE IDS"])
        resource_ids = payload["resource_ids"]
        if not resource_ids:
            text_lines.append("none available")
        for item in resource_ids:
            examples = item.get("examples", [])
            example = examples[0] if examples else {}
            text_lines.append(
                f"{item['resource_id']} | count={item['count']} | "
                f"class={example.get('class_name', '')} | "
                f"text={example.get('text', '')!r} | "
                f"desc={example.get('description', '')!r} | "
                f"clickable={example.get('clickable', '')}"
            )

        try:
            text_path.write_text(
                "\n".join(text_lines) + "\n",
                encoding="utf-8",
            )
            json_path.write_text(
                json.dumps(payload, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as exc:
            self.logger.warning(
                "Could not write UI identifier inventory: %s",
                exc,
            )
        return text_path, json_path

    def write_error_report(
        self,
        exc: Exception,
        error_code: str,
        likely_cause: str,
        suggested_solution: str,
    ) -> Path:
        current_app = {"package": "", "activity": ""}
        if self.device is not None:
            try:
                current_app = self.current_app()
            except Exception:
                pass

        adb_state = "unavailable"
        try:
            result = self.adb("get-state", timeout=2)
            adb_state = normalize(result.stdout) or normalize(result.stderr)
        except Exception as state_exc:
            adb_state = f"unavailable: {state_exc}"

        hierarchy = ""
        if self.device is not None:
            try:
                hierarchy = self.device.dump_hierarchy(compressed=False)
                (self.run_dir / "error_ui.xml").write_text(
                    hierarchy, encoding="utf-8"
                )
            except Exception as hierarchy_exc:
                hierarchy = f"UI hierarchy unavailable: {hierarchy_exc}"

        identifier_text_path, identifier_json_path = (
            self.write_ui_identifier_inventory(hierarchy)
        )

        relevant_nodes: list[str] = []
        if hierarchy.startswith("<?xml") or hierarchy.startswith("<hierarchy"):
            try:
                root = ET.fromstring(hierarchy)
                for node in root.iter("node"):
                    resource_id = normalize(node.attrib.get("resource-id"))
                    text = normalize(node.attrib.get("text"))
                    description = normalize(node.attrib.get("content-desc"))
                    class_name = normalize(node.attrib.get("class"))
                    clickable = normalize(node.attrib.get("clickable"))
                    enabled = normalize(node.attrib.get("enabled"))
                    bounds = normalize(node.attrib.get("bounds"))
                    searchable = " ".join(
                        (resource_id, text, description)
                    ).lower()
                    important = (
                        clickable == "true"
                        or any(
                            token in searchable
                            for token in (
                                "search", "cari", "report", "lapor", "submit", "verify",
                                "close", "misinformation", "false information",
                                "fraud", "harassment", "violent", "hateful",
                                "gambling", "criminal",
                            )
                        )
                    )
                    if not important:
                        continue
                    relevant_nodes.append(
                        f"{resource_id} | {class_name} | text={text!r} | "
                        f"desc={description!r} | bounds={bounds} | "
                        f"clickable={clickable} | enabled={enabled}"
                    )
                    if len(relevant_nodes) >= 120:
                        relevant_nodes.append("... relevant nodes truncated ...")
                        break
            except Exception as parse_exc:
                relevant_nodes.append(f"UI parse failed: {parse_exc}")

        related_packages = [
            package
            for package in self.installed_packages
            if any(
                marker in package.lower()
                for marker in ("tiktok", "musically", "aweme", "trill")
            )
        ]

        evidence = self.build_concise_error_evidence(error_code)
        self.last_error_evidence = evidence
        precheck_elapsed = max(0.0, time.monotonic() - self._workflow_started)
        precheck_remaining = self._remaining_live_precheck_time()
        search_or_cari_observed = any(
            token in hierarchy.casefold() for token in ('text="search"', 'text="cari"', 'content-desc="search"', 'content-desc="cari"')
        )

        lines = [
            "TIKTOK LIVE WORKFLOW ERROR REPORT",
            "=" * 72,
            f"timestamp: {datetime.now().isoformat(timespec='milliseconds')}",
            f"workflow_file: {Path(__file__).resolve()}",
            f"config_file: {self.config_path}",
            f"adb_serial: {self.serial}",
            f"adb_state: {adb_state}",
            f"live_url: {self.live_url}",
            f"report_action_id: {normalize(self.config.get('report_action_id'))}",
            f"report_type: {normalize(self.config.get('report_type'))}",
            f"assignment_mode: {normalize(self.config.get('assignment_mode'))}",
            f"stage: {self.current_stage}",
            f"action: {self.current_action}",
            f"current_app: {json.dumps(current_app, ensure_ascii=False)}",
            f"precheck_elapsed_seconds: {precheck_elapsed:.3f}",
            "precheck_remaining_seconds: "
            + ("not-applicable" if precheck_remaining is None else f"{precheck_remaining:.3f}"),
            f"search_or_cari_observed: {search_or_cari_observed}",
            f"tiktok_launch_mode: {self.tiktok_launch_mode}",
            "search_candidates: "
            + json.dumps(self.search_result_candidates, ensure_ascii=False),
            "selected_search_result: "
            + json.dumps(self.search_selected_result, ensure_ascii=False),
            "observed_destination_usernames: "
            + json.dumps(self.observed_destination_usernames, ensure_ascii=False),
            f"error_code: {error_code}",
            f"exception_type: {type(exc).__name__}",
            f"exception: {exc}",
            "",
            "CONCISE EVIDENCE",
            evidence,
            "",
            "LIKELY CAUSE",
            likely_cause,
            "",
            "SUGGESTED SOLUTION",
            suggested_solution,
            "",
            "RELATED TIKTOK PACKAGES",
            ", ".join(related_packages) or "none detected",
            "",
            "UI IDENTIFIER INVENTORY",
            f"text: {identifier_text_path.name}",
            f"json: {identifier_json_path.name}",
            "",
            "LAST SELECTOR ATTEMPTS",
            json.dumps(
                self.last_selector_diagnostics,
                indent=2,
                ensure_ascii=False,
                default=str,
            ),
            "",
            "RELEVANT UI NODES",
            *(relevant_nodes or ["none available"]),
            "",
            "TRACEBACK",
            "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
        ]
        report_path = self.run_dir / "error_report.txt"
        report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        summary_lines = [
            "ERROR SUMMARY",
            "=" * 72,
            f"timestamp: {datetime.now().isoformat(timespec='milliseconds')}",
            f"device: {self.serial}",
            f"live: @{self.live_username}",
            f"report_type: {normalize(self.config.get('report_type'))}",
            f"error_code: {error_code}",
            f"stage: {self.current_stage}",
            f"action: {self.current_action}",
            f"root_cause: {likely_cause}",
            f"evidence: {evidence}",
            f"solution: {suggested_solution}",
            f"details: {report_path.name}, error_ui.xml, "
            f"{identifier_text_path.name}, {identifier_json_path.name}",
        ]
        summary_path = self.run_dir / "ERROR_SUMMARY.txt"
        summary_path.write_text(
            "\n".join(summary_lines) + "\n", encoding="utf-8"
        )
        return report_path

    def live_context_ok(self) -> bool:
        assert self.package
        current = self.current_app()
        if current["package"] != self.package:
            return False
        configured_activity = any(
            normalize(fragment).lower() in current["activity"].lower()
            for fragment in self.config.get(
                "live_activity_contains", ["LivePlayActivity", ".live."]
            )
        )
        if configured_activity:
            return True
        return bool(
            self.workflow_mode == "live_discovery"
            and getattr(self, "_discovery_detail_live_verified", False)
            and self.detail_activity_context_ok(current["activity"])
        )

    def close_tiktok(self) -> None:
        """Force-stop TikTok after a task so the next task starts clean."""
        if not self.package:
            return
        try:
            self.adb(
                "shell",
                "am",
                "force-stop",
                self.package,
                timeout=max(1, int(float(self.config.get("cleanup_timeout_seconds", 2)))),
            )
        except Exception as exc:
            self.logger.warning("TikTok final cleanup unavailable: %s", exc)

    def _raise_if_live_ended_during_workflow(self, hierarchy: str, *, context: str) -> None:
        """Classify explicit mid-workflow LIVE termination as a non-error outcome.

        This never controls/suppresses other workers. The initial dedicated
        precheck remains the only batch-level LIVE authority.
        """
        if self.workflow_mode in {"live_precheck", "live_discovery"}:
            return
        if explicit_live_ended_in_hierarchy(hierarchy):
            raise LiveEndedDuringWorkflow(
                "LIVE_ENDED_DURING_WORKFLOW: TikTok explicitly showed that the LIVE ended "
                f"during {context}; Submit was not acknowledged"
            )

    def target_is_excluded(self) -> bool:
        raw_path = normalize(self.config.get("excluded_lists_file", ""))
        if not raw_path:
            return False
        path = Path(raw_path)
        if not path.is_absolute():
            path = self.base_dir / path
        try:
            lines = path.read_text(
                encoding="utf-8-sig", errors="replace"
            ).splitlines()
        except FileNotFoundError:
            return False
        expected = self.live_username.casefold()
        for raw in lines:
            value = raw.strip()
            if not value or value.startswith("#"):
                continue
            match = re.search(r"/@([A-Za-z0-9._]{2,32})/live/?", value)
            username = match.group(1) if match else value.lstrip("@").strip()
            if username.casefold() == expected:
                return True
        return False

    def select_live_search_tab(self) -> None:
        """Switch only keyword LIVE discovery from Search Users to Search LIVE."""
        assert self.device is not None
        self.set_stage("DISCOVERY_LIVE_TAB", "Select TikTok Search LIVE tab")
        timeout = self._bounded_stage_timeout(
            float(
                self.config.get(
                    "precheck_search_result_timeout_seconds",
                    self.config.get("search_result_timeout_seconds", 12),
                )
            )
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        click_attempts = 0
        swipe_attempted = False

        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy("select Search LIVE tab for keyword discovery")
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                self._bounded_poll_sleep(poll, deadline)
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="keyword discovery LIVE tab"
            ):
                self._bounded_poll_sleep(poll, deadline)
                continue
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"DISCOVERY_SEARCH_BLOCKED: {reason}")
            if live_search_tab_selected_in_hierarchy(hierarchy):
                self.logger.info(
                    "[DISCOVERY] query=%r | Search LIVE tab selected",
                    self.search_query,
                )
                return

            bounds = live_search_tab_click_bounds_from_hierarchy(hierarchy)
            if (
                bounds is None
                and top_search_tab_selected_in_hierarchy(hierarchy)
                and live_marked_top_search_result_from_hierarchy(hierarchy) is not None
            ):
                self._live_tab_unavailable_top_ready = True
                self.logger.info(
                    "[DISCOVERY] query=%r | LIVE tab unavailable in this Search layout | using first explicit LIVE card from Top",
                    self.search_query,
                )
                return
            if bounds is not None and click_attempts < 2:
                click_attempts += 1
                x = (bounds[0] + bounds[2]) // 2
                y = (bounds[1] + bounds[3]) // 2
                try:
                    self.device.click(x, y)
                except Exception as exc:
                    if not is_uiautomator_transport_error(exc):
                        raise DestinationUnknownError(
                            f"DISCOVERY_LIVE_TAB_CLICK_FAILED: {type(exc).__name__}: {exc}"
                        ) from exc
                    self._repair_uiautomator_after_transport_failure(
                        context="Search LIVE tab click"
                    )
                self._bounded_poll_sleep(poll, deadline)
                continue

            # Some TikTok builds place LIVE just outside the left edge of the
            # initially visible Search-tab strip (Users/Shop/Sounds remain
            # visible). Drag the strip to the right to reveal its earlier tabs.
            # Keep this one bounded swipe exclusive to keyword discovery;
            # normal username search is untouched.
            if bounds is None and not swipe_attempted:
                users_control = _search_tab_control_from_hierarchy(
                    hierarchy,
                    labels={"users", "pengguna"},
                )
                if users_control is not None:
                    swipe_attempted = True
                    user_bounds = users_control[0]
                    y = (user_bounds[1] + user_bounds[3]) // 2
                    try:
                        width, _height = self.device.window_size()
                        self.device.swipe(
                            int(width * 0.28), y,
                            int(width * 0.82), y,
                            0.2,
                        )
                    except Exception as exc:
                        if not is_uiautomator_transport_error(exc):
                            self.logger.warning(
                                "[DISCOVERY] LIVE tab reveal swipe failed: %s: %s",
                                type(exc).__name__, exc,
                            )
                    self._bounded_poll_sleep(poll, deadline)
                    continue

            self._bounded_poll_sleep(poll, deadline)

        raise DestinationUnknownError(
            "DISCOVERY_LIVE_TAB_UNAVAILABLE: TikTok Search LIVE tab could not be selected"
        )

    def open_live_search_result(self, selected: SearchResultCandidate) -> None:
        """Open one top result from Search LIVE without changing normal Users logic."""
        assert self.device is not None
        self._raise_if_live_precheck_expired()

        def click_point(candidate: SearchResultCandidate) -> tuple[int, int]:
            if candidate.avatar_bounds is not None:
                bounds = candidate.avatar_bounds
                return ((bounds[0] + bounds[2]) // 2, (bounds[1] + bounds[3]) // 2)
            left, top, right, bottom = candidate.row_bounds
            return ((left + right) // 2, (top + bottom) // 2)

        x, y = click_point(selected)
        try:
            self.device.click(x, y)
        except Exception as exc:
            if not is_uiautomator_transport_error(exc):
                raise DestinationUnknownError(
                    f"DISCOVERY_LIVE_RESULT_CLICK_FAILED: {type(exc).__name__}: {exc}"
                ) from exc
            self._repair_uiautomator_after_transport_failure(
                context="Search LIVE result click"
            )
            if self.live_context_ok():
                return
            hierarchy = self._dump_hierarchy(
                "verify Search LIVE result after click transport failure"
            )
            if not live_search_tab_selected_in_hierarchy(hierarchy):
                raise DestinationUnknownError(
                    "DISCOVERY_LIVE_RESULT_CLICK_FAILED: click acknowledgement was lost and Search LIVE tab is no longer confirmed"
                ) from exc
            exact = exact_target_search_result_from_hierarchy(
                hierarchy, selected.username
            )
            if exact is None:
                raise DestinationUnknownError(
                    "DISCOVERY_LIVE_RESULT_CLICK_FAILED: result could not be safely re-resolved after transport failure"
                ) from exc
            retry_x, retry_y = click_point(exact)
            try:
                self.device.click(retry_x, retry_y)
            except Exception as retry_exc:
                raise DestinationUnknownError(
                    f"DISCOVERY_LIVE_RESULT_CLICK_FAILED: retry failed: {type(retry_exc).__name__}: {retry_exc}"
                ) from retry_exc

    def open_top_live_search_row(self, selected: TopUserRowEvidence) -> None:
        """Click exactly one structural LIVE-tab result row without identity input."""
        assert self.device is not None
        self._raise_if_live_precheck_expired()
        x, y = selected.avatar_point
        try:
            self.device.click(x, y)
        except Exception as exc:
            if not is_uiautomator_transport_error(exc):
                raise DestinationUnknownError(
                    f"DISCOVERY_LIVE_RESULT_CLICK_FAILED: {type(exc).__name__}: {exc}"
                ) from exc
            self._repair_uiautomator_after_transport_failure(
                context="structural Search LIVE result click"
            )
            if self.live_context_ok():
                return
            raise DestinationUnknownError(
                "DISCOVERY_LIVE_RESULT_CLICK_UNACKNOWLEDGED: the one structural result click lost its acknowledgement and active LIVE was not confirmed"
            ) from exc

    def select_top_search_tab_for_live_fallback(self) -> None:
        """Select Search Top once when the selected LIVE tab remains empty/loading."""
        assert self.device is not None
        self.set_stage(
            "DISCOVERY_TOP_LIVE_FALLBACK",
            "Select Search Top to find one explicitly LIVE-marked result",
        )
        timeout = self._bounded_stage_timeout(
            float(
                self.config.get(
                    "precheck_search_result_timeout_seconds",
                    self.config.get("search_result_timeout_seconds", 12),
                )
            )
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        clicked = False
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy(
                "select Search Top fallback for LIVE discovery"
            )
            if top_search_tab_selected_in_hierarchy(hierarchy):
                return
            control = _search_tab_control_from_hierarchy(
                hierarchy,
                labels={"top"},
                anchor_labels={"live", "siaran langsung", "users", "pengguna", "videos", "video", "sounds", "suara", "shop"},
            )
            if control is not None and not clicked:
                bounds = control[0]
                self.device.click(
                    (bounds[0] + bounds[2]) // 2,
                    (bounds[1] + bounds[3]) // 2,
                )
                clicked = True
            self._bounded_poll_sleep(poll, deadline)
        raise DestinationUnknownError(
            "DISCOVERY_TOP_TAB_UNAVAILABLE: Search Top could not be selected after LIVE results remained unavailable"
        )

    def complete_structural_live_discovery(
        self,
        selected: TopUserRowEvidence,
        *,
        source: str,
        selection: str,
    ) -> str:
        """Open one chosen row, prove LIVE, then obtain its canonical identity."""
        self.top_user_click_source = source
        self.search_used_top_fallback = False
        self.search_selected_result = {
            "username": "",
            "avatar_point": selected.avatar_point,
            "row_bounds": selected.row_bounds,
            "row_texts": list(selected.texts),
            "source": source,
            "selection": selection,
            "search_query": normalize(getattr(self, "search_query", self.live_username)),
        }
        self.open_top_live_search_row(selected)
        destination = self.classify_top_user_precheck_destination()
        if destination == "STALE":
            raise LiveUnavailableError(
                "DISCOVERY_STALE_LIVE_RESULT: selected Search result opened a stable ordinary video instead of active LIVE"
            )
        if destination != "LIVE":
            raise LiveUnavailableError(
                "DISCOVERY_STALE_LIVE_RESULT: the one selected Search result did not open an active LIVE"
            )
        username = self.discover_open_live_broadcaster_username()
        self.live_username = username
        self.live_url = f"https://www.tiktok.com/@{username}/live"
        self.discovered_username = username
        self.discovered_live_url = self.live_url
        self.search_selected_result["username"] = username
        if self.target_is_excluded():
            raise LiveUnavailableError(
                f"DISCOVERY_TARGET_EXCLUDED: @{username} is excluded"
            )
        return username

    @staticmethod
    def _discovery_candidate_key(
        selected: TopUserRowEvidence,
    ) -> tuple[tuple[int, int, int, int], tuple[str, ...]]:
        return (
            selected.row_bounds,
            tuple(normalize(value).casefold() for value in selected.texts if normalize(value)),
        )

    def recover_discovery_results_after_stale(self, *, source: str) -> str:
        """Return once to the same Search tab after a conclusive stale result."""
        expected_top = source == "structural-top-tab-live-marker"
        key_timeout = max(
            0.5, float(self.config.get("adb_keyevent_timeout_seconds", 8))
        )
        result = self.adb(
            "shell", "input", "keyevent", "KEYCODE_BACK", timeout=key_timeout
        )
        if result.returncode != 0:
            raise DestinationUnknownError(
                "DISCOVERY_STALE_RECOVERY_FAILED: ADB Back returned non-zero"
            )

        timeout = self._bounded_stage_timeout(
            float(self.config.get("precheck_detail_recovery_timeout_seconds", 4))
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy(
                "recover Search results after stale LIVE candidate"
            )
            selected = (
                top_search_tab_selected_in_hierarchy(hierarchy)
                if expected_top
                else live_search_tab_selected_in_hierarchy(hierarchy)
            )
            if selected:
                return hierarchy
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="LIVE discovery stale-candidate recovery"
            ):
                continue
            self._bounded_poll_sleep(poll, deadline)
        raise DestinationUnknownError(
            "DISCOVERY_STALE_RECOVERY_FAILED: Search did not return to the selected result tab before deadline"
        )

    def try_structural_live_candidates(
        self,
        rows: Sequence[TopUserRowEvidence],
        *,
        source: str,
        selection: str,
    ) -> str:
        """Try at most three distinct visible candidates, stopping at one LIVE."""
        limit = max(
            1,
            min(3, int(self.config.get("live_discovery_candidate_limit", 3))),
        )
        attempted: set[tuple[tuple[int, int, int, int], tuple[str, ...]]] = set()
        current_rows = list(rows[:limit])
        stale_count = 0
        while len(attempted) < limit:
            selected = next(
                (
                    row
                    for row in current_rows
                    if self._discovery_candidate_key(row) not in attempted
                ),
                None,
            )
            if selected is None:
                break
            attempted.add(self._discovery_candidate_key(selected))
            try:
                return self.complete_structural_live_discovery(
                    selected,
                    source=source,
                    selection=selection,
                )
            except LiveUnavailableError as exc:
                if not str(exc).startswith("DISCOVERY_STALE_LIVE_RESULT"):
                    raise
                stale_count += 1
                if len(attempted) >= limit:
                    break
                hierarchy = self.recover_discovery_results_after_stale(source=source)
                current_rows = (
                    live_marked_top_search_results_from_hierarchy(
                        hierarchy, maximum=limit
                    )
                    if source == "structural-top-tab-live-marker"
                    else live_search_result_rows_from_hierarchy(
                        hierarchy, maximum=limit
                    )
                )

        if stale_count:
            raise LiveUnavailableError(
                "DISCOVERY_STALE_LIVE_RESULT: all bounded visible LIVE candidates resolved stale or non-LIVE; "
                f"attempted={len(attempted)}"
            )
        raise LiveUnavailableError(
            "DISCOVERY_NO_LIVE_RESULT: selected Search result tab exposed no untried structurally usable LIVE candidate"
        )

    def discover_open_live_broadcaster_username(self) -> str:
        """Read canonical identity after an identity-free LIVE result selection."""
        assert self.device is not None
        self.set_stage(
            "DISCOVERY_IDENTITY",
            "Read canonical broadcaster username from opened active LIVE",
        )
        if not self.live_context_ok():
            raise DestinationUnknownError(
                "DISCOVERY_LIVE_CONTEXT_LOST: selected Search LIVE result did not remain in active LIVE"
            )

        host_config = dict(self.config["selectors"]["host_profile"])
        timeout = self._bounded_stage_timeout(
            float(host_config.get("timeout_seconds", 4))
            + float(self.config.get("live_identity_timeout_seconds", 4))
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        host_clicked = False

        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy(
                "discover canonical username from opened Search LIVE result"
            )
            # ``user_name`` is also present in the active LIVE header and can be
            # a display name that merely looks username-compatible.  Canonical
            # identity is trusted only after this workflow opened the
            # broadcaster sheet itself.
            sheet_ready = configured_text_visible_in_hierarchy(
                hierarchy, dict(self.config["selectors"]["report_button"])
            )
            if host_clicked and sheet_ready:
                candidates = profile_sheet_usernames_from_hierarchy(
                    hierarchy, exclude_live_header=True
                )
                if len(candidates) == 1:
                    self.logger.info(
                        "[DISCOVERY] broadcaster sheet verified | username=@%s", candidates[0]
                    )
                    return candidates[0]
                if len(candidates) > 1:
                    raise DestinationUnknownError(
                        f"DISCOVERY_IDENTITY_AMBIGUOUS: broadcaster sheet exposed multiple canonical usernames: {candidates}"
                    )

            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                self._bounded_poll_sleep(poll, deadline)
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="LIVE discovery identity"
            ):
                self._bounded_poll_sleep(poll, deadline)
                continue

            if not host_clicked:
                target = None
                structural = self._structural_live_host_target(hierarchy)
                if structural is not None:
                    target, _evidence = structural
                else:
                    try:
                        target, _located = self.locate_unique(
                            action="Open discovered LIVE broadcaster profile sheet",
                            selector_config=host_config,
                            timeout=min(0.35, max(0.05, deadline - time.monotonic())),
                        )
                    except WorkflowError:
                        target = None
                if target is not None:
                    self._click_once(target, "DISCOVERY_BROADCASTER_CLICK_FAILED")
                    self.logger.info("[DISCOVERY] broadcaster avatar clicked; waiting for profile sheet")
                    host_clicked = True
                    continue

            self._bounded_poll_sleep(poll, deadline)

        self._raise_if_live_precheck_expired()
        if not host_clicked:
            raise DestinationUnknownError(
                "DISCOVERY_BROADCASTER_CONTROL_UNAVAILABLE: active LIVE exposed no usable broadcaster header"
            )
        raise DestinationUnknownError(
            "DISCOVERY_IDENTITY_UNAVAILABLE: broadcaster sheet exposed no single canonical username"
        )

    def discover_top_live_user_from_search(self) -> str:
        """Open one top structural LIVE result, then discover its identity."""
        assert self.device is not None
        self.set_stage(
            "DISCOVERY_RESULTS",
            f"Find one top structural LIVE-tab result for search query {self.search_query!r}",
        )
        timeout = self._bounded_stage_timeout(
            float(
                self.config.get(
                    "precheck_search_result_timeout_seconds",
                    self.config.get("search_result_timeout_seconds", 12),
                )
            )
        )
        deadline = time.monotonic() + timeout
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        while time.monotonic() < deadline:
            hierarchy = self._dump_hierarchy("find top user in Search LIVE results")
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                self._bounded_poll_sleep(poll, deadline)
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="LIVE discovery Search LIVE results"
            ):
                self._bounded_poll_sleep(poll, deadline)
                continue
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(f"DISCOVERY_SEARCH_BLOCKED: {reason}")
            if not live_search_tab_selected_in_hierarchy(hierarchy):
                if (
                    getattr(self, "_live_tab_unavailable_top_ready", False)
                    and top_search_tab_selected_in_hierarchy(hierarchy)
                ):
                    break
                self._bounded_poll_sleep(poll, deadline)
                continue

            live_rows = live_search_result_rows_from_hierarchy(
                hierarchy,
                maximum=max(
                    1,
                    min(3, int(self.config.get("live_discovery_candidate_limit", 3))),
                ),
            )
            if live_rows:
                return self.try_structural_live_candidates(
                    live_rows,
                    source="structural-live-tab-row",
                    selection="first-usable-search-live-tab-result",
                )
            self._bounded_poll_sleep(poll, deadline)

        # Some TikTok builds keep the selected LIVE tab on an indefinite loading
        # spinner even though Top already contains result cards carrying explicit
        # LIVE badges. Select Top once and choose exactly one such card; identity
        # is still collected only after the opened destination proves active LIVE.
        self.select_top_search_tab_for_live_fallback()
        fallback_timeout = self._bounded_stage_timeout(
            float(
                self.config.get(
                    "precheck_search_result_timeout_seconds",
                    self.config.get("search_result_timeout_seconds", 12),
                )
            )
        )
        fallback_deadline = time.monotonic() + fallback_timeout
        while time.monotonic() < fallback_deadline:
            hierarchy = self._dump_hierarchy(
                "find one explicitly LIVE-marked result in Search Top"
            )
            if verification_overlay_present(hierarchy):
                self.handle_optional_verification_overlay()
                self._bounded_poll_sleep(poll, fallback_deadline)
                continue
            if self.recover_known_blocking_state(
                hierarchy, context="LIVE discovery Search Top fallback"
            ):
                self._bounded_poll_sleep(poll, fallback_deadline)
                continue
            reason = blocking_destination_reason(hierarchy)
            if reason:
                raise DestinationUnknownError(
                    f"DISCOVERY_SEARCH_BLOCKED: {reason}"
                )
            fallback_rows = live_marked_top_search_results_from_hierarchy(
                hierarchy,
                maximum=max(
                    1,
                    min(3, int(self.config.get("live_discovery_candidate_limit", 3))),
                ),
            )
            if fallback_rows:
                return self.try_structural_live_candidates(
                    fallback_rows,
                    source="structural-top-tab-live-marker",
                    selection="first-explicit-live-marked-top-result",
                )
            self._bounded_poll_sleep(poll, fallback_deadline)

        raise LiveUnavailableError(
            "DISCOVERY_NO_LIVE_RESULT: selected Search LIVE exposed no usable row and Search Top exposed no structurally usable LIVE-marked card "
            f"for query={self.search_query!r}"
        )

    def run_live_discovery(self) -> None:
        """Search a keyword and confirm the top visible LIVE-marked user."""
        self._initialize_live_precheck_deadline()
        self._raise_if_live_precheck_expired()
        self.launch_tiktok_normally()
        self.open_users_search(select_users_tab=False)
        self.select_live_search_tab()
        username = self.discover_top_live_user_from_search()
        self.set_stage(
            "LIVE_DISCOVERY_COMPLETE",
            "Top Search LIVE-tab user opened an active LIVE session",
        )
        self.logger.info(
            "LIVE DISCOVERY COMPLETE | query=%r | username=@%s",
            self.search_query,
            username,
        )

    def run_live_precheck(self) -> None:
        """Open the exact requested Users result and classify LIVE vs profile only."""
        self._initialize_live_precheck_deadline()
        self._raise_if_live_precheck_expired()
        destination = self.navigate_via_search()
        if destination == "OFFLINE":
            raise LiveUnavailableError(
                f"PROFILE_OFFLINE: @{self.live_username} exact user opened a normal profile"
            )
        if destination != "LIVE":
            raise DestinationUnknownError(
                f"DESTINATION_UNKNOWN: unexpected classification {destination}"
            )
        self.set_stage(
            "LIVE_PRECHECK_COMPLETE",
            "Exact TikTok Users result opened a LIVE session",
        )
        self.logger.info("LIVE PRECHECK COMPLETE | username=@%s", self.live_username)

    def _require_proxy_tiktok_proof(self, *, context: str, timeout_seconds: float) -> None:
        """Require current-assignment proof of real TikTok-domain relay traffic."""
        if not bool(self.config.get("proxy_require_tiktok_proof_before_submit", False)):
            return
        raw_path = normalize(self.config.get("proxy_tiktok_proof_file", ""))
        if not raw_path:
            raise WorkflowError(
                f"PROXY_TIKTOK_TRAFFIC_UNVERIFIED: proxy proof file was not configured ({context})"
            )
        proof_path = Path(raw_path)
        deadline = time.monotonic() + max(0.1, float(timeout_seconds))
        poll = max(0.05, float(self.config.get("poll_interval_seconds", 0.2)))
        last_error = "proof file not present"
        while time.monotonic() < deadline:
            try:
                payload = json.loads(proof_path.read_text(encoding="utf-8"))
                if (
                    isinstance(payload, dict)
                    and bool(payload.get("verified"))
                    and normalize(payload.get("serial")) == self.serial
                    and normalize(payload.get("target"))
                ):
                    self.logger.info(
                        "[PROXY] TikTok relay proof confirmed %s | target=%s | proxy=%s",
                        context,
                        normalize(payload.get("target")),
                        normalize(payload.get("proxy")) or "verified",
                    )
                    return
                last_error = "proof content did not match this worker"
            except FileNotFoundError:
                last_error = "proof file not present"
            except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
            self._bounded_poll_sleep(poll, deadline)
        # If the LIVE explicitly ended while waiting for proof, report the real
        # external outcome rather than mislabeling it as a proxy failure.
        try:
            hierarchy = self._dump_hierarchy(f"classify proxy proof timeout {context}")
        except DestinationUnknownError:
            hierarchy = ""
        self._raise_if_live_ended_during_workflow(hierarchy, context=context)
        raise WorkflowError(
            "PROXY_TIKTOK_TRAFFIC_UNVERIFIED: no actual TikTok-domain relay proof "
            f"was available {context} ({last_error})"
        )

    def require_proxy_tiktok_proof_before_report(self) -> None:
        self._require_proxy_tiktok_proof(
            context="after target navigation and before Report",
            timeout_seconds=float(self.config.get("proxy_early_proof_timeout_seconds", 2.5)),
        )

    # Backward-compatible alias for older tests/config integrations. The active
    # workflow calls the proof gate only after target navigation now.
    def require_proxy_tiktok_proof_after_search(self) -> None:
        self.require_proxy_tiktok_proof_before_report()

    def require_proxy_tiktok_proof_before_submit(self) -> None:
        """Final fail-closed check before irreversible Submit."""
        self._require_proxy_tiktok_proof(
            context="before Submit",
            timeout_seconds=float(self.config.get("proxy_submit_proof_timeout_seconds", 1.5)),
        )

    def run_workflow(self) -> None:
        destination = self.navigate_via_search()
        if destination != "LIVE":
            raise DestinationUnknownError(
                f"DESTINATION_UNKNOWN: unexpected classification {destination}"
            )

        # Give TikTok a real network-dependent navigation operation before
        # requiring relay proof. This keeps fail-closed proxy protection while
        # avoiding false failures caused by cached Search UI before new traffic.
        self.set_stage(
            "PROXY_PATH_VERIFY",
            "Require real TikTok relay traffic after target navigation",
        )
        self.require_proxy_tiktok_proof_before_report()

        # The exact Users result already selected the target. Once TikTok opens an
        # active LIVE, do not reject it by comparing display-name/profile-sheet
        # text to the search username again. Open the broadcaster sheet only so
        # the existing Report workflow can continue.
        self.open_live_report_sheet()
        if not self.live_profile_sheet_ready:
            raise WorkflowError(
                "PROFILE_SHEET_NOT_READY: active LIVE did not expose Report"
            )

        # No fixed stabilization sleep. open_live_report_sheet() returns only
        # after Report is actually ready; click_action() re-checks overlays/state
        # immediately before the reporting action.

        self.set_stage("REPORT_MENU", "Open Report menu")
        self.click_action(
            action="Buka menu Report",
            selector_key="report_button",
            expected_after=self.report_reason_screen_ready,
        )

        self.set_stage("REPORT_REASON", "Choose report reason")
        has_subreason = "report_subreason" in self.config["selectors"]
        self.click_action(
            action=(
                "Pilih alasan laporan: "
                + normalize(self.config["selectors"]["report_reason"].get("text"))
            ),
            selector_key="report_reason",
            expected_before=self.report_reason_screen_ready,
            expected_after=lambda: self._selector_visible_with_hierarchy_fallback(
                "report_subreason" if has_subreason else "report_description_title",
                timeout=0.08,
            )
            or (
                not has_subreason
                and self._selector_visible_with_hierarchy_fallback(
                    "submit_button", timeout=0.08
                )
            ),
        )

        if has_subreason:
            self.set_stage("REPORT_SUBREASON", "Choose report subreason")
            self.click_action(
                action=(
                    "Pilih subalasan laporan: "
                    + normalize(
                        self.config["selectors"]["report_subreason"].get("text")
                    )
                ),
                selector_key="report_subreason",
                expected_before=lambda: self._selector_visible_with_hierarchy_fallback(
                    "report_subreason", timeout=0.08
                ),
                expected_after=lambda: self._selector_visible_with_hierarchy_fallback(
                    "report_description_title", timeout=0.08
                )
                or self._selector_visible_with_hierarchy_fallback(
                    "submit_button", timeout=0.08
                ),
            )

        if bool(self.config.get("require_confirmation_before_submit", False)):
            raise WorkflowError(
                "INTERACTIVE_SUBMIT_CONFIRMATION_UNSUPPORTED_IN_24_7_MODE"
            )

        # Fail closed on the proxy path before the irreversible Submit click.
        self.require_proxy_tiktok_proof_before_submit()

        # Exactly one intentional Submit click. Success requires a fresh explicit
        # acknowledgement followed by the bounded settlement period.
        self.set_stage("SUBMIT", "Submit once, confirm, and settle")
        self.click_action(
            action="Kirim laporan",
            selector_key="submit_button",
            expected_after=lambda: self._selector_visible_with_hierarchy_fallback(
                "thanks_title", timeout=0.08
            ),
        )
        if self.submit_completed and self.submission_state == "CONFIRMED":
            self.set_stage(
                "WORKFLOW_COMPLETE",
                "TikTok UI acknowledgement and settlement completed",
            )
            self.logger.info(
                "WORKFLOW COMPLETE | UI acknowledgement and settlement completed; "
                "backend acceptance unknown"
            )
        else:
            self.set_stage("SUBMIT_UNCONFIRMED", "Submit outcome was not confirmed")

    def _finish_timings(self) -> dict[str, float]:
        now = time.monotonic()
        if self.current_stage != "INIT":
            self.stage_timings[self.current_stage] = (
                self.stage_timings.get(self.current_stage, 0.0)
                + now - self._stage_started
            )
        self.stage_timings["total"] = now - self._workflow_started
        return dict(self.stage_timings)

    def execute(self) -> int:
        result: dict[str, Any] = {
            "started_at": datetime.now().isoformat(timespec="milliseconds"),
            "adb_serial": self.serial,
            "live_url": self.live_url,
            "username": self.live_username,
            "report_action_id": normalize(self.config.get("report_action_id")),
            "report_type": normalize(self.config.get("report_type")),
            "workflow_mode": self.workflow_mode,
            "status": "failed",
            "live_status": "UNKNOWN" if self.workflow_mode == "live_precheck" else "",
            "search_query": normalize(getattr(self, "search_query", self.live_username)),
            "discovered_username": "",
            "discovered_live_url": "",
            "submission_completed": False,
            "submission_state": "NOT_SUBMITTED",
            "submit_attempted": False,
            "ui_confirmation_observed": False,
            "settlement_completed": False,
            "confirmation_source": "",
            "backend_acceptance": "unknown",
            "confirmation_wait_seconds": 0.0,
            "settlement_seconds": 0.0,
            "fixed_coordinates_used": False,
            "coordinate_ratios_used": False,
            "search_used_top_fallback": False,
            "search_selected_result": {},
            "observed_destination_usernames": [],
        }
        exit_code = 1

        try:
            if self.workflow_mode != "live_discovery" and self.target_is_excluded():
                self.set_stage("EXCLUSION_CHECK", "Target excluded before processing")
                raise LiveUnavailableError(
                    "TARGET_EXCLUDED: target is present in excluded_lists.txt"
                )
            self.set_stage("CONNECT_ADB", "One ADB state check and one uiautomator2 connect")
            self.connect()
            self.set_stage("DETECT_PACKAGE", "Use cached TikTok package or detect once")
            self.detect_package()
            if self.workflow_mode == "live_precheck":
                self.run_live_precheck()
                result["live_status"] = "LIVE"
            elif self.workflow_mode == "live_discovery":
                self.run_live_discovery()
            else:
                self.run_workflow()
            if self.workflow_mode == "report" and getattr(
                self, "submission_state", "NOT_SUBMITTED"
            ) != "CONFIRMED":
                result["status"] = "unconfirmed"
                result["error_code"] = "SUBMIT_UNCONFIRMED"
                result["reason"] = getattr(self, "submission_reason", "") or (
                    "TikTok acknowledgement and settlement were not both confirmed"
                )
                exit_code = 1
            else:
                result["status"] = "success"
                exit_code = 0
            result["stage"] = self.current_stage
            result["action"] = self.current_action

        except LiveEndedDuringWorkflow as exc:
            reason = str(exc)
            result.update(
                {
                    "status": "live_ended",
                    "stage": self.current_stage,
                    "action": self.current_action,
                    "reason": reason,
                    "error_code": "LIVE_ENDED_DURING_WORKFLOW",
                }
            )
            exit_code = 0
            self.logger.warning("LIVE ENDED DURING WORKFLOW | %s", exc)

        except LiveUnavailableError as exc:
            reason = str(exc)
            prefix = reason.partition(":")[0].strip()
            result.update(
                {
                    "status": "excluded" if prefix == "TARGET_EXCLUDED" else "skipped",
                    "stage": self.current_stage,
                    "action": self.current_action,
                    "reason": reason,
                    "error_code": prefix if re.fullmatch(r"[A-Z][A-Z0-9_]+", prefix) else "LIVE_UNAVAILABLE",
                }
            )
            if self.workflow_mode == "live_precheck" and prefix != "TARGET_EXCLUDED":
                result["live_status"] = "OFFLINE"
            exit_code = 0
            self.logger.warning("TERMINAL SKIP | %s", exc)

        except KeyboardInterrupt:
            result.update({"status": "cancelled", "error": "Cancelled by user"})
            exit_code = 130

        except Exception as exc:
            error_code, likely_cause, suggested_solution = self.classify_error(exc)
            result.update(
                {
                    "status": "failed",
                    "error": str(exc),
                    "error_code": error_code,
                    "stage": self.current_stage,
                    "action": self.current_action,
                    "likely_cause": likely_cause,
                    "suggested_solution": suggested_solution,
                }
            )
            if self.workflow_mode == "live_precheck":
                result["live_status"] = "UNKNOWN"
            if self.diagnostics_enabled:
                report_path = self.write_error_report(
                    exc, error_code, likely_cause, suggested_solution
                )
                result["error_report"] = str(report_path)
            self.logger.error(
                "FAILED | %s | stage=%s | %s",
                error_code,
                self.current_stage,
                exc,
            )

        finally:
            result["submission_completed"] = bool(self.submit_completed)
            result["completion_detection"] = self.submit_completion_detection
            result["submission_state"] = getattr(
                self, "submission_state", "NOT_SUBMITTED"
            )
            result["submit_attempted"] = bool(
                getattr(self, "submit_attempted", False)
            )
            result["ui_confirmation_observed"] = bool(
                getattr(self, "ui_confirmation_observed", False)
            )
            result["settlement_completed"] = bool(
                getattr(self, "settlement_completed", False)
            )
            result["confirmation_source"] = getattr(
                self, "confirmation_source", ""
            )
            result["backend_acceptance"] = getattr(
                self, "backend_acceptance", "unknown"
            )
            result["confirmation_wait_seconds"] = float(
                getattr(self, "confirmation_wait_seconds", 0.0)
            )
            result["settlement_seconds"] = float(
                getattr(self, "settlement_seconds", 0.0)
            )
            result["search_used_top_fallback"] = bool(self.search_used_top_fallback)
            result["search_selected_result"] = dict(self.search_selected_result)
            result["observed_destination_usernames"] = list(
                self.observed_destination_usernames
            )
            result["discovered_username"] = normalize(
                getattr(self, "discovered_username", "")
            )
            result["discovered_live_url"] = normalize(
                getattr(self, "discovered_live_url", "")
            )
            result["finished_at"] = datetime.now().isoformat(timespec="milliseconds")
            result["timings"] = self._finish_timings()
            # Persist the terminal workflow outcome before cleanup. If the hard
            # watchdog fires while force-stop cleanup is still finishing, the
            # parent can still see an acknowledged Submit and must not convert
            # that completed report into WORKER_JOB_TIMEOUT.
            (self.run_dir / "result.json").write_text(
                json.dumps(result, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            # Every executed LIVE check/report task still ends with TikTok closed.
            parent_cleanup = bool(self.config.get("parent_managed_cleanup", False))
            if self.package and not (
                self.workflow_mode == "report" and parent_cleanup
            ):
                self.close_tiktok()

        return exit_code


def main(default_config_dir: Path | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "TikTok LIVE selector-only Android workflow."
        )
    )
    parser.add_argument(
        "--config",
        default="config.json",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = (
            (default_config_dir or Path(__file__).resolve().parent)
            / config_path
        )

    return TikTokSelectorWorkflow(
        config_path
    ).execute()


if __name__ == "__main__":
    raise SystemExit(main())
