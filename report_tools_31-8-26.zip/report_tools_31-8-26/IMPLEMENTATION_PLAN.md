# Random fast-device LIVE checks and Mobile Legends discovery

Planning only. No implementation changes are included. Prepared against the current source tree on 2026-09-05.

## 1. Required behavior and settled interpretation

The user's clarification is authoritative: **Mobile Legends discovery uses three devices total, with one attempt per device.** There is no three-attempt loop on a single device and no second group of three devices.

Implement these rules:

1. For each watchlist target, select up to three distinct connected checker devices, preferring the configured fast model and randomizing device selection within that model.
2. Check the selected devices sequentially, once each, stopping immediately when one returns a verified `LIVE`. Earlier `OFFLINE` or ordinary `UNKNOWN` results must not prevent that success.
3. A single verified `LIVE` is sufficient. No majority or unanimous-positive requirement. For example, `OFFLINE, OFFLINE, LIVE` starts the existing workflow once.
4. For the existing `mobile legend` discovery, select up to three distinct devices using the same selection policy. Invoke discovery once per selected device until one returns `FOUND`. Continue after ordinary failures or no-result outcomes.
5. Keep the discovery trigger: it runs once after a watchlist round returns exactly one `LIVE` target. Zero or multiple live targets do not trigger discovery.
6. Successful discovery continues through the existing `preconfirmed_live` handoff. It must not run another three-device precheck or add the discovered account to the watchlist.

Sequential early exit is intentional: three is the maximum, and an already verified success can start the workflow without waiting for more checkers. Select a fresh random order for each target/discovery invocation; devices may recur across different targets or rounds.

One “attempt” means one call to the existing child job function. The child's existing bounded UI polling, launch recovery, and discovery-card fallback remain part of that one attempt.

## 2. Current code and baseline

All locations below are relative to this repository root. Line numbers refer to the source inspected for this plan; use function names as the edit anchors.

| Location | Current behavior / relevance |
| --- | --- |
| `loop_runner.py:410`, `refresh_connected_tcp_devices` | Reads `adb devices -l`, accepts connected TCP devices, normalizes model underscores to hyphens, and fills `DEVICE_MODEL_HINTS`. |
| `loop_runner.py:448`, `ordered_checker_candidates` | Deterministically sorts by preferred model, then cached per-device workflow duration, then original ADB order. |
| `loop_runner.py:482`, `remember_checker_speed` | Keeps an in-memory exponential moving average: 70% prior duration, 30% new duration. |
| `loop_runner.py:954` / `:966` | Frozen `LivePrecheckOutcome` and `LiveDiscoveryOutcome` carry one representative checker and timing values. |
| `loop_runner.py:1107`, `run_live_precheck_job` | Performs one killable child workflow and returns `LIVE`, `OFFLINE`, or `UNKNOWN`. Handles forced-exit cleanup. |
| `loop_runner.py:1232`, `run_live_discovery_job` | Performs one discovery child workflow and returns `FOUND`, `NONE`, or `UNKNOWN`. |
| `loop_runner.py:1354`, `run_global_live_discovery` | Already visits at most three distinct devices once each. Continues after `NONE` and selected device-local errors, but other `UNKNOWN` results stop it early. |
| `loop_runner.py:1449`, `run_global_live_precheck` | Tries at most three candidates for proxy readiness/device-local failures, but returns after the first definitive LIVE/OFFLINE or non-device-local UNKNOWN result. |
| `loop_runner.py:1940`, `write_precheck_summary` | Writes one-result `LIVE_PRECHECK.json`; it cannot currently explain several checker outcomes. |
| `loop_runner.py:2052`, `process_watchlist_target` | Starts the full existing device pipeline only after `LIVE`; preserves exclusion/removal checks and stops the monitor on precheck `INTERNAL_PROGRAM_ERROR`. |
| `loop_runner.py:2178`, `process_single_live_discovery` | Hands `FOUND` to `process_watchlist_target` with `preconfirmed_live` and `require_watchlist_membership=False`. |
| `loop_runner.py:2259`, `run_watchlist_round` | Counts live targets, then triggers `mobile legend` discovery when the count is exactly one. |
| `_shared/workflow_engine.py:5707`, `try_structural_live_candidates` | Already tries a bounded number of visible discovery cards within one child. Preserve this behavior. |
| `_shared/workflow_engine.py:5954` / `:5972` | Existing discovery and precheck workflows. Their detection and identity checks need no changes. |

Existing configuration already supplies everything required:

```json
{
  "checker_max_devices": 3,
  "checker_preferred_models": ["SM-F721U1"],
  "checker_use_speed_history": true,
  "live_precheck_timeout_seconds": 100
}
```

The repository uses a configured fast-model preference; it does not benchmark hardware models. Treat `SM_F721U1` and `SM-F721U1` as the same model. The example serial `192.168.100.10:5555` is not a permanent assignment and must not be hardcoded.

Baseline verification completed successfully:

```powershell
python -B -m unittest discover -s tests -p 'test_*.py'
```

Result: **149 tests passed in 6.836 seconds**. The test suite uses device/proxy mocks; the actual monitor was not started. This directory has no Git repository and no applicable `AGENTS.md` was found.

## 3. Exact change scope

Modify only these existing files:

- `loop_runner.py`: device ordering, multi-device decision loops, attempt records, aggregate timing and summary output.
- `tests/test_fail_fast_runner.py`: deterministic selection setup and regression coverage described below.
- `README.txt`: replace the obsolete one-checker description and document discovery/selection limits.
- `RUN_LOOP.bat`: update the LIVE precheck banner text only.
- `CHANGELOG.txt`: prepend an entry describing this change.

Do not change `settings.py`, `loop_config.json`, `proxy_manager.py`, `_shared/workflow_engine.py`, `_shared/workflow_defaults.json`, report-specific launchers/configs, target/exclusion/proxy lists, or existing log/state files. Existing settings are sufficient; add no new configuration flags, persisted speed database, benchmarking startup phase, or dependencies.

Keep normal worker concurrency, proxy assignment/proof rules, report actions, per-worker attempt counts, identity verification, CAPTCHA/overlay handling, cold starts, cleanup, watchlist ordering, maintenance, and shutdown behavior intact.

## 4. Device ordering algorithm

Update `ordered_checker_candidates`; keep its name, arguments, and list return type. Add the standard-library `random` import.

Implement the following steps in this exact order:

1. Deduplicate input serials while preserving first occurrence. Do not mutate the caller's list.
2. Read preferred models using the currently supported string-or-list handling. Normalize each model with `replace("_", "-").strip().casefold()` and remove duplicate normalized preferences while retaining their order.
3. Snapshot `DEVICE_MODEL_HINTS` and, when enabled, `CHECKER_SPEED_SECONDS` under their existing locks. Normalize snapshot model values using the same normalization as preferences.
4. For each preferred model, in configured order, collect all remaining serials matching it. Call `random.shuffle(group)` on that group and append it to the output. Remove those serials from the remaining pool.
5. Shuffle the remaining serials. If `checker_use_speed_history` is enabled, stable-sort this shuffled remainder by cached duration ascending, with missing durations represented by positive infinity. Thus measured fast fallback devices come first, and equal/missing durations retain a randomized order.
6. Append that remainder and return the complete order.

This defines the speed/randomness tradeoff explicitly: preferred-model devices are sampled uniformly without replacement, while speed history prioritizes fallback devices. Do not re-sort a preferred-model group by individual duration after shuffling it.

Consequences:

- With at least three connected `SM-F721U1` devices, the first three all come from that model and form a random sample.
- With fewer than three, use those available preferred devices first, then fill from the next preferred models and the speed-ranked fallback pool.
- With no matching preferred model, use fallback ordering directly.
- With no model information or speed history, selection is random among all supplied connected devices.
- No additional ADB calls, property probes, network calls, or device connections are needed.

Both global functions must create their bounded candidate list once, before attempting any candidate:

```python
ordered = ordered_checker_candidates(config, serials)
limit = max(1, min(3, int(config.get("checker_max_devices", 3))))
candidates = ordered[:limit]
```

Respect configurations smaller than three. With one or two connected devices, use each once. A proxy failure consumes that device's slot; never replace it with a fourth device. Do not reselect, refresh, or revisit a serial within one global operation.

Leave `remember_checker_speed` unchanged. Call it only with an individual child's `workflow_seconds` after `LIVE`/`OFFLINE` or `FOUND`/`NONE`, as today. Aggregate operation duration must never be used to train the cache.

## 5. Attempt records and timing

Add a frozen `CheckerAttemptOutcome` dataclass immediately before the two checker outcome dataclasses, with these fields:

```python
serial: str
model: str
status: str
error_code: str = ""
reason: str = ""
workflow_started: bool = False
proxy_seconds: float = 0.0
workflow_seconds: float = 0.0
```

Append this field, with its default, to both existing outcome dataclasses so existing positional constructors remain compatible:

```python
attempts: tuple[CheckerAttemptOutcome, ...] = ()
```

Each global function maintains a local attempt list. Record one entry per device actually attempted, in execution order. Store the normalized model hint, or an empty string if unknown. A proxy preparation failure/malformed preparation response is an `UNKNOWN` attempt with `workflow_started=False`, zero workflow time, and the existing operation-specific proxy failure code (`CHECKER_PROXY_FAILED` or `DISCOVERY_PROXY_FAILED`).

Time each `prepare_stream([checker], context)` operation separately. Sum these intervals into the aggregate `proxy_seconds`. Sum child outcome `workflow_seconds` into aggregate `workflow_seconds`. Set aggregate `duration_seconds` to elapsed wall time since the global function began. Do not measure proxy time using one timer spanning earlier child workflows; the current loops would otherwise overcount it after retries.

Use `replace` to attach these aggregate fields and the attempt tuple to whichever child outcome represents the final result. For `LIVE`/`FOUND`, retain the successful child's serial and discovery identity. Its top-level error fields must not inherit a previous failure. For an unsuccessful result, preserve the selected diagnostic outcome's original error code and reason; all other diagnostics remain in the attempt records.

All normal returns, including early success, cancellation, fatal child outcomes, and exhaustion, must include timings and the attempts collected so far. A guard that stops execution before any candidate starts has an empty attempt tuple. Do not fabricate unexecuted attempts.

## 6. Watchlist precheck decision loop

Rewrite the control flow of `run_global_live_precheck` while retaining its signature and existing child/proxy interfaces:

1. Before beginning work, honor `STOP_EVENT` and target exclusion. Keep `NO_CHECKER_DEVICE` when there are no candidates and no overriding stop/exclusion condition.
2. Before each candidate, check stop/exclusion again. Prepare only that candidate's proxy using the existing `prepare_stream([checker], context)` call.
3. Retain all preparation validation: exactly one returned item, matching serial, and readiness true. Failure records an unknown attempt and advances to the next selected device.
4. Check stop/exclusion again immediately after preparation and before launching the child. Cancellation or exclusion must not be converted into an ordinary proxy failure.
5. Call `run_live_precheck_job` exactly once for this serial. Record its outcome and individual timings; update speed history only on `LIVE`/`OFFLINE`.
6. Apply terminal guards before accepting success: stop/cancellation, `TARGET_EXCLUDED`, and `INTERNAL_PROGRAM_ERROR`. Return immediately for these cases. `process_watchlist_target` must continue to set `STOP_EVENT` for the returned internal-program error, as it does today.
7. If the child says `LIVE`, return it immediately with accumulated fields. Otherwise continue to the next selected device for both `OFFLINE` and ordinary `UNKNOWN`, including timeouts, identity mismatch, and device/UI errors. An error on one device is never positive evidence; a later device must independently prove the exact target LIVE.

After exhaustion, apply this decision table in order:

| Collected outcomes | Aggregate result |
| --- | --- |
| All selected candidate attempts completed a child and returned `OFFLINE` | Return the last OFFLINE child with aggregate fields. |
| Any executed child returned ordinary `UNKNOWN` | Return the last such UNKNOWN child, preserving its diagnostic code/reason. |
| Otherwise there was at least one proxy preparation failure | Return `UNKNOWN`, `CHECKER_PROXY_FAILED`, with joined preparation errors. This includes OFFLINE mixed with unavailable checkers. |

`LIVE` is handled by early exit and cannot be overwritten. An uncertain checker is never treated as an OFFLINE vote. Do not catch arbitrary parent Python exceptions and retry them; preserve the existing error path. Retry decisions apply to returned child outcomes only.

Remove this loop's reliance on `checker_failure_is_device_local` as a condition for trying the next candidate. The helper and its error-code set can remain unchanged to avoid unrelated cleanup.

`process_watchlist_target`, the downstream pipeline, and `run_watchlist_round` retain their existing decision and scheduling behavior. A successful aggregate result starts the full refreshed action-device pool, not just the three checkers, and contributes exactly one to the round's live-target count.

## 7. Mobile Legends discovery decision loop

Update `run_global_live_discovery` using the same bounded candidate selection, preparation validation, timing, and attempt recording.

- Check stop/cancellation before each candidate and immediately after preparation/child completion.
- Call `run_live_discovery_job` once per proxy-ready candidate, with the unchanged `search_query`.
- Stop immediately on `FOUND` and preserve its verified username and canonical URL.
- Continue to the next distinct selected device after `NONE` or an ordinary `UNKNOWN`, including discovery timeouts and non-device-local search failures.
- Return immediately on `INTERNAL_PROGRAM_ERROR`; do not retry broken code. Preserve the existing discovery caller's handling of that error rather than changing monitor-wide shutdown policy.
- `DISCOVERY_TARGET_EXCLUDED` remains a child `NONE` result, allowing another device to discover an eligible broadcaster. The existing parent exclusion check still applies to any returned FOUND target.
- Remove the device-local-error restriction and the temporary pseudo-precheck used for that restriction.

When no device finds a usable LIVE:

1. If any executed child returned `UNKNOWN`, return the last such child with aggregate fields.
2. Otherwise, if at least one child returned `NONE`, return the last NONE child. This retains the existing useful fallback for a NONE result followed only by proxy failures; NONE means discovery found no usable account, not proof that any named account is globally offline.
3. Otherwise all attempts failed preparation: return `UNKNOWN` with `DISCOVERY_PROXY_FAILED` and the preparation errors.
4. With no candidate devices, retain `UNKNOWN` / `NO_CHECKER_DEVICE`.

Do not nest an attempt loop inside the device loop. At the shipped limit, a complete unsuccessful run has at most three calls to `prepare_stream` and three calls to `run_live_discovery_job`; the latter may be fewer when preparation fails.

Keep `process_single_live_discovery`'s successful handoff unchanged apart from summary writing. Leave `preconfirmed_live.attempts` at its default empty tuple: the discovery records contain `FOUND`/`NONE`, not precheck statuses, and belong in the separate discovery summary below. Existing discovery aggregate timings are still copied to the preconfirmed outcome.

## 8. Summaries and documentation

In `loop_runner.py`:

1. Extend `write_precheck_summary` additively with `decision_rule: "any_live"` and an `attempts` array. Serialize all `CheckerAttemptOutcome` fields using `dataclasses.asdict`, rounding the two timing fields to three decimals. Preserve existing keys and their types.
2. Extend `log_live_precheck` with compact counts when attempts exist: `attempted=N live=L offline=O unknown=U`. Here `attempted` counts all attempted devices, including failed preparation; failed preparation contributes to `unknown`. Preserve existing checker, timeout-stage, and elapsed logging.
3. Add `write_discovery_summary(config=..., cycle_id=..., search_query=..., discovery=...) -> Path` beside `write_precheck_summary`. Write `LIVE_DISCOVERY.json` into the same cycle directory using `atomic_write_text`.
4. Its payload has `timestamp`, `search_query`, `status`, `username`, `live_url`, `checker_device`, `error_code`, `reason`, `duration_seconds`, `proxy_seconds`, `workflow_seconds`, `decision_rule: "first_found"`, and `attempts`. Serialize attempts exactly as above. Include no proxy credentials.
5. Call that writer in `process_single_live_discovery` immediately after `run_global_live_discovery` returns, before any result-specific early return or delegation. Preserve its existing finalization/maintenance cleanup.
6. Update the module docstring and global-function docstrings to describe up to three distinct checks and early success. Avoid stale claims that every target has exactly one actual check.

Documentation edits:

- `README.txt`: replace the LIVE precheck paragraph, explain the preferred-model randomized selection and fallback policy, update the meaning of `checker_max_devices`, and add the precise one-attempt-per-device discovery behavior plus its exactly-one-live trigger. Keep the document's existing Indonesian style.
- `RUN_LOOP.bat:18`: replace only the precheck banner with wording such as `echo LIVE precheck  : up to 3 random fast devices; any LIVE starts workflow`.
- `CHANGELOG.txt`: prepend an entry covering randomized preferred-model selection, any-LIVE prechecks, three distinct discovery attempts, and per-attempt diagnostics. Retain historical entries.

Keep the existing per-child 100-second precheck/discovery timeout and shared inner deadline unchanged. Sequential execution can consume up to three child budgets, plus proxy preparation and cleanup. Add no overall deadline that silently prevents candidates two and three from receiving their existing budgets.

## 9. Mechanical implementation order and tests

Execute these steps in order during implementation:

1. Add the attempt dataclass/default fields and implement candidate ordering.
2. Add isolated candidate-ordering tests.
3. Update the precheck loop and its tests.
4. Update the discovery loop and its tests.
5. Add summary serialization/call-site changes and their tests.
6. Update the three documentation/banner files.
7. Run the full test command below and review the changed-file scope.

Keep test randomness controlled. In the existing `GlobalPrecheckTests` and `GlobalDiscoveryTests`, patch `loop_runner.random.shuffle` to a no-op in `setUp`, register patch cleanup, and retain cache resets. That preserves their existing fixture order without making production selection deterministic. Dedicated ordering tests should override shuffle with an explicit permutation, such as reversing the supplied list. Never assert that two uncontrolled random calls must differ.

Add tests in `tests/test_fail_fast_runner.py` for these behaviors:

| Test group | Required cases/assertions |
| --- | --- |
| Candidate ordering | `SM_F721U1` and `SM-F721U1` match; all preferred devices precede fallback; an explicit shuffled order controls which three are selected from four preferred devices; preferences are deduplicated; duplicate serials appear once; input list remains unchanged. |
| Fallback ordering | Fewer preferred devices are filled from remaining devices; enabled speed history sorts fallback durations ascending; equal/missing durations preserve the controlled shuffle; disabled history does not sort; no preferences/hints/history still produces the controlled random order. Mock ADB/subprocess and assert no extra probe from the ordering helper. |
| Watchlist positive rule | `OFFLINE, OFFLINE, LIVE` returns LIVE from device 3; `UNKNOWN, OFFLINE, LIVE` also returns LIVE; `OFFLINE, LIVE` stops before device 3; first-device LIVE starts exactly one child. Preserve the winning serial and clean success error fields. |
| Watchlist negatives | Three OFFLINE results return OFFLINE; OFFLINE plus ordinary UNKNOWN returns UNKNOWN with the actual child error; OFFLINE plus proxy failure returns UNKNOWN; all preparation failures return CHECKER_PROXY_FAILED and launch no child. |
| Limits | Both globals use at most three distinct devices even with four or more supplied; proxy failures do not permit a fourth; `checker_max_devices=1` or `2` is respected; duplicated inputs cannot be retried; zero/one/two available-device cases are bounded. |
| Discovery | `NONE, NONE, FOUND` succeeds on device 3; `UNKNOWN(LIVE_DISCOVERY_TIMEOUT), FOUND` succeeds on device 2; first FOUND stops immediately; three NONE outcomes return NONE; three ordinary UNKNOWN outcomes return the last diagnostic UNKNOWN; no child calls when all preparation fails. Assert each child's serial occurs once. |
| Discovery mixed exhaustion | NONE followed by only proxy failures returns NONE; any executed UNKNOWN with no FOUND returns UNKNOWN even when other children returned NONE. |
| Stop/fatal guards | In each global function, stop already set prevents preparation; stop during preparation prevents child start; returned cancellation prevents remaining devices; INTERNAL_PROGRAM_ERROR is not retried. Precheck exclusion added between candidates or during preparation prevents subsequent child work. |
| Integration | Exercise `process_watchlist_target` with the real global precheck and mocked child/proxy/pipeline interfaces: OFFLINE, OFFLINE, LIVE launches the pipeline once with the complete action-device list; all OFFLINE/UNKNOWN never launches it. Removal/exclusion after positive checking still suppresses the pipeline. |
| Discovery handoff | Exercise `process_single_live_discovery` with mocked discovery and `process_watchlist_target`: FOUND delegates once with `preconfirmed_live.status == "LIVE"` and `require_watchlist_membership=False`; no extra global precheck is called; NONE/UNKNOWN/excluded FOUND do not delegate. Check cleanup still occurs once. |
| Timing/records | With a controlled monotonic clock, aggregate proxy time equals only preparation intervals, workflow time equals all invoked children's durations, and wall duration includes the whole operation. Speed-history calls receive individual durations only. Attempt records distinguish preparation failures from executed children and stop at early success. |
| JSON/log output | Existing precheck keys remain; attempts serialize to JSON with rounded timings and correct decision rule; discovery summary is written for FOUND/NONE/UNKNOWN before delegation/return; timeout stage survives an aggregated UNKNOWN; success does not retain a prior failure code. |

Retain the existing round-trigger tests and all normal-worker, proxy, cleanup, identity, overlay, and timeout regressions. Rename `test_exactly_one_first_available_device_performs_initial_check` to describe first-selected-device LIVE early exit; its one-child assertion remains correct. Existing discovery NONE-to-next-device tests remain valid under controlled random ordering.

Run from the repository root:

```powershell
python -B -m unittest discover -s tests -p 'test_*.py'
```

Completion requires the existing 149 tests plus the added cases to pass, no repeated device within one precheck/discovery invocation, no fourth candidate, and no changes outside the five-file implementation scope. Validate through mocked workflows; starting the production reporting monitor is not part of this implementation check.
