OTOMASI TIKTOK LIVE - IN-APP SEARCH + LAZY PROXY VALIDATION
===========================================================

Arsitektur navigasi
-------------------
Program tidak memakai Android VIEW, browser, deep link LIVE, atau website
checker untuk memasuki target. URL LIVE tetap didukung hanya sebagai format
watchlist, parsing username, identitas, dan logging.

Alur navigasi aktif:
1. Buka aplikasi TikTok secara normal.
2. Tekan Search berdasarkan accessibility/text semantik.
3. Masukkan username tanpa @ dan pilih tab Users.
4. Periksa kandidat username kanonik yang terlihat secara terbatas.
5. Pilih exact username bila ada; jika tidak, pilih user result teratas #1.
6. Tekan avatar yang berasosiasi dengan row terpilih.
7. Klasifikasikan tujuan sebagai LIVE, OFFLINE, atau UNKNOWN.
8. Verifikasi identitas akhir. Fallback tidak pernah melewati guard identitas.

LIVE precheck
-------------
Setiap target dapat diperiksa maksimal tiga kali, satu kali pada masing-masing
device TCP yang berbeda. Device model tercepat di `checker_preferred_models`
(default `SM-F721U1`) dipilih lebih dahulu dalam urutan acak baru untuk setiap
target; device lain diacak lalu diprioritaskan dengan riwayat waktu checker bila
tersedia. Satu hasil LIVE yang terverifikasi sudah cukup untuk menjalankan
workflow normal, walaupun checker lain sebelumnya melaporkan OFFLINE atau
UNKNOWN. Precheck berhenti setelah klasifikasi dan verifikasi identitas; ia
tidak menunggu lima detik, tidak menutup verification overlay, tidak membuka
menu report, dan tidak menjalankan action downstream.

Sesudah satu round menghasilkan tepat satu target watchlist LIVE, discovery
`mobile legend` juga memakai maksimal tiga device berbeda dengan satu attempt
per device. Discovery berhenti segera setelah satu device menemukan LIVE yang
valid, lalu melanjutkan workflow normal yang sama tanpa precheck kedua.

Normal worker
-------------
Setiap worker melakukan Search secara independen. Setelah LIVE dan identitas
broadcaster terverifikasi, worker menunggu tepat satu kali selama 5 detik.
Sesudah itu worker memeriksa verification overlay satu kali:

- tidak ada overlay: lanjut;
- overlay dikenali dan Close aman ditemukan: klik Close satu kali, lalu pastikan
  overlay hilang;
- overlay tidak dapat ditutup: berhenti fail-closed dengan kode VERIFY_*.

Program tidak memecahkan CAPTCHA atau berinteraksi dengan jawaban challenge.
OFFLINE, identity mismatch, dan UNKNOWN berhenti sebelum action/report.

Selector Search
---------------
Prioritas selector adalah accessibility/content-description, visible text,
resource ID yang benar-benar ditemukan di diagnostics, class/state, hierarchy,
clickable ancestor, lalu geometri relatif row/avatar. Tidak ada database
koordinat per-device. Resource ID verification `verify-bar-close` berasal dari
diagnostics project; resource ID Search baru tidak direka.

Setiap LIVE precheck dan report workflow selalu memulai TikTok dari state bersih.
Walaupun TikTok sudah foreground dan Search/Cari usable, workflow tidak mereuse
session lama: app_start(stop=True) selalu force-stop TikTok lalu cold-start baru.
Bounded polling tetap dipakai tanpa fixed startup sleep. Jika cold-start belum
usable, hanya satu bounded app_start(stop=True) recovery yang dipertahankan.
Setelah task selesai (success, OFFLINE/skip, failure, timeout, atau cancel), TikTok
selalu di-force-stop agar username berikutnya tidak mewarisi state sebelumnya.

Proxy
-----
Proxy tetap authenticated IPv4 HTTP CONNECT. Startup tidak lagi menunggu full
pool health sweep. Validasi dilakukan secara lazy ketika proxy dipakai:

proxy acak -> ADB reverse -> synthetic CONNECT ke www.tiktok.com:443 ->
target spesifik dikonfirmasi relay -> worker langsung lanjut.

Deadline konfirmasi maksimal dua detik adalah batas atas, bukan sleep tetap.
Konfirmasi yang datang lebih cepat langsung diterima. Traffic background ke
target lain tidak dapat membuat probe PASS. Proxy yang gagal dikarantina
sementara dari active selection, proxy lain dipilih secara acak, dan
proxy_list.txt tidak pernah dihapus/ditulis ulang akibat kegagalan sementara.
Fail-closed tetap aktif.

Watchlist dan exclusion
-----------------------
Satu target per baris di list_urls.txt. Format yang diterima:

@username
username
https://www.tiktok.com/@username/live

Baris kosong, komentar #, duplikat, dan baris invalid diabaikan tanpa mengubah
file. list_urls.txt dibaca ulang setiap round. excluded_lists.txt diperiksa
sebelum precheck, setelah precheck, dan di setiap child worker.

Timing yang dipertahankan
-------------------------
- watchlist_poll_interval_seconds: 0.5 detik saat watchlist kosong.
- live_precheck_timeout_seconds: satu hard deadline child precheck, 100 detik.
- Semua stage Search precheck memakai satu shared remaining-time budget; inner
  workflow berhenti sekitar 79 detik agar outer hard deadline 80 detik masih
  memiliki waktu untuk menyimpan result/diagnostics. Stage berikutnya tidak
  mendapat timeout baru ketika budget keseluruhan hampir habis.
- worker_job_timeout_seconds: hard deadline worker, 130 detik.
- selector/poll/postcondition timing existing tetap bounded.
- lifecycle round, success/failure, watchlist, dan maintenance yang sudah ada
  tidak dihapus atau didesain ulang.
- tidak ada fixed LIVE stabilization sleep. Normal worker lanjut segera setelah
  state/selector membuktikan Report benar-benar siap dan tidak diblokir overlay.

Konfigurasi proxy utama
-----------------------
- proxy_startup_health_check=false: tidak ada mandatory full sweep.
- proxy_confirmation_deadline_seconds=2: deadline target CONNECT.
- proxy_assignment_max_attempts=3: maksimum proxy per device/assignment.
- checker_max_devices=3: maksimum device berbeda untuk satu LIVE precheck atau
  discovery. Device yang gagal proxy tetap memakai satu slot dan tidak diganti
  device keempat pada operasi yang sama.
- proxy_health_cache_seconds hanya dipakai oleh health sweep opsional/diagnostik;
  tidak mengontrol eligibility assignment normal.
- Pada awal setiap watchlist round, semua proxy di proxy_list.txt eligible lagi.
  Genuine failure di-skip hanya sampai round tersebut selesai, lalu random
  replacement dipilih dengan batas proxy_assignment_max_attempts.
- proxy_parallel_setup dan max_parallel tetap membatasi concurrency.

Menjalankan
-----------
1. Pastikan perangkat TCP authorized terlihat sebagai `device` pada adb devices.
2. Isi proxy_list.txt dengan IP:PORT:USERNAME:PASSWORD.
3. Kelola target di list_urls.txt dan exclusion di excluded_lists.txt.
4. Jalankan RUN_LOOP.bat.
5. Tekan ENTER untuk shutdown aman.

Pengujian
---------
python -m unittest discover -s tests -p "test_*.py"

Diagnostics failure mencakup serial, stage, username, package/activity, XML,
Search candidates, selected result/fallback, observed identity, verification
nodes, proxy redacted, CONNECT target/timing, relay state, alasan, dan screenshot
bila tersedia. Log sukses 24/7 tetap ringkas.
