@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"
title TikTok LIVE Circular Watchlist Automation
cls

echo ============================================================
echo       TIKTOK LIVE IN-APP SEARCH WATCHLIST AUTOMATION
echo ============================================================
echo Watchlist      : list_urls.txt (persistent, circular)
echo Exclusions     : excluded_lists.txt
echo Reporting pool : configurable in loop_config.json (default 40)
echo Proxy validation: lazy randomized on-use HTTP CONNECT
echo Worker deadline: 130 seconds
echo LIVE precheck  : up to 3 random fast devices; any LIVE starts workflow
echo Navigation     : TikTok Search - Users - avatar (no direct LIVE URL)
echo Runtime        : 24/7, zero workflow retries, no cooldown
echo Stop safely    : press ENTER
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found in PATH.
    pause
    exit /b 1
)

python -c "import uiautomator2" >nul 2>nul
if errorlevel 1 (
    echo [SETUP] Installing uiautomator2...
    python -m pip install -U uiautomator2
    if errorlevel 1 (
        echo [ERROR] uiautomator2 installation failed.
        pause
        exit /b 1
    )
)

python "%~dp0loop_runner.py"
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" (
    echo.
    echo [ERROR] Program exited with code %CODE%.
    pause
)
exit /b %CODE%
