#!/usr/bin/env python3
"""24/7 circular-watchlist, fail-fast TikTok LIVE report orchestrator.

The runtime monitors the permanent ``list_urls.txt`` watchlist, checks each
target on up to three distinct fast devices, and starts the existing farm after
any device confirms LIVE. Reporting keeps bounded streaming proxy preparation,
one workflow attempt per device, and a killable child-process deadline.
"""

from __future__ import annotations

import concurrent.futures
import copy
import json
import os
import random
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlparse

from proxy_manager import ProxyManager
from settings import load_report_catalog, load_runtime_settings, load_workflow_config
from _shared.device_control import device_control_lease, stop_our_uiautomator_processes


def configure_utf8_streams() -> None:
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="backslashreplace")
            except (OSError, ValueError):
                pass


configure_utf8_streams()

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "loop_config.json"
RUNTIME_ROOT = BASE_DIR / ".runtime"
SETTINGS = load_runtime_settings(CONFIG_FILE)
CONFIG = SETTINGS.values
ADB_EXECUTABLE = str(CONFIG["adb_executable"])
REPORT_TYPES_FILE = SETTINGS.path("report_types_file", "report_types.json")
WORKFLOW_DEFAULTS_FILE = SETTINGS.path(
    "workflow_defaults_file", "_shared/workflow_defaults.json"
)
ACTIONS = load_report_catalog(REPORT_TYPES_FILE, BASE_DIR)

STOP_EVENT = threading.Event()
PRINT_LOCK = threading.Lock()
PROCESS_LOCK = threading.Lock()
PROCESS_TERMINATION_LOCK = threading.Lock()
ACTIVE_PROCESSES: set[subprocess.Popen[str]] = set()
SUCCESS_LOG_LOCK = threading.Lock()
FORCED_CLEANUP_LOCK = threading.Lock()
FORCED_CLEANUP_DONE: set[str] = set()
ACTIVE_REPORT_JOBS = 0
ACTIVE_REPORT_JOBS_LOCK = threading.Lock()
REPORT_JOBS_IDLE = threading.Event()
REPORT_JOBS_IDLE.set()
DEVICE_MODEL_HINTS: dict[str, str] = {}
DEVICE_MODEL_HINTS_LOCK = threading.Lock()
CHECKER_SPEED_SECONDS: dict[str, float] = {}
CHECKER_SPEED_LOCK = threading.Lock()


def safe_print(message: str = "", *, flush: bool = False) -> None:
    with PRINT_LOCK:
        print(message, flush=flush)


def filesystem_safe(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return cleaned[:100] or "unknown"


def resolve_config_path(config: dict[str, Any], key: str, default: str) -> Path:
    value = Path(str(config.get(key, default)))
    return value if value.is_absolute() else BASE_DIR / value


def atomic_write_text(path: Path, text: str) -> None:
    """Replace a text file atomically with no in-place corruption window."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def normalize_live_candidate(value: str) -> str | None:
    """Normalize a TikTok username or canonical LIVE URL.

    ``None`` means blank/comment; an empty string means invalid input.
    """
    raw = value.strip()
    if not raw or raw.startswith("#"):
        return None
    raw = re.split(r"\s+#", raw, maxsplit=1)[0].strip()
    if not raw:
        return None

    if raw.casefold().startswith(("http://", "https://")):
        try:
            parsed = urlparse(raw)
        except ValueError:
            return ""
        host = (parsed.hostname or "").casefold()
        if host not in {"tiktok.com", "www.tiktok.com", "m.tiktok.com"}:
            return ""
        match = re.fullmatch(r"/@([^/?#]+)/live/?", parsed.path)
        if not match:
            return ""
        username = match.group(1)
    else:
        username = raw.lstrip("@").strip().strip("/")

    username = username.split("?", 1)[0].split("#", 1)[0].strip()
    if not re.fullmatch(r"[A-Za-z0-9._]{2,32}", username):
        return ""
    return f"https://www.tiktok.com/@{username}/live"


def target_key(live_url: str) -> str:
    normalized = normalize_live_candidate(live_url)
    return (normalized or live_url.strip().rstrip("/")).casefold()


def validate_live_url(live_url: str) -> bool:
    return bool(normalize_live_candidate(live_url))


def username_from_url(live_url: str) -> str:
    normalized = normalize_live_candidate(live_url) or ""
    match = re.search(r"/@([A-Za-z0-9._]+)/live$", normalized)
    return match.group(1) if match else "unknown"


class ExclusionList:
    """Cheap mtime-cached exclusion reader with explicit forced refreshes."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._signature: tuple[int, int] | None = None
        self._keys: set[str] = set()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    def keys(self, *, force: bool = False) -> set[str]:
        with self._lock:
            try:
                stat = self.path.stat()
                signature = (stat.st_mtime_ns, stat.st_size)
            except FileNotFoundError:
                self.path.touch(exist_ok=True)
                signature = (0, 0)
            if force or signature != self._signature:
                values: set[str] = set()
                for raw in self.path.read_text(
                    encoding="utf-8-sig", errors="replace"
                ).splitlines():
                    normalized = normalize_live_candidate(raw)
                    if normalized:
                        values.add(target_key(normalized))
                self._keys = values
                self._signature = signature
            return set(self._keys)

    def contains(self, live_url: str) -> bool:
        return target_key(live_url) in self.keys(force=True)


@dataclass(frozen=True)
class WatchlistSnapshot:
    targets: tuple[str, ...]
    invalid_count: int = 0
    duplicate_count: int = 0


class LiveWatchlist:
    """Read-only, file-ordered target watchlist reloaded for every round."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._last_snapshot = WatchlistSnapshot(())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    def read_snapshot(self) -> WatchlistSnapshot:
        """Read and normalize without ever rewriting the user-managed file."""
        with self._lock:
            try:
                raw_text = self.path.read_text(
                    encoding="utf-8-sig", errors="replace"
                )
            except FileNotFoundError:
                snapshot = WatchlistSnapshot(())
                self._last_snapshot = snapshot
                return snapshot
            except OSError:
                # A transient editor/save race must not invalidate the round
                # snapshot already in use by the dispatcher.
                return self._last_snapshot

            targets: list[str] = []
            seen: set[str] = set()
            invalid_count = 0
            duplicate_count = 0
            for raw in raw_text.splitlines():
                normalized = normalize_live_candidate(raw)
                if normalized is None:
                    continue
                if normalized == "":
                    invalid_count += 1
                    continue
                key = target_key(normalized)
                if key in seen:
                    duplicate_count += 1
                    continue
                seen.add(key)
                targets.append(normalized)

            snapshot = WatchlistSnapshot(
                targets=tuple(targets),
                invalid_count=invalid_count,
                duplicate_count=duplicate_count,
            )
            self._last_snapshot = snapshot
            return snapshot

    def contains(self, live_url: str) -> bool:
        expected = target_key(live_url)
        return any(
            target_key(candidate) == expected
            for candidate in self.read_snapshot().targets
        )

    def wait_for_round(
        self, poll_seconds: float
    ) -> tuple[WatchlistSnapshot | None, float]:
        started = time.monotonic()
        while not STOP_EVENT.is_set():
            snapshot = self.read_snapshot()
            if snapshot.targets:
                return snapshot, time.monotonic() - started
            STOP_EVENT.wait(poll_seconds)
        return None, time.monotonic() - started


class SingleInstanceLock:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.handle: Any = None

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            handle.close()
            raise SystemExit("Another loop_runner.py instance owns the runtime lock") from exc
        handle.seek(1)
        handle.truncate()
        handle.write(f"pid={os.getpid()}\n".encode("ascii"))
        handle.flush()
        self.handle = handle

    def release(self) -> None:
        handle = self.handle
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        finally:
            handle.close()
            self.handle = None


class RuntimeMaintenance:
    """Low-frequency bounded log retention for stable 24/7 operation."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.interval = float(config.get("maintenance_interval_seconds", 3600))
        self.retention_seconds = float(config.get("log_retention_days", 3)) * 86400
        self.max_bytes = int(config.get("log_retention_max_total_mb", 2048)) * 1024 * 1024
        self.roots = [
            resolve_config_path(config, "cycle_logs_root", "cycle_logs"),
            resolve_config_path(config, "failed_logs_root", "failed_logs"),
            resolve_config_path(config, "success_logs_root", "success_logs"),
        ]
        self.next_run = time.monotonic() + max(60.0, self.interval)

    def run_if_due(self, *, force: bool = False) -> None:
        if not force and (self.interval <= 0 or time.monotonic() < self.next_run):
            return
        self.next_run = time.monotonic() + max(60.0, self.interval)
        cutoff = time.time() - self.retention_seconds
        files: list[Path] = []
        for root in self.roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                try:
                    if path.stat().st_mtime < cutoff:
                        path.unlink()
                    else:
                        files.append(path)
                except OSError:
                    continue
        sized: list[tuple[float, int, Path]] = []
        for path in files:
            try:
                stat = path.stat()
                sized.append((stat.st_mtime, stat.st_size, path))
            except OSError:
                pass
        total = sum(size for _mtime, size, _path in sized)
        # Files touched in the current maintenance interval can belong to the
        # active cycle. Never remove them merely to satisfy the size cap.
        protected_after = time.time() - max(3600.0, self.interval * 2)
        for _mtime, size, path in sorted(sized):
            if total <= self.max_bytes:
                break
            if _mtime >= protected_after:
                continue
            try:
                path.unlink()
                total -= size
            except OSError:
                pass
        for root in self.roots:
            if not root.exists():
                continue
            directories = sorted(
                (path for path in root.rglob("*") if path.is_dir()),
                key=lambda path: len(path.parts),
                reverse=True,
            )
            for directory in directories:
                try:
                    directory.rmdir()
                except OSError:
                    pass


def is_tcp_serial(serial: str) -> bool:
    value = serial.strip()
    if not value or value.startswith("emulator-"):
        return False
    if "._adb-tls-connect._tcp" in value:
        return True
    if ":" not in value:
        return False
    host, port = value.rsplit(":", 1)
    return bool(host and port.isdigit() and 1 <= int(port) <= 65535)


def validate_adb_host(config: dict[str, Any]) -> None:
    """Validate the shared ADB executable once, never in child workers."""
    executable = str(config.get("adb_executable", "adb"))
    try:
        result = subprocess.run(
            [executable, "version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(config.get("adb_host_timeout_seconds", 15)),
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit(f"ADB host validation failed: {exc}") from exc
    if result.returncode != 0:
        raise SystemExit((result.stderr or result.stdout or "adb version failed").strip())


def _parse_connected_tcp_devices(output: str) -> list[str]:
    """Parse authorized TCP devices while retaining model hints for checkers."""
    serials: list[str] = []
    seen: set[str] = set()
    for raw in output.splitlines():
        parts = raw.split()
        if len(parts) < 2 or parts[1] != "device":
            continue
        serial = parts[0]
        if is_tcp_serial(serial) and serial not in seen:
            seen.add(serial)
            serials.append(serial)
            model = ""
            for token in parts[2:]:
                if token.startswith("model:"):
                    model = token.partition(":")[2].replace("_", "-").strip()
                    break
            if model:
                with DEVICE_MODEL_HINTS_LOCK:
                    DEVICE_MODEL_HINTS[serial] = model
    return serials


def _run_adb_device_enumeration(values: dict[str, Any]) -> list[str]:
    try:
        result = subprocess.run(
            [str(values.get("adb_executable", "adb")), "devices", "-l"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(values.get("device_refresh_timeout_seconds", 15)),
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(f"adb devices failed: {exc}") from exc
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "adb devices failed").strip())
    return _parse_connected_tcp_devices(result.stdout)


def refresh_connected_tcp_devices(config: dict[str, Any] | None = None) -> list[str]:
    """Compatibility entry point for one uncached ADB device enumeration."""
    return _run_adb_device_enumeration(CONFIG if config is None else config)


class AdbHostUnavailable(RuntimeError):
    """Raised only when an ADB wait is cancelled during runner shutdown."""


@dataclass
class AdbHealthSnapshot:
    state: str = "HEALTHY"
    adb_executable: str = ""
    server_port: int = 5037
    server_pid: int | None = None
    connected_devices: int = 0
    consecutive_failures: int = 0
    last_success_at: str | None = None
    outage_started_at: str | None = None
    last_error: str | None = None
    last_command_seconds: float | None = None
    next_retry_at: str | None = None


class AdbHostSupervisor:
    """Serialize, cache, and recover access to the shared host ADB server."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.executable = str(config.get("adb_executable", "adb"))
        self.port = int(config.get("adb_server_port", 5037))
        self.cache_seconds = float(config.get("adb_device_cache_seconds", 10))
        self.failure_threshold = int(config.get("adb_failure_threshold", 3))
        self.first_retry_seconds = float(config.get("adb_first_retry_seconds", 5))
        self.second_retry_seconds = float(config.get("adb_second_retry_seconds", 15))
        self.cooldown_seconds = float(config.get("adb_recovery_cooldown_seconds", 60))
        self.start_settle_seconds = float(config.get("adb_server_start_settle_seconds", 5))
        self.stable_interval_seconds = float(
            config.get("adb_health_stable_interval_seconds", 2)
        )
        self.no_devices_retry_seconds = float(config.get("adb_no_devices_retry_seconds", 30))
        self.command_timeout = float(config.get("device_refresh_timeout_seconds", 15))
        self.state_file = resolve_config_path(
            config, "adb_health_state_file", "state/adb_health.json"
        )
        self._lock = threading.RLock()
        self._cached_devices: list[str] = []
        self._cache_time = 0.0
        self._outage_started_monotonic: float | None = None
        self._cooldown_until = 0.0
        self._last_command_seconds: float | None = None
        self.snapshot = AdbHealthSnapshot(
            adb_executable=self.executable,
            server_port=self.port,
        )
        self._write_snapshot()

    @staticmethod
    def _timestamp() -> str:
        return datetime.now().astimezone().isoformat(timespec="seconds")

    @staticmethod
    def _future_timestamp(seconds: float) -> str:
        return datetime.fromtimestamp(time.time() + seconds).astimezone().isoformat(
            timespec="seconds"
        )

    def _write_snapshot(self) -> None:
        try:
            atomic_write_text(
                self.state_file,
                json.dumps(asdict(self.snapshot), indent=2, sort_keys=True) + "\n",
            )
        except OSError as exc:
            safe_print(f"[ADB] health-state write failed | error={exc}")

    def _record(
        self,
        state: str,
        *,
        error: str | None = None,
        retry_seconds: float | None = None,
        message: str | None = None,
        always_log: bool = False,
    ) -> None:
        changed = self.snapshot.state != state
        self.snapshot.state = state
        self.snapshot.connected_devices = len(self._cached_devices)
        self.snapshot.last_error = error
        self.snapshot.last_command_seconds = self._last_command_seconds
        self.snapshot.next_retry_at = (
            self._future_timestamp(retry_seconds) if retry_seconds is not None else None
        )
        self._write_snapshot()
        if message and (changed or always_log):
            safe_print(message)

    def _wait(self, seconds: float) -> bool:
        """Return false when shutdown interrupts the requested wait."""
        return not STOP_EVENT.wait(max(0.0, seconds))

    def _mark_healthy(self, devices: list[str]) -> None:
        previous_state = self.snapshot.state
        previous_failures = self.snapshot.consecutive_failures
        downtime = (
            time.monotonic() - self._outage_started_monotonic
            if self._outage_started_monotonic is not None
            else 0.0
        )
        self._cached_devices = list(devices)
        self._cache_time = time.monotonic()
        self._cooldown_until = 0.0
        self._outage_started_monotonic = None
        self.snapshot.state = "HEALTHY"
        self.snapshot.connected_devices = len(devices)
        self.snapshot.consecutive_failures = 0
        self.snapshot.last_success_at = self._timestamp()
        self.snapshot.outage_started_at = None
        self.snapshot.last_error = None
        self.snapshot.last_command_seconds = self._last_command_seconds
        self.snapshot.next_retry_at = None
        if self.snapshot.server_pid is None:
            self.snapshot.server_pid = self._server_listener_pid()
        self._write_snapshot()
        if previous_state != "HEALTHY" or previous_failures:
            safe_print(
                f"[ADB] HEALTHY | devices={len(devices)} | downtime={downtime:.1f}s"
            )

    def _mark_failure(self, error: str) -> int:
        if self._outage_started_monotonic is None:
            self._outage_started_monotonic = time.monotonic()
            self.snapshot.outage_started_at = self._timestamp()
        self.snapshot.consecutive_failures += 1
        return self.snapshot.consecutive_failures

    def _enumerate_devices(self) -> list[str]:
        started = time.monotonic()
        try:
            return _run_adb_device_enumeration(self.config)
        finally:
            self._last_command_seconds = time.monotonic() - started

    def get_devices(self, *, force: bool = False) -> list[str]:
        """Return a healthy device snapshot, repairing ADB instead of skipping targets."""
        with self._lock:
            while not STOP_EVENT.is_set():
                if (
                    not force
                    and self._cache_time > 0
                    and time.monotonic() - self._cache_time < self.cache_seconds
                ):
                    return list(self._cached_devices)
                force = True
                if self._cooldown_until > time.monotonic():
                    remaining = self._cooldown_until - time.monotonic()
                    if not self._wait(remaining):
                        break
                try:
                    devices = self._enumerate_devices()
                except RuntimeError as exc:
                    error = str(exc)
                    failures = self._mark_failure(error)
                    if failures < self.failure_threshold:
                        delay = (
                            self.first_retry_seconds
                            if failures == 1
                            else self.second_retry_seconds
                        )
                        self._record(
                            "RETRYING",
                            error=error,
                            retry_seconds=delay,
                            message=(
                                f"[ADB] RETRYING | failure={failures}/{self.failure_threshold}"
                                f" | retry_in={delay:g}s"
                                f" | elapsed={self._last_command_seconds or 0.0:.1f}s"
                                f" | error={error}"
                            ),
                            always_log=True,
                        )
                        if not self._wait(delay):
                            break
                        continue
                    if self.recover_server():
                        if self._cached_devices:
                            return list(self._cached_devices)
                        continue
                    continue

                if not devices:
                    self._cached_devices = []
                    self._cache_time = 0.0
                    self.snapshot.consecutive_failures = 0
                    self._outage_started_monotonic = None
                    self.snapshot.outage_started_at = None
                    self._record(
                        "NO_DEVICES",
                        retry_seconds=self.no_devices_retry_seconds,
                        message=(
                            f"[ADB] NO_DEVICES | retry_in={self.no_devices_retry_seconds:g}s"
                        ),
                    )
                    if not self._wait(self.no_devices_retry_seconds):
                        break
                    continue

                self._mark_healthy(devices)
                return list(devices)
        raise AdbHostUnavailable("ADB device wait cancelled during shutdown")

    def _run_adb_control(self, argument: str) -> subprocess.CompletedProcess[str]:
        try:
            result = subprocess.run(
                [self.executable, argument],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.command_timeout,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError(f"adb {argument} failed: {exc}") from exc
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or f"adb {argument} failed").strip()
            raise RuntimeError(detail)
        return result

    def _probe_server(self) -> bool:
        request = b"host:version"
        frame = f"{len(request):04x}".encode("ascii") + request
        try:
            with socket.create_connection(("127.0.0.1", self.port), timeout=2.0) as client:
                client.settimeout(2.0)
                client.sendall(frame)
                return client.recv(4) == b"OKAY"
        except OSError:
            return False

    def _server_listener_pid(self) -> int | None:
        if os.name != "nt":
            return None
        try:
            result = subprocess.run(
                ["netstat", "-ano", "-p", "tcp"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=5.0,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        if result.returncode != 0:
            return None
        expected_port = str(self.port)
        for raw in result.stdout.splitlines():
            parts = raw.split()
            if len(parts) < 5 or parts[-2].upper() != "LISTENING":
                continue
            if parts[1].rsplit(":", 1)[-1] != expected_port or not parts[-1].isdigit():
                continue
            pid = int(parts[-1])
            try:
                check = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=5.0,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                return None
            first_line = check.stdout.splitlines()[0].strip() if check.stdout.splitlines() else ""
            if check.returncode == 0 and first_line.casefold().startswith('"adb.exe",'):
                return pid
        return None

    def _terminate_server_listener(self, pid: int) -> None:
        result = subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10.0,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "targeted taskkill failed").strip()
            raise RuntimeError(detail)

    def _wait_for_report_jobs(self, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while not STOP_EVENT.is_set():
            if REPORT_JOBS_IDLE.wait(timeout=min(0.25, max(0.0, deadline - time.monotonic()))):
                return True
            if time.monotonic() >= deadline:
                return False
        return False

    def _confirm_stable(self, first_devices: list[str] | None = None) -> list[str]:
        first = self._enumerate_devices() if first_devices is None else first_devices
        if not self._wait(self.stable_interval_seconds):
            raise AdbHostUnavailable("ADB stability check cancelled during shutdown")
        second = self._enumerate_devices()
        return second if second else first

    def _enter_cooldown(self, error: str) -> bool:
        self._cooldown_until = time.monotonic() + self.cooldown_seconds
        self._record(
            "COOLDOWN",
            error=error,
            retry_seconds=self.cooldown_seconds,
            message=(
                f"[ADB] COOLDOWN | recovery_failed | retry_in={self.cooldown_seconds:g}s"
                f" | error={error}"
            ),
            always_log=True,
        )
        return False

    def recover_server(self) -> bool:
        """Recover only the port-5037 server and never kill every adb.exe process."""
        with self._lock:
            if not self._wait_for_report_jobs(45.0):
                return self._enter_cooldown("active report jobs did not become idle within 45s")
            if STOP_EVENT.is_set():
                raise AdbHostUnavailable("ADB recovery cancelled during shutdown")

            downtime = (
                time.monotonic() - self._outage_started_monotonic
                if self._outage_started_monotonic is not None
                else 0.0
            )
            self._record(
                "RECOVERING",
                error=self.snapshot.last_error,
                message=f"[ADB] RECOVERING | downtime={downtime:.1f}s | active_jobs=0",
            )
            socket_healthy = self._probe_server()
            safe_print(
                f"[ADB] RECOVERING | server_socket="
                f"{'responsive' if socket_healthy else 'unresponsive'}"
                f" | executable={self.executable}"
            )

            try:
                final_devices = self._enumerate_devices()
                stable_devices = self._confirm_stable(final_devices)
            except AdbHostUnavailable:
                raise
            except RuntimeError:
                stable_devices = None
            if stable_devices:
                self._mark_healthy(stable_devices)
                return True
            if stable_devices == []:
                self._cached_devices = []
                self._cache_time = 0.0
                self.snapshot.consecutive_failures = 0
                self._record("NO_DEVICES", retry_seconds=self.no_devices_retry_seconds)
                return True

            old_pid = self._server_listener_pid()
            kill_error = ""
            try:
                self._run_adb_control("kill-server")
            except RuntimeError as exc:
                kill_error = str(exc)
            if not self._wait(1.0):
                raise AdbHostUnavailable("ADB recovery cancelled during shutdown")
            remaining_pid = self._server_listener_pid()
            if remaining_pid is not None:
                try:
                    self._terminate_server_listener(remaining_pid)
                except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                    return self._enter_cooldown(
                        f"{kill_error}; targeted server termination failed: {exc}".strip("; ")
                    )

            try:
                self._run_adb_control("start-server")
                if not self._wait(self.start_settle_seconds):
                    raise AdbHostUnavailable("ADB recovery cancelled during shutdown")
                stable_devices = self._confirm_stable()
            except AdbHostUnavailable:
                raise
            except RuntimeError as exc:
                return self._enter_cooldown(str(exc))

            self.snapshot.server_pid = self._server_listener_pid()
            safe_print(
                f"[ADB] SERVER_RESTARTED | old_pid={old_pid or 'unknown'}"
                f" | executable={self.executable}"
            )
            if stable_devices:
                self._mark_healthy(stable_devices)
                return True

            self._cached_devices = []
            self._cache_time = 0.0
            self.snapshot.consecutive_failures = 0
            self._outage_started_monotonic = None
            self.snapshot.outage_started_at = None
            self._record(
                "NO_DEVICES",
                retry_seconds=self.no_devices_retry_seconds,
                message=(
                    f"[ADB] NO_DEVICES | retry_in={self.no_devices_retry_seconds:g}s"
                ),
            )
            return True


def _connected_devices_for_work(
    config: dict[str, Any],
    adb_supervisor: AdbHostSupervisor | None,
    *,
    force: bool = False,
) -> list[str]:
    if adb_supervisor is not None:
        return adb_supervisor.get_devices(force=force)
    try:
        return refresh_connected_tcp_devices(config)
    except RuntimeError as exc:
        raise AdbHostUnavailable(str(exc)) from exc


def normalize_checker_model(value: object) -> str:
    return str(value).replace("_", "-").strip().casefold()


def ordered_checker_candidates(config: dict[str, Any], serials: list[str]) -> list[str]:
    """Randomize preferred fast models, then use measured fallback speed.

    ``adb devices -l`` already exposes model hints, so this adds no extra ADB
    round trip. Each call produces a fresh order without repeating a serial.
    """
    unique_serials = list(dict.fromkeys(str(serial) for serial in serials))
    preferred_raw = config.get("checker_preferred_models", [])
    if isinstance(preferred_raw, str):
        preferred = [preferred_raw]
    elif isinstance(preferred_raw, list):
        preferred = [str(value) for value in preferred_raw]
    else:
        preferred = []
    preferred_keys = list(
        dict.fromkeys(
            normalize_checker_model(value) for value in preferred if str(value).strip()
        )
    )
    with DEVICE_MODEL_HINTS_LOCK:
        models = {
            serial: normalize_checker_model(model)
            for serial, model in DEVICE_MODEL_HINTS.items()
        }
    use_speed_history = bool(config.get("checker_use_speed_history", False))
    with CHECKER_SPEED_LOCK:
        speeds = dict(CHECKER_SPEED_SECONDS) if use_speed_history else {}

    remaining = list(unique_serials)
    ordered: list[str] = []
    for preferred_model in preferred_keys:
        group = [serial for serial in remaining if models.get(serial, "") == preferred_model]
        random.shuffle(group)
        ordered.extend(group)
        selected = set(group)
        remaining = [serial for serial in remaining if serial not in selected]

    random.shuffle(remaining)
    if use_speed_history:
        remaining.sort(key=lambda serial: speeds.get(serial, float("inf")))
    ordered.extend(remaining)
    return ordered


def remember_checker_speed(serial: str, workflow_seconds: float) -> None:
    if not serial or workflow_seconds <= 0:
        return
    with CHECKER_SPEED_LOCK:
        previous = CHECKER_SPEED_SECONDS.get(serial)
        CHECKER_SPEED_SECONDS[serial] = workflow_seconds if previous is None else (previous * 0.7 + workflow_seconds * 0.3)


class DeviceMetadataCache:
    """In-memory per-serial cache populated by each device's first worker."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._values: dict[str, dict[str, Any]] = {}

    def get(self, serial: str) -> dict[str, Any]:
        with self._lock:
            return dict(self._values.get(serial, {}))

    def update(self, serial: str, metadata: dict[str, Any]) -> None:
        if not metadata or not metadata.get("tiktok_package"):
            return
        with self._lock:
            self._values[serial] = dict(metadata)


DEVICE_CACHE = DeviceMetadataCache()
WORKFLOW_CONFIG_CACHE: dict[str, dict[str, Any]] = {}
WORKFLOW_CONFIG_LOCK = threading.Lock()


def workflow_template(action_choice: str) -> dict[str, Any]:
    with WORKFLOW_CONFIG_LOCK:
        cached = WORKFLOW_CONFIG_CACHE.get(action_choice)
        if cached is None:
            project_dir = Path(ACTIONS[action_choice]["project_dir"])
            cached = load_workflow_config(
                project_dir / "config.json", WORKFLOW_DEFAULTS_FILE
            )
            WORKFLOW_CONFIG_CACHE[action_choice] = cached
        return copy.deepcopy(cached)


def build_worker_config(
    *,
    config: dict[str, Any],
    serial: str,
    live_url: str,
    action_choice: str,
    cycle_id: str,
    temp_job_root: Path,
    workflow_mode: str = "report",
    proxy_tiktok_proof_file: Path | None = None,
    search_query: str | None = None,
    parent_managed_cleanup: bool = False,
    worker_deadline_monotonic: float | None = None,
) -> Path:
    source = workflow_template(action_choice)
    metadata = DEVICE_CACHE.get(serial)
    source.update(
        {
            "adb_serial": serial,
            "adb_executable": str(config.get("adb_executable", "adb")),
            "adb_host_validated": True,
            "live_url": live_url,
            "report_action_id": action_choice,
            "report_type": str(ACTIONS[action_choice]["label"]),
            "workflow_mode": workflow_mode,
            "assignment_mode": "fixed",
            "require_confirmation_before_submit": False,
            "parent_managed_cleanup": bool(parent_managed_cleanup),
            "worker_deadline_monotonic": worker_deadline_monotonic,
            "diagnostics_enabled": bool(config.get("diagnostics_enabled", False)),
            "detailed_logging": bool(config.get("detailed_logging", False)),
            "live_precheck_timeout_seconds": float(
                config.get("live_precheck_timeout_seconds", 80)
            ),
            "excluded_lists_file": str(
                resolve_config_path(config, "excluded_lists_file", "excluded_lists.txt")
            ),
            "cached_device_metadata": metadata,
            "log_root": str(temp_job_root.resolve()),
            "proxy_require_tiktok_proof_before_submit": bool(
                workflow_mode == "report"
                and config.get("proxy_enabled", False)
                and config.get("proxy_verify_tiktok_traffic", False)
                and proxy_tiktok_proof_file is not None
            ),
            "proxy_tiktok_proof_file": (
                str(proxy_tiktok_proof_file.resolve())
                if proxy_tiktok_proof_file is not None
                else ""
            ),
            "proxy_submit_proof_timeout_seconds": float(
                config.get("proxy_submit_proof_timeout_seconds", 1.5)
            ),
            "proxy_early_proof_timeout_seconds": float(
                config.get("proxy_early_proof_timeout_seconds", 2.5)
            ),
        }
    )
    if search_query is not None:
        source["search_query"] = str(search_query).strip()
    if metadata.get("tiktok_package"):
        source["tiktok_package"] = metadata["tiktok_package"]
    directory = (
        RUNTIME_ROOT
        / cycle_id
        / "worker_configs"
        / filesystem_safe(username_from_url(live_url))
    )
    directory.mkdir(parents=True, exist_ok=True)
    mode_suffix = (
        "_CHECK" if workflow_mode == "live_precheck"
        else "_DISCOVERY" if workflow_mode == "live_discovery"
        else ""
    )
    path = directory / f"{filesystem_safe(serial)}_A{action_choice}{mode_suffix}.json"
    atomic_write_text(path, json.dumps(source, indent=2, ensure_ascii=False) + "\n")
    return path


def register_process(process: subprocess.Popen[str]) -> None:
    with PROCESS_LOCK:
        ACTIVE_PROCESSES.add(process)


def unregister_process(process: subprocess.Popen[str]) -> None:
    with PROCESS_LOCK:
        ACTIVE_PROCESSES.discard(process)


def register_report_job() -> None:
    global ACTIVE_REPORT_JOBS
    with ACTIVE_REPORT_JOBS_LOCK:
        ACTIVE_REPORT_JOBS += 1
        REPORT_JOBS_IDLE.clear()


def unregister_report_job() -> None:
    global ACTIVE_REPORT_JOBS
    with ACTIVE_REPORT_JOBS_LOCK:
        ACTIVE_REPORT_JOBS = max(0, ACTIVE_REPORT_JOBS - 1)
        if ACTIVE_REPORT_JOBS == 0:
            REPORT_JOBS_IDLE.set()


def terminate_worker_process_tree(process: subprocess.Popen[str]) -> None:
    """Terminate one timed-out worker and its transient ADB descendants."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        creationflags = (
            subprocess.CREATE_NO_WINDOW
            if hasattr(subprocess, "CREATE_NO_WINDOW")
            else 0
        )
        try:
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
                creationflags=creationflags,
            )
        except (OSError, subprocess.SubprocessError):
            pass
    else:
        try:
            process.terminate()
        except OSError:
            pass
    if process.poll() is None:
        try:
            process.kill()
        except OSError:
            pass


def terminate_active_processes(
    grace_seconds: float = 0.3, *, parallel: int = 32
) -> int:
    with PROCESS_TERMINATION_LOCK:
        with PROCESS_LOCK:
            running = [p for p in ACTIVE_PROCESSES if p.poll() is None]
        if os.name == "nt" and running:
            # taskkill /T is the only reliable way to stop each Python worker
            # together with its transient ADB descendants on Windows.
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(max(1, parallel), len(running)),
                thread_name_prefix="worker-tree-stop",
            ) as executor:
                list(executor.map(terminate_worker_process_tree, running))
            return len(running)
        for process in running:
            try:
                process.terminate()
            except OSError:
                pass
        deadline = time.monotonic() + max(0.0, grace_seconds)
        while running and time.monotonic() < deadline:
            running = [process for process in running if process.poll() is None]
            if running:
                time.sleep(0.02)
        if running:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(max(1, parallel), len(running)),
                thread_name_prefix="worker-tree-stop",
            ) as executor:
                list(executor.map(terminate_worker_process_tree, running))
        return len(running)


class ShutdownCoordinator:
    """One idempotent owner for Enter, Ctrl+C, and final cleanup."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.proxy_manager: ProxyManager | None = None
        self._request_lock = threading.Lock()
        self._finalize_lock = threading.Lock()
        self._requested = False
        self._finalized = False
        self._started = 0.0
        self._workers_stopped = threading.Event()

    def attach_proxy_manager(self, manager: ProxyManager) -> None:
        self.proxy_manager = manager

    def request(self, reason: str) -> None:
        with self._request_lock:
            if self._requested:
                return
            self._requested = True
            self._started = time.monotonic()
            STOP_EVENT.set()
            if self.proxy_manager is not None:
                self.proxy_manager.request_stop()
            safe_print(f"\n[STOP] {reason} received; stopping safely...", flush=True)
        try:
            terminate_active_processes(
                float(self.config.get("shutdown_worker_grace_seconds", 0.3)),
                parallel=int(self.config.get("proxy_shutdown_parallel", 32)),
            )
        finally:
            self._workers_stopped.set()

    def finalize(self) -> None:
        self.request("shutdown")
        self._workers_stopped.wait(
            max(
                3.0,
                float(self.config.get("shutdown_worker_grace_seconds", 0.3)) + 2.5,
            )
        )
        REPORT_JOBS_IDLE.wait(45.0)
        with self._finalize_lock:
            if self._finalized:
                return
            self._finalized = True
            if self.proxy_manager is not None:
                self.proxy_manager.close()
            elapsed = time.monotonic() - self._started
            safe_print(f"[STOP] safe shutdown complete in {elapsed:.1f}s", flush=True)


def start_stop_listener(
    coordinator: ShutdownCoordinator | None = None,
) -> threading.Thread:
    def listener() -> None:
        try:
            line = sys.stdin.readline()
        except (EOFError, OSError):
            return
        if line == "":
            return
        if coordinator is None:
            STOP_EVENT.set()
            safe_print("\n[STOP] ENTER received; stopping safely...", flush=True)
            terminate_active_processes()
        else:
            coordinator.request("ENTER")

    thread = threading.Thread(target=listener, name="enter-stop-listener", daemon=True)
    thread.start()
    return thread


def run_process_quiet(
    command: list[str],
    *,
    cwd: Path,
    timeout_seconds: float,
    detailed_logging: bool,
) -> tuple[int, list[str], bool, bool]:
    if STOP_EVENT.is_set():
        return 130, [], True, False
    creationflags = 0
    if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
        creationflags = subprocess.CREATE_NO_WINDOW
    process = subprocess.Popen(
        command,
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="backslashreplace",
        bufsize=1,
        creationflags=creationflags,
    )
    register_process(process)
    captured: list[str] = []
    timed_out = threading.Event()
    watchdog_stop = threading.Event()

    def enforce_deadline() -> None:
        if watchdog_stop.wait(max(0.1, timeout_seconds)):
            return
        timed_out.set()
        terminate_worker_process_tree(process)

    watchdog = threading.Thread(target=enforce_deadline, name="worker-deadline", daemon=True)
    watchdog.start()
    try:
        assert process.stdout is not None
        for raw in process.stdout:
            line = raw.rstrip("\r\n")
            captured.append(line)
            if len(captured) > 300:
                del captured[: len(captured) - 300]
            if detailed_logging:
                safe_print(line)
            if STOP_EVENT.is_set() and process.poll() is None:
                terminate_worker_process_tree(process)
        code = process.wait()
        return code, captured, STOP_EVENT.is_set() and code != 0, timed_out.is_set()
    finally:
        watchdog_stop.set()
        # Ensure the timeout watchdog has completely finished terminating this
        # child before another worker process can reuse the OS PID.
        if watchdog.is_alive():
            watchdog.join(timeout=2.5)
        if process.stdout is not None:
            process.stdout.close()
        unregister_process(process)


def force_stop_tiktok_after_forced_child_exit(
    *,
    config: dict[str, Any],
    serial: str,
    action_choice: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Best-effort parent cleanup when timeout/cancel kills child finally blocks."""
    template = workflow_template(action_choice)
    detected = str((metadata or {}).get("tiktok_package", "")).strip()
    configured = str(template.get("tiktok_package", "")).strip()
    if detected:
        packages = [detected]
    elif configured and configured.casefold() != "auto":
        packages = [configured]
    else:
        packages = list(
            dict.fromkeys(
                str(value).strip()
                for value in template.get("tiktok_packages", [])
                if str(value).strip()
            )
        )
    if not packages:
        return

    executable = str(config.get("adb_executable", "adb"))
    timeout = max(0.5, float(template.get("cleanup_timeout_seconds", 2)))
    if STOP_EVENT.is_set():
        timeout = max(
            0.5,
            float(config.get("shutdown_device_cleanup_timeout_seconds", 1)),
        )
    for package in packages:
        try:
            subprocess.run(
                [
                    executable,
                    "-s",
                    serial,
                    "shell",
                    "am",
                    "force-stop",
                    package,
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            continue


def cleanup_uiautomator_after_forced_child_exit(
    *,
    config: dict[str, Any],
    serial: str,
) -> None:
    """Reset only this project's uiautomator2 server after a forced child death.

    Normal workers leave the healthy device-side server running for reuse. A
    timeout/cancelled process is different: its finally block may never finish,
    so the parent marks the control plane clean before the phone is reused.
    """
    executable = str(config.get("adb_executable", "adb"))
    lock_timeout = max(
        0.5, float(config.get("uiautomator_device_lock_timeout_seconds", 6))
    )
    if STOP_EVENT.is_set():
        lock_timeout = min(
            lock_timeout,
            max(0.5, float(config.get("shutdown_device_cleanup_timeout_seconds", 1))),
        )
    try:
        with device_control_lease(serial, timeout_seconds=lock_timeout):
            repair = stop_our_uiautomator_processes(
                executable,
                serial,
                timeout=min(4.0, lock_timeout),
                settle_seconds=max(
                    0.2, float(config.get("uiautomator_reset_settle_seconds", 0.8))
                ),
            )
            if repair.get("before"):
                safe_print(
                    f"[{serial}] UIAUTOMATOR_CLEANUP killed={repair.get('killed_pids', [])}"
                )
    except (TimeoutError, OSError, subprocess.SubprocessError) as exc:
        if not STOP_EVENT.is_set():
            safe_print(f"[{serial}] UIAUTOMATOR_CLEANUP_WARNING {type(exc).__name__}: {exc}")


def cleanup_forced_child_once(
    *,
    config: dict[str, Any],
    serial: str,
    action_choice: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Run forced device cleanup once per serial during one shutdown."""
    if STOP_EVENT.is_set():
        with FORCED_CLEANUP_LOCK:
            if serial in FORCED_CLEANUP_DONE:
                return
            FORCED_CLEANUP_DONE.add(serial)
    force_stop_tiktok_after_forced_child_exit(
        config=config,
        serial=serial,
        action_choice=action_choice,
        metadata=metadata,
    )
    cleanup_uiautomator_after_forced_child_exit(config=config, serial=serial)


def find_latest_json(root: Path, name: str) -> tuple[dict[str, Any], Path | None]:
    paths = sorted(root.rglob(name)) if root.exists() else []
    if not paths:
        return {}, None
    path = paths[-1]
    try:
        value = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        return (value if isinstance(value, dict) else {}), path
    except (OSError, json.JSONDecodeError):
        return {}, path


def wait_for_incomplete_submission_hold(journal: dict[str, Any]) -> float:
    """Honor the post-dispatch network hold even after child interruption."""
    if not bool(journal.get("submit_attempted", False)):
        return 0.0
    state = str(journal.get("submission_state", "")).strip().upper()
    if state in {"CONFIRMED", "UNCONFIRMED"} and bool(
        journal.get("settlement_completed", False)
    ):
        return 0.0
    try:
        cleanup_epoch = float(journal.get("cleanup_not_before_epoch", 0.0))
    except (TypeError, ValueError):
        cleanup_epoch = 0.0
    if cleanup_epoch <= 0:
        try:
            cleanup_epoch = float(journal.get("submit_dispatch_epoch", 0.0)) + 35.0
        except (TypeError, ValueError):
            cleanup_epoch = time.time() + 35.0
    started = time.monotonic()
    while time.time() < cleanup_epoch:
        time.sleep(min(0.2, cleanup_epoch - time.time()))
    return time.monotonic() - started


def submission_outcome_fields(
    result: dict[str, Any], journal: dict[str, Any]
) -> dict[str, Any]:
    def value(key: str, default: Any) -> Any:
        return result[key] if key in result else journal.get(key, default)

    return {
        "submission_completed": bool(value("submission_completed", False)),
        "submission_state": str(value("submission_state", "NOT_SUBMITTED")).upper(),
        "submit_attempted": bool(value("submit_attempted", False)),
        "ui_confirmation_observed": bool(value("ui_confirmation_observed", False)),
        "settlement_completed": bool(value("settlement_completed", False)),
        "confirmation_source": str(value("confirmation_source", "")),
        "backend_acceptance": str(value("backend_acceptance", "unknown")),
        "confirmation_wait_seconds": float(value("confirmation_wait_seconds", 0.0) or 0.0),
        "settlement_seconds": float(value("settlement_seconds", 0.0) or 0.0),
    }


def settled_submission_confirmed(fields: dict[str, Any]) -> bool:
    return bool(
        fields["submission_completed"]
        and fields["submission_state"] == "CONFIRMED"
        and fields["ui_confirmation_observed"]
        and fields["settlement_completed"]
        and fields["confirmation_source"] == "tiktok_ui"
    )


@dataclass(frozen=True)
class WorkerJobOutcome:
    serial: str
    code: int
    status: str
    error_code: str = ""
    stage: str = ""
    reason: str = ""
    submission_completed: bool = False
    duration_seconds: float = 0.0
    timings: dict[str, float] = field(default_factory=dict)
    submission_state: str = "NOT_SUBMITTED"
    submit_attempted: bool = False
    ui_confirmation_observed: bool = False
    settlement_completed: bool = False
    confirmation_source: str = ""
    backend_acceptance: str = "unknown"
    confirmation_wait_seconds: float = 0.0
    settlement_seconds: float = 0.0
    cleanup_errors: tuple[str, ...] = ()


@dataclass(frozen=True)
class CheckerAttemptOutcome:
    serial: str
    model: str
    status: str
    error_code: str = ""
    reason: str = ""
    workflow_started: bool = False
    proxy_seconds: float = 0.0
    workflow_seconds: float = 0.0


@dataclass(frozen=True)
class LivePrecheckOutcome:
    status: str
    serial: str = ""
    error_code: str = ""
    reason: str = ""
    duration_seconds: float = 0.0
    proxy_seconds: float = 0.0
    workflow_seconds: float = 0.0
    cancelled: bool = False
    attempts: tuple[CheckerAttemptOutcome, ...] = ()


@dataclass(frozen=True)
class LiveDiscoveryOutcome:
    status: str
    username: str = ""
    live_url: str = ""
    serial: str = ""
    error_code: str = ""
    reason: str = ""
    duration_seconds: float = 0.0
    proxy_seconds: float = 0.0
    workflow_seconds: float = 0.0
    cancelled: bool = False
    attempts: tuple[CheckerAttemptOutcome, ...] = ()


def checker_model_hints() -> dict[str, str]:
    with DEVICE_MODEL_HINTS_LOCK:
        return {
            serial: normalize_checker_model(model)
            for serial, model in DEVICE_MODEL_HINTS.items()
        }


def checker_attempt_payload(
    attempts: tuple[CheckerAttemptOutcome, ...],
) -> list[dict[str, Any]]:
    payload = []
    for attempt in attempts:
        item = asdict(attempt)
        item["proxy_seconds"] = round(float(item["proxy_seconds"]), 3)
        item["workflow_seconds"] = round(float(item["workflow_seconds"]), 3)
        payload.append(item)
    return payload


LIVE_PRECHECK_STATUSES = frozenset({"LIVE", "OFFLINE", "UNKNOWN"})

CHECKER_DEVICE_LOCAL_ERROR_CODES = frozenset({
    "ADB_GET_STATE_FAILED",
    "ADB_DEVICE_OFFLINE",
    "UIAUTOMATOR_CONNECTION_FAILED",
    "UIAUTOMATOR_DEVICE_LOCK_TIMEOUT",
    "UIAUTOMATOR_REGISTRATION_BUSY_UNOWNED",
    "UIAUTOMATOR_STALE_SERVICE_RESET_FAILED",
    "UIAUTOMATOR_TRANSPORT_REPAIR_FAILED",
    "HIERARCHY_UNAVAILABLE",
    "TIKTOK_LAUNCH_TIMEOUT",
    "TIKTOK_UI_NOT_READY",
    "TIKTOK_LOCATION_PERMISSION_PERSISTENT",
    "TIKTOK_LOCATION_PERMISSION_CONTROL_MISSING",
    "TIKTOK_LOCATION_PERMISSION_DENY_FAILED",
    "TIKTOK_ANR_PERSISTENT",
    "SEARCH_BUTTON_CLICK_FAILED",
    "SEARCH_AVATAR_CLICK_FAILED",
    "SEARCH_AVATAR_CLICK_UNACKNOWLEDGED",
    "USERS_TAB_CLICK_FAILED",
    "USERS_TAB_CLICK_NOT_ACKNOWLEDGED",
})


def checker_failure_is_device_local(outcome: LivePrecheckOutcome) -> bool:
    code = str(outcome.error_code or "").strip().upper()
    reason = str(outcome.reason or "").casefold()
    if code in CHECKER_DEVICE_LOCAL_ERROR_CODES:
        return True
    return any(
        marker in reason
        for marker in (
            "remotedisconnected",
            "remote end closed connection",
            "uiautomation not connected",
            "already registered",
            "packageinstaller",
            "permissioncontroller",
        )
    )


def latest_precheck_stage(console: Iterable[str]) -> str:
    """Recover the last emitted workflow stage if the hard watchdog wins."""
    for line in reversed(list(console)):
        match = re.search(r"\bSTEP\s*\|\s*([A-Z][A-Z0-9_]*)\s*\|", str(line))
        if match:
            return match.group(1)
    return "UNKNOWN"


def write_minimal_result(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    serial: str,
    action_choice: str,
    outcome: WorkerJobOutcome,
) -> Path:
    compact_success = bool(config.get("compact_success_logging", True))
    if outcome.status == "success" and compact_success:
        target = resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
        filename = "SUCCESS_DEVICES.jsonl"
    elif outcome.status == "success":
        target = (
            resolve_config_path(config, "success_logs_root", "success_logs")
            / cycle_id
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / filesystem_safe(serial)
        )
        filename = "SUCCESS.json"
    elif outcome.status == "live_ended":
        # A real mid-workflow LIVE termination is neither success nor program
        # failure. Keep it with cycle outcomes rather than polluting failed_logs.
        target = (
            resolve_config_path(config, "cycle_logs_root", "cycle_logs")
            / cycle_id
            / "LIVE_ENDED_DURING_WORKFLOW"
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / filesystem_safe(serial)
        )
        filename = "LIVE_ENDED.json"
    elif outcome.status == "unconfirmed":
        target = (
            resolve_config_path(config, "failed_logs_root", "failed_logs")
            / cycle_id
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / filesystem_safe(serial)
        )
        filename = "UNCONFIRMED.json"
    else:
        target = (
            resolve_config_path(config, "failed_logs_root", "failed_logs")
            / cycle_id
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / filesystem_safe(serial)
        )
        filename = "FAILED.json"
    target.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "device": serial,
        "username": username_from_url(live_url),
        "live_url": live_url,
        "report_action": action_choice,
        "report_type": ACTIONS[action_choice]["label"],
        "status": outcome.status,
        "stage": outcome.stage,
        "error": "" if outcome.status == "live_ended" else (outcome.error_code or outcome.reason),
        "outcome_reason": outcome.reason,
        "submission_completed": outcome.submission_completed,
        "submission_state": outcome.submission_state,
        "submit_attempted": outcome.submit_attempted,
        "ui_confirmation_observed": outcome.ui_confirmation_observed,
        "settlement_completed": outcome.settlement_completed,
        "confirmation_source": outcome.confirmation_source,
        "backend_acceptance": outcome.backend_acceptance,
        "confirmation_wait_seconds": round(outcome.confirmation_wait_seconds, 3),
        "settlement_seconds": round(outcome.settlement_seconds, 3),
        "cleanup_errors": list(outcome.cleanup_errors),
        "duration_seconds": round(outcome.duration_seconds, 3),
        "timings": {key: round(value, 3) for key, value in outcome.timings.items()},
    }
    path = target / filename
    if outcome.status == "success" and compact_success:
        compact_payload = {
            "timestamp": payload["timestamp"],
            "device": serial,
            "username": payload["username"],
            "report_action": action_choice,
            "status": "success",
            "submission_completed": outcome.submission_completed,
            "submission_state": outcome.submission_state,
            "submit_attempted": outcome.submit_attempted,
            "ui_confirmation_observed": outcome.ui_confirmation_observed,
            "settlement_completed": outcome.settlement_completed,
            "confirmation_source": outcome.confirmation_source,
            "backend_acceptance": outcome.backend_acceptance,
            "confirmation_wait_seconds": round(
                outcome.confirmation_wait_seconds, 3
            ),
            "settlement_seconds": round(outcome.settlement_seconds, 3),
            "cleanup_errors": list(outcome.cleanup_errors),
            "duration_seconds": payload["duration_seconds"],
        }
        encoded = json.dumps(compact_payload, separators=(",", ":"), ensure_ascii=False)
        with SUCCESS_LOG_LOCK:
            with path.open("a", encoding="utf-8") as handle:
                handle.write(encoded + "\n")
        return path
    atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    return path


def run_live_precheck_job(
    *,
    config: dict[str, Any],
    cycle_id: str,
    serial: str,
    live_url: str,
    action_choice: str,
    exclusions: ExclusionList,
) -> LivePrecheckOutcome:
    """Run the existing direct-LIVE detector in a killable child process."""
    started = time.monotonic()
    if STOP_EVENT.is_set():
        return LivePrecheckOutcome(
            "UNKNOWN", serial, "CANCELLED", "shutdown requested", cancelled=True
        )
    if exclusions.contains(live_url):
        return LivePrecheckOutcome(
            "UNKNOWN",
            serial,
            "TARGET_EXCLUDED",
            "target was added to excluded_lists.txt before LIVE precheck",
        )

    temp_root = (
        RUNTIME_ROOT
        / cycle_id
        / "precheck_logs"
        / filesystem_safe(username_from_url(live_url))
        / filesystem_safe(serial)
    )
    worker_config = build_worker_config(
        config=config,
        serial=serial,
        live_url=live_url,
        action_choice=action_choice,
        cycle_id=cycle_id,
        temp_job_root=temp_root,
        workflow_mode="live_precheck",
    )
    project_dir = Path(ACTIONS[action_choice]["project_dir"])
    script = project_dir / "tiktok_live_selector_workflow.py"
    timeout_seconds = float(config.get("live_precheck_timeout_seconds", 80))
    code, console, cancelled, timed_out = run_process_quiet(
        [sys.executable, str(script), "--config", str(worker_config)],
        cwd=project_dir,
        timeout_seconds=timeout_seconds,
        detailed_logging=bool(config.get("detailed_logging", False)),
    )
    result, _result_path = find_latest_json(temp_root, "result.json")
    metadata, _metadata_path = find_latest_json(temp_root, "device_metadata.json")
    DEVICE_CACHE.update(serial, metadata)
    if cancelled or timed_out:
        cleanup_forced_child_once(
            config=config,
            serial=serial,
            action_choice=action_choice,
            metadata=metadata,
        )
    duration = time.monotonic() - started

    if cancelled:
        outcome = LivePrecheckOutcome(
            "UNKNOWN",
            serial,
            "CANCELLED",
            "shutdown requested",
            duration_seconds=duration,
            workflow_seconds=duration,
            cancelled=True,
        )
    elif timed_out:
        timed_out_stage = (
            str(result.get("stage", "")).strip() or latest_precheck_stage(console)
        )
        outcome = LivePrecheckOutcome(
            "UNKNOWN",
            serial,
            "LIVE_PRECHECK_TIMEOUT",
            f"LIVE precheck exceeded {timeout_seconds:g}s | stage={timed_out_stage}",
            duration_seconds=duration,
            workflow_seconds=duration,
        )
    else:
        live_status = str(result.get("live_status", "UNKNOWN")).strip().upper()
        if live_status not in LIVE_PRECHECK_STATUSES:
            live_status = "UNKNOWN"
        if live_status == "LIVE" and code != 0:
            live_status = "UNKNOWN"
        error_code = str(result.get("error_code", "")).strip().upper()
        reason = str(result.get("reason") or result.get("error") or "")
        if error_code == "LIVE_PRECHECK_TIMEOUT" and "stage=" not in reason.casefold():
            reason += f" | stage={str(result.get('stage', 'UNKNOWN')).strip() or 'UNKNOWN'}"
        outcome = LivePrecheckOutcome(
            status=live_status,
            serial=serial,
            error_code=error_code,
            reason=reason,
            duration_seconds=duration,
            workflow_seconds=duration,
        )

    if bool(config.get("diagnostics_enabled", False)) and outcome.status == "UNKNOWN":
        diagnostic_target = (
            resolve_config_path(config, "failed_logs_root", "failed_logs")
            / cycle_id
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / f"PRECHECK_{filesystem_safe(serial)}"
            / "diagnostics"
        )
        if temp_root.exists():
            if diagnostic_target.exists():
                shutil.rmtree(diagnostic_target, ignore_errors=True)
            diagnostic_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(temp_root), str(diagnostic_target))
        if console:
            atomic_write_text(diagnostic_target / "console.log", "\n".join(console) + "\n")
    else:
        shutil.rmtree(temp_root, ignore_errors=True)
    try:
        worker_config.unlink()
    except OSError:
        pass
    return outcome


def run_live_discovery_job(
    *,
    config: dict[str, Any],
    cycle_id: str,
    serial: str,
    search_query: str,
    action_choice: str,
) -> LiveDiscoveryOutcome:
    """Use the existing TikTok Search UI to find the top visible LIVE user."""
    started = time.monotonic()
    if STOP_EVENT.is_set():
        return LiveDiscoveryOutcome(
            "UNKNOWN", serial=serial, error_code="CANCELLED",
            reason="shutdown requested", cancelled=True
        )

    placeholder_url = "https://www.tiktok.com/@live.discovery/live"
    temp_root = (
        RUNTIME_ROOT
        / cycle_id
        / "discovery_logs"
        / filesystem_safe(serial)
    )
    worker_config = build_worker_config(
        config=config,
        serial=serial,
        live_url=placeholder_url,
        action_choice=action_choice,
        cycle_id=cycle_id,
        temp_job_root=temp_root,
        workflow_mode="live_discovery",
        search_query=search_query,
    )
    project_dir = Path(ACTIONS[action_choice]["project_dir"])
    script = project_dir / "tiktok_live_selector_workflow.py"
    timeout_seconds = float(config.get("live_precheck_timeout_seconds", 80))
    code, console, cancelled, timed_out = run_process_quiet(
        [sys.executable, str(script), "--config", str(worker_config)],
        cwd=project_dir,
        timeout_seconds=timeout_seconds,
        detailed_logging=bool(config.get("detailed_logging", False)),
    )
    result, _result_path = find_latest_json(temp_root, "result.json")
    metadata, _metadata_path = find_latest_json(temp_root, "device_metadata.json")
    DEVICE_CACHE.update(serial, metadata)
    if cancelled or timed_out:
        cleanup_forced_child_once(
            config=config,
            serial=serial,
            action_choice=action_choice,
            metadata=metadata,
        )

    duration = time.monotonic() - started
    if cancelled:
        outcome = LiveDiscoveryOutcome(
            "UNKNOWN", serial=serial, error_code="CANCELLED",
            reason="shutdown requested", duration_seconds=duration,
            workflow_seconds=duration, cancelled=True
        )
    elif timed_out:
        stage = str(result.get("stage", "")).strip() or latest_precheck_stage(console)
        outcome = LiveDiscoveryOutcome(
            "UNKNOWN", serial=serial, error_code="LIVE_DISCOVERY_TIMEOUT",
            reason=f"LIVE discovery exceeded {timeout_seconds:g}s | stage={stage}",
            duration_seconds=duration, workflow_seconds=duration
        )
    else:
        discovered_username = str(result.get("discovered_username", "")).strip().lstrip("@")
        discovered_url = normalize_live_candidate(
            str(result.get("discovered_live_url", "")).strip()
            or (f"https://www.tiktok.com/@{discovered_username}/live" if discovered_username else "")
        )
        error_code = str(result.get("error_code", "")).strip().upper()
        reason = str(result.get("reason") or result.get("error") or "")
        result_status = str(result.get("status", "")).strip().casefold()
        if code == 0 and result_status == "success" and discovered_username and discovered_url:
            outcome = LiveDiscoveryOutcome(
                "FOUND", username=discovered_username, live_url=discovered_url,
                serial=serial, duration_seconds=duration, workflow_seconds=duration
            )
        elif error_code in {
            "DISCOVERY_NO_LIVE_RESULT",
            "DISCOVERY_STALE_LIVE_RESULT",
            "DISCOVERY_TARGET_EXCLUDED",
        } or result_status in {"skipped", "excluded"}:
            outcome = LiveDiscoveryOutcome(
                "NONE", serial=serial, error_code=error_code,
                reason=reason, duration_seconds=duration, workflow_seconds=duration
            )
        else:
            outcome = LiveDiscoveryOutcome(
                "UNKNOWN", serial=serial, error_code=error_code or "LIVE_DISCOVERY_FAILED",
                reason=reason or f"discovery worker exited with code {code}",
                duration_seconds=duration, workflow_seconds=duration
            )

    if bool(config.get("diagnostics_enabled", False)) and outcome.status == "UNKNOWN":
        diagnostic_target = (
            resolve_config_path(config, "failed_logs_root", "failed_logs")
            / cycle_id
            / "DISCOVERY"
            / f"@{filesystem_safe(search_query)}"
            / f"CHECKER_{filesystem_safe(serial)}"
            / "diagnostics"
        )
        if temp_root.exists():
            if diagnostic_target.exists():
                shutil.rmtree(diagnostic_target, ignore_errors=True)
            diagnostic_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(temp_root), str(diagnostic_target))
        if console:
            atomic_write_text(diagnostic_target / "console.log", "\n".join(console) + "\n")
    else:
        shutil.rmtree(temp_root, ignore_errors=True)
    try:
        worker_config.unlink()
    except OSError:
        pass
    return outcome


def release_proxy_device_safely(
    proxy_manager: ProxyManager, serial: str, *, context: str
) -> tuple[str, ...]:
    """Release one prepared device without letting cleanup stop the runner."""
    release_device = getattr(proxy_manager, "release_device", None)
    if not callable(release_device):
        return ()
    try:
        errors = release_device(serial)
    except Exception as exc:
        safe_print(
            f"[PROXY ERROR] device={serial} | context={context}"
            f" | error={type(exc).__name__}: {exc}"
        )
        return (f"{type(exc).__name__}: {exc}",)
    if isinstance(errors, (list, tuple)) and errors:
        safe_print(
            f"[PROXY ERROR] device={serial} | context={context}"
            f" | errors={len(errors)}"
        )
        return tuple(str(item) for item in errors)
    return ()


def release_checker_proxy(proxy_manager: ProxyManager, serial: str) -> None:
    """Return a checker lease after its child workflow has stopped using it."""
    release_proxy_device_safely(
        proxy_manager, serial, context="checker_cleanup"
    )


def run_global_live_discovery(
    *,
    config: dict[str, Any],
    cycle_id: str,
    search_query: str,
    serials: list[str],
    proxy_manager: ProxyManager,
    action_choice: str,
) -> LiveDiscoveryOutcome:
    """Find one keyword LIVE across at most three distinct fast checkers."""
    started = time.monotonic()
    attempts: list[CheckerAttemptOutcome] = []
    proxy_total = 0.0
    workflow_total = 0.0

    def finish(result: LiveDiscoveryOutcome) -> LiveDiscoveryOutcome:
        return replace(
            result,
            duration_seconds=time.monotonic() - started,
            proxy_seconds=proxy_total,
            workflow_seconds=workflow_total,
            attempts=tuple(attempts),
        )

    if STOP_EVENT.is_set():
        return finish(
            LiveDiscoveryOutcome(
                "UNKNOWN", error_code="CANCELLED", reason="shutdown requested", cancelled=True
            )
        )
    ordered = ordered_checker_candidates(config, serials)
    if not ordered:
        return finish(
            LiveDiscoveryOutcome(
                "UNKNOWN", error_code="NO_CHECKER_DEVICE",
                reason="no connected TCP ADB device is available for LIVE discovery"
            )
        )
    maximum = max(1, min(3, int(config.get("checker_max_devices", 3))))
    candidates = ordered[:maximum]
    models = checker_model_hints()
    proxy_errors: list[str] = []
    last_no_result: LiveDiscoveryOutcome | None = None
    last_unknown: LiveDiscoveryOutcome | None = None
    last_checker = candidates[0]
    for checker in candidates:
        if STOP_EVENT.is_set():
            return finish(
                LiveDiscoveryOutcome(
                    "UNKNOWN", serial=checker, error_code="CANCELLED",
                    reason="shutdown requested", cancelled=True,
                )
            )
        last_checker = checker
        prepare_started = time.monotonic()
        prepared = list(
            proxy_manager.prepare_stream(
                [checker], f"{cycle_id} search={search_query!r} LIVE discovery"
            )
        )
        prepare_seconds = time.monotonic() - prepare_started
        proxy_total += prepare_seconds
        prepared_lease_serial = ""
        if (
            len(prepared) == 1
            and isinstance(prepared[0], (tuple, list))
            and len(prepared[0]) == 4
            and bool(prepared[0][1])
        ):
            prepared_lease_serial = str(prepared[0][0])
        if STOP_EVENT.is_set():
            if prepared_lease_serial:
                release_checker_proxy(proxy_manager, prepared_lease_serial)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "CANCELLED", "shutdown requested",
                    proxy_seconds=prepare_seconds,
                )
            )
            return finish(
                LiveDiscoveryOutcome(
                    "UNKNOWN", serial=checker, error_code="CANCELLED",
                    reason="shutdown requested", cancelled=True,
                )
            )
        if len(prepared) != 1 or not isinstance(prepared[0], (tuple, list)) or len(prepared[0]) != 4:
            reason = f"{checker}: proxy preparation did not produce exactly one valid result"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "DISCOVERY_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        prepared_serial, ready, _redacted_proxy, error = prepared[0]
        if prepared_serial != checker:
            if ready:
                release_checker_proxy(proxy_manager, str(prepared_serial))
            reason = f"{checker}: proxy preparation returned unexpected device {prepared_serial}"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "DISCOVERY_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        if not ready:
            reason = error or f"{checker}: proxy preparation failed closed"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "DISCOVERY_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        try:
            result = run_live_discovery_job(
                config=config,
                cycle_id=cycle_id,
                serial=checker,
                search_query=search_query,
                action_choice=action_choice,
            )
        finally:
            release_checker_proxy(proxy_manager, checker)
        workflow_total += result.workflow_seconds
        attempts.append(
            CheckerAttemptOutcome(
                checker,
                models.get(checker, ""),
                result.status,
                result.error_code,
                result.reason,
                workflow_started=True,
                proxy_seconds=prepare_seconds,
                workflow_seconds=result.workflow_seconds,
            )
        )
        if result.status in {"FOUND", "NONE"}:
            remember_checker_speed(checker, result.workflow_seconds)
        if result.cancelled or STOP_EVENT.is_set():
            return finish(
                replace(
                    result,
                    status="UNKNOWN",
                    error_code="CANCELLED",
                    reason="shutdown requested",
                    cancelled=True,
                )
            )
        if result.error_code == "INTERNAL_PROGRAM_ERROR":
            return finish(result)
        if result.status == "FOUND":
            return finish(result)
        if result.status == "NONE":
            last_no_result = result
            if checker != candidates[-1]:
                safe_print(
                    f"[DISCOVERY] checker={checker} saw no usable LIVE result; trying next bounded checker"
                )
        else:
            last_unknown = result
        # NONE and ordinary UNKNOWN both receive one independent retry.
    if last_no_result is not None:
        if last_unknown is None:
            return finish(last_no_result)
    if last_unknown is not None:
        return finish(last_unknown)
    return finish(
        LiveDiscoveryOutcome(
            "UNKNOWN", serial=last_checker, error_code="DISCOVERY_PROXY_FAILED",
            reason="; ".join(proxy_errors) or "all bounded checker proxy paths failed",
        )
    )


def run_global_live_precheck(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    serials: list[str],
    proxy_manager: ProxyManager,
    exclusions: ExclusionList,
    action_choice: str,
) -> LivePrecheckOutcome:
    """Check up to three distinct fast devices and accept any verified LIVE."""
    started = time.monotonic()
    attempts: list[CheckerAttemptOutcome] = []
    proxy_total = 0.0
    workflow_total = 0.0

    def finish(result: LivePrecheckOutcome) -> LivePrecheckOutcome:
        return replace(
            result,
            duration_seconds=time.monotonic() - started,
            proxy_seconds=proxy_total,
            workflow_seconds=workflow_total,
            attempts=tuple(attempts),
        )

    if STOP_EVENT.is_set():
        return finish(
            LivePrecheckOutcome(
                "UNKNOWN", error_code="CANCELLED", reason="shutdown requested", cancelled=True
            )
        )
    if exclusions.contains(live_url):
        return finish(
            LivePrecheckOutcome(
                "UNKNOWN", error_code="TARGET_EXCLUDED",
                reason="target was added to excluded_lists.txt before LIVE precheck",
            )
        )
    ordered = ordered_checker_candidates(config, serials)
    if not ordered:
        return finish(
            LivePrecheckOutcome(
                "UNKNOWN",
                error_code="NO_CHECKER_DEVICE",
                reason="no connected TCP ADB device is available for LIVE precheck",
            )
        )
    maximum = max(1, min(3, int(config.get("checker_max_devices", 3))))
    candidates = ordered[:maximum]
    models = checker_model_hints()
    proxy_errors: list[str] = []
    last_offline: LivePrecheckOutcome | None = None
    last_unknown: LivePrecheckOutcome | None = None
    last_checker = candidates[0]
    for checker in candidates:
        if STOP_EVENT.is_set():
            return finish(
                LivePrecheckOutcome(
                    "UNKNOWN", checker, "CANCELLED", "shutdown requested", cancelled=True
                )
            )
        if exclusions.contains(live_url):
            return finish(
                LivePrecheckOutcome(
                    "UNKNOWN", checker, "TARGET_EXCLUDED",
                    "target was added to excluded_lists.txt before LIVE precheck",
                )
            )
        last_checker = checker
        prepare_started = time.monotonic()
        prepared = list(
            proxy_manager.prepare_stream(
                [checker], f"{cycle_id} @{username_from_url(live_url)} LIVE precheck"
            )
        )
        prepare_seconds = time.monotonic() - prepare_started
        proxy_total += prepare_seconds
        prepared_lease_serial = ""
        if (
            len(prepared) == 1
            and isinstance(prepared[0], (tuple, list))
            and len(prepared[0]) == 4
            and bool(prepared[0][1])
        ):
            prepared_lease_serial = str(prepared[0][0])
        if STOP_EVENT.is_set():
            if prepared_lease_serial:
                release_checker_proxy(proxy_manager, prepared_lease_serial)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "CANCELLED", "shutdown requested",
                    proxy_seconds=prepare_seconds,
                )
            )
            return finish(
                LivePrecheckOutcome(
                    "UNKNOWN", checker, "CANCELLED", "shutdown requested", cancelled=True
                )
            )
        if exclusions.contains(live_url):
            if prepared_lease_serial:
                release_checker_proxy(proxy_manager, prepared_lease_serial)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "TARGET_EXCLUDED",
                    "target was added to excluded_lists.txt before LIVE precheck",
                    proxy_seconds=prepare_seconds,
                )
            )
            return finish(
                LivePrecheckOutcome(
                    "UNKNOWN", checker, "TARGET_EXCLUDED",
                    "target was added to excluded_lists.txt before LIVE precheck",
                )
            )
        if len(prepared) != 1 or not isinstance(prepared[0], (tuple, list)) or len(prepared[0]) != 4:
            reason = f"{checker}: proxy preparation did not produce exactly one valid result"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "CHECKER_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        prepared_serial, ready, _redacted_proxy, error = prepared[0]
        if prepared_serial != checker:
            if ready:
                release_checker_proxy(proxy_manager, str(prepared_serial))
            reason = f"{checker}: proxy preparation returned unexpected device {prepared_serial}"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "CHECKER_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        if not ready:
            reason = error or f"{checker}: proxy preparation failed closed"
            proxy_errors.append(reason)
            attempts.append(
                CheckerAttemptOutcome(
                    checker, models.get(checker, ""), "UNKNOWN", "CHECKER_PROXY_FAILED", reason,
                    proxy_seconds=prepare_seconds,
                )
            )
            continue
        try:
            result = run_live_precheck_job(
                config=config,
                cycle_id=cycle_id,
                serial=checker,
                live_url=live_url,
                action_choice=action_choice,
                exclusions=exclusions,
            )
        finally:
            release_checker_proxy(proxy_manager, checker)
        workflow_total += result.workflow_seconds
        attempts.append(
            CheckerAttemptOutcome(
                checker,
                models.get(checker, ""),
                result.status,
                result.error_code,
                result.reason,
                workflow_started=True,
                proxy_seconds=prepare_seconds,
                workflow_seconds=result.workflow_seconds,
            )
        )
        if result.status in {"LIVE", "OFFLINE"}:
            remember_checker_speed(checker, result.workflow_seconds)
        if result.cancelled or STOP_EVENT.is_set():
            return finish(
                replace(
                    result,
                    status="UNKNOWN",
                    error_code="CANCELLED",
                    reason="shutdown requested",
                    cancelled=True,
                )
            )
        if result.error_code in {"TARGET_EXCLUDED", "INTERNAL_PROGRAM_ERROR"}:
            return finish(result)
        if exclusions.contains(live_url):
            return finish(
                replace(
                    result, status="UNKNOWN", error_code="TARGET_EXCLUDED",
                    reason="target was added to excluded_lists.txt during LIVE precheck",
                )
            )
        if result.status == "LIVE":
            return finish(result)
        if result.status == "OFFLINE":
            last_offline = result
        else:
            last_unknown = result

    if last_unknown is not None:
        return finish(last_unknown)
    if last_offline is not None and len(attempts) == len(candidates) and all(
        attempt.workflow_started and attempt.status == "OFFLINE" for attempt in attempts
    ):
        return finish(last_offline)
    return finish(
        LivePrecheckOutcome(
            "UNKNOWN",
            last_checker,
            "CHECKER_PROXY_FAILED",
            "; ".join(proxy_errors) or "all bounded checker proxy paths failed",
        )
    )


def _run_worker_job_impl(
    *,
    config: dict[str, Any],
    cycle_id: str,
    serial: str,
    live_url: str,
    action_choice: str,
    exclusions: ExclusionList,
    proxy_tiktok_proof_file: Path | None = None,
    proxy_manager: ProxyManager | None = None,
) -> WorkerJobOutcome:
    started = time.monotonic()
    if STOP_EVENT.is_set():
        return WorkerJobOutcome(serial, 130, "cancelled")
    if exclusions.contains(live_url):
        cleanup_errors: tuple[str, ...] = ()
        release_device = getattr(proxy_manager, "release_device", None)
        if callable(release_device):
            try:
                cleanup_errors = tuple(str(item) for item in release_device(serial))
            except Exception as exc:
                cleanup_errors = (
                    f"proxy release failed: {type(exc).__name__}: {exc}",
                )
        return WorkerJobOutcome(
            serial=serial,
            code=0,
            status="excluded",
            error_code="TARGET_EXCLUDED",
            stage="EXCLUSION_CHECK",
            reason="target was added to excluded_lists.txt before worker start",
            cleanup_errors=cleanup_errors,
        )

    temp_root = (
        RUNTIME_ROOT
        / cycle_id
        / "job_logs"
        / filesystem_safe(username_from_url(live_url))
        / filesystem_safe(serial)
    )
    timeout_seconds = float(config.get("worker_job_timeout_seconds", 180))
    worker_deadline = time.monotonic() + timeout_seconds
    worker_config = build_worker_config(
        config=config,
        serial=serial,
        live_url=live_url,
        action_choice=action_choice,
        cycle_id=cycle_id,
        temp_job_root=temp_root,
        proxy_tiktok_proof_file=proxy_tiktok_proof_file,
        parent_managed_cleanup=True,
        worker_deadline_monotonic=worker_deadline,
    )
    project_dir = Path(ACTIONS[action_choice]["project_dir"])
    script = project_dir / "tiktok_live_selector_workflow.py"
    code, console, cancelled, timed_out = run_process_quiet(
        [sys.executable, str(script), "--config", str(worker_config)],
        cwd=project_dir,
        timeout_seconds=timeout_seconds,
        detailed_logging=bool(config.get("detailed_logging", False)),
    )
    result, _result_path = find_latest_json(temp_root, "result.json")
    metadata, _metadata_path = find_latest_json(temp_root, "device_metadata.json")
    journal, _journal_path = find_latest_json(temp_root, "submission_state.json")
    DEVICE_CACHE.update(serial, metadata)
    hold_seconds = wait_for_incomplete_submission_hold(journal)
    submission_fields = submission_outcome_fields(result, journal)
    if hold_seconds > 0:
        submission_fields.update(
            {
                "submission_completed": False,
                "submission_state": "UNCONFIRMED",
                "settlement_completed": True,
            }
        )
    duration = time.monotonic() - started

    if cancelled and submission_fields["submit_attempted"]:
        outcome = WorkerJobOutcome(
            serial=serial,
            code=1,
            status="unconfirmed",
            error_code="SUBMIT_WORKER_INTERRUPTED",
            stage=str(result.get("stage", "CANCELLED_AFTER_SUBMIT")),
            reason="worker was cancelled after Submit; fallback hold completed before cleanup",
            duration_seconds=duration,
            **submission_fields,
        )
    elif cancelled:
        outcome = WorkerJobOutcome(serial, 130, "cancelled", duration_seconds=duration)
    elif timed_out and str(result.get("status", "")).strip().casefold() == "live_ended":
        raw_timings = result.get("timings", {})
        timings = {
            str(key): float(value)
            for key, value in raw_timings.items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        } if isinstance(raw_timings, dict) else {}
        outcome = WorkerJobOutcome(
            serial=serial,
            code=0,
            status="live_ended",
            error_code="LIVE_ENDED_DURING_WORKFLOW",
            stage=str(result.get("stage", "")),
            reason=str(result.get("reason", "TikTok LIVE ended during workflow")),
            submission_completed=False,
            duration_seconds=duration,
            timings=timings,
        )
    elif timed_out and settled_submission_confirmed(submission_fields):
        raw_timings = result.get("timings", {})
        timings = {
            str(key): float(value)
            for key, value in raw_timings.items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        } if isinstance(raw_timings, dict) else {}
        outcome = WorkerJobOutcome(
            serial=serial,
            code=0,
            status="success",
            stage=str(result.get("stage", "WORKFLOW_COMPLETE")),
            reason="Submit acknowledgement was persisted before cleanup watchdog termination",
            duration_seconds=duration,
            timings=timings,
            **submission_fields,
        )
    elif timed_out and submission_fields["submit_attempted"]:
        outcome = WorkerJobOutcome(
            serial=serial,
            code=1,
            status="unconfirmed",
            error_code="SUBMIT_WORKER_INTERRUPTED",
            stage=str(result.get("stage", "HARD_DEADLINE")),
            reason="worker ended after Submit; fallback hold completed before cleanup",
            duration_seconds=duration,
            **submission_fields,
        )
    elif timed_out:
        outcome = WorkerJobOutcome(
            serial=serial,
            code=1,
            status="failed",
            error_code="WORKER_JOB_TIMEOUT",
            stage=str(result.get("stage", "HARD_DEADLINE")),
            reason=f"worker exceeded {timeout_seconds:g}s",
            duration_seconds=duration,
        )
    else:
        status = str(result.get("status", "failed")).strip().casefold() or "failed"
        if submission_fields["submit_attempted"] and not settled_submission_confirmed(
            submission_fields
        ):
            status = "unconfirmed"
            result = dict(result)
            result.setdefault("error_code", "SUBMIT_WORKER_INTERRUPTED")
            result.setdefault(
                "reason", "worker ended after Submit without confirmed settlement"
            )
        if status == "success" and not settled_submission_confirmed(submission_fields):
            status = "unconfirmed" if submission_fields["submit_attempted"] else "failed"
            result = dict(result)
            result["error_code"] = (
                "SUBMIT_UNCONFIRMED"
                if submission_fields["submit_attempted"]
                else "SUCCESS_WITHOUT_SUBMIT_ACK"
            )
            result["error"] = "worker returned success without confirmed settlement"
            code = 1
        raw_timings = result.get("timings", {})
        timings = {
            str(key): float(value)
            for key, value in raw_timings.items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        } if isinstance(raw_timings, dict) else {}
        outcome = WorkerJobOutcome(
            serial=serial,
            code=code,
            status=status,
            error_code=str(result.get("error_code", "")).strip().upper(),
            stage=str(result.get("stage", "")),
            reason=str(result.get("reason") or result.get("error") or ""),
            duration_seconds=duration,
            timings=timings,
            **submission_fields,
        )

    cleanup_errors: list[str] = []
    release_device = getattr(proxy_manager, "release_device", None)
    if callable(release_device):
        try:
            cleanup_errors.extend(str(item) for item in release_device(serial))
        except Exception as exc:
            cleanup_errors.append(f"proxy release failed: {type(exc).__name__}: {exc}")
    safe_print(f"[{serial}] APP_CLOSE_STARTED")
    force_stop_tiktok_after_forced_child_exit(
        config=config,
        serial=serial,
        action_choice=action_choice,
        metadata=metadata,
    )
    safe_print(f"[{serial}] APP_CLOSE_FINISHED")
    if cancelled or timed_out:
        cleanup_uiautomator_after_forced_child_exit(config=config, serial=serial)
    if cleanup_errors:
        outcome = replace(outcome, cleanup_errors=tuple(cleanup_errors))

    if outcome.status != "cancelled":
        write_minimal_result(
            config=config,
            cycle_id=cycle_id,
            live_url=live_url,
            serial=serial,
            action_choice=action_choice,
            outcome=outcome,
        )

    if bool(config.get("diagnostics_enabled", False)) and outcome.status in {
        "failed", "unconfirmed"
    }:
        diagnostic_target = (
            resolve_config_path(config, "failed_logs_root", "failed_logs")
            / cycle_id
            / f"@{filesystem_safe(username_from_url(live_url))}"
            / filesystem_safe(serial)
            / "diagnostics"
        )
        if temp_root.exists():
            if diagnostic_target.exists():
                shutil.rmtree(diagnostic_target, ignore_errors=True)
            diagnostic_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(temp_root), str(diagnostic_target))
        if console:
            atomic_write_text(diagnostic_target / "console.log", "\n".join(console) + "\n")
    else:
        shutil.rmtree(temp_root, ignore_errors=True)
    try:
        worker_config.unlink()
    except OSError:
        pass

    username = username_from_url(live_url)
    stage_times = outcome.timings
    report_seconds = sum(
        stage_times.get(stage, 0.0)
        for stage in ("REPORT_MENU", "REPORT_REASON", "REPORT_SUBREASON")
    )
    timing_suffix = (
        f" | connect={stage_times.get('CONNECT_ADB', 0.0):.1f}s"
        f" search={sum(stage_times.get(stage, 0.0) for stage in ('SEARCH_LAUNCH', 'SEARCH_OPEN', 'SEARCH_QUERY', 'SEARCH_USERS_TAB', 'SEARCH_RESULTS', 'SEARCH_AVATAR')):.1f}s"
        f" identity={stage_times.get('IDENTITY_VERIFICATION', 0.0):.1f}s"
        f" report={report_seconds:.1f}s"
        f" submit={stage_times.get('SUBMIT', 0.0):.1f}s"
        f" settle={stage_times.get('SUBMIT_SETTLEMENT', 0.0):.1f}s"
    ) if stage_times else ""
    if outcome.status == "success":
        if not bool(config.get("compact_console_logging", True)):
            safe_print(f"[{serial}] SUCCESS @{username} {duration:.1f}s{timing_suffix}")
    elif outcome.status == "cancelled":
        safe_print(f"[{serial}] CANCELLED @{username} {duration:.1f}s")
    elif outcome.status == "excluded":
        safe_print(f"[{serial}] EXCLUDED @{username}")
    elif outcome.status == "live_ended":
        safe_print(f"[{serial}] LIVE_ENDED @{username} {duration:.1f}s{timing_suffix}")
    elif outcome.status == "unconfirmed":
        safe_print(f"[{serial}] UNCONFIRMED @{username} {duration:.1f}s{timing_suffix}")
    else:
        label = outcome.error_code or outcome.stage or "FAILED"
        safe_print(f"[{serial}] FAILED {label} {duration:.1f}s{timing_suffix}")
    return outcome


def run_worker_job(
    *,
    config: dict[str, Any],
    cycle_id: str,
    serial: str,
    live_url: str,
    action_choice: str,
    exclusions: ExclusionList,
    proxy_tiktok_proof_file: Path | None = None,
    proxy_manager: ProxyManager | None = None,
) -> WorkerJobOutcome:
    """Track report cleanup so shutdown waits for post-Submit holds and teardown."""
    register_report_job()
    try:
        return _run_worker_job_impl(
            config=config,
            cycle_id=cycle_id,
            serial=serial,
            live_url=live_url,
            action_choice=action_choice,
            exclusions=exclusions,
            proxy_tiktok_proof_file=proxy_tiktok_proof_file,
            proxy_manager=proxy_manager,
        )
    finally:
        unregister_report_job()


@dataclass
class WorkerBatchOutcome:
    successes: int = 0
    unconfirmed: int = 0
    live_ended_during_workflow: int = 0
    failures: int = 0
    timeouts: int = 0
    offline: int = 0
    proxy_failed: int = 0
    device_setup_failed: int = 0
    excluded: int = 0
    interrupted: bool = False
    live_ended: bool = False
    live_ended_outcome: WorkerJobOutcome | None = None
    started_serials: list[str] = field(default_factory=list)
    # suppressed_serials is reserved for devices not started because the LIVE
    # was globally confirmed ended. User interruption is tracked separately.
    suppressed_serials: list[str] = field(default_factory=list)
    not_started_interrupted_serials: list[str] = field(default_factory=list)
    worker_outcomes: list[WorkerJobOutcome] = field(default_factory=list)


def record_runner_worker_exception(
    config: dict[str, Any], cycle_id: str, serial: str, exc: Exception
) -> None:
    target = resolve_config_path(config, "failed_logs_root", "failed_logs") / cycle_id
    target.mkdir(parents=True, exist_ok=True)
    path = target / f"ORCHESTRATOR_{filesystem_safe(serial)}.txt"
    atomic_write_text(path, f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}")
    safe_print(f"[{serial}] FAILED ORCHESTRATOR_WORKER_EXCEPTION")


def run_streaming_device_pipeline(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    serials: list[str],
    proxy_manager: ProxyManager,
    exclusions: ExclusionList,
    action_choice: str,
) -> tuple[WorkerBatchOutcome, dict[str, float]]:
    """Stream proxy-ready devices directly into the bounded report executor."""
    outcome = WorkerBatchOutcome()
    unique_serials = list(dict.fromkeys(serials))
    reporting_limit = min(max(1, int(config.get("max_parallel", 16))), len(unique_serials))
    timings = {"proxy_ready": 0.0, "proxy_total": 0.0, "reporting": 0.0}
    if not unique_serials:
        return outcome, timings

    pipeline_started = time.monotonic()
    first_ready_epoch = 0.0
    first_report_epoch = 0.0
    futures: dict[concurrent.futures.Future[WorkerJobOutcome], str] = {}
    halted = False
    halt_reason = ""
    completed_count = 0
    progress_every = max(1, int(config.get("progress_log_every_devices", 10)))

    def consume(completed: Iterable[concurrent.futures.Future[WorkerJobOutcome]]) -> None:
        nonlocal halted, halt_reason, completed_count
        for future in completed:
            serial = futures.pop(future)
            try:
                worker = future.result()
            except Exception as exc:
                outcome.failures += 1
                completed_count += 1
                record_runner_worker_exception(config, cycle_id, serial, exc)
                release_proxy_device_safely(
                    proxy_manager, serial, context="worker_exception_cleanup"
                )
                continue
            outcome.worker_outcomes.append(worker)
            completed_count += 1
            if worker.status == "success" and worker.submission_completed:
                outcome.successes += 1
            elif worker.status == "unconfirmed":
                outcome.unconfirmed += 1
            elif worker.status == "live_ended":
                # Legitimate external outcome for this phone only. The initial
                # precheck remains the only batch-level LIVE authority.
                outcome.live_ended_during_workflow += 1
            elif worker.status == "cancelled":
                outcome.interrupted = True
            elif worker.status == "excluded":
                outcome.excluded += 1
                halted = True
                halt_reason = "excluded"
            else:
                outcome.failures += 1
                if worker.error_code == "WORKER_JOB_TIMEOUT":
                    outcome.timeouts += 1
                if worker.error_code.startswith(("ADB_", "UIAUTOMATOR_")):
                    outcome.offline += 1
            if (
                bool(config.get("compact_console_logging", True))
                and completed_count % progress_every == 0
            ):
                safe_print(
                    f"[PROGRESS] completed={completed_count}/{len(unique_serials)} | "
                    f"success={outcome.successes} | unconfirmed={outcome.unconfirmed} | "
                    f"failed={outcome.failures} | "
                    f"live_ended={outcome.live_ended_during_workflow}"
                )

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=reporting_limit, thread_name_prefix="report-worker"
    ) as executor:
        for serial, ready, _redacted_proxy, _error in proxy_manager.prepare_stream(
            unique_serials, f"{cycle_id} @{username_from_url(live_url)}"
        ):
            done_now = [future for future in futures if future.done()]
            consume(done_now)
            if STOP_EVENT.is_set():
                halted = True
                halt_reason = "interrupted"
                outcome.interrupted = True
            if not ready:
                outcome.failures += 1
                if str(_error).startswith("device/ADB preparation failure:"):
                    outcome.device_setup_failed += 1
                    safe_print(f"[{serial}] FAILED DEVICE_ADB_PROXY_SETUP")
                else:
                    outcome.proxy_failed += 1
                continue
            if not first_ready_epoch:
                first_ready_epoch = time.monotonic()
                timings["proxy_ready"] = first_ready_epoch - pipeline_started
            if halted:
                release_proxy_device_safely(
                    proxy_manager, serial, context="not_started_cleanup"
                )
                if halt_reason == "interrupted":
                    outcome.not_started_interrupted_serials.append(serial)
                continue
            if exclusions.contains(live_url):
                halted = True
                halt_reason = "excluded"
                outcome.excluded += 1
                release_proxy_device_safely(
                    proxy_manager, serial, context="excluded_cleanup"
                )
                continue

            while len(futures) >= reporting_limit and not halted:
                completed, _ = concurrent.futures.wait(
                    futures, return_when=concurrent.futures.FIRST_COMPLETED
                )
                consume(completed)
            if halted:
                release_proxy_device_safely(
                    proxy_manager, serial, context="not_started_cleanup"
                )
                if halt_reason == "interrupted":
                    outcome.not_started_interrupted_serials.append(serial)
                continue
            if exclusions.contains(live_url):
                halted = True
                halt_reason = "excluded"
                outcome.excluded += 1
                release_proxy_device_safely(
                    proxy_manager, serial, context="excluded_cleanup"
                )
                continue
            if not first_report_epoch:
                first_report_epoch = time.monotonic()
            proof_required = bool(
                config.get("proxy_enabled", False)
                and config.get("proxy_verify_tiktok_traffic", False)
            )
            proof_path = (
                RUNTIME_ROOT
                / cycle_id
                / "proxy_proofs"
                / filesystem_safe(username_from_url(live_url))
                / f"{filesystem_safe(serial)}.json"
            ) if proof_required else None
            if proof_path is not None:
                arm_proof = getattr(proxy_manager, "arm_tiktok_proof", None)
                if callable(arm_proof):
                    arm_proof(serial, proof_path)
                else:
                    # A real proxy manager always exposes the proof gate.
                    # Test/dummy managers without it simply do not enable the gate.
                    proof_path = None
            outcome.started_serials.append(serial)
            try:
                future = executor.submit(
                    run_worker_job,
                    config=config,
                    cycle_id=cycle_id,
                    serial=serial,
                    live_url=live_url,
                    action_choice=action_choice,
                    exclusions=exclusions,
                    proxy_tiktok_proof_file=proof_path,
                    proxy_manager=proxy_manager,
                )
            except Exception:
                release_proxy_device_safely(
                    proxy_manager, serial, context="worker_submit_cleanup"
                )
                raise
            futures[future] = serial

        timings["proxy_total"] = time.monotonic() - pipeline_started
        while futures:
            completed, _ = concurrent.futures.wait(
                futures, return_when=concurrent.futures.FIRST_COMPLETED
            )
            consume(completed)
            if STOP_EVENT.is_set():
                outcome.interrupted = True
        if first_report_epoch:
            timings["reporting"] = time.monotonic() - first_report_epoch

    return outcome, timings


def write_precheck_summary(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    precheck: LivePrecheckOutcome,
) -> Path:
    directory = resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
    directory.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "live_url": live_url,
        "username": username_from_url(live_url),
        "live_status": precheck.status,
        "checker_device": precheck.serial,
        "error_code": precheck.error_code,
        "reason": precheck.reason,
        "duration_seconds": round(precheck.duration_seconds, 3),
        "proxy_seconds": round(precheck.proxy_seconds, 3),
        "workflow_seconds": round(precheck.workflow_seconds, 3),
        "decision_rule": "any_live",
        "attempts": checker_attempt_payload(precheck.attempts),
    }
    path = directory / "LIVE_PRECHECK.json"
    atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    return path


def write_discovery_summary(
    *,
    config: dict[str, Any],
    cycle_id: str,
    search_query: str,
    discovery: LiveDiscoveryOutcome,
) -> Path:
    directory = resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
    directory.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "search_query": search_query,
        "status": discovery.status,
        "username": discovery.username,
        "live_url": discovery.live_url,
        "checker_device": discovery.serial,
        "error_code": discovery.error_code,
        "reason": discovery.reason,
        "duration_seconds": round(discovery.duration_seconds, 3),
        "proxy_seconds": round(discovery.proxy_seconds, 3),
        "workflow_seconds": round(discovery.workflow_seconds, 3),
        "decision_rule": "first_found",
        "attempts": checker_attempt_payload(discovery.attempts),
    }
    path = directory / "LIVE_DISCOVERY.json"
    atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    return path


def log_live_precheck(live_url: str, precheck: LivePrecheckOutcome) -> None:
    fields = [f"[CHECK] @{username_from_url(live_url)}", precheck.status]
    if precheck.error_code and precheck.status == "UNKNOWN":
        fields.append(precheck.error_code)
    if precheck.serial:
        fields.append(f"checker={precheck.serial}")
    if precheck.attempts:
        statuses = [attempt.status for attempt in precheck.attempts]
        fields.append(
            "attempted={attempted} live={live} offline={offline} unknown={unknown}".format(
                attempted=len(statuses),
                live=sum(status == "LIVE" for status in statuses),
                offline=sum(status == "OFFLINE" for status in statuses),
                unknown=sum(status == "UNKNOWN" for status in statuses),
            )
        )
    if precheck.error_code == "LIVE_PRECHECK_TIMEOUT":
        stage_match = re.search(r"\bstage=([A-Z][A-Z0-9_]*)", precheck.reason)
        fields.append(f"stage={stage_match.group(1) if stage_match else 'UNKNOWN'}")
        fields.append(f"elapsed={precheck.duration_seconds:.1f}s")
    else:
        fields.append(f"{precheck.duration_seconds:.1f}s")
    safe_print(" | ".join(fields))


def write_batch_summary(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    precheck: LivePrecheckOutcome,
    action_device_refresh: float,
    pipeline_timings: dict[str, float],
    total: float,
    candidates: int,
    batch: WorkerBatchOutcome,
) -> Path:
    directory = resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
    directory.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "live_url": live_url,
        "username": username_from_url(live_url),
        "timings": {
            "live_precheck": round(precheck.duration_seconds, 3),
            "precheck_proxy": round(precheck.proxy_seconds, 3),
            "precheck_workflow": round(precheck.workflow_seconds, 3),
            "action_device_refresh": round(action_device_refresh, 3),
            **{key: round(value, 3) for key, value in pipeline_timings.items()},
            "total": round(total, 3),
        },
        "devices": {
            "candidates": candidates,
            "started": len(batch.started_serials),
            "success": batch.successes,
            "unconfirmed": batch.unconfirmed,
            "live_ended_during_workflow": batch.live_ended_during_workflow,
            "failed": batch.failures,
            "timeout": batch.timeouts,
            "offline": batch.offline,
            "proxy_failed": batch.proxy_failed,
            "device_setup_failed": batch.device_setup_failed,
            "excluded": batch.excluded,
            "suppressed": len(batch.suppressed_serials),
            "suppressed_live_ended": len(batch.suppressed_serials),
            "not_started_interrupted": len(batch.not_started_interrupted_serials),
        },
        "live_ended": batch.live_ended,
        "interrupted": batch.interrupted,
    }
    path = directory / "BATCH_SUMMARY.json"
    atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False) + "\n")

    t = payload["timings"]
    d = payload["devices"]
    safe_print("")
    safe_print(f"LIVE @{payload['username']}")
    safe_print(f"live_precheck:   {t['live_precheck']:6.1f}s")
    safe_print(f"device_refresh:  {t['action_device_refresh']:6.1f}s")
    safe_print(f"proxy_ready:     {t['proxy_ready']:6.1f}s")
    safe_print(f"proxy_total:     {t['proxy_total']:6.1f}s")
    safe_print(f"reporting:       {t['reporting']:6.1f}s")
    safe_print(f"total:           {t['total']:6.1f}s")
    safe_print("")
    safe_print("devices:")
    safe_print(f"success: {d['success']}")
    safe_print(f"unconfirmed: {d['unconfirmed']}")
    safe_print(f"live_ended_during_workflow: {d['live_ended_during_workflow']}")
    safe_print(f"failed: {d['failed']}")
    safe_print(f"timeout: {d['timeout']}")
    safe_print(f"offline: {d['offline']}")
    safe_print(f"proxy_failed: {d['proxy_failed']}")
    safe_print(f"device_setup_failed: {d['device_setup_failed']}")
    safe_print(f"suppressed_live_ended: {d['suppressed_live_ended']}")
    safe_print(f"not_started_interrupted: {d['not_started_interrupted']}")
    return path


def process_watchlist_target(
    *,
    config: dict[str, Any],
    cycle_id: str,
    live_url: str,
    watchlist: LiveWatchlist,
    exclusions: ExclusionList,
    proxy_manager: ProxyManager,
    maintenance: RuntimeMaintenance,
    action_choice: str,
    adb_supervisor: AdbHostSupervisor | None = None,
    preconfirmed_live: LivePrecheckOutcome | None = None,
    require_watchlist_membership: bool = True,
) -> str:
    """Check one persistent target, launching the farm only after LIVE."""
    username = username_from_url(live_url)
    if exclusions.contains(live_url):
        safe_print(f"[SKIP] @{username} | excluded")
        return "EXCLUDED"

    target_started = time.monotonic()
    checker_candidates: list[str] = []
    action_serials: list[str] = []
    precheck = LivePrecheckOutcome("UNKNOWN")
    cycle_directory = (
        resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
    )
    try:
        if preconfirmed_live is not None:
            precheck = preconfirmed_live
            checker_candidates = [precheck.serial] if precheck.serial else []
        else:
            try:
                checker_candidates = _connected_devices_for_work(
                    config, adb_supervisor, force=False
                )
            except AdbHostUnavailable:
                return "CANCELLED"
            else:
                precheck = run_global_live_precheck(
                    config=config,
                    cycle_id=cycle_id,
                    live_url=live_url,
                    serials=checker_candidates,
                    proxy_manager=proxy_manager,
                    exclusions=exclusions,
                    action_choice=action_choice,
                )

        write_precheck_summary(
            config=config,
            cycle_id=cycle_id,
            live_url=live_url,
            precheck=precheck,
        )
        log_live_precheck(live_url, precheck)

        if precheck.cancelled or STOP_EVENT.is_set():
            return "CANCELLED"
        if precheck.error_code == "TARGET_EXCLUDED" or exclusions.contains(live_url):
            safe_print(f"[SKIP] @{username} | excluded")
            return "EXCLUDED"
        if precheck.status == "OFFLINE":
            safe_print(f"[SKIP] @{username} | offline")
            return "OFFLINE"
        if precheck.error_code == "INTERNAL_PROGRAM_ERROR":
            safe_print(
                f"[FATAL] @{username} | INTERNAL_PROGRAM_ERROR | stopping monitor to avoid repeating the same broken code path"
            )
            STOP_EVENT.set()
            return "INTERNAL_PROGRAM_ERROR"
        if precheck.status != "LIVE":
            safe_print(f"[SKIP] @{username} | live status unknown")
            return "UNKNOWN"

        # The user's removal and exclusion files remain authoritative even if
        # they change during the precheck.
        if require_watchlist_membership and not watchlist.contains(live_url):
            safe_print(f"[SKIP] @{username} | removed from watchlist by user")
            return "REMOVED"
        if exclusions.contains(live_url):
            safe_print(f"[SKIP] @{username} | excluded")
            return "EXCLUDED"

        safe_print(f"[RUN] @{username} | LIVE confirmed | starting device workflow")
        action_refresh_started = time.monotonic()
        try:
            action_serials = _connected_devices_for_work(
                config, adb_supervisor, force=True
            )
        except AdbHostUnavailable:
            return "CANCELLED"
        action_device_refresh = time.monotonic() - action_refresh_started

        batch, pipeline_timings = run_streaming_device_pipeline(
            config=config,
            cycle_id=cycle_id,
            live_url=live_url,
            serials=action_serials,
            proxy_manager=proxy_manager,
            exclusions=exclusions,
            action_choice=action_choice,
        )
        write_batch_summary(
            config=config,
            cycle_id=cycle_id,
            live_url=live_url,
            precheck=precheck,
            action_device_refresh=action_device_refresh,
            pipeline_timings=pipeline_timings,
            total=(time.monotonic() - target_started)
            + (precheck.duration_seconds if preconfirmed_live is not None else 0.0),
            candidates=len(action_serials),
            batch=batch,
        )
        proxy_manager.verify_workflow_traffic(batch.started_serials)
        return "LIVE"
    finally:
        proxy_manager.write_health_log(cycle_directory, finalize_cycle=True)
        proxy_manager.prune_inactive_relays(action_serials or checker_candidates)
        maintenance.run_if_due()
        shutil.rmtree(RUNTIME_ROOT / cycle_id, ignore_errors=True)


def process_single_live_discovery(
    *,
    config: dict[str, Any],
    cycle_id: str,
    search_query: str,
    watchlist: LiveWatchlist,
    exclusions: ExclusionList,
    proxy_manager: ProxyManager,
    maintenance: RuntimeMaintenance,
    action_choice: str,
    adb_supervisor: AdbHostSupervisor | None = None,
) -> str:
    """Discover one top keyword LIVE and run the unchanged worker workflow on it."""
    safe_print(
        f"[DISCOVERY] exactly 1 watchlist LIVE | searching TikTok for {search_query!r}"
    )
    serials: list[str] = []
    delegated_to_target = False
    cycle_directory = (
        resolve_config_path(config, "cycle_logs_root", "cycle_logs") / cycle_id
    )
    try:
        try:
            serials = _connected_devices_for_work(
                config, adb_supervisor, force=False
            )
        except AdbHostUnavailable:
            return "CANCELLED"

        discovery = run_global_live_discovery(
            config=config,
            cycle_id=cycle_id,
            search_query=search_query,
            serials=serials,
            proxy_manager=proxy_manager,
            action_choice=action_choice,
        )
        write_discovery_summary(
            config=config,
            cycle_id=cycle_id,
            search_query=search_query,
            discovery=discovery,
        )
        if discovery.cancelled or STOP_EVENT.is_set():
            return "CANCELLED"
        if discovery.status == "NONE":
            safe_print(f"[DISCOVERY] no LIVE user found for {search_query!r}")
            return "NONE"
        if discovery.status != "FOUND" or not discovery.live_url:
            safe_print(
                f"[DISCOVERY] failed | {discovery.error_code or 'UNKNOWN'} | {discovery.reason or 'no result'}"
            )
            return "UNKNOWN"
        if exclusions.contains(discovery.live_url):
            safe_print(f"[DISCOVERY] @{discovery.username} | excluded")
            return "EXCLUDED"

        safe_print(
            f"[DISCOVERY] found top LIVE @{discovery.username} | starting existing workflow"
        )
        preconfirmed = LivePrecheckOutcome(
            status="LIVE",
            serial=discovery.serial,
            reason=f"keyword discovery confirmed LIVE for query={search_query!r}",
            duration_seconds=discovery.duration_seconds,
            proxy_seconds=discovery.proxy_seconds,
            workflow_seconds=discovery.workflow_seconds,
        )
        delegated_to_target = True
        return process_watchlist_target(
            config=config,
            cycle_id=cycle_id,
            live_url=discovery.live_url,
            watchlist=watchlist,
            exclusions=exclusions,
            proxy_manager=proxy_manager,
            maintenance=maintenance,
            action_choice=action_choice,
            adb_supervisor=adb_supervisor,
            preconfirmed_live=preconfirmed,
            require_watchlist_membership=False,
        )
    finally:
        if not delegated_to_target:
            proxy_manager.write_health_log(cycle_directory, finalize_cycle=True)
            proxy_manager.prune_inactive_relays(serials)
            maintenance.run_if_due()
            shutil.rmtree(RUNTIME_ROOT / cycle_id, ignore_errors=True)


def run_watchlist_round(
    *,
    config: dict[str, Any],
    round_number: int,
    sequence_start: int,
    snapshot: WatchlistSnapshot,
    watchlist: LiveWatchlist,
    exclusions: ExclusionList,
    proxy_manager: ProxyManager,
    maintenance: RuntimeMaintenance,
    action_choice: str,
    adb_supervisor: AdbHostSupervisor | None = None,
) -> tuple[int, int]:
    """Process one immutable round snapshot in file order."""
    safe_print(
        f"[WATCHLIST] round={round_number} | usernames={len(snapshot.targets)}"
        f" | invalid_ignored={snapshot.invalid_count}"
        f" | duplicates_ignored={snapshot.duplicate_count}"
    )
    proxy_round_ready = proxy_manager.begin_round(round_number)
    if proxy_round_ready is False:
        safe_print(
            f"[ROUND] skipped | round={round_number} | reason=PROXY_LIST_RELOAD_FAILED"
        )
        return 0, sequence_start
    visited = 0
    live_count = 0
    sequence = sequence_start
    for live_url in snapshot.targets:
        if STOP_EVENT.is_set():
            break
        # Honor user removals made after the round snapshot was read.
        if not watchlist.contains(live_url):
            continue
        if adb_supervisor is not None:
            try:
                adb_supervisor.get_devices(force=False)
            except AdbHostUnavailable:
                break
        sequence += 1
        visited += 1
        cycle_id = (
            datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            + f"_{sequence:06d}"
        )
        outcome = process_watchlist_target(
            config=config,
            cycle_id=cycle_id,
            live_url=live_url,
            watchlist=watchlist,
            exclusions=exclusions,
            proxy_manager=proxy_manager,
            maintenance=maintenance,
            action_choice=action_choice,
            adb_supervisor=adb_supervisor,
        )
        if outcome == "LIVE":
            live_count += 1

    safe_print(f"[ROUND] completed {visited} usernames | live_count={live_count}")
    if live_count == 1 and not STOP_EVENT.is_set():
        sequence += 1
        discovery_cycle_id = (
            datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            + f"_{sequence:06d}"
        )
        process_single_live_discovery(
            config=config,
            cycle_id=discovery_cycle_id,
            search_query="mobile legend",
            watchlist=watchlist,
            exclusions=exclusions,
            proxy_manager=proxy_manager,
            maintenance=maintenance,
            action_choice=action_choice,
            adb_supervisor=adb_supervisor,
        )
    return visited, sequence


def main() -> int:
    STOP_EVENT.clear()
    with FORCED_CLEANUP_LOCK:
        FORCED_CLEANUP_DONE.clear()
    config = load_runtime_settings(CONFIG_FILE).values
    action_choice = str(config.get("report_action", "3"))
    if action_choice not in ACTIONS:
        raise SystemExit(
            "report_action must be one of: " + ", ".join(sorted(ACTIONS))
        )

    instance_lock = SingleInstanceLock(
        resolve_config_path(config, "instance_lock_file", "state/loop_runner.lock")
    )
    instance_lock.acquire()
    # The instance lock proves no active runner owns the old temporary tree.
    shutil.rmtree(RUNTIME_ROOT, ignore_errors=True)
    exclusions = ExclusionList(
        resolve_config_path(config, "excluded_lists_file", "excluded_lists.txt")
    )
    watchlist = LiveWatchlist(
        resolve_config_path(config, "list_urls_file", "list_urls.txt")
    )
    maintenance = RuntimeMaintenance(config)
    maintenance.run_if_due(force=True)
    proxy_manager: ProxyManager | None = None
    adb_supervisor: AdbHostSupervisor | None = None
    shutdown = ShutdownCoordinator(config)

    try:
        validate_adb_host(config)
        adb_supervisor = AdbHostSupervisor(config)
        proxy_manager = ProxyManager(
            config, BASE_DIR, log=safe_print, stop_event=STOP_EVENT
        )
        shutdown.attach_proxy_manager(proxy_manager)
        start_stop_listener(shutdown)
        safe_print(
            "START | watchlist=list_urls.txt | max_parallel="
            f"{int(config.get('max_parallel', 16))} | proxy_parallel_setup="
            f"{int(config.get('proxy_parallel_setup', 4))} | worker_timeout="
            f"{float(config.get('worker_job_timeout_seconds', 180)):g}s"
        )
        safe_print("Edit list_urls.txt at any time; press ENTER to stop.")

        sequence = 0
        round_number = 0
        while not STOP_EVENT.is_set():
            snapshot, _watchlist_wait = watchlist.wait_for_round(
                float(config.get("watchlist_poll_interval_seconds", 0.5))
            )
            if snapshot is None:
                break
            round_number += 1
            assert proxy_manager is not None
            _visited, sequence = run_watchlist_round(
                config=config,
                round_number=round_number,
                sequence_start=sequence,
                snapshot=snapshot,
                watchlist=watchlist,
                exclusions=exclusions,
                proxy_manager=proxy_manager,
                maintenance=maintenance,
                action_choice=action_choice,
                adb_supervisor=adb_supervisor,
            )
            maintenance.run_if_due()
            if not STOP_EVENT.is_set():
                safe_print("[LOOP] restarting from first username")
    except KeyboardInterrupt:
        shutdown.request("Ctrl+C")
    finally:
        shutdown.finalize()
        maintenance.run_if_due(force=True)
        shutil.rmtree(RUNTIME_ROOT, ignore_errors=True)
        instance_lock.release()

    safe_print("Monitor stopped. No further LIVE checks will start.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
